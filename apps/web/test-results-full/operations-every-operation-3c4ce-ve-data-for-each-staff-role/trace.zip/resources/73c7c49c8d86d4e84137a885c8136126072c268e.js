(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/web/src/shared/LegacyScripts.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LegacyScripts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
const CLIENT = "/legacy/shared/api.js";
function load(src, ordered) {
    return new Promise((resolve)=>{
        const script = document.createElement("script");
        script.src = src;
        script.async = !ordered ? true : false; // ordered scripts execute in insertion order
        script.onload = script.onerror = ()=>resolve();
        document.body.appendChild(script);
    });
}
function LegacyScripts({ scripts }) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LegacyScripts.useEffect": ()=>{
            if (window.__legacyBooted) return; // React Strict Mode runs effects twice in dev
            window.__legacyBooted = true;
            // Scripts listed before api.js (e.g. the rider app's offline store) run before it boots.
            const clientIndex = scripts.indexOf(CLIENT);
            const early = clientIndex > 0 ? scripts.slice(0, clientIndex) : [];
            const rest = scripts.filter({
                "LegacyScripts.useEffect.rest": (s)=>s !== CLIENT && !early.includes(s)
            }["LegacyScripts.useEffect.rest"]);
            // Fetch page scripts while the session is being restored.
            for (const src of rest){
                const link = document.createElement("link");
                link.rel = "preload";
                link.as = "script";
                link.href = src;
                document.head.appendChild(link);
            }
            void ({
                "LegacyScripts.useEffect": async ()=>{
                    for (const src of early)await load(src, true);
                    if (scripts.includes(CLIENT)) {
                        await load(CLIENT, true);
                        await window.DF?.ready;
                    }
                    await Promise.all(rest.map({
                        "LegacyScripts.useEffect": (src)=>load(src, true)
                    }["LegacyScripts.useEffect"]));
                    // A page bridge can keep the page hidden until its own data has loaded.
                    await window.DF?.bridgeReady?.catch({
                        "LegacyScripts.useEffect": ()=>undefined
                    }["LegacyScripts.useEffect"]);
                    document.documentElement.classList.add("legacy-ready");
                }
            })["LegacyScripts.useEffect"]();
        }
    }["LegacyScripts.useEffect"], [
        scripts
    ]);
    return null;
}
_s(LegacyScripts, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = LegacyScripts;
var _c;
__turbopack_context__.k.register(_c, "LegacyScripts");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=apps_web_src_shared_LegacyScripts_tsx_1xje4_1ofuu9v._.js.map