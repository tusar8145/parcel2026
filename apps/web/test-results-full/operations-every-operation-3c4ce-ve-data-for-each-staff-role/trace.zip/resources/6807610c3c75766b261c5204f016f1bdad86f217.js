(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/next/dist/compiled/next-devtools/index.js (raw)", (function(__turbopack_context__, module, exports){

var process = {env:
{"__NEXT_BUNDLER":"Turbopack","__NEXT_BUNDLER_HAS_PERSISTENT_CACHE":true,"TURBOPACK":true,"__NEXT_EXPERIMENTAL_COLD_CACHE_BADGE":false,"__NEXT_ROUTER_BASEPATH":"","__NEXT_CACHE_COMPONENTS":false,"__NEXT_INSTANT_NAV_TOGGLE":false,"__NEXT_REQUEST_INSIGHTS":false,"__NEXT_DISABLE_DEV_OVERLAY_UX":false,"__NEXT_DEV_INDICATOR":true,"__NEXT_DEV_INDICATOR_POSITION":"bottom-left","__NEXT_DIST_DIR":"E:\\delivery-fast\\parcel2026\\apps\\web\\.next\\dev"}
};
(function(){
var __webpack_modules__={"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/devtools-indicator/devtools-indicator.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`[data-nextjs-toast] {
  &[data-hidden='true'] {
    display: none;
  }
}

.dev-tools-indicator-menu {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  background: var(--color-background-100);
  border: 1px solid var(--color-gray-alpha-400);
  background-clip: padding-box;
  box-shadow: var(--shadow-menu);
  border-radius: var(--rounded-xl);
  position: absolute;
  font-family: var(--font-stack-sans);
  z-index: 3;
  overflow: hidden;
  opacity: 0;
  outline: 0;
  min-width: 248px;
  transition: opacity var(--animate-out-duration-ms)
    var(--animate-out-timing-function);

  &[data-rendered='true'] {
    opacity: 1;
    scale: 1;
  }
}

.dev-tools-indicator-inner {
  padding: 6px;
  width: 100%;
}

.dev-tools-indicator-item {
  display: flex;
  align-items: center;
  padding: 8px 6px;
  height: var(--size-36);
  border-radius: 6px;
  text-decoration: none !important;
  user-select: none;
  white-space: nowrap;

  svg {
    width: var(--size-16);
    height: var(--size-16);
  }

  &:focus-visible {
    outline: 0;
  }
}

.dev-tools-indicator-footer {
  background: var(--color-background-200);
  padding: 6px;
  border-top: 1px solid var(--color-gray-400);
  width: 100%;
}

.dev-tools-indicator-item[data-selected='true'] {
  cursor: pointer;
  background-color: var(--color-gray-200);
}

.dev-tools-indicator-label {
  font-size: var(--size-14);
  line-height: var(--size-20);
  color: var(--color-gray-1000);
}

.dev-tools-indicator-value {
  font-size: var(--size-14);
  line-height: var(--size-20);
  color: var(--color-gray-900);
  margin-left: auto;
}

.dev-tools-indicator-issue-counts {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.dev-tools-indicator-issue-count {
  --color-primary: var(--color-gray-800);
  --color-secondary: var(--color-gray-100);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: 8px;
  min-width: var(--size-40);
  height: var(--size-24);
  background: var(--color-background-100);
  border: 1px solid var(--color-gray-alpha-400);
  background-clip: padding-box;
  box-shadow: var(--shadow-small);
  padding: 2px;
  color: var(--color-gray-1000);
  border-radius: 128px;
  font-weight: 500;
  font-size: var(--size-13);
  font-variant-numeric: tabular-nums;

  &[data-has-issues='true'] {
    --color-primary: var(--color-red-800);
    --color-secondary: var(--color-red-100);
  }

  &[data-has-issues='true'][data-variant='insight'] {
    --color-primary: var(--color-amber-800);
    --color-secondary: var(--color-amber-100);
  }

  .dev-tools-indicator-issue-count-indicator {
    width: var(--size-8);
    height: var(--size-8);
    background: var(--color-primary);
    box-shadow: 0 0 0 2px var(--color-secondary);
    border-radius: 50%;
  }
}

.dev-tools-indicator-shortcut {
  display: flex;
  gap: 4px;

  kbd {
    width: var(--size-20);
    height: var(--size-20);
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: var(--rounded-md);
    border: 1px solid var(--color-gray-400);
    font-family: var(--font-stack-sans);
    background: var(--color-background-100);
    color: var(--color-gray-1000);
    text-align: center;
    font-size: var(--size-12);
    line-height: var(--size-16);
  }
}

.dev-tools-grabbing {
  cursor: grabbing;

  > * {
    pointer-events: none;
  }
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/devtools-panel/resize/resize-handle.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`.resize-container {
  position: absolute;
  /* todo: better z index */
  z-index: 10;
  /* todo: is this needed */
  background: transparent;
}

.resize-line {
  position: absolute;
  /* todo smarter z index */
  z-index: -1;
  pointer-events: none;
  /* a normal exit animation curve- at this point the exit animation is */
  /* immediately responsive so we don't need a bespoke curve */
  transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  /* todo: better var? */
  border: 1px solid var(--color-gray-400);
}

/* start really fast because we start super hidden initially behind the panel, otherwise feels like an unintended animation delay */
.resize-container:hover ~ .resize-line {
  transition: transform 0.25s cubic-bezier(0.23, 1, 0.32, 0.9);
}

.resize-container.right,
.resize-container.left {
  top: 0;
  height: 100%;
  width: 22px;
  cursor: ew-resize;
}

/* todo: don't hard code all these values/use vars */

.resize-container.bottom,
.resize-container.top {
  left: 0;
  width: 100%;
  height: 22px;
  cursor: ns-resize;
}

.resize-container.top {
  top: -7px;
}
.resize-container.bottom {
  bottom: -7px;
}
.resize-container.left {
  left: -7px;
}
.resize-container.right {
  right: -7px;
}

.resize-container.top-left,
.resize-container.top-right,
.resize-container.bottom-left,
.resize-container.bottom-right {
  width: 26px;
  height: 26px;
  z-index: 15;
}

.resize-container.top-left {
  top: -5px;
  left: -5px;
  cursor: nwse-resize;
}
.resize-container.top-right {
  top: -5px;
  right: -5px;
  cursor: nesw-resize;
}
.resize-container.bottom-left {
  bottom: -5px;
  left: -5px;
  cursor: nesw-resize;
}
.resize-container.bottom-right {
  bottom: -5px;
  right: -5px;
  cursor: nwse-resize;
}

.resize-line.top,
.resize-line.bottom {
  height: 18px;
  width: 100%;
  background-color: var(--color-background-200);
}

.resize-line.left,
.resize-line.right {
  width: 18px;
  height: 100%;
  background-color: var(--color-background-200);
}

.resize-line.top {
  top: -7px;
  left: calc(-1 * var(--border-left, 2px));
  width: calc(100% + var(--border-horizontal, 4px));
  border-radius: var(--rounded-lg) var(--rounded-lg) 0 0;
  transform: translateY(18px);
}

.resize-line.bottom {
  bottom: -7px;
  left: calc(-1 * var(--border-left, 2px));
  width: calc(100% + var(--border-horizontal, 4px));
  border-radius: 0 0 var(--rounded-lg) var(--rounded-lg);
  transform: translateY(-18px);
}

.resize-line.left {
  top: calc(-1 * var(--border-top, 2px));
  left: -7px;
  height: calc(100% + var(--border-vertical, 4px));
  border-radius: var(--rounded-lg) 0 0 var(--rounded-lg);
  transform: translateX(18px);
}

.resize-line.right {
  top: calc(-1 * var(--border-top, 2px));
  right: -7px;
  height: calc(100% + var(--border-vertical, 4px));
  border-radius: 0 var(--rounded-lg) var(--rounded-lg) 0;
  transform: translateX(-18px);
}

.resize-container.right:hover ~ .resize-line.right,
.resize-container.left:hover ~ .resize-line.left,
.resize-line.right.dragging,
.resize-line.left.dragging {
  transform: translateX(0);
}

.resize-container.bottom:hover ~ .resize-line.bottom,
.resize-container.top:hover ~ .resize-line.top,
.resize-line.bottom.dragging,
.resize-line.top.dragging {
  transform: translateY(0);
}

/* make sure that we don't show multiple handles at once
 * we should only ever show the currently resizing handle
 * regardless of hover state 
 */
.resize-container.no-hover.right:hover ~ .resize-line.right {
  transform: translateX(-20px);
}
.resize-container.no-hover.left:hover ~ .resize-line.left {
  transform: translateX(20px);
}
.resize-container.no-hover.bottom:hover ~ .resize-line.bottom {
  transform: translateY(-20px);
}
.resize-container.no-hover.top:hover ~ .resize-line.top {
  transform: translateY(20px);
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/instant-navs/instant-navs-panel.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`.instant-nav-panel {
  display: flex;
  flex-direction: column;
  height: auto;
}

.instant-nav-content {
  overflow: hidden;
}

.instant-nav-content-container {
  position: relative;
  overflow: hidden;
}

.instant-nav-transition-layer {
  position: absolute;
  inset: 0;
  opacity: var(--instant-nav-layer-opacity, 0);
  pointer-events: none;
  transition: opacity var(--instant-nav-layer-transition-duration, 100ms)
    cubic-bezier(0.25, 0.8, 0.5, 1)
    var(--instant-nav-layer-transition-delay, 0ms);
}

.instant-nav-transition-layer.is-visible {
  z-index: 1;
  pointer-events: auto;
}

.instant-nav-transition-layer--no-enter {
  transition: none;
}

.instant-nav-state--pending {
  display: flex;
  flex-direction: column;
}

.instant-nav-state-details {
  padding: 16px 20px 0;
}

.instant-nav-state-title {
  margin: 0;
  font-size: var(--size-14);
  font-weight: 600;
  line-height: 21px;
  color: var(--color-gray-1000);
  display: flex;
  align-items: center;
  gap: 8px;
}

.instant-nav-state-title-type {
  color: var(--color-gray-900);
  font-size: var(--size-11);
  font-weight: 500;
  background-color: var(--color-gray-100);
  padding: 4px 5px;
  line-height: 1;
  border-radius: 4px;
  margin-left: 2px;
}

.instant-nav-state-description {
  margin-top: 4px;
  font-size: var(--size-14);
  color: var(--color-gray-800);
}

.instant-nav-waiting-status {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  height: 42px;
  padding: 0 20px;
  background: var(--color-blue-100);
  box-sizing: border-box;
}
@media (prefers-color-scheme: dark) {
  :host(:not(.light)) {
    .instant-nav-waiting-status {
      background: var(--color-blue-300);
    }
  }
}

.instant-nav-waiting-status-dot {
  position: relative;
  flex: 0 0 auto;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: #b8cffb;
}
@media (prefers-color-scheme: dark) {
  :host(:not(.light)) {
    .instant-nav-waiting-status-dot {
      background: #25548f;
    }
  }
}

.instant-nav-waiting-status-dot::after {
  content: '';
  position: absolute;
  top: 4px;
  left: 4px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--color-blue-700);
}
@media (prefers-color-scheme: dark) {
  :host(:not(.light)) {
    .instant-nav-waiting-status-dot::after {
      background: #468be2;
    }
  }
}

.instant-nav-waiting-status-title {
  margin: 0;
  color: var(--color-gray-1000);
  font-size: var(--size-13);
  font-weight: 400;
  line-height: 1;
}

.instant-nav-waiting-description {
  margin: 16px 0 0;
  padding: 0 20px;
  color: var(--color-gray-1000);
  font-size: var(--size-14);
  line-height: 21px;
}

.instant-nav-state-url-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 21px;
}

.instant-nav-url-row {
  display: flex;
  flex-direction: column;
  margin-top: 21px;
  min-width: 0;
  font-size: var(--size-14);
  line-height: 21px;
  color: var(--color-gray-1000);
}

.instant-nav-state-url-list .instant-nav-url-row {
  margin-top: 0;
}

.instant-nav-url-label {
  flex: 0 0 auto;
  text-transform: uppercase;
  font-size: var(--size-10);
  color: var(--color-gray-700);
  font-weight: 600;
  letter-spacing: 5%;
  line-height: 12px;
}

.instant-nav-url-value {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  /* font-family: monospace; */
  font-weight: 500;
  font-size: var(--size-12);
  /* line-height: 1; */
}

.instant-nav-debugger-paused {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  height: 42px;
  padding: 0 20px;
  border: 0;
  background: #fef4ab;
  color: var(--color-gray-1000);
  font-size: var(--size-13);
  font-weight: 400;
  line-height: 1;
}
@media (prefers-color-scheme: dark) {
  :host(:not(.light)) {
    .instant-nav-debugger-paused {
      color: #171717;
      background-color: #e7c755;
    }
  }
}

.instant-nav-debugger-paused-button {
  margin-left: auto;
  font-size: var(--size-12);
  font-weight: 500;
  color: var(--color-gray-1000);
  padding: 7px 12px 7px 14px;
  border-radius: 9999px;
  background-color: white;
  border: 1px solid var(--color-gray-alpha-300);
  display: inline-flex;
  gap: 8px;
  align-items: center;
}
@media (prefers-color-scheme: dark) {
  :host(:not(.light)) {
    .instant-nav-debugger-paused-button {
      background-color: #000000;
    }
    .instant-nav-debugger-paused-button:hover {
      background-color: #2e2e2e;
    }
  }
}

.instant-nav-debugger-paused-button:hover {
  background: #fafafa;
}

.instant-nav-debugger-paused-button:focus-visible {
  outline: var(--focus-ring);
  outline-offset: 2px;
}

.instant-nav-debugger-paused-button svg {
  flex: 0 0 auto;
}

.instant-nav-debugger-paused-button span {
  flex: 1;
  text-align: left;
}

.instant-nav-pause-control {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 18px 20px;
  border-top: 1px solid var(--color-gray-400);
  margin-top: -1px;
}

.instant-nav-pause-copy {
  flex: 1;
  min-width: 0;
}

.instant-nav-pause-copy label {
  margin: 0;
  color: var(--color-gray-1000);
  font-size: var(--size-14);
  font-weight: 500;
  line-height: 21px;
}

.instant-nav-pause-copy p {
  margin: 0px;
  color: var(--color-gray-900);
  font-size: var(--size-14);
  line-height: 21px;
}

.instant-nav-pause-toggle {
  position: relative;
  flex: 0 0 auto;
  width: 36px;
  height: 20px;
  padding: 0;
  border: 0;
  border-radius: 9999px;
  background: var(--color-gray-300);
  box-shadow: inset 0 0 0 1px var(--color-gray-alpha-300);
  cursor: pointer;
  transition:
    background-color 150ms var(--timing-swift),
    box-shadow 150ms var(--timing-swift);
}

.instant-nav-pause-toggle[aria-checked='true'] {
  background: var(--color-blue-700);
  box-shadow: inset 0 0 0 1px var(--color-blue-700);
}

.instant-nav-pause-toggle:focus-visible {
  outline: var(--focus-ring);
  outline-offset: 2px;
}

.instant-nav-pause-toggle-thumb {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--color-background-100);
  box-shadow: 0 1px 2px var(--color-gray-alpha-400);
  transition: transform 150ms var(--timing-swift);
}

.instant-nav-pause-toggle[aria-checked='true'] .instant-nav-pause-toggle-thumb {
  transform: translateX(16px);
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/overview/segment-boundary-trigger.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`.segment-boundary-trigger {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 6px;
  line-height: 16px;
  font-weight: 500;
  color: var(--color-gray-1000);
  border-radius: 999px;
  border: none;
  font-size: var(--size-12);
  cursor: pointer;
  transition: background-color 0.15s ease;
}

.segment-boundary-trigger-text {
  font-size: var(--size-12);
  font-weight: 500;
  user-select: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.segment-boundary-trigger-text .plus-icon {
  transition: transform 0.25s ease;
}

.segment-boundary-trigger-text:hover .plus-icon {
  color: var(--color-gray-800);
}

.segment-boundary-trigger svg {
  width: 14px;
  height: 14px;
  flex-shrink: 0;
  vertical-align: middle;
}

.segment-boundary-trigger:hover svg {
  color: var(--color-gray-700);
}

.segment-boundary-trigger[disabled] svg,
.segment-boundary-trigger[disabled]:hover svg {
  color: var(--color-gray-400);
  cursor: not-allowed;
}

.segment-boundary-dropdown {
  padding: 8px;
  background: var(--color-background-100);
  border: 1px solid var(--color-gray-400);
  border-radius: 16px;
  min-width: 120px;
  user-select: none;
  cursor: default;
  box-shadow: 0px 4px 8px -4px
    color-mix(in srgb, var(--color-gray-900) 4%, transparent);
}

.segment-boundary-dropdown-positioner {
  z-index: var(--top-z-index);
}

.segment-boundary-dropdown-item {
  display: flex;
  align-items: center;
  padding: 8px;
  line-height: 20px;
  font-size: 14px;
  border-radius: 6px;
  color: var(--color-gray-1000);
  cursor: pointer;
  min-width: 220px;
  border: none;
  background: none;
  width: 100%;
}

.segment-boundary-dropdown-item[data-disabled] {
  color: var(--color-gray-400);
  cursor: not-allowed;
}

.segment-boundary-dropdown-item svg {
  margin-right: 12px;
  color: currentColor;
}

.segment-boundary-dropdown-item:hover {
  background: var(--color-gray-200);
}

.segment-boundary-dropdown-item:first-child {
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
}

.segment-boundary-dropdown-item:last-child {
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
}

.segment-boundary-group-label {
  padding: 8px;
  font-size: 13px;
  line-height: 16px;
  font-weight: 400;
  color: var(--color-gray-900);
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/overview/segment-explorer.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`.segment-explorer-content {
  font-size: var(--size-14);
  padding: 0 8px;
  width: 100%;
  height: 100%;
}

.segment-explorer-page-route-bar {
  display: flex;
  align-items: center;
  padding: 14px 16px;
  background-color: var(--color-background-200);
  gap: 12px;
}

.segment-explorer-page-route-bar-path {
  font-size: var(--size-14);
  font-weight: 500;
  color: var(--color-gray-1000);
  font-family: var(--font-mono);
  white-space: nowrap;
  line-height: 20px;
}

.segment-explorer-item {
  margin: 4px 0;
  border-radius: 6px;
}

.segment-explorer-item:nth-child(even) {
  background-color: var(--color-background-200);
}
.segment-explorer-item-row {
  display: flex;
  flex-direction: column;
  padding-top: 10px;
  padding-bottom: 10px;
  padding-right: 4px;
}
.segment-explorer-item-row-main {
  display: flex;
  align-items: center;
  white-space: pre;
  color: var(--color-gray-1000);
}

.segment-explorer-children--intended {
  padding-left: 16px;
}

.segment-explorer-filename {
  display: inline-flex;
  width: 100%;
  align-items: center;
}

.segment-explorer-filename select {
  margin-left: auto;
}
.segment-explorer-filename--path {
  margin-right: 8px;
}
.segment-explorer-filename--path small {
  display: inline-block;
  width: 0;
  opacity: 0;
}
.segment-explorer-filename--name {
  color: var(--color-gray-800);
}

.segment-explorer-files {
  display: inline-flex;
  gap: 8px;
  margin-left: auto;
}

.segment-explorer-files + .segment-boundary-trigger {
  margin-left: 8px;
}

.segment-explorer-file-label {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0 6px;
  height: 20px;
  border-radius: 16px;
  line-height: 16px;
  font-size: var(--size-12);
  font-weight: 500;
  background-color: var(--color-gray-300);
  color: var(--color-gray-1000);
  cursor: pointer;
  text-align: center;
}

.segment-explorer-file-label:focus-visible {
  outline: var(--focus-ring);
  outline-offset: 2px;
}
.segment-explorer-file-label-text {
  display: inline-flex;
  align-items: center;
}

.segment-explorer-file-label--overridden {
  background-color: var(--color-amber-300);
  color: var(--color-amber-900);
}

.segment-explorer-file-label .code-icon {
  opacity: 0;
  margin-left: 0;
  width: 0;
  transition: all 0.15s ease-in-out;
}
.segment-explorer-file-label:hover .code-icon {
  opacity: 1;
  width: 12px;
  margin-left: 4px;
}

.segment-explorer-file-label:hover {
  filter: brightness(0.95);
}

.segment-explorer-file-label--builtin {
  background-color: transparent;
  color: var(--color-gray-900);
  border: 1px dashed var(--color-gray-500);
  height: 24px;
}
.segment-explorer-file-label--builtin svg {
  margin-left: 4px;
  margin-right: -4px;
}

/* Footer styles */
.segment-explorer-footer {
  padding: 8px;
  border-top: 1px solid var(--color-gray-400);
  user-select: none;
}

.segment-explorer-footer-button {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  padding: 6px;
  background: var(--color-background-100);
  border: 1px solid var(--color-gray-400);
  border-radius: 6px;
  color: var(--color-gray-1000);
  font-size: var(--size-14);
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.15s ease;
}

.segment-explorer-footer-button:hover:not(:disabled) {
  background: var(--color-gray-200);
}

.segment-explorer-footer-button--disabled {
  cursor: not-allowed;
}

.segment-explorer-footer-text {
  text-align: center;
}

.segment-explorer-footer-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  background: var(--color-amber-300);
  color: var(--color-amber-900);
  border-radius: 10px;
  font-size: var(--size-12);
  font-weight: 600;
  line-height: 1;
}

.segment-explorer-file-label-tooltip--sm {
  white-space: nowrap;
}

.segment-explorer-file-label-tooltip--lg {
  min-width: 200px;
}

.segment-explorer-suggestions {
  display: inline-flex;
  gap: 8px;
}

.segment-explorer-suggestions-tooltip {
  width: 200px;
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/request-insights/request-insights-panel.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`.request-insights-panel {
  display: grid;
  grid-template-columns: minmax(210px, 320px) minmax(420px, 1fr);
  height: 100%;
  min-height: 0;
  color: var(--color-gray-1000);
}

.request-insights-empty {
  padding: 16px 20px;
  color: var(--color-gray-900);
  font-size: var(--size-14);
}

.request-insights-list-empty {
  padding: 16px 20px;
  color: var(--color-gray-900);
  font-size: var(--size-12);
  line-height: 1.5;
}

.request-insights-list {
  border-right: 1px solid var(--color-gray-400);
  overflow: auto;
  min-width: 0;
}

.request-insights-list-toolbar {
  position: sticky;
  top: 0;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 36px;
  padding: 4px 10px;
  border-bottom: 1px solid var(--color-gray-400);
  background: var(--color-background-100);
  font-size: var(--size-12);
}

.request-insights-settings {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.request-insights-settings-dot {
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: 999px;
  background: var(--color-red-800);
}

.request-insights-settings-trigger {
  display: inline-flex;
  width: 24px;
  height: 24px;
  align-items: center;
  justify-content: center;
  border: 0;
  border-radius: 4px;
  background: transparent;
  color: var(--color-gray-900);
  cursor: pointer;
}

.request-insights-settings-trigger:hover,
.request-insights-settings-trigger[aria-expanded='true'] {
  background: var(--color-gray-300);
  color: var(--color-gray-1000);
}

.request-insights-settings-positioner {
  z-index: var(--top-z-index);
}

.request-insights-settings-menu {
  min-width: 160px;
  border: 1px solid var(--color-gray-400);
  border-radius: 8px;
  background: var(--color-background-100);
  box-shadow: 0px 4px 8px -4px
    color-mix(in srgb, var(--color-gray-900) 4%, transparent);
  padding: 4px;
  user-select: none;
}

.request-insights-settings-item {
  display: flex;
  align-items: center;
  gap: 6px;
  border-radius: 6px;
  padding: 6px 8px;
  cursor: pointer;
  font-size: var(--size-12);
  color: var(--color-gray-1000);
}

.request-insights-settings-item[data-highlighted] {
  background: var(--color-gray-200);
}

.request-insights-settings-checkbox {
  display: inline-flex;
  width: 14px;
  height: 14px;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  border: 1px solid var(--color-gray-500);
  border-radius: 4px;
  background: var(--color-background-100);
  color: var(--color-background-100);
}

.request-insights-settings-checkbox[data-checked] {
  border-color: var(--color-gray-1000);
  background: var(--color-gray-1000);
}

.request-insights-row {
  display: grid;
  grid-template-columns: 8px minmax(0, 1fr) auto;
  grid-template-rows: auto auto;
  align-items: center;
  column-gap: 8px;
  row-gap: 2px;
  width: 100%;
  min-height: 44px;
  padding: 7px 10px;
  border: 0;
  border-bottom: 1px solid var(--color-gray-400);
  background: transparent;
  color: inherit;
  cursor: pointer;
  text-align: left;
}

.request-insights-row:hover,
.request-insights-row[data-selected='true'] {
  background: var(--color-gray-100);
}

.request-insights-row[data-selected='true'] {
  box-shadow: inset 2px 0 0 var(--color-blue-800);
}

.request-insights-status {
  grid-row: 1 / span 2;
  width: 7px;
  height: 7px;
  border-radius: 999px;
  background: var(--color-gray-700);
}

.request-insights-status[data-status='ok'] {
  background: var(--color-green-800);
}

.request-insights-status[data-status='error'] {
  background: var(--color-red-800);
}

.request-insights-route {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: var(--size-13);
  font-weight: 500;
}

.request-insights-route-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.request-insights-row[data-internal='true'] .request-insights-route-label {
  color: var(--color-gray-900);
  font-weight: 400;
}

.request-insights-row[data-nested='true'] .request-insights-route {
  padding-left: 18px;
}

.request-insights-nested-arrow {
  flex-shrink: 0;
  color: var(--color-gray-700);
}

.request-insights-internal-badge {
  flex-shrink: 0;
  margin-right: 6px;
  border: 1px solid var(--color-gray-500);
  border-radius: 999px;
  padding: 1px 6px;
  color: var(--color-gray-800);
  font-size: var(--size-10);
  font-weight: 500;
  letter-spacing: 0.02em;
  text-transform: uppercase;
}

.request-insights-page-load {
  flex-shrink: 0;
  border-radius: 999px;
  padding: 1px 5px;
  background: var(--color-blue-100);
  color: var(--color-blue-900);
  font-size: var(--size-10);
  font-weight: 600;
  line-height: 16px;
  white-space: nowrap;
}

.request-insights-item-context {
  min-width: 0;
  overflow: hidden;
  color: var(--color-gray-900);
  font-size: var(--size-11);
  font-weight: 400;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.request-insights-duration,
.request-insights-meta {
  color: var(--color-gray-900);
  font-size: var(--size-12);
  white-space: nowrap;
}

.request-insights-duration {
  justify-self: end;
  color: var(--color-gray-1000);
  font-family: var(--font-mono);
  text-align: right;
}

.request-insights-fetch-summary {
  justify-self: end;
  text-align: right;
}

.request-insights-details {
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  overflow: auto;
}

.request-insights-summary {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--color-gray-400);
}

.request-insights-heading {
  min-width: 0;
}

.request-insights-title-row {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}

.request-insights-title {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: var(--size-15);
  font-weight: 600;
}

.request-insights-copy {
  flex-shrink: 0;
}

.request-insights-total {
  flex-shrink: 0;
  color: var(--color-gray-1000);
  font-family: var(--font-mono);
  font-size: var(--size-13);
}

.request-insights-overview {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding: 8px 16px;
  border-bottom: 1px solid var(--color-gray-400);
}

.request-insights-overview span {
  min-width: 0;
  border: 1px solid var(--color-gray-400);
  border-radius: 4px;
  padding: 2px 6px;
  color: var(--color-gray-900);
  font-size: var(--size-12);
  white-space: nowrap;
}

.request-insights-error {
  padding: 8px 16px;
  border-bottom: 1px solid var(--color-gray-400);
  color: var(--color-red-900);
  font-size: var(--size-13);
}

.request-insights-diagnosis {
  padding: 10px 16px;
  border-bottom: 1px solid var(--color-gray-400);
  color: var(--color-gray-1000);
  font-size: var(--size-13);
}

.request-insights-section {
  padding: 10px 16px;
  border-bottom: 1px solid var(--color-gray-400);
}

.request-insights-section-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 8px;
}

.request-insights-section-title {
  margin-bottom: 8px;
  color: var(--color-gray-900);
  font-size: var(--size-12);
  font-weight: 600;
  text-transform: uppercase;
}

.request-insights-section-heading .request-insights-section-title {
  margin-bottom: 0;
}

.request-insights-section-note {
  color: var(--color-gray-800);
  font-size: var(--size-11);
}

.request-insights-muted {
  color: var(--color-gray-900);
  font-size: var(--size-13);
}

.request-insights-trace-viewport {
  overflow-x: auto;
}

.request-insights-trace {
  min-width: 560px;
}

.request-insights-trace-header,
.request-insights-span-row {
  display: grid;
  grid-template-columns: minmax(180px, 320px) minmax(240px, 1fr) 64px;
  align-items: center;
  gap: 10px;
}

.request-insights-trace-header {
  min-height: 24px;
  border-bottom: 1px solid var(--color-gray-400);
  color: var(--color-gray-800);
  font-size: var(--size-11);
  font-weight: 600;
  text-transform: uppercase;
}

.request-insights-trace-axis {
  position: relative;
  align-self: stretch;
  font-family: var(--font-mono);
  font-weight: 400;
  text-transform: none;
}

.request-insights-trace-tick {
  position: absolute;
  top: 3px;
  transform: translateX(-50%);
  white-space: nowrap;
}

.request-insights-trace-tick::after {
  position: absolute;
  top: 14px;
  left: 50%;
  width: 1px;
  height: 4px;
  background: var(--color-gray-500);
  content: '';
}

.request-insights-trace-tick[data-edge='start'] {
  transform: none;
}

.request-insights-trace-tick[data-edge='start']::after {
  left: 0;
}

.request-insights-trace-tick[data-edge='end'] {
  transform: translateX(-100%);
}

.request-insights-trace-tick[data-edge='end']::after {
  right: 0;
  left: auto;
}

.request-insights-trace-duration-heading {
  text-align: right;
}

.request-insights-trace-rows {
  display: flex;
  flex-direction: column;
}

.request-insights-span-row {
  min-height: 28px;
  border-bottom: 1px solid var(--color-gray-300);
}

.request-insights-span-row:last-child {
  border-bottom: 0;
}

.request-insights-span-name {
  min-width: 0;
  overflow: hidden;
  color: var(--color-gray-900);
  font-size: var(--size-12);
}

.request-insights-span-label {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.request-insights-span-label > span:last-child,
.request-insights-fetch-url > span:first-child {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.request-insights-span-marker {
  width: 6px;
  height: 6px;
  flex: 0 0 auto;
  border-radius: 999px;
  background: var(--color-blue-800);
}

.request-insights-span-marker[data-kind='fetch'] {
  background: var(--color-purple-700);
}

.request-insights-span-row .request-insights-span-marker[data-status='error'] {
  background: var(--color-red-800);
}

.request-insights-fetch-host,
.request-insights-cache-reason {
  min-width: 0;
  overflow: hidden;
  color: var(--color-gray-800);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.request-insights-span-duration {
  color: var(--color-gray-900);
  font-family: var(--font-mono);
  font-size: var(--size-12);
  text-align: right;
  white-space: nowrap;
}

.request-insights-span-track {
  position: relative;
  height: 8px;
  border-radius: 999px;
}

.request-insights-span-bar {
  position: absolute;
  top: 0;
  bottom: 0;
  min-width: 2px;
  border-radius: 999px;
  background: var(--color-blue-800);
}

.request-insights-span-row[data-kind='fetch'] .request-insights-span-bar {
  background: var(--color-purple-700);
}

.request-insights-span-row .request-insights-span-bar[data-status='error'] {
  background: var(--color-red-800);
}

.request-insights-fetch-table {
  display: flex;
  flex-direction: column;
  border-top: 1px solid var(--color-gray-400);
}

.request-insights-fetch {
  display: grid;
  grid-template-columns: 46px minmax(0, 1fr) 58px 42px 58px minmax(92px, 160px);
  gap: 8px;
  min-height: 28px;
  align-items: center;
  border-bottom: 1px solid var(--color-gray-400);
  color: var(--color-gray-900);
  font-family: var(--font-mono);
  font-size: var(--size-12);
}

.request-insights-fetch-header {
  min-height: 24px;
  color: var(--color-gray-800);
  font-family: inherit;
  font-size: var(--size-11);
  font-weight: 600;
  text-transform: uppercase;
}

.request-insights-method {
  color: var(--color-gray-1000);
}

.request-insights-fetch-url {
  display: flex;
  min-width: 0;
  overflow: hidden;
  gap: 8px;
}

@media (max-width: 900px) {
  .request-insights-summary {
    align-items: flex-start;
  }

  .request-insights-title-row {
    flex-wrap: wrap;
  }
}

@media (max-width: 700px) {
  .request-insights-panel {
    grid-template-columns: 1fr;
  }

  .request-insights-list {
    max-height: 180px;
    border-right: 0;
    border-bottom: 1px solid var(--color-gray-400);
  }

  .request-insights-fetch {
    grid-template-columns: 44px minmax(0, 1fr) 56px;
  }

  .request-insights-fetch > span:nth-child(n + 4) {
    display: none;
  }
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/toast/style.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`.nextjs-toast {
  position: fixed;
  z-index: var(--top-z-index);
  max-width: 420px;
  box-shadow: 0px 16px 32px rgba(0, 0, 0, 0.25);
}

.nextjs-toast-errors-parent {
  padding: 16px;
  border-radius: var(--rounded-4xl);
  font-weight: 500;
  color: var(--color-ansi-bright-white);
  background-color: var(--color-ansi-red);
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/tooltip/tooltip.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`.tooltip-wrapper {
  position: relative;
  display: inline-block;
  line-height: 1;
}

.tooltip {
  position: relative;
  padding: 6px 12px;
  border-radius: 8px;
  font-size: 14px;
  line-height: 1.4;
  pointer-events: none;
  color: var(--color-gray-100);
  background-color: var(--color-gray-1000);
}

.tooltip-arrow {
  position: absolute;
  width: 0;
  height: 0;
  border-style: solid;
  border-width: var(--arrow-size, 6px);
  border-color: transparent;
}

.tooltip-arrow--top {
  border-width: var(--arrow-size, 6px) var(--arrow-size, 6px) 0
    var(--arrow-size, 6px);
  border-top-color: var(--color-gray-1000);
  bottom: 0;
  transform: translateY(100%);
}

.tooltip-arrow--bottom {
  border-width: 0 var(--arrow-size, 6px) var(--arrow-size, 6px)
    var(--arrow-size, 6px);
  border-bottom-color: var(--color-gray-1000);
  top: 0;
  transform: translateY(-100%);
}

.tooltip-arrow--left {
  border-width: var(--arrow-size, 6px) 0 var(--arrow-size, 6px)
    var(--arrow-size, 6px);
  border-left-color: var(--color-gray-1000);
  right: 0;
  transform: translateX(100%);
}

.tooltip-arrow--right {
  border-width: var(--arrow-size, 6px) var(--arrow-size, 6px)
    var(--arrow-size, 6px) 0;
  border-right-color: var(--color-gray-1000);
  left: 0;
  transform: translateX(-100%);
}

.tooltip-positioner {
  z-index: var(--top-z-index);
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/global.css"(e,t,r){"use strict";r.d(t,{A:()=>f});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a),s=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/normalize.css"),l=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/default-theme.css"),c=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/dark-theme.css"),u=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/colors.css"),d=i()(o());d.i(s.A),d.i(l.A),d.i(c.A),d.i(u.A),d.push([e.id,`/* devtool global css variables */
:host {
  /* variables */
  --top-z-index: 2147483647;
}

/* global styles */
* {
  -webkit-font-smoothing: antialiased;
}

/* global reset for draggable content scrollbar styles */
[data-nextjs-scrollable-content],
[data-nextjs-scrollable-content] * {
  &::-webkit-scrollbar {
    width: 6px;
    height: 6px;
    border-radius: 0 0 1rem 1rem;
    margin-bottom: 1rem;
  }

  &::-webkit-scrollbar-button {
    display: none;
  }

  &::-webkit-scrollbar-track {
    border-radius: 0 0 1rem 1rem;
    background-color: var(--color-background-100);
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 1rem;
    background-color: var(--color-gray-500);
  }
}

/* Place overflow: hidden on this so we can break out from [data-nextjs-dialog] */
[data-nextjs-scrollable-content] {
  overflow: hidden;
  border-radius: inherit;
}
`,""]);let f=d},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/menu/panel-router.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`/* Panel content padding styles */
.panel-content {
  padding: 16px;
  padding-top: 8px;
  overflow: hidden;
}

/* User preferences wrapper styles */
.user-preferences-wrapper {
  padding: 20px;
  padding-top: 8px;
  overflow: hidden;
}

/* Panel route base styles */
.panel-route {
  opacity: var(--panel-opacity);
  transition: var(--panel-transition);
}

.turbopack-upgrade-link {
  text-decoration: underline;
  font-weight: 500;
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/normalize.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`:host {
  all: initial;

  /* the direction property is not reset by 'all' */
  direction: ltr;
}

/*!
 * Bootstrap Reboot v4.4.1 (https://getbootstrap.com/)
 * Copyright 2011-2019 The Bootstrap Authors
 * Copyright 2011-2019 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * Forked from Normalize.css, licensed MIT (https://github.com/necolas/normalize.css/blob/master/LICENSE.md)
 */
*,
*::before,
*::after {
  box-sizing: border-box;
}

:host {
  font-family: sans-serif;
  line-height: 1.15;
  -webkit-text-size-adjust: 100%;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}

article,
aside,
figcaption,
figure,
footer,
header,
hgroup,
main,
nav,
section {
  display: block;
}

:host {
  margin: 0;
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue',
    Arial, 'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji',
    'Segoe UI Symbol', 'Noto Color Emoji';
  font-size: 16px;
  font-weight: 400;
  line-height: 1.5;
  color: var(--color-font);
  text-align: left;
}

:host:not(button) {
  background-color: #fff;
}

[tabindex='-1']:focus:not(:focus-visible) {
  outline: 0 !important;
}

hr {
  box-sizing: content-box;
  height: 0;
  overflow: visible;
}

h1,
h2,
h3,
h4,
h5,
h6 {
  margin-top: 0;
  margin-bottom: 8px;
}

p {
  margin-top: 0;
  margin-bottom: 16px;
}

abbr[title],
abbr[data-original-title] {
  text-decoration: underline;
  -webkit-text-decoration: underline dotted;
  text-decoration: underline dotted;
  cursor: help;
  border-bottom: 0;
  -webkit-text-decoration-skip-ink: none;
  text-decoration-skip-ink: none;
}

address {
  margin-bottom: 16px;
  font-style: normal;
  line-height: inherit;
}

ol,
ul,
dl {
  margin-top: 0;
  margin-bottom: 16px;
}

ol ol,
ul ul,
ol ul,
ul ol {
  margin-bottom: 0;
}

dt {
  font-weight: 700;
}

dd {
  margin-bottom: 8px;
  margin-left: 0;
}

blockquote {
  margin: 0 0 16px;
}

b,
strong {
  font-weight: bolder;
}

small {
  font-size: 80%;
}

sub,
sup {
  position: relative;
  font-size: 75%;
  line-height: 0;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

a {
  color: #007bff;
  text-decoration: none;
  background-color: transparent;
}

a:hover {
  color: #0056b3;
  text-decoration: underline;
}

a:not([href]) {
  color: inherit;
  text-decoration: none;
}

a:not([href]):hover {
  color: inherit;
  text-decoration: none;
}

pre,
code,
kbd,
samp {
  font-family:
    SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New',
    monospace;
  font-size: 1em;
}

pre {
  margin-top: 0;
  margin-bottom: 16px;
  overflow: auto;
}

figure {
  margin: 0 0 16px;
}

img {
  vertical-align: middle;
  border-style: none;
}

svg {
  overflow: hidden;
  vertical-align: middle;
}

table {
  border-collapse: collapse;
}

caption {
  padding-top: 12px;
  padding-bottom: 12px;
  color: #6c757d;
  text-align: left;
  caption-side: bottom;
}

th {
  text-align: inherit;
}

label {
  display: inline-block;
  margin-bottom: 8px;
}

button {
  border-radius: 0;
  border: 0;
  padding: 0;
  margin: 0;
  background: none;
  appearance: none;
  -webkit-appearance: none;
}

button:focus {
  outline: 1px dotted;
  outline: 5px auto -webkit-focus-ring-color;
}

button:focus:not(:focus-visible) {
  outline: none;
}

input,
button,
select,
optgroup,
textarea {
  margin: 0;
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}

button,
input {
  overflow: visible;
}

button,
select {
  text-transform: none;
}

select {
  word-wrap: normal;
}

button,
[type='button'],
[type='reset'],
[type='submit'] {
  -webkit-appearance: button;
}

button:not(:disabled),
[type='button']:not(:disabled),
[type='reset']:not(:disabled),
[type='submit']:not(:disabled) {
  cursor: pointer;
}

button::-moz-focus-inner,
[type='button']::-moz-focus-inner,
[type='reset']::-moz-focus-inner,
[type='submit']::-moz-focus-inner {
  padding: 0;
  border-style: none;
}

input[type='radio'],
input[type='checkbox'] {
  box-sizing: border-box;
  padding: 0;
}

input[type='date'],
input[type='time'],
input[type='datetime-local'],
input[type='month'] {
  -webkit-appearance: listbox;
}

textarea {
  overflow: auto;
  resize: vertical;
}

fieldset {
  min-width: 0;
  padding: 0;
  margin: 0;
  border: 0;
}

legend {
  display: block;
  width: 100%;
  max-width: 100%;
  padding: 0;
  margin-bottom: 8px;
  font-size: 24px;
  line-height: inherit;
  color: inherit;
  white-space: normal;
}

progress {
  vertical-align: baseline;
}

[type='number']::-webkit-inner-spin-button,
[type='number']::-webkit-outer-spin-button {
  height: auto;
}

[type='search'] {
  outline-offset: -2px;
  -webkit-appearance: none;
}

[type='search']::-webkit-search-decoration {
  -webkit-appearance: none;
}

::-webkit-file-upload-button {
  font: inherit;
  -webkit-appearance: button;
}

output {
  display: inline-block;
}

summary {
  display: list-item;
  cursor: pointer;
}

template {
  display: none;
}

[hidden] {
  display: none !important;
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/panel/dynamic-panel.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`/* Panel container base styles with dynamic positioning and sizing */
.dynamic-panel-container {
  position: fixed;
  z-index: 2147483646;
  outline: none;
  top: var(--panel-top, auto);
  bottom: var(--panel-bottom, auto);
  left: var(--panel-left, auto);
  right: var(--panel-right, auto);
  width: var(--panel-width);
  height: var(--panel-height);
  min-width: var(--panel-min-width);
  min-height: var(--panel-min-height);
  max-width: var(--panel-max-width);
  max-height: var(--panel-max-height);
}

/* Panel content container styles */
.panel-content-container {
  position: relative;
  width: 100%;
  height: 100%;
  border: 1px solid var(--color-gray-alpha-400);
  border-radius: var(--rounded-xl);
  background: var(--color-background-100);
  display: flex;
  flex-direction: column;
}

/* Draggable content area styles */
.draggable-content {
  flex: 1;
  overflow: auto;
  border-radius: inherit;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/colors.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`:host {
  /*
   * CAUTION: THIS IS A WORKAROUND!
   * The code frame renderer (next-code-frame) uses hardcoded ANSI colors that don't match
   * our theme colors. We do a workaround mapping to change the ANSI color matching the theme.
   *
   * next-code-frame color scheme:
   *   cyan (36m):    keywords (const, function, return, etc.)
   *   yellow (33m):  capitalized identifiers (Component names, types)
   *   magenta (35m): numbers, regex literals
   *   green (32m):   strings
   *   gray (90m):    comments, gutter
   */
  /* cyan: keyword */
  --color-ansi-cyan: var(--color-syntax-keyword);
  /* yellow: capitalized identifiers */
  --color-ansi-yellow: var(--color-syntax-function);
  /* magenta: number, regex */
  --color-ansi-magenta: var(--color-syntax-keyword);
  /* green: string */
  --color-ansi-green: var(--color-syntax-string);
  /* gray (bright black): comment, gutter */
  --color-ansi-bright-black: var(--color-syntax-comment);

  /* Ansi - Temporary */
  --color-ansi-selection: var(--color-gray-alpha-300);
  --color-ansi-bg: var(--color-background-200);
  --color-ansi-fg: var(--color-gray-1000);

  --color-ansi-white: var(--color-gray-700);
  --color-ansi-black: var(--color-gray-200);
  --color-ansi-blue: var(--color-blue-700);
  --color-ansi-red: var(--color-red-700);
  --color-ansi-bright-white: var(--color-gray-1000);
  --color-ansi-bright-blue: var(--color-blue-800);
  --color-ansi-bright-cyan: var(--color-blue-800);
  --color-ansi-bright-green: var(--color-green-800);
  --color-ansi-bright-magenta: var(--color-blue-800);
  --color-ansi-bright-red: var(--color-red-800);
  --color-ansi-bright-yellow: var(--color-amber-900);

  /* Background Light */
  --color-background-100: #ffffff;
  --color-background-200: #fafafa;

  /* Syntax Light */
  --color-syntax-comment: #545454;
  --color-syntax-constant: #171717;
  --color-syntax-function: #0054ad;
  --color-syntax-keyword: #a51850;
  --color-syntax-link: #066056;
  --color-syntax-parameter: #8f3e00;
  --color-syntax-punctuation: #171717;
  --color-syntax-string: #036157;
  --color-syntax-string-expression: #066056;

  /* Gray Scale Light */
  --color-gray-100: #f2f2f2;
  --color-gray-200: #ebebeb;
  --color-gray-300: #e6e6e6;
  --color-gray-400: #eaeaea;
  --color-gray-500: #c9c9c9;
  --color-gray-600: #a8a8a8;
  --color-gray-700: #8f8f8f;
  --color-gray-800: #7d7d7d;
  --color-gray-900: #666666;
  --color-gray-1000: #171717;

  /* Gray Alpha Scale Light */
  --color-gray-alpha-100: rgba(0, 0, 0, 0.05);
  --color-gray-alpha-200: rgba(0, 0, 0, 0.081);
  --color-gray-alpha-300: rgba(0, 0, 0, 0.1);
  --color-gray-alpha-400: rgba(0, 0, 0, 0.08);
  --color-gray-alpha-500: rgba(0, 0, 0, 0.21);
  --color-gray-alpha-600: rgba(0, 0, 0, 0.34);
  --color-gray-alpha-700: rgba(0, 0, 0, 0.44);
  --color-gray-alpha-800: rgba(0, 0, 0, 0.51);
  --color-gray-alpha-900: rgba(0, 0, 0, 0.605);
  --color-gray-alpha-1000: rgba(0, 0, 0, 0.91);

  /* Blue Scale Light */
  --color-blue-100: #f0f7ff;
  --color-blue-200: #edf6ff;
  --color-blue-300: #e1f0ff;
  --color-blue-400: #cde7ff;
  --color-blue-500: #99ceff;
  --color-blue-600: #52aeff;
  --color-blue-700: #0070f3;
  --color-blue-800: #0060d1;
  --color-blue-900: #0067d6;
  --color-blue-1000: #0025ad;

  /* Purple Scale Light */
  --color-purple-100: #f9f3fd;
  --color-purple-200: #f8f2fd;
  --color-purple-300: #f1ecfb;
  --color-purple-400: #eadff7;
  --color-purple-500: #d4bced;
  --color-purple-600: #bd92e9;
  --color-purple-700: #8250dc;
  --color-purple-800: #6f47c4;
  --color-purple-900: #6a2db5;
  --color-purple-1000: #2e004d;

  /* Red Scale Light */
  --color-red-100: #fff0f0;
  --color-red-200: #ffebeb;
  --color-red-300: #ffe5e5;
  --color-red-400: #fdd8d8;
  --color-red-500: #f8baba;
  --color-red-600: #f87274;
  --color-red-700: #e5484d;
  --color-red-800: #da3036;
  --color-red-900: #ca2a30;
  --color-red-1000: #381316;

  /* Amber Scale Light */
  --color-amber-100: #fff6e5;
  --color-amber-200: #fff4d5;
  --color-amber-300: #fef0cd;
  --color-amber-400: #ffddbf;
  --color-amber-500: #ffc96b;
  --color-amber-600: #f5b047;
  --color-amber-700: #ffb224;
  --color-amber-800: #ff990a;
  --color-amber-900: #a35200;
  --color-amber-1000: #4e2009;

  /* Green Scale Light */
  --color-green-100: #effbef;
  --color-green-200: #eafaea;
  --color-green-300: #dcf6dc;
  --color-green-400: #c8f1c9;
  --color-green-500: #99e59f;
  --color-green-600: #6cda76;
  --color-green-700: #46a758;
  --color-green-800: #388e4a;
  --color-green-900: #297c3b;
  --color-green-1000: #18311e;

  /* Instant Guidance Cards */
  --color-instant-border-blue: rgba(0, 112, 243, 0.4);
  --color-instant-border-purple: rgba(130, 80, 220, 0.4);
  --color-instant-border-red: rgba(229, 72, 77, 0.45);
  --color-instant-border-amber: rgba(180, 110, 0, 0.6);
  --color-instant-border-teal: rgba(0, 160, 140, 0.55);
  --color-instant-text-purple: rgb(130, 80, 220);
  --color-instant-text-amber: rgb(163, 82, 0);
  --color-instant-text-teal: rgb(0, 130, 115);

  /* Turbopack Light - Temporary */
  --color-turbopack-text-red: #ff1e56;
  --color-turbopack-text-blue: #0096ff;
  --color-turbopack-border-red: #f0adbe;
  --color-turbopack-border-blue: #adccea;
  --color-turbopack-background-red: #fff7f9;
  --color-turbopack-background-blue: #f6fbff;
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/dark-theme.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`:host(.dark) {
  --color-font: white;
  --color-backdrop: rgba(0, 0, 0, 0.8);
  --color-border-shadow: rgba(255, 255, 255, 0.145);

  --color-title-color: #fafafa;
  --color-stack-notes: #a9a9a9;

  /* Background Dark */
  --color-background-100: #0a0a0a;
  --color-background-200: #000000;

  /* Syntax Dark */
  --color-syntax-comment: #a0a0a0;
  --color-syntax-constant: #ededed;
  --color-syntax-function: #52a9ff;
  --color-syntax-keyword: #f76e99;
  --color-syntax-link: #0ac5b2;
  --color-syntax-parameter: #f1a10d;
  --color-syntax-punctuation: #ededed;
  --color-syntax-string: #0ac5b2;
  --color-syntax-string-expression: #0ac5b2;

  /* Gray Scale Dark */
  --color-gray-100: #1a1a1a;
  --color-gray-200: #1f1f1f;
  --color-gray-300: #292929;
  --color-gray-400: #2e2e2e;
  --color-gray-500: #454545;
  --color-gray-600: #878787;
  --color-gray-700: #8f8f8f;
  --color-gray-800: #7d7d7d;
  --color-gray-900: #a0a0a0;
  --color-gray-1000: #ededed;

  /* Gray Alpha Scale Dark */
  --color-gray-alpha-100: rgba(255, 255, 255, 0.066);
  --color-gray-alpha-200: rgba(255, 255, 255, 0.087);
  --color-gray-alpha-300: rgba(255, 255, 255, 0.125);
  --color-gray-alpha-400: rgba(255, 255, 255, 0.145);
  --color-gray-alpha-500: rgba(255, 255, 255, 0.239);
  --color-gray-alpha-600: rgba(255, 255, 255, 0.506);
  --color-gray-alpha-700: rgba(255, 255, 255, 0.54);
  --color-gray-alpha-800: rgba(255, 255, 255, 0.47);
  --color-gray-alpha-900: rgba(255, 255, 255, 0.61);
  --color-gray-alpha-1000: rgba(255, 255, 255, 0.923);

  /* Blue Scale Dark */
  --color-blue-100: #0f1b2d;
  --color-blue-200: #10243e;
  --color-blue-300: #0f3058;
  --color-blue-400: #0d3868;
  --color-blue-500: #0a4481;
  --color-blue-600: #0091ff;
  --color-blue-700: #0070f3;
  --color-blue-800: #0060d1;
  --color-blue-900: #52a9ff;
  --color-blue-1000: #eaf6ff;

  /* Purple Scale Dark */
  --color-purple-100: #391c4a;
  --color-purple-200: #422154;
  --color-purple-300: #53306a;
  --color-purple-400: #5f3a79;
  --color-purple-500: #6d4790;
  --color-purple-600: #8e63d2;
  --color-purple-700: #8e63d2;
  --color-purple-800: #7d53c4;
  --color-purple-900: #c79bfb;
  --color-purple-1000: #f7f0ff;

  /* Red Scale Dark */
  --color-red-100: #2a1314;
  --color-red-200: #3d1719;
  --color-red-300: #551a1e;
  --color-red-400: #671e22;
  --color-red-500: #822025;
  --color-red-600: #e5484d;
  --color-red-700: #e5484d;
  --color-red-800: #da3036;
  --color-red-900: #ff6369;
  --color-red-1000: #ffecee;

  /* Amber Scale Dark */
  --color-amber-100: #271700;
  --color-amber-200: #341c00;
  --color-amber-300: #4a2900;
  --color-amber-400: #573300;
  --color-amber-500: #693f05;
  --color-amber-600: #e79c13;
  --color-amber-700: #ffb224;
  --color-amber-800: #ff990a;
  --color-amber-900: #f1a10d;
  --color-amber-1000: #fef3dd;

  /* Green Scale Dark */
  --color-green-100: #0b2211;
  --color-green-200: #0f2c17;
  --color-green-300: #11351b;
  --color-green-400: #0c461b;
  --color-green-500: #126427;
  --color-green-600: #1a9338;
  --color-green-700: #46a758;
  --color-green-800: #388e4a;
  --color-green-900: #63c174;
  --color-green-1000: #e5fbeb;

  /* Instant Guidance Cards */
  --color-instant-border-blue: rgba(82, 169, 255, 0.45);
  --color-instant-border-purple: rgba(160, 120, 240, 0.45);
  --color-instant-border-red: rgba(255, 99, 105, 0.4);
  --color-instant-border-amber: rgba(231, 156, 19, 0.5);
  --color-instant-border-teal: rgba(45, 212, 191, 0.5);
  --color-instant-text-purple: rgb(160, 120, 240);
  --color-instant-text-amber: rgb(241, 161, 13);
  --color-instant-text-teal: rgb(45, 212, 191);

  /* Turbopack Dark - Temporary */
  --color-turbopack-text-red: #ff6d92;
  --color-turbopack-text-blue: #45b2ff;
  --color-turbopack-border-red: #6e293b;
  --color-turbopack-border-blue: #284f80;
  --color-turbopack-background-red: #250d12;
  --color-turbopack-background-blue: #0a1723;
}

@media (prefers-color-scheme: dark) {
  :host(:not(.light)) {
    --color-font: white;
    --color-backdrop: rgba(0, 0, 0, 0.8);
    --color-border-shadow: rgba(255, 255, 255, 0.145);

    --color-title-color: #fafafa;
    --color-stack-notes: #a9a9a9;

    /* Background Dark */
    --color-background-100: #0a0a0a;
    --color-background-200: #000000;

    /* Syntax Dark */
    --color-syntax-comment: #a0a0a0;
    --color-syntax-constant: #ededed;
    --color-syntax-function: #52a9ff;
    --color-syntax-keyword: #f76e99;
    --color-syntax-link: #0ac5b2;
    --color-syntax-parameter: #f1a10d;
    --color-syntax-punctuation: #ededed;
    --color-syntax-string: #0ac5b2;
    --color-syntax-string-expression: #0ac5b2;

    /* Gray Scale Dark */
    --color-gray-100: #1a1a1a;
    --color-gray-200: #1f1f1f;
    --color-gray-300: #292929;
    --color-gray-400: #2e2e2e;
    --color-gray-500: #454545;
    --color-gray-600: #878787;
    --color-gray-700: #8f8f8f;
    --color-gray-800: #7d7d7d;
    --color-gray-900: #a0a0a0;
    --color-gray-1000: #ededed;

    /* Gray Alpha Scale Dark */
    --color-gray-alpha-100: rgba(255, 255, 255, 0.066);
    --color-gray-alpha-200: rgba(255, 255, 255, 0.087);
    --color-gray-alpha-300: rgba(255, 255, 255, 0.125);
    --color-gray-alpha-400: rgba(255, 255, 255, 0.145);
    --color-gray-alpha-500: rgba(255, 255, 255, 0.239);
    --color-gray-alpha-600: rgba(255, 255, 255, 0.506);
    --color-gray-alpha-700: rgba(255, 255, 255, 0.54);
    --color-gray-alpha-800: rgba(255, 255, 255, 0.47);
    --color-gray-alpha-900: rgba(255, 255, 255, 0.61);
    --color-gray-alpha-1000: rgba(255, 255, 255, 0.923);

    /* Blue Scale Dark */
    --color-blue-100: #0f1b2d;
    --color-blue-200: #10243e;
    --color-blue-300: #0f3058;
    --color-blue-400: #0d3868;
    --color-blue-500: #0a4481;
    --color-blue-600: #0091ff;
    --color-blue-700: #0070f3;
    --color-blue-800: #0060d1;
    --color-blue-900: #52a9ff;
    --color-blue-1000: #eaf6ff;

    /* Purple Scale Dark */
    --color-purple-100: #391c4a;
    --color-purple-200: #422154;
    --color-purple-300: #53306a;
    --color-purple-400: #5f3a79;
    --color-purple-500: #6d4790;
    --color-purple-600: #8e63d2;
    --color-purple-700: #8e63d2;
    --color-purple-800: #7d53c4;
    --color-purple-900: #c79bfb;
    --color-purple-1000: #f7f0ff;

    /* Red Scale Dark */
    --color-red-100: #2a1314;
    --color-red-200: #3d1719;
    --color-red-300: #551a1e;
    --color-red-400: #671e22;
    --color-red-500: #822025;
    --color-red-600: #e5484d;
    --color-red-700: #e5484d;
    --color-red-800: #da3036;
    --color-red-900: #ff6369;
    --color-red-1000: #ffecee;

    /* Amber Scale Dark */
    --color-amber-100: #271700;
    --color-amber-200: #341c00;
    --color-amber-300: #4a2900;
    --color-amber-400: #573300;
    --color-amber-500: #693f05;
    --color-amber-600: #e79c13;
    --color-amber-700: #ffb224;
    --color-amber-800: #ff990a;
    --color-amber-900: #f1a10d;
    --color-amber-1000: #fef3dd;

    /* Green Scale Dark */
    --color-green-100: #0b2211;
    --color-green-200: #0f2c17;
    --color-green-300: #11351b;
    --color-green-400: #0c461b;
    --color-green-500: #126427;
    --color-green-600: #1a9338;
    --color-green-700: #46a758;
    --color-green-800: #388e4a;
    --color-green-900: #63c174;
    --color-green-1000: #e5fbeb;

    /* Instant Guidance Cards */
    --color-instant-border-blue: rgba(82, 169, 255, 0.45);
    --color-instant-border-purple: rgba(160, 120, 240, 0.45);
    --color-instant-border-red: rgba(255, 99, 105, 0.4);
    --color-instant-border-amber: rgba(231, 156, 19, 0.5);
    --color-instant-border-teal: rgba(45, 212, 191, 0.5);
    --color-instant-text-purple: rgb(160, 120, 240);
    --color-instant-text-amber: rgb(241, 161, 13);
    --color-instant-text-teal: rgb(45, 212, 191);

    /* Turbopack Dark - Temporary */
    --color-turbopack-text-red: #ff6d92;
    --color-turbopack-text-blue: #45b2ff;
    --color-turbopack-border-red: #6e293b;
    --color-turbopack-border-blue: #284f80;
    --color-turbopack-background-red: #250d12;
    --color-turbopack-background-blue: #0a1723;
  }
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/default-theme.css"(e,t,r){"use strict";r.d(t,{A:()=>s});var n=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=r.n(n),a=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"),i=r.n(a)()(o());i.push([e.id,`:host {
  /* 
   * Although the style applied to the shadow host is isolated,
   * the element that attached the shadow host (i.e. "nextjs-portal")
   * is still affected by the parent's style (e.g. "body"). This may
   * occur style conflicts like "display: flex", with other children
   * elements therefore give the shadow host an absolute position.
   */
  position: absolute;

  --color-font: #757575;
  --color-backdrop: rgba(250, 250, 250, 0.8);
  --color-border-shadow: rgba(0, 0, 0, 0.145);

  --color-title-color: #1f1f1f;
  --color-stack-notes: #777;

  --color-accents-1: #808080;
  --color-accents-2: #222222;
  --color-accents-3: #404040;

  --font-stack-monospace:
    '__nextjs-Geist Mono', 'Geist Mono', 'SFMono-Regular', Consolas,
    'Liberation Mono', Menlo, Courier, monospace;
  --font-stack-sans:
    '__nextjs-Geist', 'Geist', -apple-system, 'Source Sans Pro', sans-serif;

  font-family: var(--font-stack-sans);
  font-variant-ligatures: none;

  /* TODO: Remove replaced ones. */
  --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  --shadow-lg:
    0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --shadow-xl:
    0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);
  --shadow-inner: inset 0 2px 4px 0 rgb(0 0 0 / 0.05);
  --shadow-none: 0 0 #0000;

  --shadow-small: 0px 2px 2px rgba(0, 0, 0, 0.04);
  --shadow-menu:
    0px 1px 1px rgba(0, 0, 0, 0.02), 0px 4px 8px -4px rgba(0, 0, 0, 0.04),
    0px 16px 24px -8px rgba(0, 0, 0, 0.06);

  --focus-color: var(--color-blue-800);
  --focus-ring: 2px solid var(--focus-color);

  --timing-swift: cubic-bezier(0.23, 0.88, 0.26, 0.92);
  --timing-overlay: cubic-bezier(0.175, 0.885, 0.32, 1.1);
  /* prettier-ignore */
  --timing-bounce: linear(0 0%, 0.005871 1%, 0.022058 2%, 0.046612 3%, 0.077823 4%, 0.114199 5%, 0.154441 6%, 0.197431 7.000000000000001%, 0.242208 8%, 0.287959 9%, 0.333995 10%, 0.379743 11%, 0.424732 12%, 0.46858 13%, 0.510982 14.000000000000002%, 0.551702 15%, 0.590564 16%, 0.627445 17%, 0.662261 18%, 0.694971 19%, 0.725561 20%, 0.754047 21%, 0.780462 22%, 0.804861 23%, 0.82731 24%, 0.847888 25%, 0.866679 26%, 0.883775 27%, 0.899272 28.000000000000004%, 0.913267 28.999999999999996%, 0.925856 30%, 0.937137 31%, 0.947205 32%, 0.956153 33%, 0.96407 34%, 0.971043 35%, 0.977153 36%, 0.982479 37%, 0.987094 38%, 0.991066 39%, 0.994462 40%, 0.997339 41%, 0.999755 42%, 1.001761 43%, 1.003404 44%, 1.004727 45%, 1.00577 46%, 1.006569 47%, 1.007157 48%, 1.007563 49%, 1.007813 50%, 1.007931 51%, 1.007939 52%, 1.007855 53%, 1.007697 54%, 1.007477 55.00000000000001%, 1.00721 56.00000000000001%, 1.006907 56.99999999999999%, 1.006576 57.99999999999999%, 1.006228 59%, 1.005868 60%, 1.005503 61%, 1.005137 62%, 1.004776 63%, 1.004422 64%, 1.004078 65%, 1.003746 66%, 1.003429 67%, 1.003127 68%, 1.00284 69%, 1.002571 70%, 1.002318 71%, 1.002082 72%, 1.001863 73%, 1.00166 74%, 1.001473 75%, 1.001301 76%, 1.001143 77%, 1.001 78%, 1.000869 79%, 1.000752 80%, 1.000645 81%, 1.00055 82%, 1.000464 83%, 1.000388 84%, 1.000321 85%, 1.000261 86%, 1.000209 87%, 1.000163 88%, 1.000123 89%, 1.000088 90%);

  --rounded-none: 0px;
  --rounded-sm: 2px;
  --rounded-md: 4px;
  --rounded-md-2: 6px;
  --rounded-lg: 8px;
  --rounded-xl: 12px;
  --rounded-2xl: 16px;
  --rounded-3xl: 24px;
  --rounded-4xl: 32px;
  --rounded-full: 9999px;

  /* 
    This value gets set from the Dev Tools preferences,
    and we use the following --size-* variables to 
    scale the relevant elements.

    The reason why we don't rely on rem values is because
    if an app sets their root font size to something tiny, 
    it feels unexpected to have the app root size leak 
    into a Next.js surface.

    https://github.com/vercel/next.js/discussions/76812
  */
  --nextjs-dev-tools-scale: 1;
  --size-1: calc(1px / var(--nextjs-dev-tools-scale));
  --size-2: calc(2px / var(--nextjs-dev-tools-scale));
  --size-3: calc(3px / var(--nextjs-dev-tools-scale));
  --size-4: calc(4px / var(--nextjs-dev-tools-scale));
  --size-5: calc(5px / var(--nextjs-dev-tools-scale));
  --size-6: calc(6px / var(--nextjs-dev-tools-scale));
  --size-7: calc(7px / var(--nextjs-dev-tools-scale));
  --size-8: calc(8px / var(--nextjs-dev-tools-scale));
  --size-9: calc(9px / var(--nextjs-dev-tools-scale));
  --size-10: calc(10px / var(--nextjs-dev-tools-scale));
  --size-11: calc(11px / var(--nextjs-dev-tools-scale));
  --size-12: calc(12px / var(--nextjs-dev-tools-scale));
  --size-13: calc(13px / var(--nextjs-dev-tools-scale));
  --size-14: calc(14px / var(--nextjs-dev-tools-scale));
  --size-15: calc(15px / var(--nextjs-dev-tools-scale));
  --size-16: calc(16px / var(--nextjs-dev-tools-scale));
  --size-17: calc(17px / var(--nextjs-dev-tools-scale));
  --size-18: calc(18px / var(--nextjs-dev-tools-scale));
  --size-20: calc(20px / var(--nextjs-dev-tools-scale));
  --size-22: calc(22px / var(--nextjs-dev-tools-scale));
  --size-24: calc(24px / var(--nextjs-dev-tools-scale));
  --size-26: calc(26px / var(--nextjs-dev-tools-scale));
  --size-28: calc(28px / var(--nextjs-dev-tools-scale));
  --size-30: calc(30px / var(--nextjs-dev-tools-scale));
  --size-32: calc(32px / var(--nextjs-dev-tools-scale));
  --size-34: calc(34px / var(--nextjs-dev-tools-scale));
  --size-36: calc(36px / var(--nextjs-dev-tools-scale));
  --size-38: calc(38px / var(--nextjs-dev-tools-scale));
  --size-40: calc(40px / var(--nextjs-dev-tools-scale));
  --size-42: calc(42px / var(--nextjs-dev-tools-scale));
  --size-44: calc(44px / var(--nextjs-dev-tools-scale));
  --size-46: calc(46px / var(--nextjs-dev-tools-scale));
  --size-48: calc(48px / var(--nextjs-dev-tools-scale));

  @media print {
    display: none;
  }
}

h1,
h2,
h3,
h4,
h5,
h6 {
  margin-bottom: 8px;
  font-weight: 500;
  line-height: 1.5;
}

a {
  color: var(--color-blue-900);
  &:hover {
    color: var(--color-blue-900);
  }
  &:focus-visible {
    outline: var(--focus-ring);
  }
}
`,""]);let s=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/api.js"(e){"use strict";e.exports=function(e){var t=[];return t.toString=function(){return this.map(function(t){var r="",n=void 0!==t[5];return t[4]&&(r+="@supports (".concat(t[4],") {")),t[2]&&(r+="@media ".concat(t[2]," {")),n&&(r+="@layer".concat(t[5].length>0?" ".concat(t[5]):""," {")),r+=e(t),n&&(r+="}"),t[2]&&(r+="}"),t[4]&&(r+="}"),r}).join("")},t.i=function(e,r,n,o,a){"string"==typeof e&&(e=[[null,e,void 0]]);var i={};if(n)for(var s=0;s<this.length;s++){var l=this[s][0];null!=l&&(i[l]=!0)}for(var c=0;c<e.length;c++){var u=[].concat(e[c]);n&&i[u[0]]||(void 0!==a&&(void 0===u[5]||(u[1]="@layer".concat(u[5].length>0?" ".concat(u[5]):""," {").concat(u[1],"}")),u[5]=a),r&&(u[2]&&(u[1]="@media ".concat(u[2]," {").concat(u[1],"}")),u[2]=r),o&&(u[4]?(u[1]="@supports (".concat(u[4],") {").concat(u[1],"}"),u[4]=o):u[4]="".concat(o)),t.push(u))}},t}},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/runtime/noSourceMaps.js"(e){"use strict";e.exports=function(e){return e[1]}},"../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.23__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js"(e){"use strict";var t=[];function r(e){for(var r=-1,n=0;n<t.length;n++)if(t[n].identifier===e){r=n;break}return r}function n(e,n){for(var o={},a=[],i=0;i<e.length;i++){var s=e[i],l=n.base?s[0]+n.base:s[0],c=o[l]||0,u="".concat(l," ").concat(c);o[l]=c+1;var d=r(u),f={css:s[1],media:s[2],sourceMap:s[3],supports:s[4],layer:s[5]};if(-1!==d)t[d].references++,t[d].updater(f);else{var p=function(e,t){var r=t.domAPI(t);return r.update(e),function(t){t?(t.css!==e.css||t.media!==e.media||t.sourceMap!==e.sourceMap||t.supports!==e.supports||t.layer!==e.layer)&&r.update(e=t):r.remove()}}(f,n);n.byIndex=i,t.splice(i,0,{identifier:u,updater:p,references:1})}a.push(u)}return a}e.exports=function(e,o){var a=n(e=e||[],o=o||{});return function(e){e=e||[];for(var i=0;i<a.length;i++){var s=r(a[i]);t[s].references--}for(var l=n(e,o),c=0;c<a.length;c++){var u=r(a[c]);0===t[u].references&&(t[u].updater(),t.splice(u,1))}a=l}}},"../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.23__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/insertStyleElement.js"(e){"use strict";e.exports=function(e){var t=document.createElement("style");return e.setAttributes(t,e.attributes),e.insert(t,e.options),t}},"../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.23__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js"(e,t,r){"use strict";e.exports=function(e){var t=r.nc;t&&e.setAttribute("nonce",t)}},"../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.23__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/styleDomAPI.js"(e){"use strict";e.exports=function(e){if("undefined"==typeof document)return{update:function(){},remove:function(){}};var t=e.insertStyleElement(e);return{update:function(r){var n,o,a;n="",r.supports&&(n+="@supports (".concat(r.supports,") {")),r.media&&(n+="@media ".concat(r.media," {")),(o=void 0!==r.layer)&&(n+="@layer".concat(r.layer.length>0?" ".concat(r.layer):""," {")),n+=r.css,o&&(n+="}"),r.media&&(n+="}"),r.supports&&(n+="}"),(a=r.sourceMap)&&"undefined"!=typeof btoa&&(n+="\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(a))))," */")),e.styleTagTransform(n,t,e.options)},remove:function(){var e;null===(e=t).parentNode||e.parentNode.removeChild(e)}}}},"../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.23__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/styleTagTransform.js"(e){"use strict";e.exports=function(e,t){if(t.styleSheet)t.styleSheet.cssText=e;else{for(;t.firstChild;)t.removeChild(t.firstChild);t.appendChild(document.createTextNode(e))}}},"./dist/compiled/anser/index.js"(e){(()=>{"use strict";var t={621:e=>{var t=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}(),r=[[{color:"0, 0, 0",class:"ansi-black"},{color:"187, 0, 0",class:"ansi-red"},{color:"0, 187, 0",class:"ansi-green"},{color:"187, 187, 0",class:"ansi-yellow"},{color:"0, 0, 187",class:"ansi-blue"},{color:"187, 0, 187",class:"ansi-magenta"},{color:"0, 187, 187",class:"ansi-cyan"},{color:"255,255,255",class:"ansi-white"}],[{color:"85, 85, 85",class:"ansi-bright-black"},{color:"255, 85, 85",class:"ansi-bright-red"},{color:"0, 255, 0",class:"ansi-bright-green"},{color:"255, 255, 85",class:"ansi-bright-yellow"},{color:"85, 85, 255",class:"ansi-bright-blue"},{color:"255, 85, 255",class:"ansi-bright-magenta"},{color:"85, 255, 255",class:"ansi-bright-cyan"},{color:"255, 255, 255",class:"ansi-bright-white"}]];e.exports=function(){function e(){if(!(this instanceof e))throw TypeError("Cannot call a class as a function");this.fg=this.bg=this.fg_truecolor=this.bg_truecolor=null,this.bright=0}return t(e,null,[{key:"escapeForHtml",value:function(t){return(new e).escapeForHtml(t)}},{key:"linkify",value:function(t){return(new e).linkify(t)}},{key:"ansiToHtml",value:function(t,r){return(new e).ansiToHtml(t,r)}},{key:"ansiToJson",value:function(t,r){return(new e).ansiToJson(t,r)}},{key:"ansiToText",value:function(t){return(new e).ansiToText(t)}}]),t(e,[{key:"setupPalette",value:function(){this.PALETTE_COLORS=[];for(var e=0;e<2;++e)for(var t=0;t<8;++t)this.PALETTE_COLORS.push(r[e][t].color);for(var n=[0,95,135,175,215,255],o=function(e,t,r){return n[e]+", "+n[t]+", "+n[r]},a=0;a<6;++a)for(var i=0;i<6;++i)for(var s=0;s<6;++s)this.PALETTE_COLORS.push(o(a,i,s));for(var l=8,c=0;c<24;++c,l+=10)this.PALETTE_COLORS.push(o(l,l,l))}},{key:"escapeForHtml",value:function(e){return e.replace(/[&<>]/gm,function(e){return"&"==e?"&amp;":"<"==e?"&lt;":">"==e?"&gt;":""})}},{key:"linkify",value:function(e){return e.replace(/(https?:\/\/[^\s]+)/gm,function(e){return'<a href="'+e+'">'+e+"</a>"})}},{key:"ansiToHtml",value:function(e,t){return this.process(e,t,!0)}},{key:"ansiToJson",value:function(e,t){return(t=t||{}).json=!0,t.clearLine=!1,this.process(e,t,!0)}},{key:"ansiToText",value:function(e){return this.process(e,{},!1)}},{key:"process",value:function(e,t,r){var n=this,o=e.split(/\033\[/),a=o.shift();null==t&&(t={}),t.clearLine=/\r/.test(e);var i=o.map(function(e){return n.processChunk(e,t,r)});if(t&&t.json){var s=this.processChunkJson("");return s.content=a,s.clearLine=t.clearLine,i.unshift(s),t.remove_empty&&(i=i.filter(function(e){return!e.isEmpty()})),i}return i.unshift(a),i.join("")}},{key:"processChunkJson",value:function(e,t,n){var o=(t=void 0===t?{}:t).use_classes=void 0!==t.use_classes&&t.use_classes,a=t.key=o?"class":"color",i={content:e,fg:null,bg:null,fg_truecolor:null,bg_truecolor:null,clearLine:t.clearLine,decoration:null,was_processed:!1,isEmpty:function(){return!i.content}},s=e.match(/^([!\x3c-\x3f]*)([\d;]*)([\x20-\x2c]*[\x40-\x7e])([\s\S]*)/m);if(!s)return i;i.content=s[4];var l=s[2].split(";");if(""!==s[1]||"m"!==s[3]||!n)return i;for(this.decoration=null;l.length>0;){var c=parseInt(l.shift());if(isNaN(c)||0===c)this.fg=this.bg=this.decoration=null;else if(1===c)this.decoration="bold";else if(2===c)this.decoration="dim";else if(3==c)this.decoration="italic";else if(4==c)this.decoration="underline";else if(5==c)this.decoration="blink";else if(7===c)this.decoration="reverse";else if(8===c)this.decoration="hidden";else if(9===c)this.decoration="strikethrough";else if(39==c)this.fg=null;else if(49==c)this.bg=null;else if(c>=30&&c<38)this.fg=r[0][c%10][a];else if(c>=90&&c<98)this.fg=r[1][c%10][a];else if(c>=40&&c<48)this.bg=r[0][c%10][a];else if(c>=100&&c<108)this.bg=r[1][c%10][a];else if(38===c||48===c){var u=38===c;if(l.length>=1){var d=l.shift();if("5"===d&&l.length>=1){var f=parseInt(l.shift());if(f>=0&&f<=255)if(o){var p=f>=16?"ansi-palette-"+f:r[+(f>7)][f%8].class;u?this.fg=p:this.bg=p}else this.PALETTE_COLORS||this.setupPalette(),u?this.fg=this.PALETTE_COLORS[f]:this.bg=this.PALETTE_COLORS[f]}else if("2"===d&&l.length>=3){var h=parseInt(l.shift()),m=parseInt(l.shift()),g=parseInt(l.shift());if(h>=0&&h<=255&&m>=0&&m<=255&&g>=0&&g<=255){var v=h+", "+m+", "+g;o?u?(this.fg="ansi-truecolor",this.fg_truecolor=v):(this.bg="ansi-truecolor",this.bg_truecolor=v):u?this.fg=v:this.bg=v}}}}}return null===this.fg&&null===this.bg&&null===this.decoration||(i.fg=this.fg,i.bg=this.bg,i.fg_truecolor=this.fg_truecolor,i.bg_truecolor=this.bg_truecolor,i.decoration=this.decoration,i.was_processed=!0),i}},{key:"processChunk",value:function(e,t,r){var n=this;t=t||{};var o=this.processChunkJson(e,t,r);if(t.json)return o;if(o.isEmpty())return"";if(!o.was_processed)return o.content;var a=t.use_classes,i=[],s=[],l={},c=function(e){var t=[],r=void 0;for(r in e)e.hasOwnProperty(r)&&t.push("data-"+r+'="'+n.escapeForHtml(e[r])+'"');return t.length>0?" "+t.join(" "):""};return(o.fg&&(a?(s.push(o.fg+"-fg"),null!==o.fg_truecolor&&(l["ansi-truecolor-fg"]=o.fg_truecolor,o.fg_truecolor=null)):i.push("color:rgb("+o.fg+")")),o.bg&&(a?(s.push(o.bg+"-bg"),null!==o.bg_truecolor&&(l["ansi-truecolor-bg"]=o.bg_truecolor,o.bg_truecolor=null)):i.push("background-color:rgb("+o.bg+")")),o.decoration&&(a?s.push("ansi-"+o.decoration):"bold"===o.decoration?i.push("font-weight:bold"):"dim"===o.decoration?i.push("opacity:0.5"):"italic"===o.decoration?i.push("font-style:italic"):"reverse"===o.decoration?i.push("filter:invert(100%)"):"hidden"===o.decoration?i.push("visibility:hidden"):"strikethrough"===o.decoration?i.push("text-decoration:line-through"):i.push("text-decoration:"+o.decoration)),a)?'<span class="'+s.join(" ")+'"'+c(l)+">"+o.content+"</span>":'<span style="'+i.join(";")+'"'+c(l)+">"+o.content+"</span>"}}]),e}()}},r={};function n(e){var o=r[e];if(void 0!==o)return o.exports;var a=r[e]={exports:{}},i=!0;try{t[e](a,a.exports,n),i=!1}finally{i&&delete r[e]}return a.exports}n.ab="//",e.exports=n(621)})()},"./dist/compiled/react-dom/cjs/react-dom-client.production.js"(e,t,r){"use strict";var n,o=r("./dist/compiled/scheduler/index.js"),a=r("./dist/compiled/react/index.js"),i=r("./dist/compiled/react-dom/index.js");function s(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var r=2;r<arguments.length;r++)t+="&args[]="+encodeURIComponent(arguments[r])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function l(e){for(var t=e,r=t;r&&!r.alternate;)0!=(4098&(t=r).flags)&&(e=t.return),r=t.return;for(;t.return;)t=t.return;return 3===t.tag?e:null}function c(e){if(13===e.tag){var t=e.memoizedState;if(null===t&&null!==(e=e.alternate)&&(t=e.memoizedState),null!==t)return t.dehydrated}return null}function u(e){if(31===e.tag){var t=e.memoizedState;if(null===t&&null!==(e=e.alternate)&&(t=e.memoizedState),null!==t)return t.dehydrated}return null}function d(e){if(l(e)!==e)throw Error(s(188))}function f(e,t,r,n,o,a){for(;null!==e;){if((5===e.tag||27===e.tag||6===e.tag)&&r(e,n,o,a)||(22!==e.tag||null===e.memoizedState)&&(t||5!==e.tag&&27!==e.tag)&&f(e.child,t,r,n,o,a))return!0;e=e.sibling}return!1}function p(e){for(e=e.return;null!==e;){if(3===e.tag||5===e.tag||27===e.tag)return e;e=e.return}return null}function h(e){var t=!1;for(e=e.return;null!==e&&(4===e.tag&&(t=!0),3!==e.tag&&5!==e.tag&&27!==e.tag);)e=e.return;return t}function m(e){var t=[null,null],r=p(e);return null===r||function e(t,r,n,o){for(;null!==n;){if(n===r)o.foundSelf=!0;else if(5===n.tag||27===n.tag||6===n.tag){if(o.foundSelf)return t[1]=n,!0;t[0]=n}else if((22!==n.tag||null===n.memoizedState)&&e(t,r,n.child,o))return!0;n=n.sibling}return!1}(t,e,r.child,{foundSelf:!1}),t}function g(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(s(559))}}var v=null,x=null;function y(e,t,r){return e===r||e===t&&(v=e,!0)}function b(e,t,r){return e===r?(x=e,!1):e===t&&(null!==x&&(v=e),!0)}function w(e){if(null===e)return null;do e=null===e?null:e.return;while(e&&5!==e.tag&&27!==e.tag&&3!==e.tag);return e||null}function _(e,t,r){for(var n=0,o=e;o;o=r(o))n++;o=0;for(var a=t;a;a=r(a))o++;for(;0<n-o;)e=r(e),n--;for(;0<o-n;)t=r(t),o--;for(;n--;){if(e===t||null!==t&&e===t.alternate)return e;e=r(e),t=r(t)}return null}var k=Object.assign,j=Symbol.for("react.element"),S=Symbol.for("react.transitional.element"),C=Symbol.for("react.portal"),E=Symbol.for("react.fragment"),T=Symbol.for("react.strict_mode"),N=Symbol.for("react.profiler"),I=Symbol.for("react.consumer"),z=Symbol.for("react.context"),R=Symbol.for("react.forward_ref"),P=Symbol.for("react.suspense"),L=Symbol.for("react.suspense_list"),O=Symbol.for("react.memo"),M=Symbol.for("react.lazy");Symbol.for("react.scope");var A=Symbol.for("react.activity"),D=Symbol.for("react.legacy_hidden");Symbol.for("react.tracing_marker");var F=Symbol.for("react.memo_cache_sentinel"),$=Symbol.for("react.view_transition"),U=Symbol.for("react.recoverable"),Z=Symbol.iterator;function q(e){return null===e||"object"!=typeof e?null:"function"==typeof(e=Z&&e[Z]||e["@@iterator"])?e:null}var B=Symbol.for("react.client.reference"),V=Array.isArray,H=a.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,W=i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,G={pending:!1,data:null,method:null,action:null},K=[],Y=-1;function X(e){return{current:e}}function Q(e){0>Y||(e.current=K[Y],K[Y]=null,Y--)}function J(e,t){K[++Y]=e.current,e.current=t}var ee=X(null),et=X(null),er=X(null),en=X(null);function eo(e,t){switch(J(er,t),J(et,e),J(ee,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?ub(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)e=uw(t=ub(t),e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}Q(ee),J(ee,e)}function ea(){Q(ee),Q(et),Q(er)}function ei(e){var t=e.memoizedState;null!==t&&(dD._currentValue=t.memoizedState,J(en,e));var r=uw(t=ee.current,e.type);t!==r&&(J(et,e),J(ee,r))}function es(e){et.current===e&&(Q(ee),Q(et)),en.current===e&&(Q(en),dD._currentValue=G)}function el(e){if(void 0===t0)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);t0=t&&t[1]||"",t1=-1<e.stack.indexOf("\n    at")?" (<anonymous>)":-1<e.stack.indexOf("@")?"@unknown:0:0":""}return"\n"+t0+e+t1}var ec=!1;function eu(e,t){if(!e||ec)return"";ec=!0;var r=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var n={DetermineComponentFrameRoot:function(){try{if(t){var r=function(){throw Error()};if(Object.defineProperty(r.prototype,"props",{set:function(){throw Error()}}),"object"==typeof Reflect&&Reflect.construct){try{Reflect.construct(r,[])}catch(e){var n=e}Reflect.construct(e,[],r)}else{try{r.call()}catch(e){n=e}r=!1;try{var o=Object.getOwnPropertyDescriptor(e.prototype,"props");Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),r=!0,new e}finally{r&&(void 0!==o?Object.defineProperty(e.prototype,"props",o):delete e.prototype.props)}}}else{try{throw Error()}catch(e){n=e}(r=e())&&"function"==typeof r.catch&&r.catch(function(){})}}catch(e){if(e&&n&&"string"==typeof e.stack)return[e.stack,n.stack]}return[null,null]}};n.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var o=Object.getOwnPropertyDescriptor(n.DetermineComponentFrameRoot,"name");o&&o.configurable&&Object.defineProperty(n.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var a=n.DetermineComponentFrameRoot(),i=a[0],s=a[1];if(i&&s){var l=i.split("\n"),c=s.split("\n");for(o=n=0;n<l.length&&!l[n].includes("DetermineComponentFrameRoot");)n++;for(;o<c.length&&!c[o].includes("DetermineComponentFrameRoot");)o++;if(n===l.length||o===c.length)for(n=l.length-1,o=c.length-1;1<=n&&0<=o&&l[n]!==c[o];)o--;for(;1<=n&&0<=o;n--,o--)if(l[n]!==c[o]){if(1!==n||1!==o)do if(n--,o--,0>o||l[n]!==c[o]){var u="\n"+l[n].replace(" at new "," at ");return e.displayName&&u.includes("<anonymous>")&&(u=u.replace("<anonymous>",e.displayName)),u}while(1<=n&&0<=o);break}}}finally{ec=!1,Error.prepareStackTrace=r}return(r=e?e.displayName||e.name:"")?el(r):""}function ed(e){try{var t="",r=null;do t+=function(e,t){switch(e.tag){case 26:case 27:case 5:return el(e.type);case 16:return el("Lazy");case 13:return e.child!==t&&null!==t?el("Suspense Fallback"):el("Suspense");case 19:return el("SuspenseList");case 0:case 15:return eu(e.type,!1);case 11:return eu(e.type.render,!1);case 1:return eu(e.type,!0);case 31:return el("Activity");case 30:return el("ViewTransition");default:return""}}(e,r),r=e,e=e.return;while(e);return t}catch(e){return"\nError generating stack: "+e.message+"\n"+e.stack}}var ef=Object.prototype.hasOwnProperty,ep=o.unstable_scheduleCallback,eh=o.unstable_cancelCallback,em=o.unstable_shouldYield,eg=o.unstable_requestPaint,ev=o.unstable_now,ex=o.unstable_getCurrentPriorityLevel,ey=o.unstable_ImmediatePriority,eb=o.unstable_UserBlockingPriority,ew=o.unstable_NormalPriority,e_=o.unstable_LowPriority,ek=o.unstable_IdlePriority,ej=o.log,eS=o.unstable_setDisableYieldValue,eC=null,eE=null;function eT(e){if("function"==typeof ej&&eS(e),eE&&"function"==typeof eE.setStrictMode)try{eE.setStrictMode(eC,e)}catch(e){}}var eN=Math.clz32?Math.clz32:function(e){return 0==(e>>>=0)?32:31-(eI(e)/ez|0)|0},eI=Math.log,ez=Math.LN2,eR=256,eP=262144,eL=4194304;function eO(e){var t=42&e;if(0!==t)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return 3932160&e;case 4194304:case 8388608:case 0x1000000:case 0x2000000:return 0x3c00000&e;case 0x4000000:return 0x4000000;case 0x8000000:return 0x8000000;case 0x10000000:return 0x10000000;case 0x20000000:return 0x20000000;case 0x40000000:return 0;default:return e}}function eM(e,t,r){var n=e.pendingLanes;if(0===n)return 0;var o=0,a=e.suspendedLanes,i=e.pingedLanes;e=e.warmLanes;var s=0x7ffffff&n;return 0!==s?0!=(n=s&~a)?o=eO(n):0!=(i&=s)?o=eO(i):r||0!=(r=s&~e)&&(o=eO(r)):0!=(s=n&~a)?o=eO(s):0!==i?o=eO(i):r||0!=(r=n&~e)&&(o=eO(r)),0===o?0:0!==t&&t!==o&&0==(t&a)&&((a=o&-o)>=(r=t&-t)||32===a&&0!=(4194048&r))?t:o}function eA(e,t){return 0==(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)}function eD(e,t){0!=(8&t)&&(t|=32&t);var r=e.entangledLanes;if(0!==r)for(e=e.entanglements,r&=t;0<r;){var n=31-eN(r),o=1<<n;t|=e[n],r&=~o}return t}function eF(){var e=eL;return 0==(0x3c00000&(eL<<=1))&&(eL=4194304),e}function e$(e){for(var t=[],r=0;31>r;r++)t.push(e);return t}function eU(e,t){e.pendingLanes|=t,0x10000000!==t&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function eZ(e,t,r){e.pendingLanes|=t,e.suspendedLanes&=~t;var n=31-eN(t);e.entangledLanes|=t,e.entanglements[n]=0x40000000|e.entanglements[n]|261930&r}function eq(e,t){var r=e.entangledLanes|=t;for(e=e.entanglements;r;){var n=31-eN(r),o=1<<n;o&t|e[n]&t&&(e[n]|=t),r&=~o}}function eB(e,t){var r=t&-t;return 0!=((r=0!=(42&r)?1:eV(r))&(e.suspendedLanes|t))?0:r}function eV(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 0x1000000:case 0x2000000:e=128;break;case 0x10000000:e=0x8000000;break;default:e=0}return e}function eH(e){return 2<(e&=-e)?8<e?0!=(0x7ffffff&e)?32:0x10000000:8:2}function eW(){var e=W.p;return 0!==e?e:void 0===(e=window.event)?32:dQ(e.type)}function eG(e,t){var r=W.p;try{return W.p=e,t()}finally{W.p=r}}var eK=Math.random().toString(36).slice(2),eY="__reactFiber$"+eK,eX="__reactProps$"+eK,eQ="__reactContainer$"+eK,eJ="__reactEvents$"+eK,e0="__reactListeners$"+eK,e1="__reactHandles$"+eK,e2="__reactResources$"+eK,e3="__reactMarker$"+eK,e5="__reactLoad$"+eK;function e4(e){delete e[eY],delete e[eX],delete e[e0],delete e[e1]}function e6(e){var t;if(t=e[eY])return t;for(var r=e.parentNode;r;){if(t=r[eQ]||r[eY]){if(r=t.alternate,null!==t.child||null!==r&&null!==r.child)for(e=dn(e);null!==e;){if(r=e[eY])return r;e=dn(e)}return t}r=(e=r).parentNode}return null}function e7(e){if(e=e[eY]||e[eQ]){var t=e.tag;if(5===t||6===t||13===t||31===t||26===t||27===t||3===t)return e}return null}function e9(e){var t=e.tag;if(5===t||26===t||27===t||6===t)return e.stateNode;throw Error(s(33))}function e8(e){var t=e[e2];return t||(t=e[e2]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function te(e){e[e3]=!0}function tt(e){e[e5]=void 0}var tr=new Set,tn={};function to(e,t){ta(e,t),ta(e+"Capture",t)}function ta(e,t){for(tn[e]=t,e=0;e<t.length;e++)tr.add(t[e])}var ti=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),ts={},tl={},tc=!1;function tu(){var e=tc;return tc=!1,e}function td(e,t,r){if(ef.call(tl,t)||!ef.call(ts,t)&&(ti.test(t)?tl[t]=!0:(ts[t]=!0,!1)))if(null===r)e.removeAttribute(t);else{switch(typeof r){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var n=t.toLowerCase().slice(0,5);if("data-"!==n&&"aria-"!==n)return void e.removeAttribute(t)}e.setAttribute(t,r)}}function tf(e,t,r){if(null===r)e.removeAttribute(t);else{switch(typeof r){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,r)}}function tp(e,t,r,n){if(null===n)e.removeAttribute(r);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(r);return}e.setAttributeNS(t,r,n)}}function th(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":case"object":return e;default:return""}}function tm(e){var t=e.type;return(e=e.nodeName)&&"input"===e.toLowerCase()&&("checkbox"===t||"radio"===t)}function tg(e){if(!e._valueTracker){var t=tm(e)?"checked":"value";e._valueTracker=function(e,t,r){var n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&void 0!==n&&"function"==typeof n.get&&"function"==typeof n.set){var o=n.get,a=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return o.call(this)},set:function(e){r=""+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(e){r=""+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}(e,t,""+e[t])}}function tv(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var r=t.getValue(),n="";return e&&(n=tm(e)?e.checked?"true":"false":e.value),(e=n)!==r&&(t.setValue(e),!0)}var tx=/[\n"\\]/g;function ty(e){return e.replace(tx,function(e){return"\\"+e.charCodeAt(0).toString(16)+" "})}function tb(e,t,r,n,o,a,i,s){e.name="",null!=i&&"function"!=typeof i&&"symbol"!=typeof i&&"boolean"!=typeof i?e.type=i:e.removeAttribute("type"),null!=t?"number"===i?(0===t&&""===e.value||e.value!=t)&&(e.value=""+th(t)):e.value!==""+th(t)&&(e.value=""+th(t)):"submit"!==i&&"reset"!==i||e.removeAttribute("value"),null!=t?"number"===i&&e.value==t?t_(e,th(e.value)):t_(e,th(t)):null!=r?t_(e,th(r)):null!=n&&e.removeAttribute("value"),null==o&&null!=a&&(e.defaultChecked=!!a),null!=o&&(e.checked=o&&"function"!=typeof o&&"symbol"!=typeof o),null!=s&&"function"!=typeof s&&"symbol"!=typeof s&&"boolean"!=typeof s?e.name=""+th(s):e.removeAttribute("name")}function tw(e,t,r,n,o,a,i,s){if(null!=a&&"function"!=typeof a&&"symbol"!=typeof a&&"boolean"!=typeof a&&(e.type=a),null!=t||null!=r){if(("submit"===a||"reset"===a)&&null==t)return void tg(e);r=null!=r?""+th(r):"",t=null!=t?""+th(t):r,s||t===e.value||(e.value=t),e.defaultValue=t}n="function"!=typeof(n=null!=n?n:o)&&"symbol"!=typeof n&&!!n,e.checked=s?e.checked:!!n,e.defaultChecked=!!n,null!=i&&"function"!=typeof i&&"symbol"!=typeof i&&"boolean"!=typeof i&&(e.name=i),tg(e)}function t_(e,t){e.defaultValue!==""+t&&(e.defaultValue=""+t)}function tk(e,t,r,n){if(e=e.options,t){t={};for(var o=0;o<r.length;o++)t["$"+r[o]]=!0;for(r=0;r<e.length;r++)o=t.hasOwnProperty("$"+e[r].value),e[r].selected!==o&&(e[r].selected=o),o&&n&&(e[r].defaultSelected=!0)}else{for(o=0,r=""+th(r),t=null;o<e.length;o++){if(e[o].value===r){e[o].selected=!0,n&&(e[o].defaultSelected=!0);return}null!==t||e[o].disabled||(t=e[o])}null!==t&&(t.selected=!0)}}function tj(e,t,r){if(null!=t&&((t=""+th(t))!==e.value&&(e.value=t),null==r)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=null!=r?""+th(r):""}function tS(e,t,r,n){if(null==t){if(null!=n){if(null!=r)throw Error(s(92));if(V(n)){if(1<n.length)throw Error(s(93));n=n[0]}r=n}null==r&&(r=""),t=r}e.defaultValue=r=th(t),(n=e.textContent)===r&&""!==n&&null!==n&&(e.value=n),tg(e)}function tC(e,t){if(t){var r=e.firstChild;if(r&&r===e.lastChild&&3===r.nodeType){r.nodeValue=t;return}}e.textContent=t}var tE=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function tT(e,t,r){var n=0===t.indexOf("--");null==r||"boolean"==typeof r||""===r?n?e.setProperty(t,""):"float"===t?e.cssFloat="":e[t]="":n?e.setProperty(t,r):"number"!=typeof r||0===r||tE.has(t)?"float"===t?e.cssFloat=r:e[t]=(""+r).trim():e[t]=r+"px"}function tN(e,t,r){if(null!=t&&"object"!=typeof t)throw Error(s(62));if(e=e.style,null!=r){for(var n in r)!r.hasOwnProperty(n)||null!=t&&t.hasOwnProperty(n)||(0===n.indexOf("--")?e.setProperty(n,""):"float"===n?e.cssFloat="":e[n]="",tc=!0);for(var o in t)n=t[o],t.hasOwnProperty(o)&&r[o]!==n&&(tT(e,o,n),tc=!0)}else for(var a in t)t.hasOwnProperty(a)&&tT(e,a,t[a])}function tI(e){if(-1===e.indexOf("-"))return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var tz=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),tR=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function tP(e){return tR.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function tL(){}var tO=null;function tM(e){return(e=e.target||e.srcElement||window).correspondingUseElement&&(e=e.correspondingUseElement),3===e.nodeType?e.parentNode:e}var tA=null,tD=null;function tF(e){var t=e7(e);if(t&&(e=t.stateNode)){var r=e[eX]||null;switch(e=t.stateNode,t.type){case"input":if(tb(e,r.value,r.defaultValue,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name),t=r.name,"radio"===r.type&&null!=t){for(r=e;r.parentNode;)r=r.parentNode;for(r=r.querySelectorAll('input[name="'+ty(""+t)+'"][type="radio"]'),t=0;t<r.length;t++){var n=r[t];if(n!==e&&n.form===e.form){var o=n[eX]||null;if(!o)throw Error(s(90));tb(n,o.value,o.defaultValue,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name)}}for(t=0;t<r.length;t++)(n=r[t]).form===e.form&&tv(n)}break;case"textarea":tj(e,r.value,r.defaultValue);break;case"select":null!=(t=r.value)&&tk(e,!!r.multiple,t,!1)}}}var t$=!1;function tU(e,t,r){if(t$)return e(t,r);t$=!0;try{return e(t)}finally{if(t$=!1,(null!==tA||null!==tD)&&(cf(),tA&&(t=tA,e=tD,tD=tA=null,tF(t),e)))for(t=0;t<e.length;t++)tF(e[t])}}function tZ(e,t){var r=e.stateNode;if(null===r)return null;var n=r[eX]||null;if(null===n)return null;switch(r=n[t],t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(n=!n.disabled)||(n="button"!==(e=e.type)&&"input"!==e&&"select"!==e&&"textarea"!==e),e=!n;break;default:e=!1}if(e)return null;if(r&&"function"!=typeof r)throw Error(s(231,t,typeof r));return r}var tq="undefined"!=typeof window&&void 0!==window.document&&void 0!==window.document.createElement,tB=!1;if(tq)try{var tV={};Object.defineProperty(tV,"passive",{get:function(){tB=!0}}),window.addEventListener("test",tV,tV),window.removeEventListener("test",tV,tV)}catch(e){tB=!1}var tH=null,tW=null,tG=null;function tK(){if(tG)return tG;var e,t,r=tW,n=r.length,o="value"in tH?tH.value:tH.textContent,a=o.length;for(e=0;e<n&&r[e]===o[e];e++);var i=n-e;for(t=1;t<=i&&r[n-t]===o[a-t];t++);return tG=o.slice(e,1<t?1-t:void 0)}function tY(e){var t=e.keyCode;return"charCode"in e?0===(e=e.charCode)&&13===t&&(e=13):e=t,10===e&&(e=13),32<=e||13===e?e:0}function tX(){return!0}function tQ(){return!1}function tJ(e){function t(t,r,n,o,a){for(var i in this._reactName=t,this._targetInst=n,this.type=r,this.nativeEvent=o,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(i)&&(t=e[i],this[i]=t?t(o):o[i]);return this.isDefaultPrevented=(null!=o.defaultPrevented?o.defaultPrevented:!1===o.returnValue)?tX:tQ,this.isPropagationStopped=tQ,this}return k(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():"unknown"!=typeof e.returnValue&&(e.returnValue=!1),this.isDefaultPrevented=tX)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():"unknown"!=typeof e.cancelBubble&&(e.cancelBubble=!0),this.isPropagationStopped=tX)},persist:function(){},isPersistent:tX}),t}var t0,t1,t2,t3,t5,t4={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},t6=tJ(t4),t7=k({},t4,{view:0,detail:0}),t9=tJ(t7),t8=k({},t7,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ru,button:0,buttons:0,relatedTarget:function(e){return void 0===e.relatedTarget?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==t5&&(t5&&"mousemove"===e.type?(t2=e.screenX-t5.screenX,t3=e.screenY-t5.screenY):t3=t2=0,t5=e),t2)},movementY:function(e){return"movementY"in e?e.movementY:t3}}),re=tJ(t8),rt=tJ(k({},t8,{dataTransfer:0})),rr=tJ(k({},t7,{relatedTarget:0})),rn=tJ(k({},t4,{animationName:0,elapsedTime:0,pseudoElement:0})),ro=tJ(k({},t4,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}})),ra=tJ(k({},t4,{data:0})),ri={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},rs={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},rl={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function rc(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):!!(e=rl[e])&&!!t[e]}function ru(){return rc}var rd=tJ(k({},t7,{key:function(e){if(e.key){var t=ri[e.key]||e.key;if("Unidentified"!==t)return t}return"keypress"===e.type?13===(e=tY(e))?"Enter":String.fromCharCode(e):"keydown"===e.type||"keyup"===e.type?rs[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ru,charCode:function(e){return"keypress"===e.type?tY(e):0},keyCode:function(e){return"keydown"===e.type||"keyup"===e.type?e.keyCode:0},which:function(e){return"keypress"===e.type?tY(e):"keydown"===e.type||"keyup"===e.type?e.keyCode:0}})),rf=tJ(k({},t8,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),rp=tJ(k({},t4,{submitter:0})),rh=tJ(k({},t7,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ru})),rm=tJ(k({},t4,{propertyName:0,elapsedTime:0,pseudoElement:0})),rg=tJ(k({},t8,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),rv=tJ(k({},t4,{newState:0,oldState:0,source:0})),rx=[9,13,27,32],ry=tq&&"CompositionEvent"in window,rb=null;tq&&"documentMode"in document&&(rb=document.documentMode);var rw=tq&&"TextEvent"in window&&!rb,r_=tq&&(!ry||rb&&8<rb&&11>=rb),rk=!1;function rj(e,t){switch(e){case"keyup":return -1!==rx.indexOf(t.keyCode);case"keydown":return 229!==t.keyCode;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function rS(e){return"object"==typeof(e=e.detail)&&"data"in e?e.data:null}var rC=!1,rE={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function rT(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return"input"===t?!!rE[e.type]:"textarea"===t}function rN(e,t,r,n){tA?tD?tD.push(n):tD=[n]:tA=n,0<(t=ua(t,"onChange")).length&&(r=new t6("onChange","change",null,r,n),e.push({event:r,listeners:t}))}var rI=null,rz=null;function rR(e){c7(e,0)}function rP(e){if(tv(e9(e)))return e}function rL(e,t){if("change"===e)return t}var rO=!1;if(tq){if(tq){var rM="oninput"in document;if(!rM){var rA=document.createElement("div");rA.setAttribute("oninput","return;"),rM="function"==typeof rA.oninput}n=rM}else n=!1;rO=n&&(!document.documentMode||9<document.documentMode)}function rD(){rI&&(rI.detachEvent("onpropertychange",rF),rz=rI=null)}function rF(e){if("value"===e.propertyName&&rP(rz)){var t=[];rN(t,rz,e,tM(e)),tU(rR,t)}}function r$(e,t,r){"focusin"===e?(rD(),rI=t,rz=r,rI.attachEvent("onpropertychange",rF)):"focusout"===e&&rD()}function rU(e){if("selectionchange"===e||"keyup"===e||"keydown"===e)return rP(rz)}function rZ(e,t){if("click"===e)return rP(t)}function rq(e,t){if("input"===e||"change"===e)return rP(t)}var rB="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t};function rV(e,t){if(rB(e,t))return!0;if("object"!=typeof e||null===e||"object"!=typeof t||null===t)return!1;var r=Object.keys(e),n=Object.keys(t);if(r.length!==n.length)return!1;for(n=0;n<r.length;n++){var o=r[n];if(!ef.call(t,o)||!rB(e[o],t[o]))return!1}return!0}function rH(e){if(void 0===(e=e||("undefined"!=typeof document?document:void 0)))return null;try{return e.activeElement||e.body}catch(t){return e.body}}function rW(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function rG(e,t){var r,n=rW(e);for(e=0;n;){if(3===n.nodeType){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=rW(n)}}function rK(e){e=null!=e&&null!=e.ownerDocument&&null!=e.ownerDocument.defaultView?e.ownerDocument.defaultView:window;for(var t=rH(e.document);t instanceof e.HTMLIFrameElement;){try{var r="string"==typeof t.contentWindow.location.href}catch(e){r=!1}if(r)e=t.contentWindow;else break;t=rH(e.document)}return t}function rY(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&("input"===t&&("text"===e.type||"search"===e.type||"tel"===e.type||"url"===e.type||"password"===e.type)||"textarea"===t||"true"===e.contentEditable)}var rX=tq&&"documentMode"in document&&11>=document.documentMode,rQ=null,rJ=null,r0=null,r1=!1;function r2(e,t,r){var n=r.window===r?r.document:9===r.nodeType?r:r.ownerDocument;r1||null==rQ||rQ!==rH(n)||(n="selectionStart"in(n=rQ)&&rY(n)?{start:n.selectionStart,end:n.selectionEnd}:{anchorNode:(n=(n.ownerDocument&&n.ownerDocument.defaultView||window).getSelection()).anchorNode,anchorOffset:n.anchorOffset,focusNode:n.focusNode,focusOffset:n.focusOffset},r0&&rV(r0,n)||(r0=n,0<(n=ua(rJ,"onSelect")).length&&(t=new t6("onSelect","select",null,t,r),e.push({event:t,listeners:n}),t.target=rQ)))}function r3(e,t){var r={};return r[e.toLowerCase()]=t.toLowerCase(),r["Webkit"+e]="webkit"+t,r["Moz"+e]="moz"+t,r}var r5={animationcancel:r3("Animation","AnimationCancel"),animationend:r3("Animation","AnimationEnd"),animationiteration:r3("Animation","AnimationIteration"),animationstart:r3("Animation","AnimationStart"),transitionrun:r3("Transition","TransitionRun"),transitionstart:r3("Transition","TransitionStart"),transitioncancel:r3("Transition","TransitionCancel"),transitionend:r3("Transition","TransitionEnd")},r4={},r6={};function r7(e){if(r4[e])return r4[e];if(!r5[e])return e;var t,r=r5[e];for(t in r)if(r.hasOwnProperty(t)&&t in r6)return r4[e]=r[t];return e}tq&&(r6=document.createElement("div").style,"AnimationEvent"in window||(delete r5.animationcancel.animation,delete r5.animationend.animation,delete r5.animationiteration.animation,delete r5.animationstart.animation),"TransitionEvent"in window||delete r5.transitionend.transition);var r9=r7("animationcancel"),r8=r7("animationend"),ne=r7("animationiteration"),nt=r7("animationstart"),nr=r7("transitionrun"),nn=r7("transitionstart"),no=r7("transitioncancel"),na=r7("transitionend"),ni=new Map,ns="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function nl(e,t){ni.set(e,t),to(t,[e])}ns.push("scrollEnd");var nc=0;function nu(e,t){return null!=e.name&&"auto"!==e.name?e.name:null!==t.autoName?t.autoName:t.autoName=e="_"+(e=l5.identifierPrefix)+"t_"+(nc++).toString(32)+"_"}function nd(e){if(null==e||"string"==typeof e)return e;var t=null,r=cr;if(null!==r)for(var n=0;n<r.length;n++){var o=e[r[n]];if(null!=o){if("none"===o)return"none";t=null==t?o:t+" "+o}}return null==t?e.default:t}function nf(e,t){return e=nd(e),null==(t=nd(t))?"auto"===e?null:e:"auto"===t?null:t}var np="function"==typeof reportError?reportError:function(e){if("object"==typeof window&&"function"==typeof window.ErrorEvent){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:"object"==typeof e&&null!==e&&"string"==typeof e.message?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if("object"==typeof process&&"function"==typeof process.emit)return void process.emit("uncaughtException",e);console.error(e)},nh=[],nm=0,ng=0;function nv(){for(var e=nm,t=ng=nm=0;t<e;){var r=nh[t];nh[t++]=null;var n=nh[t];nh[t++]=null;var o=nh[t];nh[t++]=null;var a=nh[t];if(nh[t++]=null,null!==n&&null!==o){var i=n.pending;null===i?o.next=o:(o.next=i.next,i.next=o),n.pending=o}0!==a&&nw(r,o,a)}}function nx(e,t,r,n){nh[nm++]=e,nh[nm++]=t,nh[nm++]=r,nh[nm++]=n,ng|=n,e.lanes|=n,null!==(e=e.alternate)&&(e.lanes|=n)}function ny(e,t,r,n){return nx(e,t,r,n),n_(e)}function nb(e,t){return nx(e,null,null,t),n_(e)}function nw(e,t,r){e.lanes|=r;var n=e.alternate;null!==n&&(n.lanes|=r);for(var o=!1,a=e.return;null!==a;)a.childLanes|=r,null!==(n=a.alternate)&&(n.childLanes|=r),22===a.tag&&(null===(e=a.stateNode)||1&e._visibility||(o=!0)),e=a,a=a.return;return 3===e.tag?(a=e.stateNode,o&&null!==t&&(o=31-eN(r),null===(n=(e=a.hiddenUpdates)[o])?e[o]=[t]:n.push(t),t.lane=0x20000000|r),a):null}function n_(e){if(50<cn)throw cn=0,co=null,Error(s(185));for(var t=e.return;null!==t;)t=(e=t).return;return 3===e.tag?e.stateNode:null}var nk={};function nj(e,t,r,n){this.tag=e,this.key=r,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=n,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function nS(e,t,r,n){return new nj(e,t,r,n)}function nC(e){return!(!(e=e.prototype)||!e.isReactComponent)}function nE(e,t){var r=e.alternate;return null===r?((r=nS(e.tag,t,e.key,e.mode)).elementType=e.elementType,r.type=e.type,r.stateNode=e.stateNode,r.alternate=e,e.alternate=r):(r.pendingProps=t,r.type=e.type,r.flags=0,r.subtreeFlags=0,r.deletions=null),r.flags=0x47f00000&e.flags,r.childLanes=e.childLanes,r.lanes=e.lanes,r.child=e.child,r.memoizedProps=e.memoizedProps,r.memoizedState=e.memoizedState,r.updateQueue=e.updateQueue,t=e.dependencies,r.dependencies=null===t?null:{lanes:t.lanes,firstContext:t.firstContext},r.sibling=e.sibling,r.index=e.index,r.ref=e.ref,r.refCleanup=e.refCleanup,r}function nT(e,t){e.flags&=0x47f00002;var r=e.alternate;return null===r?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=r.childLanes,e.lanes=r.lanes,e.child=r.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=r.memoizedProps,e.memoizedState=r.memoizedState,e.updateQueue=r.updateQueue,e.type=r.type,e.dependencies=null===(t=r.dependencies)?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function nN(e,t,r,n,o,a){var i=0;if("function"==typeof(n=e))nC(n)&&(i=1);else if("string"==typeof n)i=!function(e,t,r){if(1===r||null!=t.itemProp)return!1;switch(e){case"meta":case"title":return!0;case"style":if("string"!=typeof t.precedence||"string"!=typeof t.href||""===t.href)break;return!0;case"link":if("string"!=typeof t.rel||"string"!=typeof t.href||""===t.href||t.onLoad||t.onError)break;if("stylesheet"===t.rel)return e=t.disabled,"string"==typeof t.precedence&&null==e;return!0;case"script":if(t.async&&"function"!=typeof t.async&&"symbol"!=typeof t.async&&!t.onLoad&&!t.onError&&t.src&&"string"==typeof t.src)return!0}return!1}(e,r,ee.current)?"html"===e||"head"===e||"body"===e?27:5:26;else e:switch(n){case A:return(e=nS(31,r,t,o)).elementType=A,e.lanes=a,e;case E:return nI(r.children,o,a,t);case T:i=8,o|=24;break;case N:return(e=nS(12,r,t,2|o)).elementType=N,e.lanes=a,e;case P:return(e=nS(13,r,t,o)).elementType=P,e.lanes=a,e;case L:return(e=nS(19,r,t,o)).elementType=L,e.lanes=a,e;case D:case $:return(e=nS(30,r,t,e=32|o)).elementType=$,e.lanes=a,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if("object"==typeof n&&null!==n)switch(n.$$typeof){case z:i=10;break e;case I:i=9;break e;case R:i=11;break e;case O:i=14;break e;case M:i=16,n=null;break e}i=29,r=Error(s(130,null===e?"null":typeof e,"")),n=null}return(t=nS(i,r,t,o)).elementType=e,t.type=n,t.lanes=a,t}function nI(e,t,r,n){return(e=nS(7,e,n,t)).lanes=r,e}function nz(e,t,r){return(e=nS(6,e,null,t)).lanes=r,e}function nR(e){var t=nS(18,null,null,0);return t.stateNode=e,t}function nP(e,t,r){return(t=nS(4,null!==e.children?e.children:[],e.key,t)).lanes=r,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var nL=new WeakMap;function nO(e,t){if("object"==typeof e&&null!==e){var r=nL.get(e);return void 0!==r?r:(t={value:e,source:t,stack:ed(t)},nL.set(e,t),t)}return{value:e,source:t,stack:ed(t)}}var nM=[],nA=0,nD=null,nF=0,n$=[],nU=0,nZ=null,nq=1,nB="";function nV(e,t){nM[nA++]=nF,nM[nA++]=nD,nD=e,nF=t}function nH(e,t,r){n$[nU++]=nq,n$[nU++]=nB,n$[nU++]=nZ,nZ=e;var n=nq;e=nB;var o=32-eN(n)-1;n&=~(1<<o),r+=1;var a=32-eN(t)+o;if(30<a){var i=o-o%5;a=(n&(1<<i)-1).toString(32),n>>=i,o-=i,nq=1<<32-eN(t)+o|r<<o|n,nB=a+e}else nq=1<<a|r<<o|n,nB=e}function nW(e){null!==e.return&&(nV(e,1),nH(e,1,0))}function nG(e){for(;e===nD;)nD=nM[--nA],nM[nA]=null,nF=nM[--nA],nM[nA]=null;for(;e===nZ;)nZ=n$[--nU],n$[nU]=null,nB=n$[--nU],n$[nU]=null,nq=n$[--nU],n$[nU]=null}function nK(e,t){n$[nU++]=nq,n$[nU++]=nB,n$[nU++]=nZ,nq=t.id,nB=t.overflow,nZ=e}var nY=null,nX=null,nQ=!1,nJ=null,n0=!1,n1=Error(s(519));function n2(e){var t=Error(s(418,1<arguments.length&&void 0!==arguments[1]&&arguments[1]?"text":"HTML",""));throw n9(nO(t,e)),n1}function n3(e){var t=e.stateNode,r=e.type,n=e.memoizedProps;switch(t[eY]=e,t[eX]=n,r){case"dialog":c9("cancel",t),c9("close",t);break;case"iframe":case"object":case"embed":c9("load",t);break;case"video":case"audio":for(r=0;r<c4.length;r++)c9(c4[r],t);break;case"source":c9("error",t);break;case"img":case"image":case"link":c9("error",t),c9("load",t);break;case"details":c9("toggle",t);break;case"input":c9("invalid",t),tw(t,n.value,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name,!0);break;case"select":c9("invalid",t);break;case"textarea":c9("invalid",t),tS(t,n.value,n.defaultValue,n.children)}"string"!=typeof(r=n.children)&&"number"!=typeof r&&"bigint"!=typeof r||t.textContent===""+r||!0===n.suppressHydrationWarning||ud(t.textContent,r)?(null!=n.popover&&(c9("beforetoggle",t),c9("toggle",t)),null!=n.onScroll&&c9("scroll",t),null!=n.onScrollEnd&&c9("scrollend",t),null!=n.onClick&&(t.onclick=tL),t=!0):t=!1,t||n2(e,!0)}function n5(e){for(nY=e.return;nY;)switch(nY.tag){case 5:case 31:case 13:n0=!1;return;case 27:case 3:n0=!0;return;default:nY=nY.return}}function n4(e){if(e!==nY)return!1;if(!nQ)return n5(e),nQ=!0,!1;var t,r=e.tag;if((t=3!==r&&27!==r)&&((t=5===r)&&(t="form"===(t=e.type)||"button"===t||uk(e.type,e.memoizedProps)),t=!t),t&&nX&&n2(e),n5(e),13===r){if(!(e=null!==(e=e.memoizedState)?e.dehydrated:null))throw Error(s(317));nX=dr(e)}else if(31===r){if(!(e=null!==(e=e.memoizedState)?e.dehydrated:null))throw Error(s(317));nX=dr(e)}else 27===r?(r=nX,uz(e.type)?(e=dt,dt=null,nX=e):nX=r):nX=nY?de(e.stateNode.nextSibling):null;return!0}function n6(){nX=nY=null,nQ=!1}function n7(){var e=nJ;return null!==e&&(null===lY?lY=e:lY.push.apply(lY,e),nJ=null),e}function n9(e){null===nJ?nJ=[e]:nJ.push(e)}var n8=X(null),oe=null,ot=null;function or(e,t,r){J(n8,t._currentValue),t._currentValue=r}function on(e){e._currentValue=n8.current,Q(n8)}function oo(e,t,r){for(;null!==e;){var n=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,null!==n&&(n.childLanes|=t)):null!==n&&(n.childLanes&t)!==t&&(n.childLanes|=t),e===r)break;e=e.return}}function oa(e,t,r,n){var o=e.child;for(null!==o&&(o.return=e);null!==o;){var a=o.dependencies;if(null!==a){var i=o.child;a=a.firstContext;e:for(;null!==a;){var l=a;a=o;for(var c=0;c<t.length;c++)if(l.context===t[c]){a.lanes|=r,null!==(l=a.alternate)&&(l.lanes|=r),oo(a.return,r,e),n||(i=null);break e}a=l.next}}else if(18===o.tag){if(null===(i=o.return))throw Error(s(341));i.lanes|=r,null!==(a=i.alternate)&&(a.lanes|=r),oo(i,r,e),i=null}else 13===o.tag&&null!==o.memoizedState&&null===o.memoizedState.dehydrated?(o.lanes|=r,null!==(i=o.alternate)&&(i.lanes|=r),oo(o.return,r,e),i=null!==(i=o.child)?i.sibling:null):i=o.child;if(null!==i)i.return=o;else for(i=o;null!==i;){if(i===e){i=null;break}if(null!==(o=i.sibling)){o.return=i.return,i=o;break}i=i.return}o=i}}function oi(e,t,r,n){e=null;for(var o=t,a=!1;null!==o;){if(!a){if(0!=(524288&o.flags))a=!0;else if(0!=(262144&o.flags))break}if(10===o.tag){var i=o.alternate;if(null===i)throw Error(s(387));if(null!==(i=i.memoizedProps)){var l=o.type;rB(o.pendingProps.value,i.value)||(null!==e?e.push(l):e=[l])}}else if(o===en.current){if(null===(i=o.alternate))throw Error(s(387));i.memoizedState.memoizedState!==o.memoizedState.memoizedState&&(null!==e?e.push(dD):e=[dD])}o=o.return}return null!==e&&oa(t,e,r,n),t.flags|=262144,null!==e}function os(e){for(e=e.firstContext;null!==e;){if(!rB(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function ol(e){oe=e,ot=null,null!==(e=e.dependencies)&&(e.firstContext=null)}function oc(e){return od(oe,e)}function ou(e,t){return null===oe&&ol(e),od(e,t)}function od(e,t){var r=t._currentValue;if(t={context:t,memoizedValue:r,next:null},null===ot){if(null===e)throw Error(s(308));ot=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else ot=ot.next=t;return r}var of="undefined"!=typeof AbortController?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(t,r){e.push(r)}};this.abort=function(){t.aborted=!0,e.forEach(function(e){return e()})}},op=o.unstable_scheduleCallback,oh=o.unstable_NormalPriority,om={$$typeof:z,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function og(){return{controller:new of,data:new Map,refCount:0}}function ov(e){e.refCount--,0===e.refCount&&op(oh,function(){e.controller.abort()})}function ox(e,t){if(0!=(4194048&e.pendingLanes)){var r=e.transitionTypes;for(null===r&&(r=e.transitionTypes=[]),e=0;e<t.length;e++){var n=t[e];-1===r.indexOf(n)&&r.push(n)}}}var oy=null,ob=null,ow=0,o_=0,ok=null;function oj(){if(0==--ow&&(oy=null,null!==ob)){null!==ok&&(ok.status="fulfilled");var e=ob;ob=null,o_=0,ok=null;for(var t=0;t<e.length;t++)(0,e[t])()}}var oS=H.S;H.S=function(e,t){if(lJ=ev(),"object"==typeof t&&null!==t&&"function"==typeof t.then&&function(e,t){if(null===ob){var r=ob=[];ow=0,o_=c1(),ok={status:"pending",value:void 0,then:function(e){r.push(e)}}}ow++,t.then(oj,oj)}(0,t),null!==oy)for(var r=cZ;null!==r;)ox(r,oy),r=r.next;if(null!==(r=e.types)){for(var n=cZ;null!==n;)ox(n,r),n=n.next;if(0!==o_){null===(n=oy)&&(n=oy=[]);for(var o=0;o<r.length;o++){var a=r[o];-1===n.indexOf(a)&&n.push(a)}}}null!==oS&&oS(e,t)};var oC=X(null);function oE(){var e=oC.current;return null!==e?e:lL.pooledCache}function oT(e,t){null===t?J(oC,oC.current):J(oC,t.pool)}function oN(){var e=oE();return null===e?null:{parent:om._currentValue,pool:e}}var oI=Error(s(460)),oz=Error(s(474)),oR=Error(s(542)),oP={then:function(){}};function oL(e){return"fulfilled"===(e=e.status)||"rejected"===e}function oO(e,t,r){switch(void 0===(r=e[r])?e.push(t):r!==t&&(t.then(tL,tL),t=r),t.status){case"fulfilled":return t.value;case"rejected":if(oF(e=t.reason),void 0===e&&!("reason"in t))throw Error(s(600));throw e;default:if("string"==typeof t.status)t.then(tL,tL);else{if(null!==(e=lL)&&100<e.shellSuspendCounter)throw Error(s(482));(e=t).status="pending",e.then(function(e){if("pending"===t.status){var r=t;r.status="fulfilled",r.value=e}},function(e){if("pending"===t.status){var r=t;r.status="rejected",r.reason=e}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw oF(e=t.reason),e}throw oA=t,oI}}function oM(e){try{return(0,e._init)(e._payload)}catch(e){if(null!==e&&"object"==typeof e&&"function"==typeof e.then)throw oA=e,oI;throw e}}var oA=null;function oD(){if(null===oA)throw Error(s(459));var e=oA;return oA=null,e}function oF(e){if(e===oI||e===oR)throw Error(s(483))}var o$=null,oU=0;function oZ(e){var t=oU;return oU+=1,null===o$&&(o$=[]),oO(o$,e,t)}function oq(e,t){e.ref=void 0!==(t=t.props.ref)?t:null}function oB(e,t){if(t.$$typeof===j)throw Error(s(525));throw Error(s(31,"[object Object]"===(e=Object.prototype.toString.call(t))?"object with keys {"+Object.keys(t).join(", ")+"}":e))}function oV(e){function t(t,r){if(e){var n=t.deletions;null===n?(t.deletions=[r],t.flags|=16):n.push(r)}}function r(r,n){if(!e)return null;for(;null!==n;)t(r,n),n=n.sibling;return null}function n(e){for(var t=new Map;null!==e;)null===e.key?t.set(e.index,e):t.set(e.key,e),e=e.sibling;return t}function o(e,t){return(e=nE(e,t)).index=0,e.sibling=null,e}function a(t,r,n){return(t.index=n,e)?null!==(n=t.alternate)?(n=n.index)<r?(t.flags|=2,r):n:(t.flags|=0x8000002,r):(t.flags|=1048576,r)}function i(t){return e&&null===t.alternate&&(t.flags|=0x8000002),t}function l(e,t,r,n){return null===t||6!==t.tag?(t=nz(r,e.mode,n)).return=e:(t=o(t,r)).return=e,t}function c(e,t,r,n){var a=r.type;return a===E?(oq(e=d(e,t,r.props.children,n,r.key),r),e):(null!==t&&(t.elementType===a||"object"==typeof a&&null!==a&&a.$$typeof===M&&oM(a)===t.type)?oq(t=o(t,r.props),r):oq(t=nN(r.type,r.key,r.props,null,e.mode,n),r),t.return=e,t)}function u(e,t,r,n){return null===t||4!==t.tag||t.stateNode.containerInfo!==r.containerInfo||t.stateNode.implementation!==r.implementation?(t=nP(r,e.mode,n)).return=e:(t=o(t,r.children||[])).return=e,t}function d(e,t,r,n,a){return null===t||7!==t.tag?(t=nI(r,e.mode,n,a)).return=e:(t=o(t,r)).return=e,t}function f(e,t,r){if("string"==typeof t&&""!==t||"number"==typeof t||"bigint"==typeof t)return(t=nz(""+t,e.mode,r)).return=e,t;if("object"==typeof t&&null!==t){switch(t.$$typeof){case S:return oq(r=nN(t.type,t.key,t.props,null,e.mode,r),t),r.return=e,r;case C:return(t=nP(t,e.mode,r)).return=e,t;case M:return f(e,t=oM(t),r)}if(V(t)||q(t))return(t=nI(t,e.mode,r,null)).return=e,t;if("function"==typeof t.then)return f(e,oZ(t),r);if(t.$$typeof===z)return f(e,ou(e,t),r);oB(e,t)}return null}function p(e,t,r,n){var o=null!==t?t.key:null;if("string"==typeof r&&""!==r||"number"==typeof r||"bigint"==typeof r)return null!==o?null:l(e,t,""+r,n);if("object"==typeof r&&null!==r){switch(r.$$typeof){case S:return r.key===o?c(e,t,r,n):null;case C:return r.key===o?u(e,t,r,n):null;case M:return p(e,t,r=oM(r),n)}if(V(r)||q(r))return null!==o?null:d(e,t,r,n,null);if("function"==typeof r.then)return p(e,t,oZ(r),n);if(r.$$typeof===z)return p(e,t,ou(e,r),n);oB(e,r)}return null}function h(e,t,r,n,o){if("string"==typeof n&&""!==n||"number"==typeof n||"bigint"==typeof n)return l(t,e=e.get(r)||null,""+n,o);if("object"==typeof n&&null!==n){switch(n.$$typeof){case S:return c(t,e=e.get(null===n.key?r:n.key)||null,n,o);case C:return u(t,e=e.get(null===n.key?r:n.key)||null,n,o);case M:return h(e,t,r,n=oM(n),o)}if(V(n)||q(n))return d(t,e=e.get(r)||null,n,o,null);if("function"==typeof n.then)return h(e,t,r,oZ(n),o);if(n.$$typeof===z)return h(e,t,r,ou(t,n),o);oB(t,n)}return null}return function(l,c,u,d){try{oU=0;var m=function l(c,u,d,m){if("object"==typeof d&&null!==d&&d.type===E&&null===d.key&&void 0===d.props.ref&&(d=d.props.children),"object"==typeof d&&null!==d){switch(d.$$typeof){case S:e:{for(var g=d.key;null!==u;){if(u.key===g){if((g=d.type)===E){if(7===u.tag){r(c,u.sibling),oq(m=o(u,d.props.children),d),m.return=c,c=m;break e}}else if(u.elementType===g||"object"==typeof g&&null!==g&&g.$$typeof===M&&oM(g)===u.type){r(c,u.sibling),oq(m=o(u,d.props),d),m.return=c,c=m;break e}r(c,u);break}t(c,u),u=u.sibling}d.type===E?oq(m=nI(d.props.children,c.mode,m,d.key),d):oq(m=nN(d.type,d.key,d.props,null,c.mode,m),d),m.return=c,c=m}return i(c);case C:e:{for(g=d.key;null!==u;){if(u.key===g)if(4===u.tag&&u.stateNode.containerInfo===d.containerInfo&&u.stateNode.implementation===d.implementation){r(c,u.sibling),(m=o(u,d.children||[])).return=c,c=m;break e}else{r(c,u);break}t(c,u),u=u.sibling}(m=nP(d,c.mode,m)).return=c,c=m}return i(c);case M:return l(c,u,d=oM(d),m)}if(V(d))return function(o,i,s,l){for(var c=null,u=null,d=i,m=i=0,g=null;null!==d&&m<s.length;m++){d.index>m?(g=d,d=null):g=d.sibling;var v=p(o,d,s[m],l);if(null===v){null===d&&(d=g);break}e&&d&&null===v.alternate&&t(o,d),i=a(v,i,m),null===u?c=v:u.sibling=v,u=v,d=g}if(m===s.length)return r(o,d),nQ&&nV(o,m),c;if(null===d){for(;m<s.length;m++)null!==(d=f(o,s[m],l))&&(i=a(d,i,m),null===u?c=d:u.sibling=d,u=d);return nQ&&nV(o,m),c}for(d=n(d);m<s.length;m++)null!==(g=h(d,o,m,s[m],l))&&(e&&null!==(v=g.alternate)&&d.delete(null===v.key?m:v.key),i=a(g,i,m),null===u?c=g:u.sibling=g,u=g);return e&&d.forEach(function(e){return t(o,e)}),nQ&&nV(o,m),c}(c,u,d,m);if(q(d)){if("function"!=typeof(g=q(d)))throw Error(s(150));return function(o,i,l,c){if(null==l)throw Error(s(151));for(var u=null,d=null,m=i,g=i=0,v=null,x=l.next();null!==m&&!x.done;g++,x=l.next()){m.index>g?(v=m,m=null):v=m.sibling;var y=p(o,m,x.value,c);if(null===y){null===m&&(m=v);break}e&&m&&null===y.alternate&&t(o,m),i=a(y,i,g),null===d?u=y:d.sibling=y,d=y,m=v}if(x.done)return r(o,m),nQ&&nV(o,g),u;if(null===m){for(;!x.done;g++,x=l.next())null!==(x=f(o,x.value,c))&&(i=a(x,i,g),null===d?u=x:d.sibling=x,d=x);return nQ&&nV(o,g),u}for(m=n(m);!x.done;g++,x=l.next())null!==(x=h(m,o,g,x.value,c))&&(e&&null!==(v=x.alternate)&&m.delete(null===v.key?g:v.key),i=a(x,i,g),null===d?u=x:d.sibling=x,d=x);return e&&m.forEach(function(e){return t(o,e)}),nQ&&nV(o,g),u}(c,u,d=g.call(d),m)}if("function"==typeof d.then)return l(c,u,oZ(d),m);if(d.$$typeof===z)return l(c,u,ou(c,d),m);oB(c,d)}return"string"==typeof d&&""!==d||"number"==typeof d||"bigint"==typeof d?(d=""+d,null!==u&&6===u.tag?(r(c,u.sibling),(m=o(u,d)).return=c):(r(c,u),(m=nz(d,c.mode,m)).return=c),i(c=m)):r(c,u)}(l,c,u,d);return o$=null,m}catch(e){if(e===oI||e===oR)throw e;var g=nS(29,e,null,l.mode);return g.lanes=d,g.return=l,g}finally{}}}var oH=oV(!0),oW=oV(!1),oG=!1;function oK(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function oY(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function oX(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function oQ(e,t,r){var n=e.updateQueue;if(null===n)return null;if(n=n.shared,0!=(2&lP)){var o=n.pending;return null===o?t.next=t:(t.next=o.next,o.next=t),n.pending=t,t=n_(e),nw(e,null,r),t}return nx(e,n,t,r),n_(e)}function oJ(e,t,r){if(null!==(t=t.updateQueue)&&(t=t.shared,0!=(4194048&r))){var n=t.lanes;n&=e.pendingLanes,r|=n,t.lanes=r,eq(e,r)}}function o0(e,t){var r=e.updateQueue,n=e.alternate;if(null!==n&&r===(n=n.updateQueue)){var o=null,a=null;if(null!==(r=r.firstBaseUpdate)){do{var i={lane:r.lane,tag:r.tag,payload:r.payload,callback:null,next:null};null===a?o=a=i:a=a.next=i,r=r.next}while(null!==r);null===a?o=a=t:a=a.next=t}else o=a=t;r={baseState:n.baseState,firstBaseUpdate:o,lastBaseUpdate:a,shared:n.shared,callbacks:n.callbacks},e.updateQueue=r;return}null===(e=r.lastBaseUpdate)?r.firstBaseUpdate=t:e.next=t,r.lastBaseUpdate=t}var o1=!1;function o2(){if(o1){var e=ok;if(null!==e)throw e}}function o3(e,t,r,n){o1=!1;var o=e.updateQueue;oG=!1;var a=o.firstBaseUpdate,i=o.lastBaseUpdate,s=o.shared.pending;if(null!==s){o.shared.pending=null;var l=s,c=l.next;l.next=null,null===i?a=c:i.next=c,i=l;var u=e.alternate;null!==u&&(s=(u=u.updateQueue).lastBaseUpdate)!==i&&(null===s?u.firstBaseUpdate=c:s.next=c,u.lastBaseUpdate=l)}if(null!==a){var d=o.baseState;for(i=0,u=c=l=null,s=a;;){var f=-0x20000001&s.lane,p=f!==s.lane;if(p?(lM&f)===f:(n&f)===f){0!==f&&f===o_&&(o1=!0),null!==u&&(u=u.next={lane:0,tag:s.tag,payload:s.payload,callback:null,next:null});e:{var h=e,m=s;switch(f=t,m.tag){case 1:if("function"==typeof(h=m.payload)){d=h.call(r,d,f);break e}d=h;break e;case 3:h.flags=-65537&h.flags|128;case 0:if(null==(f="function"==typeof(h=m.payload)?h.call(r,d,f):h))break e;d=k({},d,f);break e;case 2:oG=!0}}null!==(f=s.callback)&&(e.flags|=64,p&&(e.flags|=8192),null===(p=o.callbacks)?o.callbacks=[f]:p.push(f))}else p={lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},null===u?(c=u=p,l=d):u=u.next=p,i|=f;if(null===(s=s.next))if(null===(s=o.shared.pending))break;else s=(p=s).next,p.next=null,o.lastBaseUpdate=p,o.shared.pending=null}null===u&&(l=d),o.baseState=l,o.firstBaseUpdate=c,o.lastBaseUpdate=u,null===a&&(o.shared.lanes=0),lB|=i,e.lanes=i,e.memoizedState=d}}function o5(e,t){if("function"!=typeof e)throw Error(s(191,e));e.call(t)}function o4(e,t){var r=e.callbacks;if(null!==r)for(e.callbacks=null,e=0;e<r.length;e++)o5(r[e],t)}var o6=X(null),o7=X(0);function o9(e,t){J(o7,e=lZ),J(o6,t),lZ=e|t.baseLanes}function o8(){J(o7,lZ),J(o6,o6.current)}function ae(){lZ=o7.current,Q(o6),Q(o7)}var at=X(null),ar=null;function an(e){var t=e.alternate;J(al,1&al.current),J(at,e),null===ar&&(null===t||null!==o6.current?ar=e:null!==t.memoizedState&&(ar=e))}function ao(e){J(al,al.current),J(at,e),null===ar&&(ar=e)}function aa(e){22===e.tag?(J(al,al.current),J(at,e),null===ar&&(ar=e)):ai()}function ai(){J(al,al.current),J(at,at.current)}function as(e){Q(at),ar===e&&(ar=null),Q(al)}var al=X(0);function ac(e,t){J(at,at.current),J(al,t)}function au(e){Q(al),Q(at),ar===e&&(ar=null)}function ad(e){for(var t=e;null!==t;){if(13===t.tag){var r=t.memoizedState;if(null!==r&&(null===(r=r.dehydrated)||u9(r)||u8(r)))return t}else if(19===t.tag&&"independent"!==t.memoizedProps.revealOrder){if(0!=(128&t.flags))return t}else if(null!==t.child){t.child.return=t,t=t.child;continue}if(t===e)break;for(;null===t.sibling;){if(null===t.return||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var af=0,ap=null,ah=null,am=null,ag=!1,av=!1,ax=!1,ay=0,ab=0,aw=null,a_=0;function ak(){throw Error(s(321))}function aj(e,t){if(null===t)return!1;for(var r=0;r<t.length&&r<e.length;r++)if(!rB(e[r],t[r]))return!1;return!0}function aS(e,t,r,n,o,a){return af=a,ap=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,H.H=null===e||null===e.memoizedState?iP:iL,ax=!1,a=r(n,o),ax=!1,av&&(a=aE(t,r,n,o)),aC(e),a}function aC(e){H.H=iR;var t=null!==ah&&null!==ah.next;if(af=0,am=ah=ap=null,ag=!1,ab=0,aw=null,t)throw Error(s(300));null===e||iY||null!==(e=e.dependencies)&&os(e)&&(iY=!0)}function aE(e,t,r,n){ap=e;var o=0;do{if(av&&(aw=null),ab=0,av=!1,25<=o)throw Error(s(301));if(o+=1,am=ah=null,null!=e.updateQueue){var a=e.updateQueue;a.lastEffect=null,a.events=null,a.stores=null,null!=a.memoCache&&(a.memoCache.index=0)}H.H=iO,a=t(r,n)}while(av);return a}function aT(){var e=H.H,t=e.useState()[0];return t="function"==typeof t.then?aO(t):t,e=e.useState()[0],(null!==ah?ah.memoizedState:null)!==e&&(ap.flags|=1024),t}function aN(){var e=0!==ay;return ay=0,e}function aI(e,t,r){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~r}function az(e){if(ag){for(e=e.memoizedState;null!==e;){var t=e.queue;null!==t&&(t.pending=null),e=e.next}ag=!1}af=0,am=ah=ap=null,av=!1,ab=ay=0,aw=null}function aR(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return null===am?ap.memoizedState=am=e:am=am.next=e,am}function aP(){if(null===ah){var e=ap.alternate;e=null!==e?e.memoizedState:null}else e=ah.next;var t=null===am?ap.memoizedState:am.next;if(null!==t)am=t,ah=e;else{if(null===e){if(null===ap.alternate)throw Error(s(467));throw Error(s(310))}e={memoizedState:(ah=e).memoizedState,baseState:ah.baseState,baseQueue:ah.baseQueue,queue:ah.queue,next:null},null===am?ap.memoizedState=am=e:am=am.next=e}return am}function aL(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function aO(e){var t=ab;return ab+=1,null===aw&&(aw=[]),e=oO(aw,e,t),t=ap,null===(null===am?t.memoizedState:am.next)&&(H.H=null===(t=t.alternate)||null===t.memoizedState?iP:iL),e}function aM(e){if(null!==e&&"object"==typeof e){if("function"==typeof e.then)return aO(e);if(e.$$typeof===U)return;if(e.$$typeof===z)return oc(e)}throw Error(s(438,String(e)))}function aA(e){var t=null,r=ap.updateQueue;if(null!==r&&(t=r.memoCache),null==t){var n=ap.alternate;null!==n&&null!==(n=n.updateQueue)&&null!=(n=n.memoCache)&&(t={data:n.data.map(function(e){return e.slice()}),index:0})}if(null==t&&(t={data:[],index:0}),null===r&&(r=aL(),ap.updateQueue=r),r.memoCache=t,void 0===(r=t.data[t.index]))for(r=t.data[t.index]=Array(e),n=0;n<e;n++)r[n]=F;return t.index++,r}function aD(e,t){return"function"==typeof t?t(e):t}function aF(e){return a$(aP(),ah,e)}function a$(e,t,r){var n=e.queue;if(null===n)throw Error(s(311));n.lastRenderedReducer=r;var o=e.baseQueue,a=n.pending;if(null!==a){if(null!==o){var i=o.next;o.next=a.next,a.next=i}t.baseQueue=o=a,n.pending=null}if(a=e.baseState,null===o)e.memoizedState=a;else{t=o.next;var l=i=null,c=null,u=t,d=!1;do{var f=-0x20000001&u.lane;if(f!==u.lane?(lM&f)===f:(af&f)===f){var p=u.revertLane;if(0===p)null!==c&&(c=c.next={lane:0,revertLane:0,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),f===o_&&(d=!0);else if((af&p)===p){u=u.next,p===o_&&(d=!0);continue}else f={lane:0,revertLane:u.revertLane,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},null===c?(l=c=f,i=a):c=c.next=f,ap.lanes|=p,lB|=p;f=u.action,ax&&r(a,f),a=u.hasEagerState?u.eagerState:r(a,f)}else p={lane:f,revertLane:u.revertLane,gesture:u.gesture,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},null===c?(l=c=p,i=a):c=c.next=p,ap.lanes|=f,lB|=f;u=u.next}while(null!==u&&u!==t);if(null===c?i=a:c.next=l,!rB(a,e.memoizedState)&&(iY=!0,d&&null!==(r=ok)))throw r;e.memoizedState=a,e.baseState=i,e.baseQueue=c,n.lastRenderedState=a}return null===o&&(n.lanes=0),[e.memoizedState,n.dispatch]}function aU(e){var t=aP(),r=t.queue;if(null===r)throw Error(s(311));r.lastRenderedReducer=e;var n=r.dispatch,o=r.pending,a=t.memoizedState;if(null!==o){r.pending=null;var i=o=o.next;do a=e(a,i.action),i=i.next;while(i!==o);rB(a,t.memoizedState)||(iY=!0),t.memoizedState=a,null===t.baseQueue&&(t.baseState=a),r.lastRenderedState=a}return[a,n]}function aZ(e,t,r){var n=ap,o=aP(),a=nQ;if(a){if(void 0===r)throw Error(s(407));r=r()}else r=t();var i=!rB((ah||o).memoizedState,r);if(i&&(o.memoizedState=r,iY=!0),o=o.queue,io(aV.bind(null,n,o,e),[e]),a9((e=o.getSnapshot!==t||i||null!==am&&0!=(1&am.memoizedState.tag))?9:8,{destroy:void 0},aB.bind(null,n,o,r,t),null),e){if(n.flags|=2048,null===lL)throw Error(s(349));a||0!=(127&af)||aq(n,t,r)}return r}function aq(e,t,r){e.flags|=16384,e={getSnapshot:t,value:r},null===(t=ap.updateQueue)?(t=aL(),ap.updateQueue=t,t.stores=[e]):null===(r=t.stores)?t.stores=[e]:r.push(e)}function aB(e,t,r,n){t.value=r,t.getSnapshot=n,aH(t)&&aW(e)}function aV(e,t,r){return r(function(){aH(t)&&aW(e)})}function aH(e){var t=e.getSnapshot;e=e.value;try{var r=t();return!rB(e,r)}catch(e){return!0}}function aW(e){var t=nb(e,2);null!==t&&cl(t,e,2)}function aG(e){var t=aR();if("function"==typeof e){var r=e;if(e=r(),ax){eT(!0);try{r()}finally{eT(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:aD,lastRenderedState:e},t}function aK(e,t,r,n){return e.baseState=r,a$(e,ah,"function"==typeof n?n:aD)}function aY(e,t,r,n,o){if(iN(e))throw Error(s(485));if(null!==(e=t.action)){var a={payload:o,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(e){a.listeners.push(e)}};null!==H.T?r(!0):a.isTransition=!1,n(a),null===(r=t.pending)?(a.next=t.pending=a,aX(t,a)):(a.next=r.next,t.pending=r.next=a)}}function aX(e,t){var r=t.action,n=t.payload,o=e.state;if(t.isTransition){var a=H.T,i={};i.types=null!==a?a.types:null,H.T=i;try{var s=r(o,n),l=H.S;null!==l&&l(i,s),aQ(e,t,s)}catch(r){a0(e,t,r)}finally{null!==a&&null!==i.types&&(a.types=i.types),H.T=a}}else try{a=r(o,n),aQ(e,t,a)}catch(r){a0(e,t,r)}}function aQ(e,t,r){null!==r&&"object"==typeof r&&"function"==typeof r.then?r.then(function(r){aJ(e,t,r)},function(r){return a0(e,t,r)}):aJ(e,t,r)}function aJ(e,t,r){t.status="fulfilled",t.value=r,a1(t),e.state=r,null!==(t=e.pending)&&((r=t.next)===t?e.pending=null:(r=r.next,t.next=r,aX(e,r)))}function a0(e,t,r){var n=e.pending;if(e.pending=null,null!==n){n=n.next;do t.status="rejected",t.reason=r,a1(t),t=t.next;while(t!==n)}e.action=null}function a1(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function a2(e,t){return t}function a3(e,t){if(nQ){var r=lL.formState;if(null!==r){e:{var n=ap;if(nQ){if(nX){t:{for(var o=nX,a=n0;8!==o.nodeType;)if(!a||null===(o=de(o.nextSibling))){o=null;break t}o="F!"===(a=o.data)||"F"===a?o:null}if(o){nX=de(o.nextSibling),n="F!"===o.data;break e}}n2(n)}n=!1}n&&(t=r[0])}}return(r=aR()).memoizedState=r.baseState=t,n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:a2,lastRenderedState:t},r.queue=n,r=iC.bind(null,ap,n),n.dispatch=r,n=aG(!1),a=iT.bind(null,ap,!1,n.queue),n=aR(),o={state:t,dispatch:null,action:e,pending:null},n.queue=o,r=aY.bind(null,ap,o,a,r),o.dispatch=r,n.memoizedState=e,[t,r,!1]}function a5(e){return a4(aP(),ah,e)}function a4(e,t,r){if(t=a$(e,t,a2)[0],e=aF(aD)[0],"object"==typeof t&&null!==t&&"function"==typeof t.then)try{var n=aO(t)}catch(e){if(e===oI)throw oR;throw e}else n=t;var o=(t=aP()).queue,a=o.dispatch;return r!==t.memoizedState&&(ap.flags|=2048,a9(9,{destroy:void 0},a6.bind(null,o,r),null)),[n,a,e]}function a6(e,t){e.action=t}function a7(e){var t=aP(),r=ah;if(null!==r)return a4(t,r,e);aP(),t=t.memoizedState;var n=(r=aP()).queue.dispatch;return r.memoizedState=e,[t,n,!1]}function a9(e,t,r,n){return e={tag:e,create:r,deps:n,inst:t,next:null},null===(t=ap.updateQueue)&&(t=aL(),ap.updateQueue=t),null===(r=t.lastEffect)?t.lastEffect=e.next=e:(n=r.next,r.next=e,e.next=n,t.lastEffect=e),e}function a8(){return aP().memoizedState}function ie(e,t,r,n){var o=aR();ap.flags|=e,o.memoizedState=a9(1|t,{destroy:void 0},r,void 0===n?null:n)}function it(e,t,r,n){var o=aP();n=void 0===n?null:n;var a=o.memoizedState.inst;null!==ah&&null!==n&&aj(n,ah.memoizedState.deps)?o.memoizedState=a9(t,a,r,n):(ap.flags|=e,o.memoizedState=a9(1|t,a,r,n))}function ir(e,t){ie(8390656,8,e,t)}function io(e,t){it(2048,8,e,t)}function ia(e){var t=aP().memoizedState,r={ref:t,nextImpl:e};ap.flags|=4;var n=ap.updateQueue;if(null===n)n=aL(),ap.updateQueue=n,n.events=[r];else{var o=n.events;null===o?n.events=[r]:o.push(r)}return function(){if(0!=(2&lP))throw Error(s(440));return t.impl.apply(void 0,arguments)}}function ii(e,t){return it(4,2,e,t)}function is(e,t){return it(4,4,e,t)}function il(e,t){if("function"==typeof t){var r=t(e=e());return function(){"function"==typeof r?r():t(null)}}if(null!=t)return t.current=e=e(),function(){t.current=null}}function ic(e,t,r){r=null!=r?r.concat([e]):null,it(4,4,il.bind(null,t,e),r)}function iu(){}function id(e,t){var r=aP();t=void 0===t?null:t;var n=r.memoizedState;return null!==t&&aj(t,n[1])?n[0]:(r.memoizedState=[e,t],e)}function ip(e,t){var r=aP();t=void 0===t?null:t;var n=r.memoizedState;if(null!==t&&aj(t,n[1]))return n[0];if(n=e(),ax){eT(!0);try{e()}finally{eT(!1)}}return r.memoizedState=[n,t],n}function ih(e,t,r){return void 0===r||0!=(0x40000000&af)&&0==(261930&lM)?e.memoizedState=t:(e.memoizedState=r,e=ci(),ap.lanes|=e,lB|=e,r)}function im(e,t,r,n){return rB(r,t)?r:null!==o6.current?(rB(e=ih(e,r,n),t)||(iY=!0),e):0==(106&af)||0!=(0x40000000&af)&&0==(261930&lM)?(iY=!0,e.memoizedState=r):(e=ci(),ap.lanes|=e,lB|=e,t)}function ig(e,t,r,n,o){var a=W.p;W.p=0!==a&&8>a?a:8;var i=H.T,s={};s.types=null!==i?i.types:null,H.T=s,iT(e,!1,t,r);try{var l=o(),c=H.S;if(null!==c&&c(s,l),null!==l&&"object"==typeof l&&"function"==typeof l.then){var u,d,f=(u=[],d={status:"pending",value:null,reason:null,then:function(e){u.push(e)}},l.then(function(){d.status="fulfilled",d.value=n;for(var e=0;e<u.length;e++)(0,u[e])(n)},function(e){for(d.status="rejected",d.reason=e,e=0;e<u.length;e++)(0,u[e])(void 0)}),d);iE(e,t,f,ca(e))}else iE(e,t,n,ca(e))}catch(r){iE(e,t,{then:function(){},status:"rejected",reason:r},ca())}finally{W.p=a,null!==i&&null!==s.types&&(i.types=s.types),H.T=i}}function iv(){}function ix(e,t,r,n){if(5!==e.tag)throw Error(s(476));var o=iy(e).queue;ig(e,o,t,G,null===r?iv:function(){return ib(e),r(n)})}function iy(e){var t=e.memoizedState;if(null!==t)return t;var r={};return(t={memoizedState:G,baseState:G,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:aD,lastRenderedState:G},next:null}).next={memoizedState:r,baseState:r,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:aD,lastRenderedState:r},next:null},e.memoizedState=t,null!==(e=e.alternate)&&(e.memoizedState=t),t}function ib(e){var t=iy(e);null===t.next&&(t=e.alternate.memoizedState),iE(e,t.next.queue,{},ca())}function iw(){return oc(dD)}function i_(){return aP().memoizedState}function ik(){return aP().memoizedState}function ij(e){for(var t=e.return;null!==t;){switch(t.tag){case 24:case 3:var r=ca(),n=oQ(t,e=oX(r),r);null!==n&&(cl(n,t,r),oJ(n,t,r)),t={cache:og()},e.payload=t;return}t=t.return}}function iS(e,t,r){var n=ca();r={lane:n,revertLane:0,gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},iN(e)?iI(t,r):null!==(r=ny(e,t,r,n))&&(cl(r,e,n),iz(r,t,n))}function iC(e,t,r){iE(e,t,r,ca())}function iE(e,t,r,n){var o={lane:n,revertLane:0,gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null};if(iN(e))iI(t,o);else{var a=e.alternate;if(0===e.lanes&&(null===a||0===a.lanes)&&null!==(a=t.lastRenderedReducer))try{var i=t.lastRenderedState,s=a(i,r);if(o.hasEagerState=!0,o.eagerState=s,rB(s,i))return nx(e,t,o,0),null===lL&&nv(),!1}catch(e){}finally{}if(null!==(r=ny(e,t,o,n)))return cl(r,e,n),iz(r,t,n),!0}return!1}function iT(e,t,r,n){if(n={lane:2,revertLane:c1(),gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},iN(e)){if(t)throw Error(s(479))}else null!==(t=ny(e,r,n,2))&&cl(t,e,2)}function iN(e){var t=e.alternate;return e===ap||null!==t&&t===ap}function iI(e,t){av=ag=!0;var r=e.pending;null===r?t.next=t:(t.next=r.next,r.next=t),e.pending=t}function iz(e,t,r){if(0!=(4194048&r)){var n=t.lanes;n&=e.pendingLanes,t.lanes=r|=n,eq(e,r)}}var iR={readContext:oc,use:aM,useCallback:ak,useContext:ak,useEffect:ak,useImperativeHandle:ak,useLayoutEffect:ak,useInsertionEffect:ak,useMemo:ak,useReducer:ak,useRef:ak,useState:ak,useDebugValue:ak,useDeferredValue:ak,useTransition:ak,useSyncExternalStore:ak,useId:ak,useHostTransitionStatus:ak,useFormState:ak,useActionState:ak,useOptimistic:ak,useMemoCache:ak,useCacheRefresh:ak,useEffectEvent:ak},iP={readContext:oc,use:aM,useCallback:function(e,t){return aR().memoizedState=[e,void 0===t?null:t],e},useContext:oc,useEffect:ir,useImperativeHandle:function(e,t,r){r=null!=r?r.concat([e]):null,ie(4194308,4,il.bind(null,t,e),r)},useLayoutEffect:function(e,t){return ie(4194308,4,e,t)},useInsertionEffect:function(e,t){ie(4,2,e,t)},useMemo:function(e,t){var r=aR();t=void 0===t?null:t;var n=e();if(ax){eT(!0);try{e()}finally{eT(!1)}}return r.memoizedState=[n,t],n},useReducer:function(e,t,r){var n=aR();if(void 0!==r){var o=r(t);if(ax){eT(!0);try{r(t)}finally{eT(!1)}}}else o=t;return n.memoizedState=n.baseState=o,n.queue=e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:o},e=e.dispatch=iS.bind(null,ap,e),[n.memoizedState,e]},useRef:function(e){return aR().memoizedState={current:e}},useState:function(e){var t=(e=aG(e)).queue,r=iC.bind(null,ap,t);return t.dispatch=r,[e.memoizedState,r]},useDebugValue:iu,useDeferredValue:function(e,t){return ih(aR(),e,t)},useTransition:function(){var e=aG(!1);return e=ig.bind(null,ap,e.queue,!0,!1),aR().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,r){var n=ap,o=aR();if(nQ){if(void 0===r)throw Error(s(407));r=r()}else{if(r=t(),null===lL)throw Error(s(349));0!=(127&lM)||aq(n,t,r)}o.memoizedState=r;var a={value:r,getSnapshot:t};return o.queue=a,ir(aV.bind(null,n,a,e),[e]),n.flags|=2048,a9(9,{destroy:void 0},aB.bind(null,n,a,r,t),null),r},useId:function(){var e=aR(),t=lL.identifierPrefix;if(nQ){var r=nB,n=nq;t="_"+t+"R_"+(r=(n&~(1<<32-eN(n)-1)).toString(32)+r),0<(r=ay++)&&(t+="H"+r.toString(32)),t+="_"}else t="_"+t+"r_"+(r=a_++).toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:iw,useFormState:a3,useActionState:a3,useOptimistic:function(e){var t=aR();t.memoizedState=t.baseState=e;var r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=r,t=iT.bind(null,ap,!0,r),r.dispatch=t,[e,t]},useMemoCache:aA,useCacheRefresh:function(){return aR().memoizedState=ij.bind(null,ap)},useEffectEvent:function(e){var t=aR(),r={impl:e};return t.memoizedState=r,function(){if(0!=(2&lP))throw Error(s(440));return r.impl.apply(void 0,arguments)}}},iL={readContext:oc,use:aM,useCallback:id,useContext:oc,useEffect:io,useImperativeHandle:ic,useInsertionEffect:ii,useLayoutEffect:is,useMemo:ip,useReducer:aF,useRef:a8,useState:function(){return aF(aD)},useDebugValue:iu,useDeferredValue:function(e,t){return im(aP(),ah.memoizedState,e,t)},useTransition:function(){var e=aF(aD)[0],t=aP().memoizedState;return["boolean"==typeof e?e:aO(e),t]},useSyncExternalStore:aZ,useId:i_,useHostTransitionStatus:iw,useFormState:a5,useActionState:a5,useOptimistic:function(e,t){return aK(aP(),ah,e,t)},useMemoCache:aA,useCacheRefresh:ik,useEffectEvent:ia},iO={readContext:oc,use:aM,useCallback:id,useContext:oc,useEffect:io,useImperativeHandle:ic,useInsertionEffect:ii,useLayoutEffect:is,useMemo:ip,useReducer:aU,useRef:a8,useState:function(){return aU(aD)},useDebugValue:iu,useDeferredValue:function(e,t){var r=aP();return null===ah?ih(r,e,t):im(r,ah.memoizedState,e,t)},useTransition:function(){var e=aU(aD)[0],t=aP().memoizedState;return["boolean"==typeof e?e:aO(e),t]},useSyncExternalStore:aZ,useId:i_,useHostTransitionStatus:iw,useFormState:a7,useActionState:a7,useOptimistic:function(e,t){var r=aP();return null!==ah?aK(r,ah,e,t):(r.baseState=e,[e,r.queue.dispatch])},useMemoCache:aA,useCacheRefresh:ik,useEffectEvent:ia};function iM(e,t,r,n){r=null==(r=r(n,t=e.memoizedState))?t:k({},t,r),e.memoizedState=r,0===e.lanes&&(e.updateQueue.baseState=r)}var iA={enqueueSetState:function(e,t,r){e=e._reactInternals;var n=ca(),o=oX(n);o.payload=t,null!=r&&(o.callback=r),null!==(t=oQ(e,o,n))&&(cl(t,e,n),oJ(t,e,n))},enqueueReplaceState:function(e,t,r){e=e._reactInternals;var n=ca(),o=oX(n);o.tag=1,o.payload=t,null!=r&&(o.callback=r),null!==(t=oQ(e,o,n))&&(cl(t,e,n),oJ(t,e,n))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var r=ca(),n=oX(r);n.tag=2,null!=t&&(n.callback=t),null!==(t=oQ(e,n,r))&&(cl(t,e,r),oJ(t,e,r))}};function iD(e,t,r,n,o,a,i){return"function"==typeof(e=e.stateNode).shouldComponentUpdate?e.shouldComponentUpdate(n,a,i):!t.prototype||!t.prototype.isPureReactComponent||!rV(r,n)||!rV(o,a)}function iF(e,t,r,n){e=t.state,"function"==typeof t.componentWillReceiveProps&&t.componentWillReceiveProps(r,n),"function"==typeof t.UNSAFE_componentWillReceiveProps&&t.UNSAFE_componentWillReceiveProps(r,n),t.state!==e&&iA.enqueueReplaceState(t,t.state,null)}function i$(e,t){var r=t;if("ref"in t)for(var n in r={},t)"ref"!==n&&(r[n]=t[n]);if(e=e.defaultProps)for(var o in r===t&&(r=k({},r)),e)void 0===r[o]&&(r[o]=e[o]);return r}function iU(e){np(e)}function iZ(e){console.error(e)}function iq(e){np(e)}function iB(e,t){try{(0,e.onUncaughtError)(t.value,{componentStack:t.stack})}catch(e){setTimeout(function(){throw e})}}function iV(e,t,r){try{(0,e.onCaughtError)(r.value,{componentStack:r.stack,errorBoundary:1===t.tag?t.stateNode:null})}catch(e){setTimeout(function(){throw e})}}function iH(e,t,r){return(r=oX(r)).tag=3,r.payload={element:null},r.callback=function(){iB(e,t)},r}function iW(e){return(e=oX(e)).tag=3,e}function iG(e,t,r,n){var o=r.type.getDerivedStateFromError;if("function"==typeof o){var a=n.value;e.payload=function(){return o(a)},e.callback=function(){iV(t,r,n)}}var i=r.stateNode;null!==i&&"function"==typeof i.componentDidCatch&&(e.callback=function(){iV(t,r,n),"function"!=typeof o&&(null===l2?l2=new Set([this]):l2.add(this));var e=n.stack;this.componentDidCatch(n.value,{componentStack:null!==e?e:""})})}var iK=Error(s(461)),iY=!1;function iX(e,t,r,n){t.child=null===e?oW(t,null,r,n):oH(t,e.child,r,n)}function iQ(e,t,r,n,o){r=r.render;var a=t.ref;if("ref"in n){var i={};for(var s in n)"ref"!==s&&(i[s]=n[s])}else i=n;return(ol(t),n=aS(e,t,r,i,a,o),s=aN(),null===e||iY)?(nQ&&s&&nW(t),t.flags|=1,iX(e,t,n,o),t.child):(aI(e,t,o),sh(e,t,o))}function iJ(e,t,r,n,o){if(null===e){var a=r.type;return"function"!=typeof a||nC(a)||void 0!==a.defaultProps||null!==r.compare?((e=nN(r.type,null,n,t,t.mode,o)).ref=t.ref,e.return=t,t.child=e):(t.tag=15,t.type=a,i0(e,t,a,n,o))}if(a=e.child,!sm(e,o)){var i=a.memoizedProps;if((r=null!==(r=r.compare)?r:rV)(i,n)&&e.ref===t.ref)return sh(e,t,o)}return t.flags|=1,(e=nE(a,n)).ref=t.ref,e.return=t,t.child=e}function i0(e,t,r,n,o){if(null!==e){var a=e.memoizedProps;if(rV(a,n)&&e.ref===t.ref)if(iY=!1,t.pendingProps=n=a,!sm(e,o))return t.lanes=e.lanes,sh(e,t,o);else 0!=(131072&e.flags)&&(iY=!0)}return i7(e,t,r,n,o)}function i1(e,t,r,n){var o=n.children,a=null!==e?e.memoizedState:null;if(null===e&&null===t.stateNode&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),"hidden"===n.mode){if(0!=(128&t.flags)){if(a=null!==a?a.baseLanes|r:r,null!==e){for(o=0,n=t.child=e.child;null!==n;)o=o|n.lanes|n.childLanes,n=n.sibling;n=o&~a}else n=0,t.child=null;return i3(e,t,a,r,n)}if(0==(0x20000000&r))return n=t.lanes=0x20000000,i3(e,t,null!==a?a.baseLanes|r:r,r,n);t.memoizedState={baseLanes:0,cachePool:null},null!==e&&oT(t,null!==a?a.cachePool:null),null!==a?o9(t,a):o8(),aa(t)}else null!==a?(oT(t,a.cachePool),o9(t,a),ai(),t.memoizedState=null):(null!==e&&oT(t,null),o8(),ai());return iX(e,t,o,r),t.child}function i2(e,t){return null!==e&&22===e.tag||null!==t.stateNode||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function i3(e,t,r,n,o){var a=oE();return t.memoizedState={baseLanes:r,cachePool:a=null===a?null:{parent:om._currentValue,pool:a}},null!==e&&oT(t,null),o8(),aa(t),null!==e&&oi(e,t,n,!0),t.childLanes=o,null}function i5(e,t){return(t=si({mode:t.mode,children:t.children},e.mode)).ref=e.ref,e.child=t,t.return=e,t}function i4(e,t,r){return oH(t,e.child,null,r),e=i5(t,t.pendingProps),e.flags|=2,as(t),t.memoizedState=null,e}function i6(e,t){var r=t.ref;if(null===r)null!==e&&null!==e.ref&&(t.flags|=4194816);else{if("function"!=typeof r&&"object"!=typeof r)throw Error(s(284));(null===e||e.ref!==r)&&(t.flags|=4194816)}}function i7(e,t,r,n,o){return(ol(t),r=aS(e,t,r,n,void 0,o),n=aN(),null===e||iY)?(nQ&&n&&nW(t),t.flags|=1,iX(e,t,r,o),t.child):(aI(e,t,o),sh(e,t,o))}function i9(e,t,r,n,o,a){return(ol(t),t.updateQueue=null,r=aE(t,n,r,o),aC(e),n=aN(),null===e||iY)?(nQ&&n&&nW(t),t.flags|=1,iX(e,t,r,a),t.child):(aI(e,t,a),sh(e,t,a))}function i8(e,t,r,n,o){if(ol(t),null===t.stateNode){var a=nk,i=r.contextType;"object"==typeof i&&null!==i&&(a=oc(i)),t.memoizedState=null!==(a=new r(n,a)).state&&void 0!==a.state?a.state:null,a.updater=iA,t.stateNode=a,a._reactInternals=t,(a=t.stateNode).props=n,a.state=t.memoizedState,a.refs={},oK(t),i=r.contextType,a.context="object"==typeof i&&null!==i?oc(i):nk,a.state=t.memoizedState,"function"==typeof(i=r.getDerivedStateFromProps)&&(iM(t,r,i,n),a.state=t.memoizedState),"function"==typeof r.getDerivedStateFromProps||"function"==typeof a.getSnapshotBeforeUpdate||"function"!=typeof a.UNSAFE_componentWillMount&&"function"!=typeof a.componentWillMount||(i=a.state,"function"==typeof a.componentWillMount&&a.componentWillMount(),"function"==typeof a.UNSAFE_componentWillMount&&a.UNSAFE_componentWillMount(),i!==a.state&&iA.enqueueReplaceState(a,a.state,null),o3(t,n,a,o),o2(),a.state=t.memoizedState),"function"==typeof a.componentDidMount&&(t.flags|=4194308),n=!0}else if(null===e){a=t.stateNode;var s=t.memoizedProps,l=i$(r,s);a.props=l;var c=a.context,u=r.contextType;i=nk,"object"==typeof u&&null!==u&&(i=oc(u));var d=r.getDerivedStateFromProps;u="function"==typeof d||"function"==typeof a.getSnapshotBeforeUpdate,s=t.pendingProps!==s,u||"function"!=typeof a.UNSAFE_componentWillReceiveProps&&"function"!=typeof a.componentWillReceiveProps||(s||c!==i)&&iF(t,a,n,i),oG=!1;var f=t.memoizedState;a.state=f,o3(t,n,a,o),o2(),c=t.memoizedState,s||f!==c||oG?("function"==typeof d&&(iM(t,r,d,n),c=t.memoizedState),(l=oG||iD(t,r,l,n,f,c,i))?(u||"function"!=typeof a.UNSAFE_componentWillMount&&"function"!=typeof a.componentWillMount||("function"==typeof a.componentWillMount&&a.componentWillMount(),"function"==typeof a.UNSAFE_componentWillMount&&a.UNSAFE_componentWillMount()),"function"==typeof a.componentDidMount&&(t.flags|=4194308)):("function"==typeof a.componentDidMount&&(t.flags|=4194308),t.memoizedProps=n,t.memoizedState=c),a.props=n,a.state=c,a.context=i,n=l):("function"==typeof a.componentDidMount&&(t.flags|=4194308),n=!1)}else{a=t.stateNode,oY(e,t),u=i$(r,i=t.memoizedProps),a.props=u,d=t.pendingProps,f=a.context,c=r.contextType,l=nk,"object"==typeof c&&null!==c&&(l=oc(c)),(c="function"==typeof(s=r.getDerivedStateFromProps)||"function"==typeof a.getSnapshotBeforeUpdate)||"function"!=typeof a.UNSAFE_componentWillReceiveProps&&"function"!=typeof a.componentWillReceiveProps||(i!==d||f!==l)&&iF(t,a,n,l),oG=!1,f=t.memoizedState,a.state=f,o3(t,n,a,o),o2();var p=t.memoizedState;i!==d||f!==p||oG||null!==e&&null!==e.dependencies&&os(e.dependencies)?("function"==typeof s&&(iM(t,r,s,n),p=t.memoizedState),(u=oG||iD(t,r,u,n,f,p,l)||null!==e&&null!==e.dependencies&&os(e.dependencies))?(c||"function"!=typeof a.UNSAFE_componentWillUpdate&&"function"!=typeof a.componentWillUpdate||("function"==typeof a.componentWillUpdate&&a.componentWillUpdate(n,p,l),"function"==typeof a.UNSAFE_componentWillUpdate&&a.UNSAFE_componentWillUpdate(n,p,l)),"function"==typeof a.componentDidUpdate&&(t.flags|=4),"function"==typeof a.getSnapshotBeforeUpdate&&(t.flags|=1024)):("function"!=typeof a.componentDidUpdate||i===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),"function"!=typeof a.getSnapshotBeforeUpdate||i===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),t.memoizedProps=n,t.memoizedState=p),a.props=n,a.state=p,a.context=l,n=u):("function"!=typeof a.componentDidUpdate||i===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),"function"!=typeof a.getSnapshotBeforeUpdate||i===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),n=!1)}return a=n,i6(e,t),n=0!=(128&t.flags),a||n?(a=t.stateNode,r=n&&"function"!=typeof r.getDerivedStateFromError?null:a.render(),t.flags|=1,null!==e&&n?(t.child=oH(t,e.child,null,o),t.child=oH(t,null,r,o)):iX(e,t,r,o),t.memoizedState=a.state,e=t.child):e=sh(e,t,o),e}function se(e,t,r,n){return n6(),t.flags|=256,iX(e,t,r,n),t.child}var st={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function sr(e){return{baseLanes:e,cachePool:oN()}}function sn(e,t,r){return e=null!==e?e.childLanes&~r:0,t&&(e|=lW),e}function so(e,t,r){var n,o=t.pendingProps,a=!1,i=0!=(128&t.flags);if((n=i)||(n=(null===e||null!==e.memoizedState)&&0!=(2&al.current)),n&&(a=!0,t.flags&=-129),n=0!=(32&t.flags),t.flags&=-33,null===e){if(nQ){if(a?an(t):ai(),(e=nX)?null!==(e=null!==(e=u7(e,n0))&&"&"!==e.data?e:null)&&(t.memoizedState={dehydrated:e,treeContext:null!==nZ?{id:nq,overflow:nB}:null,retryLane:0x20000000,hydrationErrors:null},(r=nR(e)).return=t,t.child=r,nY=t,nX=null):e=null,null===e)throw n2(t);return u8(e)?t.lanes=32:t.lanes=0x20000000,null}return(i=o.children,o=o.fallback,a)?(ai(),i=si({mode:"hidden",children:i},a=t.mode),o=nI(o,a,r,null),i.return=t,o.return=t,i.sibling=o,t.child=i,(o=t.child).memoizedState=sr(r),o.childLanes=sn(e,n,r),t.memoizedState=st,i2(null,o)):(an(t),sa(t,i))}var l=e.memoizedState;if(null!==l){var c=l.dehydrated;if(null!==c){var u=e,d=t,f=i,p=n,h=o,m=c,g=l,v=r;if(f)return 256&d.flags?(an(d),d.flags&=-257,ss(u,d,v)):null!==d.memoizedState?(ai(),d.child=u.child,d.flags|=128,null):(ai(),m=h.fallback,g=d.mode,h=si({mode:"visible",children:h.children},g),m=nI(m,g,v,null),m.flags|=2,h.return=d,m.return=d,h.sibling=m,d.child=h,oH(d,u.child,null,v),(h=d.child).memoizedState=sr(v),h.childLanes=sn(u,p,v),d.memoizedState=st,i2(null,h));if(an(d),u8(m)){if(p=m.nextSibling&&m.nextSibling.dataset)var x=p.dgst;return""!==(p=x)&&((h=Error(s(419))).stack="",h.digest=p,n9({value:h,source:null,stack:null})),ss(u,d,v)}if(iY||oi(u,d,v,!1),p=0!=(v&u.childLanes),iY||p){if(null!==o6.current)return ss(u,d,v);if(null!==(p=lL)&&0!==(h=eB(p,v))&&h!==g.retryLane)throw g.retryLane=h,nb(u,h),cl(p,u,h),iK;return u9(m)||cy(),ss(u,d,v)}return u9(m)?(d.flags|=192,d.child=u.child,null):(u=g.treeContext,nX=de(m.nextSibling),nY=d,nQ=!0,nJ=null,n0=!1,null!==u&&nK(d,u),d=sa(d,h.children),d.flags|=0x8001000,d)}}return a?(ai(),a=o.fallback,i=t.mode,c=(l=e.child).sibling,(o=nE(l,{mode:"hidden",children:o.children})).subtreeFlags=0x47f00000&l.subtreeFlags,null!==c?a=nE(c,a):(a=nI(a,i,r,null),a.flags|=2),a.return=t,o.return=t,o.sibling=a,t.child=o,i2(null,o),o=t.child,null===(a=e.child.memoizedState)?a=sr(r):(null!==(i=a.cachePool)?(l=om._currentValue,i=i.parent!==l?{parent:l,pool:l}:i):i=oN(),a={baseLanes:a.baseLanes|r,cachePool:i}),o.memoizedState=a,o.childLanes=sn(e,n,r),t.memoizedState=st,i2(e.child,o)):(an(t),e=(r=e.child).sibling,(r=nE(r,{mode:"visible",children:o.children})).return=t,r.sibling=null,null!==e&&(null===(n=t.deletions)?(t.deletions=[e],t.flags|=16):n.push(e)),t.child=r,t.memoizedState=null,r)}function sa(e,t){return(t=si({mode:"visible",children:t},e.mode)).return=e,e.child=t}function si(e,t){return(e=nS(22,e,null,t)).lanes=0,e}function ss(e,t,r){return oH(t,e.child,null,r),e=sa(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function sl(e,t,r){e.lanes|=t;var n=e.alternate;null!==n&&(n.lanes|=t),oo(e.return,t,r)}function sc(e){for(var t=null;null!==e;){var r=e.alternate;null!==r&&null===ad(r)&&(t=e),e=e.sibling}return t}function su(e,t,r,n,o,a){var i=e.memoizedState;null===i?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:n,tail:r,tailMode:o,treeForkCount:a}:(i.isBackwards=t,i.rendering=null,i.renderingStartTime=0,i.last=n,i.tail=r,i.tailMode=o,i.treeForkCount=a)}function sd(e){var t=e.child;for(e.child=null;null!==t;){var r=t.sibling;t.sibling=e.child,e.child=t,t=r}}function sf(e,t,r){var n=t.pendingProps,o=n.revealOrder,a=n.tail;n=n.children;var i=al.current;if(128&t.flags)return ac(t,i),null;var s=0!=(2&i);if(s?(i=1&i|2,t.flags|=128):i&=1,ac(t,i),"backwards"===o&&null!==e?(sd(e),iX(e,t,n,r),sd(e)):iX(e,t,n,r),n=nQ?nF:0,!s&&null!==e&&0!=(128&e.flags))e:for(e=t.child;null!==e;){if(13===e.tag)null!==e.memoizedState&&sl(e,r,t);else if(19===e.tag)sl(e,r,t);else if(null!==e.child){e.child.return=e,e=e.child;continue}if(e===t)break;for(;null===e.sibling;){if(null===e.return||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(o){case"backwards":null===(r=sc(t.child))?(o=t.child,t.child=null):(o=r.sibling,r.sibling=null,sd(t)),su(t,!0,o,null,a,n);break;case"unstable_legacy-backwards":for(r=null,o=t.child,t.child=null;null!==o;){if(null!==(e=o.alternate)&&null===ad(e)){t.child=o;break}e=o.sibling,o.sibling=r,r=o,o=e}su(t,!0,r,null,a,n);break;case"together":su(t,!1,null,null,void 0,n);break;case"independent":t.memoizedState=null;break;default:null===(r=sc(t.child))?(o=t.child,t.child=null):(o=r.sibling,r.sibling=null),su(t,!1,o,r,a,n)}return t.child}function sp(e,t,r){var n=t.pendingProps;return or(t,t.type,n.value),iX(e,t,n.children,r),t.child}function sh(e,t,r){if(null!==e&&(t.dependencies=e.dependencies),lB|=t.lanes,0==(r&t.childLanes)){if(null===e)return null;else if(oi(e,t,r,!1),0==(r&t.childLanes))return null}if(null!==e&&t.child!==e.child)throw Error(s(153));if(null!==t.child){for(r=nE(e=t.child,e.pendingProps),t.child=r,r.return=t;null!==e.sibling;)e=e.sibling,(r=r.sibling=nE(e,e.pendingProps)).return=t;r.sibling=null}return t.child}function sm(e,t){return 0!=(e.lanes&t)||!!(null!==(e=e.dependencies)&&os(e))}function sg(e,t,r){if(null!==e)if(e.memoizedProps!==t.pendingProps)iY=!0;else{if(!sm(e,r)&&0==(128&t.flags))return iY=!1,function(e,t,r){switch(t.tag){case 3:eo(t,t.stateNode.containerInfo),or(t,om,e.memoizedState.cache),n6();break;case 27:case 5:ei(t);break;case 4:eo(t,t.stateNode.containerInfo);break;case 10:or(t,t.type,t.memoizedProps.value);break;case 31:if(null!==t.memoizedState)return t.flags|=128,ao(t),null;break;case 13:var n=t.memoizedState;if(null!==n){if(null!==n.dehydrated)return an(t),t.flags|=128,null;n=oi(e,t,r,!1);var o=t.child.childLanes;if(n||0!=(r&o))return so(e,t,r);return an(t),null!==(e=sh(e,t,r))?e.sibling:null}an(t);break;case 19:if(128&t.flags)return sf(e,t,r);if(o=0!=(128&e.flags),(n=0!=(r&t.childLanes))||(oi(e,t,r,!1),n=0!=(r&t.childLanes)),o){if(n)return sf(e,t,r);t.flags|=128}if(null!==(o=t.memoizedState)&&(o.rendering=null,o.tail=null,o.lastEffect=null),ac(t,al.current),!n)return null;break;case 22:return t.lanes=0,i1(e,t,r,t.pendingProps);case 24:or(t,om,e.memoizedState.cache)}return sh(e,t,r)}(e,t,r);iY=0!=(131072&e.flags)}else iY=!1,nQ&&0!=(1048576&t.flags)&&nH(t,nF,t.index);switch(t.lanes=0,t.tag){case 16:e:{var n=t.pendingProps;if(e=oM(t.elementType),t.type=e,"function"==typeof e)nC(e)?(n=i$(e,n),t.tag=1,t=i8(null,t,e,n,r)):(t.tag=0,t=i7(null,t,e,n,r));else{if(null!=e){var o=e.$$typeof;if(o===R){t.tag=11,t=iQ(null,t,e,n,r);break e}if(o===O){t.tag=14,t=iJ(null,t,e,n,r);break e}if(o===z){t.tag=10,t.type=e,t=sp(null,t,r);break e}}throw Error(s(306,t=function e(t){if(null==t)return null;if("function"==typeof t)return t.$$typeof===B?null:t.displayName||t.name||null;if("string"==typeof t)return t;switch(t){case E:return"Fragment";case N:return"Profiler";case T:return"StrictMode";case P:return"Suspense";case L:return"SuspenseList";case A:return"Activity";case $:return"ViewTransition"}if("object"==typeof t)switch(t.$$typeof){case C:return"Portal";case z:return t.displayName||"Context";case I:return(t._context.displayName||"Context")+".Consumer";case R:var r=t.render;return(t=t.displayName)||(t=""!==(t=r.displayName||r.name||"")?"ForwardRef("+t+")":"ForwardRef"),t;case O:return null!==(r=t.displayName||null)?r:e(t.type)||"Memo";case M:r=t._payload,t=t._init;try{return e(t(r))}catch(e){}}return null}(e)||e,""))}}return t;case 0:return i7(e,t,t.type,t.pendingProps,r);case 1:return o=i$(n=t.type,t.pendingProps),i8(e,t,n,o,r);case 3:e:{if(eo(t,t.stateNode.containerInfo),null===e)throw Error(s(387));n=t.pendingProps;var a=t.memoizedState;o=a.element,oY(e,t),o3(t,n,null,r);var i=t.memoizedState;if(or(t,om,n=i.cache),n!==a.cache&&oa(t,[om],r,!0),o2(),n=i.element,a.isDehydrated)if(a={element:n,isDehydrated:!1,cache:i.cache},t.updateQueue.baseState=a,t.memoizedState=a,256&t.flags){t=se(e,t,n,r);break e}else if(n!==o){n9(o=nO(Error(s(424)),t)),t=se(e,t,n,r);break e}else for(nX=de((e=9===(e=t.stateNode.containerInfo).nodeType?e.body:"HTML"===e.nodeName?e.ownerDocument.body:e).firstChild),nY=t,nQ=!0,nJ=null,n0=!0,r=oW(t,null,n,r),t.child=r;r;)r.flags=-3&r.flags|0x8001000,r=r.sibling;else{if(n6(),n===o){t=sh(e,t,r);break e}iX(e,t,n,r)}t=t.child}return t;case 26:return i6(e,t),null===e?(r=dh(t.type,null,t.pendingProps,null))?t.memoizedState=r:nQ||(t.stateNode=u_(t.type,t.pendingProps,er.current,t)):t.memoizedState=dh(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return ei(t),null===e&&nQ&&(n=t.stateNode=da(t.type,t.pendingProps,er.current),nY=t,n0=!0,o=nX,uz(t.type)?(dt=o,nX=de(n.firstChild)):nX=o),iX(e,t,t.pendingProps.children,r),i6(e,t),null===e&&(t.flags|=4194304),t.child;case 5:return null===e&&nQ&&((o=n=nX)&&(null!==(n=function(e,t,r,n){for(;1===e.nodeType;){if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!n&&("INPUT"!==e.nodeName||"hidden"!==e.type))break}else if(n){if(!e[e3])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if("stylesheet"===(o=e.getAttribute("rel"))&&e.hasAttribute("data-precedence")||o!==r.rel||e.getAttribute("href")!==(null==r.href||""===r.href?null:r.href)||e.getAttribute("crossorigin")!==(null==r.crossOrigin?null:r.crossOrigin)||e.getAttribute("title")!==(null==r.title?null:r.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(((o=e.getAttribute("src"))!==(null==r.src?null:r.src)||e.getAttribute("type")!==(null==r.type?null:r.type)||e.getAttribute("crossorigin")!==(null==r.crossOrigin?null:r.crossOrigin))&&o&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else{if("input"!==t||"hidden"!==e.type)return e;var o=null==r.name?null:""+r.name;if("hidden"===r.type&&e.getAttribute("name")===o)return e}if(null===(e=de(e.nextSibling)))break}return null}(n,t.type,t.pendingProps,n0))?(t.stateNode=n,nY=t,nX=de(n.firstChild),n0=!1,o=!0):o=!1),o||n2(t)),ei(t),o=t.type,a=t.pendingProps,i=null!==e?e.memoizedProps:null,n=a.children,uk(o,a)?n=null:null!==i&&uk(o,i)&&(t.flags|=32),null!==t.memoizedState&&(dD._currentValue=o=aS(e,t,aT,null,null,r)),i6(e,t),iX(e,t,n,r),t.child;case 6:return null===e&&nQ&&((e=r=nX)&&(null!==(r=function(e,t,r){if(""===t)return null;for(;3!==e.nodeType;)if((1!==e.nodeType||"INPUT"!==e.nodeName||"hidden"!==e.type)&&!r||null===(e=de(e.nextSibling)))return null;return e}(r,t.pendingProps,n0))?(t.stateNode=r,nY=t,nX=null,e=!0):e=!1),e||n2(t)),null;case 13:return so(e,t,r);case 4:return eo(t,t.stateNode.containerInfo),n=t.pendingProps,null===e?t.child=oH(t,null,n,r):iX(e,t,n,r),t.child;case 11:return iQ(e,t,t.type,t.pendingProps,r);case 7:return n=t.pendingProps,i6(e,t),iX(e,t,n,r),t.child;case 8:case 12:return iX(e,t,t.pendingProps.children,r),t.child;case 10:return sp(e,t,r);case 9:return o=t.type._context,n=t.pendingProps.children,ol(t),n=n(o=oc(o)),t.flags|=1,iX(e,t,n,r),t.child;case 14:return iJ(e,t,t.type,t.pendingProps,r);case 15:return i0(e,t,t.type,t.pendingProps,r);case 19:return sf(e,t,r);case 31:var l=e,c=t,u=r,d=c.pendingProps,f=0!=(128&c.flags);if(c.flags&=-129,null===l){if(nQ){if("hidden"===d.mode)return l=i5(c,d),c.lanes=0x20000000,l.memoizedState={baseLanes:0,cachePool:null},i2(null,l);if(ao(c),(l=nX)?null!==(l=null!==(l=u7(l,n0))&&"&"===l.data?l:null)&&(c.memoizedState={dehydrated:l,treeContext:null!==nZ?{id:nq,overflow:nB}:null,retryLane:0x20000000,hydrationErrors:null},(u=nR(l)).return=c,c.child=u,nY=c,nX=null):l=null,null===l)throw n2(c);return c.lanes=0x20000000,null}return i5(c,d)}var p=l.memoizedState;if(null!==p){var h=p.dehydrated;if(ao(c),f)if(256&c.flags)c.flags&=-257,c=i4(l,c,u);else if(null!==c.memoizedState)c.child=l.child,c.flags|=128,c=null;else throw Error(s(558));else if(iY||oi(l,c,u,!1),f=0!=(u&l.childLanes),iY||f){if(null===o6.current){if(null!==(d=lL)&&0!==(h=eB(d,u))&&h!==p.retryLane)throw p.retryLane=h,nb(l,h),cl(d,l,h),iK;cy()}c=i4(l,c,u)}else l=p.treeContext,nX=de(h.nextSibling),nY=c,nQ=!0,nJ=null,n0=!1,null!==l&&nK(c,l),c=i5(c,d),c.flags|=0x8001000;return c}return(l=nE(l.child,{mode:d.mode,children:d.children})).ref=c.ref,c.child=l,l.return=c,l;case 22:return i1(e,t,r,t.pendingProps);case 24:return ol(t),n=oc(om),null===e?(null===(o=oE())&&(o=lL,a=og(),o.pooledCache=a,a.refCount++,null!==a&&(o.pooledCacheLanes|=r),o=a),t.memoizedState={parent:n,cache:o},oK(t),or(t,om,o)):(0!=(e.lanes&r)&&(oY(e,t),o3(t,null,null,r),o2()),o=e.memoizedState,a=t.memoizedState,o.parent!==n?(o={parent:n,cache:n},t.memoizedState=o,0===t.lanes&&(t.memoizedState=t.updateQueue.baseState=o),or(t,om,n)):(or(t,om,n=a.cache),n!==o.cache&&oa(t,[om],r,!0))),iX(e,t,t.pendingProps.children,r),t.child;case 30:return null===t.stateNode&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),null!=(n=t.pendingProps).name&&"auto"!==n.name?t.flags|=null===e?0x1202000:0x1200000:nQ&&nW(t),null!==e&&e.memoizedProps.name!==n.name?t.flags|=4194816:i6(e,t),iX(e,t,n.children,r),t.child;case 29:throw t.pendingProps}throw Error(s(156,t.tag))}function sv(e){e.flags|=4}function sx(e,t,r,n,o){var a;if((a=0!=(32&e.mode))&&(a=null===r?dE(t,n):dE(t,n)&&(n.src!==r.src||n.srcSet!==r.srcSet)),a){if(e.flags|=0x1000000,(0x13ffff40&o)===o)if(e.stateNode.complete)e.flags|=8192;else if(cg())e.flags|=8192;else throw oA=oP,oz}else e.flags&=-0x1000001}function sy(e,t){if("stylesheet"!==t.type||0!=(4&t.state.loading))e.flags&=-0x1000001;else if(e.flags|=0x1000000,!dT(t))if(cg())e.flags|=8192;else throw oA=oP,oz}function sb(e,t){null!==t&&(e.flags|=4),16384&e.flags&&(t=22!==e.tag?eF():0x20000000,e.lanes|=t,lG|=t)}function sw(e,t){if(!nQ)switch(e.tailMode){case"visible":break;case"collapsed":for(var r=e.tail,n=null;null!==r;)null!==r.alternate&&(n=r),r=r.sibling;null===n?t||null===e.tail?e.tail=null:e.tail.sibling=null:n.sibling=null;break;default:for(r=null,t=e.tail;null!==t;)null!==t.alternate&&(r=t),t=t.sibling;null===r?e.tail=null:r.sibling=null}}function s_(e){var t=null!==e.alternate&&e.alternate.child===e.child,r=0,n=0;if(t)for(var o=e.child;null!==o;)r|=o.lanes|o.childLanes,n|=0x47f00000&o.subtreeFlags,n|=0x47f00000&o.flags,o.return=e,o=o.sibling;else for(o=e.child;null!==o;)r|=o.lanes|o.childLanes,n|=o.subtreeFlags,n|=o.flags,o.return=e,o=o.sibling;return e.subtreeFlags|=n,e.childLanes=r,t}function sk(e,t){switch(nG(t),t.tag){case 3:on(om),ea();break;case 26:case 27:case 5:es(t);break;case 4:ea();break;case 31:null!==t.memoizedState&&as(t);break;case 13:as(t);break;case 19:au(t);break;case 10:on(t.type);break;case 22:case 23:as(t),ae(),null!==e&&Q(oC);break;case 24:on(om)}}function sj(e,t){try{var r=t.updateQueue,n=null!==r?r.lastEffect:null;if(null!==n){var o=n.next;r=o;do{if((r.tag&e)===e){n=void 0;var a=r.create;r.inst.destroy=n=a()}r=r.next}while(r!==o)}}catch(e){cM(t,t.return,e)}}function sS(e,t,r){try{var n=t.updateQueue,o=null!==n?n.lastEffect:null;if(null!==o){var a=o.next;n=a;do{if((n.tag&e)===e){var i=n.inst,s=i.destroy;if(void 0!==s){i.destroy=void 0,o=t;try{s()}catch(e){cM(o,r,e)}}}n=n.next}while(n!==a)}}catch(e){cM(t,t.return,e)}}function sC(e){var t=e.updateQueue;if(null!==t){var r=e.stateNode;try{o4(t,r)}catch(t){cM(e,e.return,t)}}}function sE(e,t,r){r.props=i$(e.type,e.memoizedProps),r.state=e.memoizedState;try{r.componentWillUnmount()}catch(r){cM(e,t,r)}}function sT(e,t){try{var r=e.ref;if(null!==r){switch(e.tag){case 26:case 27:case 5:var n=e.stateNode;break;case 30:var o=e.stateNode,a=nu(e.memoizedProps,o);(null===o.ref||o.ref.name!==a)&&(o.ref=uU(a)),n=o.ref;break;case 7:if(null===e.stateNode){var i=new uZ(e);f(e.child,!1,u3,i,void 0,void 0),e.stateNode=i}n=e.stateNode;break;default:n=e.stateNode}"function"==typeof r?e.refCleanup=r(n):r.current=n}}catch(r){cM(e,t,r)}}function sN(e,t){var r=e.ref,n=e.refCleanup;if(null!==r)if("function"==typeof n)try{n()}catch(r){cM(e,t,r)}finally{e.refCleanup=null,null!=(e=e.alternate)&&(e.refCleanup=null)}else if("function"==typeof r)try{r(null)}catch(r){cM(e,t,r)}else r.current=null}function sI(e,t){if((5===e.tag||27===e.tag||6===e.tag)&&null===e.alternate&&null!==t)for(var r=0;r<t.length;r++)u4(e.stateNode,t[r])}function sz(e){for(var t=e.return;null!==t&&(sL(t)&&u4(e.stateNode,t.stateNode),!sP(t));)t=t.return}function sR(e){for(var t=e.return;null!==t&&(sL(t)&&function(e,t){var r=t._eventListeners;if(null!==r)for(var n=0;n<r.length;n++){var o=r[n];e.removeEventListener(o.type,o.attachedListener,uV(o.optionsOrUseCapture))}3!==e.nodeType&&(null!==(r=t._observers)&&r.forEach(function(r){var n;"string"==typeof r.rootMargin?(uJ.push({fragmentInstance:t,observer:r,instance:e}),u0||(u0=!0,n=function(){u0=!1;var e=uJ;uJ=[];for(var t=0;t<e.length;t++){var r=e[t];r.observer.unobserve(r.instance)}},uT(function(){uT(function(e){return n(e)})}))):r.unobserve(e)}),null!=e.reactFragments&&e.reactFragments.delete(t))}(e.stateNode,t.stateNode),!sP(t));)t=t.return}function sP(e){return 5===e.tag||3===e.tag||27===e.tag}function sL(e){return e&&7===e.tag&&null!==e.stateNode}function sO(e){var t=e.type,r=e.memoizedProps,n=e.stateNode;try{switch(t){case"button":case"input":case"select":case"textarea":r.autoFocus&&n.focus();break;case"img":r.src?n.src=r.src:r.srcSet&&(n.srcset=r.srcSet)}}catch(t){cM(e,e.return,t)}}function sM(e,t,r){try{var n=e.stateNode;(function(e,t,r,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var o=null,a=null,i=null,l=null,c=null,u=null,d=null;for(h in r){var f=r[h];if(r.hasOwnProperty(h)&&null!=f)switch(h){case"checked":case"value":break;case"defaultValue":c=f;default:n.hasOwnProperty(h)||uf(e,t,h,null,n,f)}}for(var p in n){var h=n[p];if(f=r[p],n.hasOwnProperty(p)&&(null!=h||null!=f))switch(p){case"type":h!==f&&(tc=!0),a=h;break;case"name":h!==f&&(tc=!0),o=h;break;case"checked":h!==f&&(tc=!0),u=h;break;case"defaultChecked":h!==f&&(tc=!0),d=h;break;case"value":h!==f&&(tc=!0),i=h;break;case"defaultValue":h!==f&&(tc=!0),l=h;break;case"children":case"dangerouslySetInnerHTML":if(null!=h)throw Error(s(137,t));break;default:h!==f&&uf(e,t,p,h,n,f)}}tb(e,i,l,c,u,d,a,o);return;case"select":for(a in h=i=l=p=null,r)if(c=r[a],r.hasOwnProperty(a)&&null!=c)switch(a){case"value":break;case"multiple":h=c;default:n.hasOwnProperty(a)||uf(e,t,a,null,n,c)}for(o in n)if(a=n[o],c=r[o],n.hasOwnProperty(o)&&(null!=a||null!=c))switch(o){case"value":a!==c&&(tc=!0),p=a;break;case"defaultValue":a!==c&&(tc=!0),l=a;break;case"multiple":a!==c&&(tc=!0),i=a;default:a!==c&&uf(e,t,o,a,n,c)}t=l,r=i,n=h,null!=p?tk(e,!!r,p,!1):!!n!=!!r&&(null!=t?tk(e,!!r,t,!0):tk(e,!!r,r?[]:"",!1));return;case"textarea":for(l in h=p=null,r)if(o=r[l],r.hasOwnProperty(l)&&null!=o&&!n.hasOwnProperty(l))switch(l){case"value":case"children":break;default:uf(e,t,l,null,n,o)}for(i in n)if(o=n[i],a=r[i],n.hasOwnProperty(i)&&(null!=o||null!=a))switch(i){case"value":o!==a&&(tc=!0),p=o;break;case"defaultValue":o!==a&&(tc=!0),h=o;break;case"children":break;case"dangerouslySetInnerHTML":if(null!=o)throw Error(s(91));break;default:o!==a&&uf(e,t,i,o,n,a)}tj(e,p,h);return;case"option":for(var m in r)p=r[m],r.hasOwnProperty(m)&&null!=p&&!n.hasOwnProperty(m)&&("selected"===m?e.selected=!1:uf(e,t,m,null,n,p));for(c in n)p=n[c],h=r[c],n.hasOwnProperty(c)&&p!==h&&(null!=p||null!=h)&&("selected"===c?(p!==h&&(tc=!0),e.selected=p&&"function"!=typeof p&&"symbol"!=typeof p):uf(e,t,c,p,n,h));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var g in r)p=r[g],r.hasOwnProperty(g)&&null!=p&&!n.hasOwnProperty(g)&&uf(e,t,g,null,n,p);for(u in n)if(p=n[u],h=r[u],n.hasOwnProperty(u)&&p!==h&&(null!=p||null!=h))switch(u){case"children":case"dangerouslySetInnerHTML":if(null!=p)throw Error(s(137,t));break;default:uf(e,t,u,p,n,h)}return;default:if(tI(t)){for(var v in r)p=r[v],r.hasOwnProperty(v)&&void 0!==p&&!n.hasOwnProperty(v)&&up(e,t,v,void 0,n,p);for(d in n)p=n[d],h=r[d],n.hasOwnProperty(d)&&p!==h&&(void 0!==p||void 0!==h)&&up(e,t,d,p,n,h);return}}for(var x in r)p=r[x],r.hasOwnProperty(x)&&null!=p&&!n.hasOwnProperty(x)&&uf(e,t,x,null,n,p);for(f in n)p=n[f],h=r[f],n.hasOwnProperty(f)&&p!==h&&(null!=p||null!=h)&&uf(e,t,f,p,n,h)})(n,e.type,r,t),n[eX]=t}catch(t){cM(e,e.return,t)}}function sA(e){return 5===e.tag||3===e.tag||26===e.tag||27===e.tag&&uz(e.type)||4===e.tag}function sD(e){e:for(;;){for(;null===e.sibling;){if(null===e.return||sA(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;5!==e.tag&&6!==e.tag&&18!==e.tag;){if(27===e.tag&&uz(e.type)||2&e.flags||null===e.child||4===e.tag)continue e;e.child.return=e,e=e.child}if(!(2&e.flags))return e.stateNode}}function sF(e,t,r,n){var o=e.tag;if(5===o||6===o)o=e.stateNode,t?r.insertBefore(o,t):r.appendChild(o),sI(e,n),tc=!0;else if(4!==o&&(27===o&&(sI(e,n),n=null,uz(e.type)&&(r=e.stateNode)),null!==(e=e.child)))for(sF(e,t,r,n),e=e.sibling;null!==e;)sF(e,t,r,n),e=e.sibling}function s$(e){var t=e.stateNode,r=e.memoizedProps;try{for(var n=e.type,o=t.attributes;o.length;)t.removeAttributeNode(o[0]);uh(t,n,r),t[eY]=e,t[eX]=r}catch(t){cM(e,e.return,t)}}var sU=!1,sZ=null;function sq(e){(30===e.tag||0!=(0x2000000&e.subtreeFlags))&&(sU=!0)}var sB=null;function sV(){var e=sB;return sB=null,e}var sH=0;function sW(e,t,r,n,o){return sH=0,function e(t,r,n,o,a){for(var i=!1;null!==t;){if(5===t.tag){var s=t.stateNode;if(null!==o){var l=uA(s);o.push(l),l.view&&(i=!0)}else i||uA(s).view&&(i=!0);sU=!0,uL(s,0===sH?r:r+"_"+sH,n),sH++}else(22!==t.tag||null===t.memoizedState)&&(30===t.tag&&a||e(t.child,r,n,o,a)&&(i=!0));t=t.sibling}return i}(e.child,t,r,n,o)}function sG(e,t){for(;null!==e;)5===e.tag?uO(e.stateNode,e.memoizedProps):(22!==e.tag||null===e.memoizedState)&&(30===e.tag&&t||sG(e.child,t)),e=e.sibling}function sK(e){if(0!=(0x1200000&e.subtreeFlags))for(e=e.child;null!==e;){if((22!==e.tag||null===e.memoizedState)&&(sK(e),30===e.tag&&0!=(0x1200000&e.flags)&&e.stateNode.paired)){var t=e.memoizedProps;if(null==t.name||"auto"===t.name)throw Error(s(544));var r=t.name;"none"!==(t=nf(t.default,t.share))&&(sW(e,r,t,null,!1)||sG(e.child,!1))}e=e.sibling}}function sY(e,t){if(30===e.tag){var r=e.stateNode,n=e.memoizedProps,o=nu(n,r),a=nf(n.default,r.paired?n.share:n.enter);"none"!==a?sW(e,o,a,null,!1)?(sK(e),r.paired||t||cs(e,n.onEnter)):sG(e.child,!1):sK(e)}else if(0!=(0x2000000&e.subtreeFlags))for(e=e.child;null!==e;)sY(e,t),e=e.sibling;else sK(e)}function sX(e){if(null!==sZ&&0!==sZ.size){var t=sZ;if(0!=(0x1200000&e.subtreeFlags))for(e=e.child;null!==e;){if(22!==e.tag||null===e.memoizedState){if(30===e.tag&&0!=(0x1200000&e.flags)){var r=e.memoizedProps,n=r.name;if(null!=n&&"auto"!==n){var o=t.get(n);if(void 0!==o){var a=nf(r.default,r.share);if("none"!==a&&(sW(e,n,a,null,!1)?(o.paired=a=e.stateNode,a.paired=o,cs(e,r.onShare)):sG(e.child,!1)),t.delete(n),0===t.size)break}}}sX(e)}e=e.sibling}}}function sQ(e){if(30===e.tag){var t=e.memoizedProps,r=nu(t,e.stateNode),n=null!==sZ?sZ.get(r):void 0,o=nf(t.default,void 0!==n?t.share:t.exit);"none"!==o&&(sW(e,r,o,null,!1)?void 0!==n?(n.paired=o=e.stateNode,o.paired=n,sZ.delete(r),cs(e,t.onShare)):cs(e,t.onExit):sG(e.child,!1)),null!==sZ&&sX(e)}else if(0!=(0x2000000&e.subtreeFlags))for(e=e.child;null!==e;)sQ(e),e=e.sibling;else null!==sZ&&sX(e)}function sJ(e){if(0!=(0x1200000&e.subtreeFlags))for(e=e.child;null!==e;){if(22!==e.tag||null===e.memoizedState){if(30===e.tag&&0!=(0x1200000&e.flags)){var t=e.stateNode;null!==t.paired&&(t.paired=null,sG(e.child,!1))}sJ(e)}e=e.sibling}}function s0(e){if(30===e.tag)e.stateNode.paired=null,sG(e.child,!1),sJ(e);else if(0!=(0x2000000&e.subtreeFlags))for(e=e.child;null!==e;)s0(e),e=e.sibling;else sJ(e)}function s1(e,t,r,n,o,a,i){for(var s=!1;null!==t;){if(5===t.tag){var l=t.stateNode;if(null!==a&&sH<a.length){var c,u=a[sH],d=uA(l);if((u.view||d.view)&&(s=!0),c=0==(4&e.flags))if(d.clip)c=!0;else{c=u.rect;var f=d.rect;c=c.y!==f.y||c.x!==f.x||c.height!==f.height||c.width!==f.width}c&&(e.flags|=4),d.abs?d=!u.abs:(u=u.rect,d=d.rect,d=u.height!==d.height||u.width!==d.width),d&&(e.flags|=32)}else e.flags|=32;0!=(4&e.flags)&&uL(l,0===sH?r:r+"_"+sH,o),s&&0!=(4&e.flags)||(null===sB&&(sB=[]),sB.push(l,0===sH?n:n+"_"+sH,t.memoizedProps)),sH++}else(22!==t.tag||null===t.memoizedState)&&(30===t.tag&&i?e.flags|=32&t.flags:s1(e,t.child,r,n,o,a,i)&&(s=!0));t=t.sibling}return s}var s2=!1,s3=!1,s5=!1,s4=!1,s6="function"==typeof WeakSet?WeakSet:Set,s7=null,s9=!1,s8=!1,le=!1,lt=!1;function lr(e){for(;null!==s7;){var t=s7,r=e,n=t.alternate,o=t.flags;switch(t.tag){case 0:case 11:case 15:case 5:case 26:case 27:case 6:case 4:case 17:break;case 1:if(0!=(1024&o)&&null!==n){r=void 0,o=n.memoizedProps,n=n.memoizedState;var a=t.stateNode;try{var i=i$(t.type,o);r=a.getSnapshotBeforeUpdate(i,n),a.__reactInternalSnapshotBeforeUpdate=r}catch(e){cM(t,t.return,e)}}break;case 3:if(0!=(1024&o)){if(9===(r=(n=t.stateNode.containerInfo).nodeType))u6(n);else if(1===r)switch(n.nodeName){case"HEAD":case"HTML":case"BODY":u6(n);break;default:n.textContent=""}}break;case 30:r&&null!==n&&(r=nu(n.memoizedProps,n.stateNode),"none"!==(o=nf((o=t.memoizedProps).default,o.update))&&sW(n,r,o,n.memoizedState=[],!0));break;default:if(0!=(1024&o))throw Error(s(163))}if(null!==(n=t.sibling)){n.return=t.return,s7=n;break}s7=t.return}}function ln(e,t,r){var n=r.flags;switch(r.tag){case 0:case 11:case 15:lx(e,r),4&n&&sj(5,r);break;case 1:if(lx(e,r),4&n)if(e=r.stateNode,null===t)try{e.componentDidMount()}catch(e){cM(r,r.return,e)}else{var o=i$(r.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(o,t,e.__reactInternalSnapshotBeforeUpdate)}catch(e){cM(r,r.return,e)}}64&n&&sC(r),512&n&&sT(r,r.return);break;case 3:if(lx(e,r),64&n&&null!==(e=r.updateQueue)){if(t=null,null!==r.child)switch(r.child.tag){case 27:case 5:case 1:t=r.child.stateNode}try{o4(e,t)}catch(e){cM(r,r.return,e)}}break;case 27:null===t&&4&n&&s$(r);case 26:case 5:lx(e,r),null===t&&4&n&&sO(r),512&n&&sT(r,r.return);break;case 12:lx(e,r);break;case 31:lx(e,r),4&n&&lc(e,r);break;case 13:lx(e,r),4&n&&lu(e,r),64&n&&null!==(e=r.memoizedState)&&null!==(e=e.dehydrated)&&function(e,t){var r=e.ownerDocument;if("$~"===e.data)e._reactRetry=t;else if("$?"!==e.data||"loading"!==r.readyState)t();else{var n=function(){t(),r.removeEventListener("DOMContentLoaded",n)};r.addEventListener("DOMContentLoaded",n),e._reactRetry=n}}(e,r=c$.bind(null,r));break;case 22:if(!(n=null!==r.memoizedState||s2)){var a=null!==t&&null!==t.memoizedState||s3;t=s2,o=s3,s2=n,(s3=a)&&!o?(n=2,0!=(8772&r.subtreeFlags)&&(n|=1),function e(t,r,n){for(n=0!=(8772&r.subtreeFlags)?n:-2&n,r=r.child;null!==r;){var o=r.alternate,a=t,i=r,s=i.flags,l=0!=(1&n);switch(i.tag){case 0:case 11:case 15:e(a,i,n),sj(4,i);break;case 1:if(e(a,i,n),"function"==typeof(a=(o=i).stateNode).componentDidMount)try{a.componentDidMount()}catch(e){cM(o,o.return,e)}if(null!==(a=(o=i).updateQueue)){var c=o.stateNode;try{var u=a.shared.hiddenCallbacks;if(null!==u)for(a.shared.hiddenCallbacks=null,a=0;a<u.length;a++)o5(u[a],c)}catch(e){cM(o,o.return,e)}}l&&64&s&&sC(i),sT(i,i.return);break;case 27:0!=(2&n)&&s$(i);case 5:5!==i.tag&&27!==i.tag||sz(i),e(a,i,n),l&&null===o&&4&s&&sO(i),sT(i,i.return);break;case 6:sz(i);break;case 26:c=i.stateNode,null!==i.memoizedState||null===c||s2||dC(du(c.ownerDocument),i.type,c),e(a,i,n),l&&null===o&&4&s&&sO(i),sT(i,i.return);break;case 12:e(a,i,n);break;case 31:e(a,i,n),l&&4&s&&lc(a,i);break;case 13:e(a,i,n),l&&4&s&&lu(a,i);break;case 22:null===i.memoizedState&&e(a,i,n),sT(i,i.return);break;case 30:e(a,i,n),sT(i,i.return);break;case 7:sT(i,i.return);default:e(a,i,n)}r=r.sibling}}(e,r,n)):lx(e,r),s2=t,s3=o}break;case 30:lx(e,r),512&n&&sT(r,r.return);break;case 7:512&n&&sT(r,r.return);default:lx(e,r)}}function lo(e,t){for(e=e.child;null!==e;)(function e(t,r){switch(t.tag){case 5:case 26:try{var n=t.stateNode;if(r){var o=n.style;"function"==typeof o.setProperty?o.setProperty("display","none","important"):o.display="none"}else{var a=t.stateNode,i=t.memoizedProps.style,s=null!=i&&i.hasOwnProperty("display")?i.display:null;a.style.display=null==s||"boolean"==typeof s?"":(""+s).trim()}}catch(e){cM(t,t.return,e)}!function t(r,n){if(0x4000000&r.subtreeFlags)for(r=r.child;null!==r;){e:{var o=r;switch(o.tag){case 4:e(o,n);break e;case 22:null===o.memoizedState&&t(o,n);break e;default:t(o,n)}}r=r.sibling}}(t,r);break;case 6:try{t.stateNode.nodeValue=r?"":t.memoizedProps,tc=!0}catch(e){cM(t,t.return,e)}break;case 18:try{var l=t.stateNode;r?uP(l,!0):uP(t.stateNode,!1)}catch(e){cM(t,t.return,e)}break;case 22:case 23:null===t.memoizedState&&lo(t,r);break;default:lo(t,r)}})(e,t),e=e.sibling}var la=null,li=!1;function ls(e,t,r){for(r=r.child;null!==r;)ll(e,t,r),r=r.sibling}function ll(e,t,r){if(eE&&"function"==typeof eE.onCommitFiberUnmount)try{eE.onCommitFiberUnmount(eC,r)}catch(e){}switch(r.tag){case 26:s3||sN(r,t),ls(e,t,r),r.memoizedState?r.memoizedState.count--:r.stateNode&&!s3&&(r=r.stateNode).parentNode.removeChild(r);break;case 27:s3||sN(r,t),sR(r);var n=la,o=li;uz(r.type)&&(la=r.stateNode,li=!1),ls(e,t,r),di(r.stateNode,r.type,r.memoizedProps),la=n,li=o;break;case 5:s3||sN(r,t),sR(r);case 6:if(6===r.tag&&sR(r),n=la,o=li,la=null,ls(e,t,r),la=n,li=o,null!==la)if(li)try{(9===la.nodeType?la.body:"HTML"===la.nodeName?la.ownerDocument.body:la).removeChild(r.stateNode),tc=!0}catch(e){cM(r,t,e)}else try{la.removeChild(r.stateNode),tc=!0}catch(e){cM(r,t,e)}break;case 18:null!==la&&(li?(uR(9===(e=la).nodeType?e.body:"HTML"===e.nodeName?e.ownerDocument.body:e,r.stateNode),fi(e)):uR(la,r.stateNode));break;case 4:n=la,o=li,la=r.stateNode.containerInfo,li=!0,ls(e,t,r),la=n,li=o;break;case 0:case 11:case 14:case 15:sS(2,r,t),s3||sS(4,r,t),ls(e,t,r);break;case 1:s3||(sN(r,t),"function"==typeof(n=r.stateNode).componentWillUnmount&&sE(r,t,n)),ls(e,t,r);break;case 21:default:ls(e,t,r);break;case 22:s3=(n=s3)||null!==r.memoizedState,ls(e,t,r),s3=n;break;case 30:sN(r,t),ls(e,t,r);break;case 7:s3||sN(r,t),ls(e,t,r)}}function lc(e,t){if(null===t.memoizedState&&null!==(e=t.alternate)&&null!==(e=e.memoizedState)){e=e.dehydrated;try{fi(e)}catch(e){cM(t,t.return,e)}}}function lu(e,t){if(null===t.memoizedState&&null!==(e=t.alternate)&&null!==(e=e.memoizedState)&&null!==(e=e.dehydrated))try{fi(e)}catch(e){cM(t,t.return,e)}}function ld(e,t){var r=function(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return null===t&&(t=e.stateNode=new s6),t;case 22:return null===(t=(e=e.stateNode)._retryCache)&&(t=e._retryCache=new s6),t;default:throw Error(s(435,e.tag))}}(e);t.forEach(function(t){if(!r.has(t)){r.add(t);var n=cU.bind(null,e,t);t.then(n,n)}})}function lf(e,t,r){var n=t.deletions;if(null!==n)for(var o=0;o<n.length;o++){var a=n[o],i=e,l=t,c=l;e:for(;null!==c;){switch(c.tag){case 27:if(uz(c.type)){la=c.stateNode,li=!1;break e}break;case 5:la=c.stateNode,li=!1;break e;case 3:case 4:la=c.stateNode.containerInfo,li=!0;break e}c=c.return}if(null===la)throw Error(s(160));ll(i,l,a),la=null,li=!1,null!==(i=a.alternate)&&(i.return=null),a.return=null}if(13886&t.subtreeFlags)for(t=t.child;null!==t;)lh(t,e,r),t=t.sibling}var lp=null;function lh(e,t,r){var n=e.alternate,o=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(4&o&&null!==(n=null!==(n=e.updateQueue)?n.events:null))for(var a=0;a<n.length;a++){var i=n[a];i.ref.impl=i.nextImpl}lf(t,e,r),lm(e),4&o&&(sS(3,e,e.return),sj(3,e),sS(5,e,e.return));break;case 1:lf(t,e,r),lm(e),512&o&&(s3||null===n||sN(n,n.return)),64&o&&s2&&null!==(e=e.updateQueue)&&null!==(t=e.callbacks)&&(r=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=null===r?t:r.concat(t));break;case 26:if(a=lp,lf(t,e,r),lm(e),512&o&&(s3||null===n||sN(n,n.return)),4&o)if(o=null!==n?n.memoizedState:null,r=e.memoizedState,null===n)if(null===r)if(null===e.stateNode)if(s2)e.stateNode=u_(e.type,e.memoizedProps,t.containerInfo,e);else{e:{t=e.type,r=e.memoizedProps,o=a.ownerDocument||a;t:switch(t){case"title":(!(n=o.getElementsByTagName("title")[0])||n[e3]||n[eY]||"http://www.w3.org/2000/svg"===n.namespaceURI||n.hasAttribute("itemprop"))&&(n=o.createElement(t),o.head.insertBefore(n,o.querySelector("head > title"))),uh(n,t,r),n[eY]=e,te(n),t=n;break e;case"link":if(a=dS("link","href",o).get(t+(r.href||""))){for(i=0;i<a.length;i++)if((n=a[i]).getAttribute("href")===(null==r.href||""===r.href?null:r.href)&&n.getAttribute("rel")===(null==r.rel?null:r.rel)&&n.getAttribute("title")===(null==r.title?null:r.title)&&n.getAttribute("crossorigin")===(null==r.crossOrigin?null:r.crossOrigin)){a.splice(i,1);break t}}uh(n=o.createElement(t),t,r),o.head.appendChild(n);break;case"meta":if(a=dS("meta","content",o).get(t+(r.content||""))){for(i=0;i<a.length;i++)if((n=a[i]).getAttribute("content")===(null==r.content?null:""+r.content)&&n.getAttribute("name")===(null==r.name?null:r.name)&&n.getAttribute("property")===(null==r.property?null:r.property)&&n.getAttribute("http-equiv")===(null==r.httpEquiv?null:r.httpEquiv)&&n.getAttribute("charset")===(null==r.charSet?null:r.charSet)){a.splice(i,1);break t}}uh(n=o.createElement(t),t,r),o.head.appendChild(n);break;default:throw Error(s(468,t))}n[eY]=e,te(n),t=n}e.stateNode=t}else s2||dC(a,e.type,e.stateNode);else e.stateNode=db(a,r,e.memoizedProps);else o!==r?(null===o?null===(t=n.stateNode)||s3||t.parentNode.removeChild(t):o.count--,null===r?s2||dC(a,e.type,e.stateNode):db(a,r,e.memoizedProps)):null===r&&null!==e.stateNode&&sM(e,e.memoizedProps,n.memoizedProps);break;case 27:lf(t,e,r),lm(e),512&o&&(s3||null===n||sN(n,n.return)),null!==n&&4&o&&sM(e,e.memoizedProps,n.memoizedProps);break;case 5:if(a=s5,s5=!1,lf(t,e,r),s5=a,lm(e),512&o&&(s3||null===n||sN(n,n.return)),32&e.flags){t=e.stateNode;try{tC(t,""),tc=!0}catch(t){cM(e,e.return,t)}}4&o&&null!=e.stateNode&&(t=e.memoizedProps,sM(e,t,null!==n?n.memoizedProps:t)),1024&o&&(s4=!0);break;case 6:if(lf(t,e,r),lm(e),4&o){if(null===e.stateNode)throw Error(s(162));t=e.memoizedProps,r=e.stateNode;try{r.nodeValue=t,tc=!0}catch(t){cM(e,e.return,t)}}break;case 3:if(tc=!1,dj=null,a=lp,lp=du(t.containerInfo),lf(t,e,r),lp=a,lm(e),4&o&&null!==n&&n.memoizedState.isDehydrated)try{fi(t.containerInfo)}catch(t){cM(e,e.return,t)}s4&&(s4=!1,function e(t){if(1024&t.subtreeFlags)for(t=t.child;null!==t;){var r=t;e(r),5===r.tag&&1024&r.flags&&(r=r.stateNode,dV=!0,r.reset(),dV=!1),t=t.sibling}}(e)),tc=!1;break;case 4:o=s5,s5=s2,n=tu(),a=lp,lp=du(e.stateNode.containerInfo),lf(t,e,r),lm(e),lp=a,tc&&s8&&(le=!0),tc=n,s5=o;break;case 12:lf(t,e,r),lm(e);break;case 31:case 19:lf(t,e,r),lm(e),4&o&&null!==(t=e.updateQueue)&&(e.updateQueue=null,ld(e,t));break;case 13:lf(t,e,r),lm(e),8192&e.child.flags&&null!==e.memoizedState!=(null!==n&&null!==n.memoizedState)&&(lQ=ev()),4&o&&null!==(t=e.updateQueue)&&(e.updateQueue=null,ld(e,t));break;case 22:a=null!==e.memoizedState,i=null!==n&&null!==n.memoizedState;var l=s2,c=s3,u=s5;s2=l||a,s5=u||a,s3=c||i,lf(t,e,r),s3=c,s5=u,s2=l,lm(e),8192&o&&((t=e.stateNode)._visibility=a?-2&t._visibility:1|t._visibility,!a||null===n||i||s2||s3||(t=i||s3,r=s2,n=s3,s2=a||s2,s3=t,function e(t,r){for(t=t.child;null!==t;){var n=t;switch(n.tag){case 0:case 11:case 14:case 15:sS(4,n,n.return),e(n,r);break;case 1:sN(n,n.return);var o=n.stateNode;"function"==typeof o.componentWillUnmount&&sE(n,n.return,o),e(n,r);break;case 27:0!=(2&r)&&di(n.stateNode,n.type,n.memoizedProps);case 5:sN(n,n.return),5!==n.tag&&27!==n.tag||sR(n),e(n,r);break;case 6:sR(n);break;case 26:sN(n,n.return),o=n.stateNode,null!==n.memoizedState||null===o||s3||o.parentNode.removeChild(o),e(n,r);break;case 22:null===n.memoizedState&&e(n,r);break;case 30:sN(n,n.return),e(n,r);break;case 7:sN(n,n.return);default:e(n,r)}t=t.sibling}}(e,2),s2=r,s3=n),!a&&s5||lo(e,a)),4&o&&null!==(t=e.updateQueue)&&null!==(r=t.retryQueue)&&(t.retryQueue=null,ld(e,r));break;case 30:512&o&&(s3||null===n||sN(n,n.return)),o=tu(),a=s8,i=(0x13ffff00&r)===r,l=e.memoizedProps,s8=i&&"none"!==nf(l.default,l.update),lf(t,e,r),lm(e),i&&null!==n&&tc&&(e.flags|=4),s8=a,tc=o;break;case 21:break;case 7:512&o&&(s3||null===n||sN(n,n.return)),n&&null!==n.stateNode&&(n.stateNode._fragmentFiber=e);default:lf(t,e,r),lm(e)}}function lm(e){var t=e.flags;if(2&t){try{for(var r,n=e.return;null!==n;){if(sA(n)){r=n;break}n=n.return}n=null;for(var o=e.return;null!==o;){if(sL(o)){var a=o.stateNode;null===n?n=[a]:n.push(a)}if(sP(o))break;o=o.return}var i=n;if(null==r)throw Error(s(160));switch(r.tag){case 27:var l=r.stateNode,c=sD(e);sF(e,c,l,i);break;case 5:var u=r.stateNode;32&r.flags&&(tC(u,""),r.flags&=-33);var d=sD(e);sF(e,d,u,i);break;case 3:case 4:var f=r.stateNode.containerInfo,p=sD(e);!function e(t,r,n,o){var a=t.tag;if(5===a||6===a)a=t.stateNode,r?(9===n.nodeType?n.body:"HTML"===n.nodeName?n.ownerDocument.body:n).insertBefore(a,r):((r=9===n.nodeType?n.body:"HTML"===n.nodeName?n.ownerDocument.body:n).appendChild(a),null!=(n=n._reactRootContainer)||null!==r.onclick||(r.onclick=tL)),sI(t,o),tc=!0;else if(4!==a&&(27===a&&(sI(t,o),o=null,uz(t.type)&&(n=t.stateNode,r=null)),null!==(t=t.child)))for(e(t,r,n,o),t=t.sibling;null!==t;)e(t,r,n,o),t=t.sibling}(e,p,f,i);break;default:throw Error(s(161))}}catch(t){cM(e,e.return,t)}e.flags&=-3}4096&t&&(e.flags&=-4097)}function lg(e,t){if(9270&t.subtreeFlags)for(t=t.child;null!==t;)lv(t,e),t=t.sibling;else!function e(t,r){for(t=t.child;null!==t;){if(30===t.tag){var n=t.memoizedProps,o=t.stateNode,a=nu(n,o),i=nf(n.default,n.update);if(r)var s=null===(o=o.clones)?null:o.map(uD);else s=t.memoizedState,t.memoizedState=null;o=t;var l=t.child;sH=0,a=s1(o,l,a,a,i,s,!1),0!=(4&t.flags)&&a&&(r||cs(t,n.onUpdate))}else 0!=(0x2000000&t.subtreeFlags)&&e(t,r);t=t.sibling}}(t,!1)}function lv(e,t){var r=e.alternate;if(null===r)sY(e,!1);else switch(e.tag){case 3:if(lt=s9=!1,sV(),lg(t,e),!s9&&!le){if(null!==(e=sB))for(var n=0;n<e.length;n+=3){r=e[n];var o=e[n+1];uO(r,e[n+2]),null!==(r=r.ownerDocument.documentElement)&&r.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+o+")"})}null!==(e=9===(e=t.containerInfo).nodeType?e.documentElement:e.ownerDocument.documentElement)&&""===e.style.viewTransitionName&&(e.style.viewTransitionName="none",e.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),lt=!0}sB=null;break;case 5:default:lg(t,e);break;case 4:n=s9,s9=!1,lg(t,e),s9&&(le=!0),s9=n;break;case 22:null===e.memoizedState&&(null!==r.memoizedState?sY(e,!1):lg(t,e));break;case 30:n=s9,o=sV(),s9=!1,lg(t,e),s9&&(e.flags|=4);var a=e.memoizedProps,i=e.stateNode;t=nu(a,i),i=nu(r.memoizedProps,i);var s=nf(a.default,a.update);"none"===s?t=!1:(a=r.memoizedState,r.memoizedState=null,r=e.child,sH=0,t=s1(e,r,t,i,s,a,!0),sH!==(null===a?0:a.length)&&(e.flags|=32)),0!=(4&e.flags)&&t?(cs(e,e.memoizedProps.onUpdate),sB=o):null!==o&&(o.push.apply(o,sB),sB=o),s9=0!=(32&e.flags)||n}}function lx(e,t){if(8772&t.subtreeFlags)for(t=t.child;null!==t;)ln(e,t.alternate,t),t=t.sibling}function ly(e,t){var r=null;null!==e&&null!==e.memoizedState&&null!==e.memoizedState.cachePool&&(r=e.memoizedState.cachePool.pool),e=null,null!==t.memoizedState&&null!==t.memoizedState.cachePool&&(e=t.memoizedState.cachePool.pool),e!==r&&(null!=e&&e.refCount++,null!=r&&ov(r))}function lb(e,t){e=null,null!==t.alternate&&(e=t.alternate.memoizedState.cache),(t=t.memoizedState.cache)!==e&&(t.refCount++,null!=e&&ov(e))}function lw(e,t,r,n){var o=(0x13ffff00&r)===r;if(t.subtreeFlags&(o?10262:10256))for(t=t.child;null!==t;)l_(e,t,r,n),t=t.sibling;else o&&function e(t){for(t=t.child;null!==t;)30===t.tag?sG(t.child,!1):0!=(0x2000000&t.subtreeFlags)&&e(t),t=t.sibling}(t)}function l_(e,t,r,n){var o=(0x13ffff00&r)===r;o&&null===t.alternate&&null!==t.return&&null!==t.return.alternate&&s0(t);var a=t.flags;switch(t.tag){case 0:case 11:case 15:lw(e,t,r,n),2048&a&&sj(9,t);break;case 1:case 31:case 13:default:lw(e,t,r,n);break;case 3:lw(e,t,r,n),o&&lt&&("root"===(e=9===(e=e.containerInfo).nodeType?e.body:"HTML"===e.nodeName?e.ownerDocument.body:e).style.viewTransitionName&&(e.style.viewTransitionName=""),null!==(e=e.ownerDocument.documentElement)&&"none"===e.style.viewTransitionName&&(e.style.viewTransitionName="")),2048&a&&(a=null,null!==t.alternate&&(a=t.alternate.memoizedState.cache),(t=t.memoizedState.cache)!==a&&(t.refCount++,null!=a&&ov(a)));break;case 12:if(2048&a){lw(e,t,r,n),a=t.stateNode;try{var i=t.memoizedProps,s=i.id,l=i.onPostCommit;"function"==typeof l&&l(s,null===t.alternate?"mount":"update",a.passiveEffectDuration,-0)}catch(e){cM(t,t.return,e)}}else lw(e,t,r,n);break;case 23:break;case 22:i=t.stateNode,s=t.alternate,null!==t.memoizedState?(o&&null!==s&&null===s.memoizedState&&s0(s),2&i._visibility?lw(e,t,r,n):lk(e,t)):(o&&null!==s&&null!==s.memoizedState&&s0(t),2&i._visibility?lw(e,t,r,n):(i._visibility|=2,function e(t,r,n,o,a){for(a=a&&0!=(10256&r.subtreeFlags),r=r.child;null!==r;){var i=r,s=i.flags;switch(i.tag){case 0:case 11:case 15:e(t,i,n,o,a),sj(8,i);break;case 23:break;case 22:var l=i.stateNode;null!==i.memoizedState?2&l._visibility?e(t,i,n,o,a):lk(t,i):(l._visibility|=2,e(t,i,n,o,a)),a&&2048&s&&ly(i.alternate,i);break;case 24:e(t,i,n,o,a),a&&2048&s&&lb(i.alternate,i);break;default:e(t,i,n,o,a)}r=r.sibling}}(e,t,r,n,0!=(10256&t.subtreeFlags)))),2048&a&&ly(s,t);break;case 24:lw(e,t,r,n),2048&a&&lb(t.alternate,t);break;case 30:o&&null!==(a=t.alternate)&&(sG(a.child,!0),sG(t.child,!0)),lw(e,t,r,n)}}function lk(e,t){if(10256&t.subtreeFlags)for(t=t.child;null!==t;){var r=t,n=r.flags;switch(r.tag){case 22:lk(e,r),2048&n&&ly(r.alternate,r);break;case 24:lk(e,r),2048&n&&lb(r.alternate,r);break;default:lk(e,r)}t=t.sibling}}var lj=8192;function lS(e,t,r){if(e.subtreeFlags&lj)for(e=e.child;null!==e;)lC(e,t,r),e=e.sibling}function lC(e,t,r){switch(e.tag){case 26:lS(e,t,r),e.flags&lj&&(null!==e.memoizedState?function(e,t,r,n){if("stylesheet"===r.type&&("string"!=typeof n.media||!1!==matchMedia(n.media).matches)&&0==(4&r.state.loading)){if(null===r.instance){var o=dm(n.href),a=t.querySelector(dg(o));if(a){null!==(t=a._p)&&"object"==typeof t&&"function"==typeof t.then&&(e.count++,e=dP.bind(e),t.then(e,e)),r.state.loading|=4,r.instance=a,te(a);return}a=t.ownerDocument||t,n=dv(n),(o=dl.get(o))&&d_(n,o),te(a=a.createElement("link"));var i=a;i._p=new Promise(function(e,t){i.onload=e,i.onerror=t}),uh(a,"link",n),r.instance=a}null===e.stylesheets&&(e.stylesheets=new Map),e.stylesheets.set(r,t),(t=r.state.preload)&&0==(3&r.state.loading)&&(e.count++,r=dP.bind(e),t.addEventListener("load",r),t.addEventListener("error",r))}}(r,lp,e.memoizedState,e.memoizedProps):(e=e.stateNode,(0x13ffff40&t)===t&&dI(r,e)));break;case 5:lS(e,t,r),e.flags&lj&&(e=e.stateNode,(0x13ffff40&t)===t&&dI(r,e));break;case 3:case 4:var n=lp;lp=du(e.stateNode.containerInfo),lS(e,t,r),lp=n;break;case 22:null===e.memoizedState&&(null!==(n=e.alternate)&&null!==n.memoizedState?(n=lj,lj=0x1000000,lS(e,t,r),lj=n):lS(e,t,r));break;case 30:if(0!=(e.flags&lj)&&null!=(n=e.memoizedProps.name)&&"auto"!==n){var o=e.stateNode;o.paired=null,null===sZ&&(sZ=new Map),sZ.set(n,o)}lS(e,t,r);break;default:lS(e,t,r)}}function lE(e){var t=e.alternate;if(null!==t&&null!==(e=t.child)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(null!==e)}}function lT(e){var t=e.deletions;if(0!=(16&e.flags)){if(null!==t)for(var r=0;r<t.length;r++){var n=t[r];s7=n,lI(n,e)}lE(e)}if(10256&e.subtreeFlags)for(e=e.child;null!==e;)lN(e),e=e.sibling}function lN(e){switch(e.tag){case 0:case 11:case 15:lT(e),2048&e.flags&&sS(9,e,e.return);break;case 3:case 12:default:lT(e);break;case 22:var t=e.stateNode;null!==e.memoizedState&&2&t._visibility&&(null===e.return||13!==e.return.tag)?(t._visibility&=-3,function e(t){var r=t.deletions;if(0!=(16&t.flags)){if(null!==r)for(var n=0;n<r.length;n++){var o=r[n];s7=o,lI(o,t)}lE(t)}for(t=t.child;null!==t;){switch((r=t).tag){case 0:case 11:case 15:sS(8,r,r.return),e(r);break;case 22:2&(n=r.stateNode)._visibility&&(n._visibility&=-3,e(r));break;default:e(r)}t=t.sibling}}(e)):lT(e)}}function lI(e,t){for(;null!==s7;){var r=s7;switch(r.tag){case 0:case 11:case 15:sS(8,r,t);break;case 23:case 22:if(null!==r.memoizedState&&null!==r.memoizedState.cachePool){var n=r.memoizedState.cachePool.pool;null!=n&&n.refCount++}break;case 24:ov(r.memoizedState.cache)}if(null!==(n=r.child))n.return=r,s7=n;else for(r=e;null!==s7;){var o=(n=s7).sibling,a=n.return;if(!function e(t){var r=t.alternate;null!==r&&(t.alternate=null,e(r)),t.child=null,t.deletions=null,t.sibling=null,5===t.tag&&null!==(r=t.stateNode)&&e4(r),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}(n),n===r){s7=null;break}if(null!==o){o.return=a,s7=o;break}s7=a}}}var lz={getCacheForType:function(e){var t=oc(om),r=t.data.get(e);return void 0===r&&(r=e(),t.data.set(e,r)),r},cacheSignal:function(){return oc(om).controller.signal}},lR="function"==typeof WeakMap?WeakMap:Map,lP=0,lL=null,lO=null,lM=0,lA=0,lD=null,lF=!1,l$=!1,lU=!1,lZ=0,lq=0,lB=0,lV=0,lH=0,lW=0,lG=0,lK=null,lY=null,lX=!1,lQ=0,lJ=0,l0=1/0,l1=null,l2=null,l3=0,l5=null,l4=null,l6=0,l7=0,l9=null,l8=null,ce=null,ct=null,cr=null,cn=0,co=null;function ca(){return 0!=(2&lP)&&0!==lM?lM&-lM:null!==H.T?c1():eW()}function ci(){if(0===lW)if(0==(0x20000000&lM)||nQ){var e=eP;0==(3932160&(eP<<=1))&&(eP=262144),lW=e}else lW=0x20000000;return null!==(e=at.current)&&(e.flags|=32),lW}function cs(e,t){if(null!=t){var r=e.stateNode,n=r.ref;null===n&&(n=r.ref=uU(nu(e.memoizedProps,r))),null===ct&&(ct=[]),ct.push(t.bind(null,n))}}function cl(e,t,r){(e===lL&&(2===lA||9===lA)||null!==e.cancelPendingCommit)&&(ch(e,0),cd(e,lM,lW,!1)),eU(e,r),(0==(2&lP)||e!==lL)&&(e===lL&&(0==(2&lP)&&(lV|=r),4===lq&&cd(e,lM,lW,!1)),cG(e))}function cc(e,t,r){if(0!=(6&lP))throw Error(s(327));for(var n=!r&&0==(127&t)&&0==(t&e.expiredLanes)||eA(e,t),o=n?function(e,t){var r=lP;lP|=2;var n=cv(),o=cx();lL!==e||lM!==t?(l1=null,l0=ev()+500,ch(e,t)):l$=eA(e,t);e:for(;;)try{if(0!==lA&&null!==lO){t=lO;var a=lD;t:switch(lA){case 1:lA=0,lD=null,ck(e,t,a,1);break;case 2:case 9:if(oL(a)){lA=0,lD=null,c_(t);break}t=function(){2!==lA&&9!==lA||lL!==e||(lA=7),cG(e)},a.then(t,t);break e;case 3:lA=7;break e;case 4:lA=5;break e;case 7:oL(a)?(lA=0,lD=null,c_(t)):(lA=0,lD=null,ck(e,t,a,7));break;case 5:var i=null;switch(lO.tag){case 26:i=lO.memoizedState;case 5:case 27:var l=lO;if(i?dT(i):l.stateNode.complete){lA=0,lD=null;var c=l.sibling;if(null!==c)lO=c;else{var u=l.return;null!==u?(lO=u,cj(u)):lO=null}break t}}lA=0,lD=null,ck(e,t,a,5);break;case 6:lA=0,lD=null,ck(e,t,a,6);break;case 8:cp(),lq=6;break e;default:throw Error(s(462))}}for(;null!==lO&&!em();)cw(lO);break}catch(t){cm(e,t)}return(ot=oe=null,H.H=n,H.A=o,lP=r,null!==lO)?0:(lL=null,lM=0,nv(),lq)}(e,t):cb(e,t,!0),a=n;;){if(0===o)l$&&!n&&cd(e,t,0,!1);else{if(r=e.current.alternate,a&&!function(e){for(var t=e;;){var r=t.tag;if((0===r||11===r||15===r)&&16384&t.flags&&null!==(r=t.updateQueue)&&null!==(r=r.stores))for(var n=0;n<r.length;n++){var o=r[n],a=o.getSnapshot;o=o.value;try{if(!rB(a(),o))return!1}catch(e){return!1}}if(r=t.child,16384&t.subtreeFlags&&null!==r)r.return=t,t=r;else{if(t===e)break;for(;null===t.sibling;){if(null===t.return||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}(r)){o=cb(e,t,!1),a=!1;continue}if(2===o){if(a=t,e.errorRecoveryDisabledLanes&a)var i=0;else i=0!=(i=-0x20000001&e.pendingLanes)?i:0x20000000&i?0x20000000:0;if(0!==i){t=i;e:{o=lK;var l=e.current.memoizedState.isDehydrated;if(l&&(ch(e,i).flags|=256),6===(i=cb(e,i,!1)))l||(e.errorRecoveryDisabledLanes=e.errorRecoveryDisabledLanes|a|lW);else if(2!==i){if(lU&&!l){e.errorRecoveryDisabledLanes|=a,lV|=a,o=4;break e}a=lY,lY=o,null!==a&&(null===lY?lY=a:lY.push.apply(lY,a))}o=i}if(a=!1,2!==o)continue}}if(1===o){ch(e,0),cd(e,t,0,!0);break}e:{switch(n=e,a=o){case 0:case 1:throw Error(s(345));case 4:if((4194048&t)!==t&&(0x3c00000&t)!==t)break;case 6:cd(n,t,lW,!lF);break e;case 2:lY=null;break;case 3:case 5:break;default:throw Error(s(329))}if((0x3c00000&t)===t&&10<(o=lQ+300-ev())){if(cd(n,t,lW,!lF),0!==eM(n,0,!0))break e;l6=t,n.timeoutHandle=uS(cu.bind(null,n,r,lY,l1,lX,t,lW,lV,lG,lF,a,"Throttled",-0,0),o);break e}cu(n,r,lY,l1,lX,t,lW,lV,lG,lF,a,null,-0,0)}}break}cG(e)}function cu(e,t,r,n,o,a,i,s,l,c,u,d,f,p){e.timeoutHandle=-1;var h,m,g=t.subtreeFlags,v=(0x13ffff00&a)===a;if(d=null,(v||8192&g||0x1002000==(0x1002000&g))&&(sZ=null,lC(t,a,d={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:tL}),v&&(g=d,null!=(v=(9===(v=e.containerInfo).nodeType?v:v.ownerDocument).__reactViewTransition)&&(g.count++,g.waitingForViewTransition=!0,g=dP.bind(g),v.finished.then(g,g))),null!==(h=d,m=g=(0x3c00000&a)===a?lQ-ev():(4194048&a)===a?lJ-ev():0,h.stylesheets&&0===h.count&&dM(h,h.stylesheets),g=0<h.count||0<h.imgCount?function(e){var t=setTimeout(function(){if(h.stylesheets&&dM(h,h.stylesheets),h.unsuspend){var e=h.unsuspend;h.unsuspend=null,e()}},6e4+m);0<h.imgBytes&&0===dz&&(dz=62500*function(){if("function"==typeof performance.getEntriesByType){for(var e=0,t=0,r=performance.getEntriesByType("resource"),n=0;n<r.length;n++){var o=r[n],a=o.transferSize,i=o.initiatorType,s=o.duration;if(a&&s&&ug(i)){for(i=0,s=o.responseEnd,n+=1;n<r.length;n++){var l=r[n],c=l.startTime;if(c>s)break;var u=l.transferSize,d=l.initiatorType;u&&ug(d)&&(i+=u*((l=l.responseEnd)<s?1:(s-c)/(l-c)))}if(--n,t+=8*(a+i)/(o.duration/1e3),10<++e)break}}if(0<e)return t/e/1e6}return navigator.connection&&"number"==typeof(e=navigator.connection.downlink)?e:5}());var r=setTimeout(function(){if(h.waitingForImages=!1,0===h.count&&(h.stylesheets&&dM(h,h.stylesheets),h.unsuspend)){var e=h.unsuspend;h.unsuspend=null,e()}},(h.imgBytes>dz?50:800)+m);return h.unsuspend=e,function(){h.unsuspend=null,clearTimeout(t),clearTimeout(r)}}:null))){l6=a,e.cancelPendingCommit=g(cC.bind(null,e,t,a,r,n,o,i,s,l,c,u,d,null,f,p)),cd(e,a,i,!c);return}cC(e,t,a,r,n,o,i,s,l,c,u,d)}function cd(e,t,r,n){t=eD(e,t)&~lH&~lV,e.suspendedLanes|=t,e.pingedLanes&=~t,n&&(e.warmLanes|=t),n=e.expirationTimes;for(var o=t;0<o;){var a=31-eN(o),i=1<<a;n[a]=-1,o&=~i}0!==r&&eZ(e,r,t)}function cf(){return 0!=(6&lP)||(cK(0,!1),!1)}function cp(){if(null!==lO){if(0===lA)var e=lO.return;else e=lO,ot=oe=null,az(e),o$=null,oU=0,e=lO;for(;null!==e;)sk(e.alternate,e),e=e.return;lO=null}}function ch(e,t){var r=e.timeoutHandle;return -1!==r&&(e.timeoutHandle=-1,uC(r)),null!==(r=e.cancelPendingCommit)&&(e.cancelPendingCommit=null,r()),l6=0,cp(),lL=e,lO=r=nE(e.current,null),lM=t,lA=0,lD=null,lF=!1,l$=eA(e,t),lU=!1,lG=lW=lH=lV=lB=lq=0,lY=lK=null,lX=!1,lZ=eD(e,t),nv(),r}function cm(e,t){ap=null,H.H=iR,t===oI||t===oR?(t=oD(),lA=3):t===oz?(t=oD(),lA=4):lA=t===iK?8:null!==t&&"object"==typeof t&&"function"==typeof t.then?6:1,lD=t,null===lO&&(lq=1,iB(e,nO(t,e.current)))}function cg(){var e=at.current;return null===e||((4194048&lM)===lM?null===ar:((0x3c00000&lM)===lM||0!=(0x20000000&lM))&&e===ar)}function cv(){var e=H.H;return H.H=iR,null===e?iR:e}function cx(){var e=H.A;return H.A=lz,e}function cy(){lq=4,lF||(4194048&lM)!==lM&&null!==at.current||(l$=!0),0==(0x7ffffff&lB)&&0==(0x7ffffff&lV)||null===lL||cd(lL,lM,lW,!1)}function cb(e,t,r){var n=lP;lP|=2;var o=cv(),a=cx();(lL!==e||lM!==t)&&(l1=null,ch(e,t)),t=!1;var i=lq;e:for(;;)try{if(0!==lA&&null!==lO){var s=lO,l=lD;switch(lA){case 8:cp(),i=6;break e;case 3:case 2:case 9:case 6:null===at.current&&(t=!0);var c=lA;if(lA=0,lD=null,ck(e,s,l,c),r&&l$){i=0;break e}break;default:c=lA,lA=0,lD=null,ck(e,s,l,c)}}(function(){for(;null!==lO;)cw(lO)})(),i=lq;break}catch(t){cm(e,t)}return t&&e.shellSuspendCounter++,ot=oe=null,lP=n,H.H=o,H.A=a,null===lO&&(lL=null,lM=0,nv()),i}function cw(e){var t=sg(e.alternate,e,lZ);e.memoizedProps=e.pendingProps,null===t?cj(e):lO=t}function c_(e){var t=e,r=t.alternate;switch(t.tag){case 15:case 0:t=i9(r,t,t.pendingProps,t.type,void 0,lM);break;case 11:t=i9(r,t,t.pendingProps,t.type.render,t.ref,lM);break;case 5:az(t);var n=t;n===nY&&(nQ?(n5(n),5===n.tag&&null!=n.stateNode&&(nX=n.stateNode)):(n5(n),nQ=!0));default:sk(r,t),t=sg(r,t=lO=nT(t,lZ),lZ)}e.memoizedProps=e.pendingProps,null===t?cj(e):lO=t}function ck(e,t,r,n){ot=oe=null,az(t),o$=null,oU=0;var o=t.return;try{if(function(e,t,r,n,o){if(r.flags|=32768,null!==n&&"object"==typeof n&&"function"==typeof n.then){if(null!==(t=r.alternate)&&oi(t,r,o,!0),null!==(r=at.current)){switch(r.tag){case 31:case 13:case 19:return null===ar?cy():null===r.alternate&&0===lq&&(lq=3),r.flags&=-257,r.flags|=65536,r.lanes=o,n===oP?r.flags|=16384:(null===(t=r.updateQueue)?r.updateQueue=new Set([n]):t.add(n),cA(e,n,o)),!1;case 22:return r.flags|=65536,n===oP?r.flags|=16384:(null===(t=r.updateQueue)?(t={transitions:null,markerInstances:null,retryQueue:new Set([n])},r.updateQueue=t):null===(r=t.retryQueue)?t.retryQueue=new Set([n]):r.add(n),cA(e,n,o)),!1}throw Error(s(435,r.tag))}return cA(e,n,o),cy(),!1}if(nQ)return null!==(t=at.current)?(0==(65536&t.flags)&&(t.flags|=256),t.flags|=65536,t.lanes=o,n!==n1&&n9(nO(e=Error(s(422),{cause:n}),r))):(n!==n1&&n9(nO(t=Error(s(423),{cause:n}),r)),e=e.current.alternate,e.flags|=65536,o&=-o,e.lanes|=o,n=nO(n,r),o=iH(e.stateNode,n,o),o0(e,o),4!==lq&&(lq=2)),!1;var a=Error(s(520),{cause:n});if(a=nO(a,r),null===lK?lK=[a]:lK.push(a),4!==lq&&(lq=2),null===t)return!0;n=nO(n,r),r=t;do{switch(r.tag){case 3:return r.flags|=65536,e=o&-o,r.lanes|=e,e=iH(r.stateNode,n,e),o0(r,e),!1;case 1:if(t=r.type,a=r.stateNode,0==(128&r.flags)&&("function"==typeof t.getDerivedStateFromError||null!==a&&"function"==typeof a.componentDidCatch&&(null===l2||!l2.has(a))))return r.flags|=65536,o&=-o,r.lanes|=o,iG(o=iW(o),e,r,n),o0(r,o),!1;break;case 22:if(null!==r.memoizedState)return r.flags|=65536,!1}r=r.return}while(null!==r);return!1}(e,o,t,r,lM)){lq=1,iB(e,nO(r,e.current)),lO=null;return}}catch(t){if(null!==o)throw lO=o,t;lq=1,iB(e,nO(r,e.current)),lO=null;return}32768&t.flags?(nQ||1===n?e=!0:l$||0!=(0x20000000&lM)?e=!1:(lF=e=!0,(2===n||9===n||3===n||6===n)&&null!==(n=at.current)&&13===n.tag&&(n.flags|=16384)),cS(t,e)):cj(t)}function cj(e){var t=e;do{if(0!=(32768&t.flags))return void cS(t,lF);e=t.return;var r=function(e,t,r){var n=t.pendingProps;switch(nG(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:case 1:return s_(t),null;case 3:return r=t.stateNode,n=null,null!==e&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),on(om),ea(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(null===e||null===e.child)&&(n4(t)?sv(t):null===e||e.memoizedState.isDehydrated&&0==(256&t.flags)||(t.flags|=1024,n7())),s_(t),null;case 26:var o=t.type,a=t.memoizedState;return null===e?(sv(t),null!==a?(s_(t),sy(t,a)):(s_(t),sx(t,o,null,n,r))):a?a!==e.memoizedState?(sv(t),s_(t),sy(t,a)):(s_(t),t.flags&=-0x1000001):((e=e.memoizedProps)!==n&&sv(t),s_(t),sx(t,o,e,n,r)),null;case 27:if(es(t),r=er.current,o=t.type,null!==e&&null!=t.stateNode)e.memoizedProps!==n&&sv(t);else{if(!n){if(null===t.stateNode)throw Error(s(166));return s_(t),t.subtreeFlags&=-0x2000001,null}e=ee.current,n4(t)?n3(t,e):(t.stateNode=e=da(o,n,r),sv(t))}return s_(t),t.subtreeFlags&=-0x2000001,null;case 5:if(es(t),o=t.type,null!==e&&null!=t.stateNode)e.memoizedProps!==n&&sv(t);else{if(!n){if(null===t.stateNode)throw Error(s(166));return s_(t),t.subtreeFlags&=-0x2000001,null}if(a=ee.current,n4(t))n3(t,a);else{var i=uy(er.current);switch(a){case 1:a=i.createElementNS("http://www.w3.org/2000/svg",o);break;case 2:a=i.createElementNS("http://www.w3.org/1998/Math/MathML",o);break;default:switch(o){case"svg":a=i.createElementNS("http://www.w3.org/2000/svg",o);break;case"math":a=i.createElementNS("http://www.w3.org/1998/Math/MathML",o);break;case"script":(a=i.createElement("div")).innerHTML="<script><\/script>",a=a.removeChild(a.firstChild);break;case"select":a="string"==typeof n.is?i.createElement("select",{is:n.is}):i.createElement("select"),n.multiple?a.multiple=!0:n.size&&(a.size=n.size);break;default:a="string"==typeof n.is?i.createElement(o,{is:n.is}):i.createElement(o)}}a[eY]=t,a[eX]=n;e:for(i=t.child;null!==i;){if(5===i.tag||6===i.tag)a.appendChild(i.stateNode);else if(4!==i.tag&&27!==i.tag&&null!==i.child){i.child.return=i,i=i.child;continue}if(i===t)break;for(;null===i.sibling;){if(null===i.return||i.return===t)break e;i=i.return}i.sibling.return=i.return,i=i.sibling}switch(t.stateNode=a,uh(a,o,n),o){case"button":case"input":case"select":case"textarea":n=!!n.autoFocus;break;case"img":n=!0;break;default:n=!1}n&&sv(t)}}return s_(t),t.subtreeFlags&=-0x2000001,sx(t,t.type,null===e?null:e.memoizedProps,t.pendingProps,r),null;case 6:if(e&&null!=t.stateNode)e.memoizedProps!==n&&sv(t);else{if("string"!=typeof n&&null===t.stateNode)throw Error(s(166));if(e=er.current,n4(t)){if(e=t.stateNode,r=t.memoizedProps,n=null,null!==(o=nY))switch(o.tag){case 27:case 5:n=o.memoizedProps}e[eY]=t,(e=!!(e.nodeValue===r||null!==n&&!0===n.suppressHydrationWarning||ud(e.nodeValue,r)))||n2(t,!0)}else(e=uy(e).createTextNode(n))[eY]=t,t.stateNode=e}return s_(t),null;case 31:if(r=t.memoizedState,null===e||null!==e.memoizedState){if(n=n4(t),null!==r){if(null===e){if(!n)throw Error(s(318));if(!(e=null!==(e=t.memoizedState)?e.dehydrated:null))throw Error(s(557));e[eY]=t}else n6(),0==(128&t.flags)&&(t.memoizedState=null),t.flags|=4;s_(t),e=!1}else r=n7(),null!==e&&null!==e.memoizedState&&(e.memoizedState.hydrationErrors=r),e=!0;if(!e){if(256&t.flags)return as(t),t;return as(t),null}if(0!=(128&t.flags))throw Error(s(558))}return s_(t),null;case 13:if(n=t.memoizedState,null===e||null!==e.memoizedState&&null!==e.memoizedState.dehydrated){if(o=n4(t),null!==n&&null!==n.dehydrated){if(null===e){if(!o)throw Error(s(318));if(!(o=null!==(o=t.memoizedState)?o.dehydrated:null))throw Error(s(317));o[eY]=t}else n6(),0==(128&t.flags)&&(t.memoizedState=null),t.flags|=4;s_(t),o=!1}else o=n7(),null!==e&&null!==e.memoizedState&&(e.memoizedState.hydrationErrors=o),o=!0;if(!o){if(256&t.flags)return as(t),t;return as(t),null}}if(as(t),0!=(128&t.flags))return t.lanes=r,t;return r=null!==n,e=null!==e&&null!==e.memoizedState,r&&(n=t.child,o=null,null!==n.alternate&&null!==n.alternate.memoizedState&&null!==n.alternate.memoizedState.cachePool&&(o=n.alternate.memoizedState.cachePool.pool),a=null,null!==n.memoizedState&&null!==n.memoizedState.cachePool&&(a=n.memoizedState.cachePool.pool),a!==o&&(n.flags|=2048)),r!==e&&r&&(t.child.flags|=8192),sb(t,t.updateQueue),s_(t),null;case 4:return ea(),null===e&&ut(t.stateNode.containerInfo),t.flags|=0x4000000,s_(t),null;case 10:return on(t.type),s_(t),null;case 19:if(au(t),null===(n=t.memoizedState))return s_(t),null;if(o=0!=(128&t.flags),null===(a=n.rendering))if(o)sw(n,!1);else{if(0!==lq||null!==e&&0!=(128&e.flags))for(e=t.child;null!==e;){if(null!==(a=ad(e))){for(t.flags|=128,sw(n,!1),t.updateQueue=e=a.updateQueue,sb(t,e),t.subtreeFlags=0,e=r,r=t.child;null!==r;)nT(r,e),r=r.sibling;return ac(t,1&al.current|2),nQ&&nV(t,n.treeForkCount),t.child}e=e.sibling}null!==n.tail&&ev()>l0&&(t.flags|=128,o=!0,sw(n,!1),t.lanes=4194304)}else{if(!o)if(null!==(e=ad(a))){if(t.flags|=128,o=!0,t.updateQueue=e=e.updateQueue,sb(t,e),sw(n,!0),null===n.tail&&"collapsed"!==n.tailMode&&"visible"!==n.tailMode&&!a.alternate&&!nQ)return s_(t),null}else 2*ev()-n.renderingStartTime>l0&&0x20000000!==r&&(t.flags|=128,o=!0,sw(n,!1),t.lanes=4194304);n.isBackwards?(a.sibling=t.child,t.child=a):(null!==(e=n.last)?e.sibling=a:t.child=a,n.last=a)}if(null!==n.tail){e=n.tail;e:{for(r=e;null!==r;){if(null!==r.alternate){r=!1;break e}r=r.sibling}r=!0}return n.rendering=e,n.tail=e.sibling,n.renderingStartTime=ev(),e.sibling=null,a=al.current,a=o?1&a|2:1&a,"visible"===n.tailMode||"collapsed"===n.tailMode||!r||nQ?ac(t,a):(r=a,J(at,t),J(al,r),null===ar&&(ar=t)),nQ&&nV(t,n.treeForkCount),e}return s_(t),null;case 22:case 23:return as(t),ae(),n=null!==t.memoizedState,null!==e?null!==e.memoizedState!==n&&(t.flags|=8192):n&&(t.flags|=8192),n?0!=(0x20000000&r)&&0==(128&t.flags)&&(s_(t),6&t.subtreeFlags&&(t.flags|=8192)):s_(t),null!==(r=t.updateQueue)&&sb(t,r.retryQueue),r=null,null!==e&&null!==e.memoizedState&&null!==e.memoizedState.cachePool&&(r=e.memoizedState.cachePool.pool),n=null,null!==t.memoizedState&&null!==t.memoizedState.cachePool&&(n=t.memoizedState.cachePool.pool),n!==r&&(t.flags|=2048),null!==e&&Q(oC),null;case 24:return r=null,null!==e&&(r=e.memoizedState.cache),t.memoizedState.cache!==r&&(t.flags|=2048),on(om),s_(t),null;case 25:return null;case 30:return t.flags|=0x2000000,s_(t),null}throw Error(s(156,t.tag))}(t.alternate,t,lZ);if(null!==r){lO=r;return}if(null!==(t=t.sibling)){lO=t;return}lO=t=e}while(null!==t);0===lq&&(lq=5)}function cS(e,t){do{var r=function(e,t){switch(nG(t),t.tag){case 1:return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 3:return on(om),ea(),0!=(65536&(e=t.flags))&&0==(128&e)?(t.flags=-65537&e|128,t):null;case 26:case 27:case 5:return es(t),null;case 31:if(null!==t.memoizedState){if(as(t),null===t.alternate)throw Error(s(340));n6()}return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 13:if(as(t),null!==(e=t.memoizedState)&&null!==e.dehydrated){if(null===t.alternate)throw Error(s(340));n6()}return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 19:return au(t),65536&(e=t.flags)?(t.flags=-65537&e|128,null!==(e=t.memoizedState)&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return ea(),null;case 10:return on(t.type),null;case 22:case 23:return as(t),ae(),null!==e&&Q(oC),65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 24:return on(om),null;default:return null}}(e.alternate,e);if(null!==r){r.flags&=32767,lO=r;return}if(null!==(r=e.return)&&(r.flags|=32768,r.subtreeFlags=0,r.deletions=null),!t&&null!==(e=e.sibling)){lO=e;return}lO=e=r}while(null!==e);lq=6,lO=null}function cC(e,t,r,n,o,a,i,l,c,u,d,f){e.cancelPendingCommit=null;do cP();while(0!==l3);if(0!=(6&lP))throw Error(s(327));if(null!==t){if(t===e.current)throw Error(s(177));e===lL&&(lO=lL=null,lM=0),l4=t,l5=e,l6=r,l9=o,l8=n,function(e,t,r,n,o,a,i){var s,l=t.lanes|t.childLanes;if(l7=l,!function(e,t,r,n,o,a){var i=e.pendingLanes;e.pendingLanes=r,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=r,e.entangledLanes&=r,e.errorRecoveryDisabledLanes&=r,e.shellSuspendCounter=0;var s=e.entanglements,l=e.expirationTimes,c=e.hiddenUpdates;for(r=i&~r;0<r;){var u=31-eN(r),d=1<<u;s[u]=0,l[u]=-1;var f=c[u];if(null!==f)for(c[u]=null,u=0;u<f.length;u++){var p=f[u];null!==p&&(p.lane&=-0x20000001)}r&=~d}0!==n&&eZ(e,n,0),0!==a&&0===o&&0!==e.tag&&(e.suspendedLanes|=a&~(i&~t))}(e,r,l|=ng,n,o,a),ct=null,(0x13ffff00&r)===r?(s=e.transitionTypes,e.transitionTypes=null,cr=s,n=10262):(cr=null,n=10256),0!=(t.subtreeFlags&n)||0!=(t.flags&n)?(e.callbackNode=null,e.callbackPriority=0,ep(ew,function(){return cL(),null})):(e.callbackNode=null,e.callbackPriority=0),sU=!1,n=0!=(13878&t.flags),0!=(13878&t.subtreeFlags)||n){n=H.T,H.T=null,o=W.p,W.p=2,a=lP,lP|=4;try{!function(e,t,r){if(e=e.containerInfo,uv=dV,rY(e=rK(e))){if("selectionStart"in e)var n={start:e.selectionStart,end:e.selectionEnd};else e:{var o=(n=(n=e.ownerDocument)&&n.defaultView||window).getSelection&&n.getSelection();if(o&&0!==o.rangeCount){n=o.anchorNode;var a,i=o.anchorOffset,s=o.focusNode;o=o.focusOffset;try{n.nodeType,s.nodeType}catch(e){n=null;break e}var l=0,c=-1,u=-1,d=0,f=0,p=e,h=null;t:for(;;){for(;p!==n||0!==i&&3!==p.nodeType||(c=l+i),p!==s||0!==o&&3!==p.nodeType||(u=l+o),3===p.nodeType&&(l+=p.nodeValue.length),null!==(a=p.firstChild);)h=p,p=a;for(;;){if(p===e)break t;if(h===n&&++d===i&&(c=l),h===s&&++f===o&&(u=l),null!==(a=p.nextSibling))break;h=(p=h).parentNode}p=a}n=-1===c||-1===u?null:{start:c,end:u}}else n=null}n=n||{start:0,end:0}}else n=null;for(ux={focusedElem:e,selectionRange:n},dV=!1,r=(0x13ffff00&r)===r,s7=t,t=r?9270:1024;null!==s7;){if(e=s7,r&&null!==(n=e.deletions))for(i=0;i<n.length;i++)r&&sQ(n[i]);if(null===e.alternate&&0!=(2&e.flags))r&&sq(e),lr(r);else{if(22===e.tag){if(n=e.alternate,null!==e.memoizedState){null!==n&&null===n.memoizedState&&r&&sQ(n),lr(r);continue}else if(null!==n&&null!==n.memoizedState){r&&sq(e),lr(r);continue}}n=e.child,0!=(e.subtreeFlags&t)&&null!==n?(n.return=e,s7=n):(r&&function e(t){for(t=t.child;null!==t;){if(30===t.tag){var r=t.memoizedProps,n=nu(r,t.stateNode);r=nf(r.default,r.update),t.flags&=-5,"none"!==r&&sW(t,n,r,t.memoizedState=[],!1)}else 0!=(0x2000000&t.subtreeFlags)&&e(t);t=t.sibling}}(e),lr(r))}}sZ=null}(e,t,r)}finally{lP=a,W.p=o,H.T=n}}l3=1,sU?ce=function(e,t,r,n,o,a,i,s,l){var c=9===t.nodeType?t:t.ownerDocument;try{var u=c.startViewTransition({update:function(){var t=c.defaultView,r=t.navigation&&t.navigation.transition,i=c.fonts.status;n();var s=[];if("loaded"===i&&(c.documentElement.clientHeight,"loading"===c.fonts.status&&s.push(c.fonts.ready)),i=s.length,null!==e)for(var l=e.suspenseyImages,u=0,d=0;d<l.length;d++){var f=l[d];if(!f.complete){var p=f.getBoundingClientRect();if(0<p.bottom&&0<p.right&&p.top<t.innerHeight&&p.left<t.innerWidth){if((u+=dN(f))>dz){s.length=i;break}f=new Promise(uF.bind(f)),s.push(f)}}}return 0<s.length?(t=Promise.race([Promise.all(s),new Promise(function(e){return setTimeout(e,500)})]).then(o,o),(r?Promise.allSettled([r.finished,t]):t).then(a,a)):(o(),r)?r.finished.then(a,a):void a()},types:r});c.__reactViewTransition=u;var d=[];return u.ready.then(function(){for(var e=c.documentElement.getAnimations({subtree:!0}),t=0;t<e.length;t++){var r=e[t],n=r.effect,o=n.pseudoElement;if(null!=o&&o.startsWith("::view-transition")){d.push(r),r=n.getKeyframes();for(var a=o=void 0,s=!0,l=0;l<r.length;l++){var u=r[l],f=u.width;if(void 0===o)o=f;else if(o!==f){s=!1;break}if(f=u.height,void 0===a)a=f;else if(a!==f){s=!1;break}delete u.width,delete u.height,"none"===u.transform&&delete u.transform}s&&void 0!==o&&void 0!==a&&(n.setKeyframes(r),(s=getComputedStyle(n.target,n.pseudoElement)).width!==o||s.height!==a)&&((s=r[0]).width=o,s.height=a,(s=r[r.length-1]).width=o,s.height=a,n.setKeyframes(r))}}i()},function(e){c.__reactViewTransition===u&&(c.__reactViewTransition=null);try{"object"==typeof e&&null!==e&&"InvalidStateError"===e.name&&("View transition was skipped because document visibility state is hidden."===e.message||"Skipping view transition because document visibility state has become hidden."===e.message||"Skipping view transition because viewport size changed."===e.message||"Transition was aborted because of invalid state"===e.message)&&(e=null),null!==e&&l(e)}finally{n(),o(),i()}}),u.finished.finally(function(){for(var e=0;e<d.length;e++)d[e].cancel();c.__reactViewTransition===u&&(c.__reactViewTransition=null),s()}),u}catch(e){return n(),o(),i(),null}}(i,e.containerInfo,cr,cN,cI,cT,cz,cL,cE,null,null):(cN(),cI(),cz())}(e,t,r,i,l,c,f)}}function cE(e){0!==l3&&(0,l5.onRecoverableError)(e,{componentStack:null})}function cT(){3===l3&&(l3=0,lv(l4,l5),l3=4)}function cN(){if(1===l3){l3=0;var e=l5,t=l4,r=l6,n=0!=(13878&t.flags);if(0!=(13878&t.subtreeFlags)||n){n=H.T,H.T=null;var o=W.p;W.p=2;var a=lP;lP|=4;try{s8=le=!1,lh(t,e,r),r=ux;var i=rK(e.containerInfo),s=r.focusedElem,l=r.selectionRange;if(i!==s&&s&&s.ownerDocument&&function e(t,r){return!!t&&!!r&&(t===r||(!t||3!==t.nodeType)&&(r&&3===r.nodeType?e(t,r.parentNode):"contains"in t?t.contains(r):!!t.compareDocumentPosition&&!!(16&t.compareDocumentPosition(r))))}(s.ownerDocument.documentElement,s)){if(null!==l&&rY(s)){var c=l.start,u=l.end;if(void 0===u&&(u=c),"selectionStart"in s)s.selectionStart=c,s.selectionEnd=Math.min(u,s.value.length);else{var d=s.ownerDocument||document,f=d&&d.defaultView||window;if(f.getSelection){var p=f.getSelection(),h=s.textContent.length,m=Math.min(l.start,h),g=void 0===l.end?m:Math.min(l.end,h);!p.extend&&m>g&&(i=g,g=m,m=i);var v=rG(s,m),x=rG(s,g);if(v&&x&&(1!==p.rangeCount||p.anchorNode!==v.node||p.anchorOffset!==v.offset||p.focusNode!==x.node||p.focusOffset!==x.offset)){var y=d.createRange();y.setStart(v.node,v.offset),p.removeAllRanges(),m>g?(p.addRange(y),p.extend(x.node,x.offset)):(y.setEnd(x.node,x.offset),p.addRange(y))}}}}for(d=[],p=s;p=p.parentNode;)1===p.nodeType&&d.push({element:p,left:p.scrollLeft,top:p.scrollTop});for("function"==typeof s.focus&&s.focus(),s=0;s<d.length;s++){var b=d[s];b.element.scrollLeft=b.left,b.element.scrollTop=b.top}}dV=!!uv,ux=uv=null}finally{lP=a,W.p=o,H.T=n}}e.current=t,l3=2}}function cI(){if(2===l3){l3=0;var e=l5,t=l4,r=0!=(8772&t.flags);if(0!=(8772&t.subtreeFlags)||r){r=H.T,H.T=null;var n=W.p;W.p=2;var o=lP;lP|=4;try{ln(e,t.alternate,t)}finally{lP=o,W.p=n,H.T=r}}l3=3}}function cz(){if(4===l3||3===l3){l3=0;var e=ce;ce=null,eg();var t=l5,r=l4,n=l6,o=l8,a=(0x13ffff00&n)===n?10262:10256;if(0!=(r.subtreeFlags&a)||0!=(r.flags&a)?l3=5:(l3=0,l4=l5=null,cR(t,t.pendingLanes)),0===(a=t.pendingLanes)&&(l2=null),eH(n),r=r.stateNode,eE&&"function"==typeof eE.onCommitFiberRoot)try{eE.onCommitFiberRoot(eC,r,void 0,128==(128&r.current.flags))}catch(e){}if(null!==o){r=H.T,a=W.p,W.p=2,H.T=null;try{for(var i=t.onRecoverableError,s=0;s<o.length;s++){var l=o[s];i(l.value,{componentStack:l.stack})}}finally{H.T=r,W.p=a}}if(o=ct,i=cr,cr=null,null!==o&&(ct=null,null===i&&(i=[]),null!==e))for(l=0;l<o.length;l++)void 0!==(r=(0,o[l])(i))&&e.finished.finally(r);0!=(3&l6)&&cP(),cG(t),a=t.pendingLanes,0!=(261930&n)&&0!=(42&a)?t===co?cn++:(cn=0,co=t):(cn=0,co=null),cK(0,!1)}}function cR(e,t){0==(e.pooledCacheLanes&=t)&&null!=(t=e.pooledCache)&&(e.pooledCache=null,ov(t))}function cP(){return null!==ce&&(ce.skipTransition(),ce=null),cN(),cI(),cz(),cL()}function cL(){if(5!==l3)return!1;var e=l5,t=l7;l7=0;var r=eH(l6),n=H.T,o=W.p;try{W.p=32>r?32:r,H.T=null,r=l9,l9=null;var a=l5,i=l6;if(l3=0,l4=l5=null,l6=0,0!=(6&lP))throw Error(s(331));var l=lP;if(lP|=4,lN(a.current),l_(a,a.current,i,r),lP=l,cK(0,!1),eE&&"function"==typeof eE.onPostCommitFiberRoot)try{eE.onPostCommitFiberRoot(eC,a)}catch(e){}return!0}finally{W.p=o,H.T=n,cR(e,t)}}function cO(e,t,r){t=nO(r,t),t=iH(e.stateNode,t,2),null!==(e=oQ(e,t,2))&&(eU(e,2),cG(e))}function cM(e,t,r){if(3===e.tag)cO(e,e,r);else for(;null!==t;){if(3===t.tag){cO(t,e,r);break}if(1===t.tag){var n=t.stateNode;if("function"==typeof t.type.getDerivedStateFromError||"function"==typeof n.componentDidCatch&&(null===l2||!l2.has(n))){e=nO(r,e),null!==(n=oQ(t,r=iW(2),2))&&(iG(r,n,t,e),eU(n,2),cG(n));break}}t=t.return}}function cA(e,t,r){var n=e.pingCache;if(null===n){n=e.pingCache=new lR;var o=new Set;n.set(t,o)}else void 0===(o=n.get(t))&&(o=new Set,n.set(t,o));o.has(r)||(lU=!0,o.add(r),e=cD.bind(null,e,t,r),t.then(e,e))}function cD(e,t,r){var n=e.pingCache;null!==n&&n.delete(t),e.pingedLanes|=e.suspendedLanes&r,e.warmLanes&=~r,lL===e&&(lM&r)===r&&((4===lq||3===lq&&(0x3c00000&lM)===lM&&300>ev()-lQ)&&0==(2&lP)?ch(e,0):lH|=r,lG===lM&&(lG=0)),cG(e)}function cF(e,t){0===t&&(t=eF()),null!==(e=nb(e,t))&&(eU(e,t),cG(e))}function c$(e){var t=e.memoizedState,r=0;null!==t&&(r=t.retryLane),cF(e,r)}function cU(e,t){var r=0;switch(e.tag){case 31:case 13:var n=e.stateNode,o=e.memoizedState;null!==o&&(r=o.retryLane);break;case 19:n=e.stateNode;break;case 22:n=e.stateNode._retryCache;break;default:throw Error(s(314))}null!==n&&n.delete(t),cF(e,r)}var cZ=null,cq=null,cB=!1,cV=!1,cH=!1,cW=0;function cG(e){e!==cq&&null===e.next&&(null===cq?cZ=cq=e:cq=cq.next=e),cV=!0,cB||(cB=!0,uN(function(){0!=(6&lP)?ep(ey,cY):cX()}))}function cK(e,t){if(!cH&&cV){cH=!0;do for(var r=!1,n=cZ;null!==n;){if(!t)if(0!==e){var o=n.pendingLanes;if(0===o)var a=0;else{var i=n.suspendedLanes,s=n.pingedLanes;a=0xc000095&(a=(1<<31-eN(42|e)+1)-1&(o&~(i&~s)))?0xc000095&a|1:a?2|a:0}0!==a&&(r=!0,c0(n,a))}else a=lM,0==(3&(a=eM(n,n===lL?a:0,null!==n.cancelPendingCommit||-1!==n.timeoutHandle)))||eA(n,a)||(r=!0,c0(n,a));n=n.next}while(r);cH=!1}}function cY(){cX()}function cX(){cV=cB=!1;var e,t=0;0===cW||((e=window.event)&&"popstate"===e.type?e===uj||(uj=e,0):(uj=null,1))||(t=cW);for(var r=ev(),n=null,o=cZ;null!==o;){var a=o.next,i=cQ(o,r);0===i?(o.next=null,null===n?cZ=a:n.next=a,null===a&&(cq=n)):(n=o,(0!==t||0!=(3&i))&&(cV=!0)),o=a}0!==l3&&5!==l3||cK(t,!1),0!==cW&&(cW=0)}function cQ(e,t){for(var r=e.suspendedLanes,n=e.pingedLanes,o=e.expirationTimes,a=-0x3c00001&e.pendingLanes;0<a;){var i=31-eN(a),s=1<<i,l=o[i];-1===l?(0==(s&r)||0!=(s&n))&&(o[i]=function(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;default:return -1}}(s,t)):l<=t&&(e.expiredLanes|=s),a&=~s}if(t=lL,r=lM,r=eM(e,e===t?r:0,null!==e.cancelPendingCommit||-1!==e.timeoutHandle),n=e.callbackNode,0===r||e===t&&(2===lA||9===lA)||null!==e.cancelPendingCommit)return null!==n&&null!==n&&eh(n),e.callbackNode=null,e.callbackPriority=0;if(0==(3&r)||eA(e,r)){if((t=r&-r)===e.callbackPriority)return t;switch(null!==n&&eh(n),eH(r)){case 2:case 8:r=eb;break;case 32:default:r=ew;break;case 0x10000000:r=ek}return r=ep(r,n=cJ.bind(null,e)),e.callbackPriority=t,e.callbackNode=r,t}return null!==n&&null!==n&&eh(n),e.callbackPriority=2,e.callbackNode=null,2}function cJ(e,t){if(0!==l3&&5!==l3)return e.callbackNode=null,e.callbackPriority=0,null;var r=e.callbackNode;if(cP()&&e.callbackNode!==r)return null;var n=lM;return 0===(n=eM(e,e===lL?n:0,null!==e.cancelPendingCommit||-1!==e.timeoutHandle))?null:(cc(e,n,t),cQ(e,ev()),null!=e.callbackNode&&e.callbackNode===r?cJ.bind(null,e):null)}function c0(e,t){if(cP())return null;cc(e,t,!0)}function c1(){if(0===cW){var e=o_;0===e&&(e=eR,0==(261888&(eR<<=1))&&(eR=256)),cW=e}return cW}function c2(e){return null==e||"symbol"==typeof e||"boolean"==typeof e?null:"function"==typeof e?e:tP(e)}for(var c3=0;c3<ns.length;c3++){var c5=ns[c3];nl(c5.toLowerCase(),"on"+(c5[0].toUpperCase()+c5.slice(1)))}nl(r9,"onAnimationCancel"),nl(r8,"onAnimationEnd"),nl(ne,"onAnimationIteration"),nl(nt,"onAnimationStart"),nl("dblclick","onDoubleClick"),nl("focusin","onFocus"),nl("focusout","onBlur"),nl(nr,"onTransitionRun"),nl(nn,"onTransitionStart"),nl(no,"onTransitionCancel"),nl(na,"onTransitionEnd"),ta("onMouseEnter",["mouseout","mouseover"]),ta("onMouseLeave",["mouseout","mouseover"]),ta("onPointerEnter",["pointerout","pointerover"]),ta("onPointerLeave",["pointerout","pointerover"]),to("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),to("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),to("onBeforeInput",["compositionend","keypress","textInput","paste"]),to("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),to("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),to("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var c4="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),c6=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(c4));function c7(e,t){t=0!=(4&t);for(var r=0;r<e.length;r++){var n=e[r],o=n.event;n=n.listeners;e:{var a=void 0;if(t)for(var i=n.length-1;0<=i;i--){var s=n[i],l=s.instance,c=s.currentTarget;if(s=s.listener,l!==a&&o.isPropagationStopped())break e;a=s,o.currentTarget=c;try{a(o)}catch(e){np(e)}o.currentTarget=null,a=l}else for(i=0;i<n.length;i++){if(l=(s=n[i]).instance,c=s.currentTarget,s=s.listener,l!==a&&o.isPropagationStopped())break e;a=s,o.currentTarget=c;try{a(o)}catch(e){np(e)}o.currentTarget=null,a=l}}}}function c9(e,t){var r=t[eJ];void 0===r&&(r=t[eJ]=new Set);var n=e+"__bubble";r.has(n)||(ur(t,e,2,!1),r.add(n))}function c8(e,t,r){var n=0;t&&(n|=4),ur(r,e,n,t)}var ue="_reactListening"+Math.random().toString(36).slice(2);function ut(e){if(!e[ue]){e[ue]=!0,tr.forEach(function(t){"selectionchange"!==t&&(c6.has(t)||c8(t,!1,e),c8(t,!0,e))});var t=9===e.nodeType?e:e.ownerDocument;null===t||t[ue]||(t[ue]=!0,c8("selectionchange",!1,t))}}function ur(e,t,r,n){switch(dQ(t)){case 2:var o=dH;break;case 8:o=dW;break;default:o=dG}r=o.bind(null,t,r,e),o=void 0,tB&&("touchstart"===t||"touchmove"===t||"wheel"===t)&&(o=!0),n?void 0!==o?e.addEventListener(t,r,{capture:!0,passive:o}):e.addEventListener(t,r,!0):void 0!==o?e.addEventListener(t,r,{passive:o}):e.addEventListener(t,r,!1)}function un(e,t,r,n,o){var a=n;if(0==(1&t)&&0==(2&t)&&null!==n)e:for(;;){if(null===n)return;var i=n.tag;if(3===i||4===i){var s=n.stateNode.containerInfo;if(s===o)break;if(4===i)for(i=n.return;null!==i;){var c=i.tag;if((3===c||4===c)&&i.stateNode.containerInfo===o)return;i=i.return}for(;null!==s;){if(null===(i=e6(s)))return;if(5===(c=i.tag)||6===c||26===c||27===c){n=a=i;continue e}s=s.parentNode}}n=n.return}tU(function(){var n=a,o=tM(r),i=[];e:{var s=ni.get(e);if(void 0!==s){var c=t6,u=e;switch(e){case"keypress":if(0===tY(r))break e;case"keydown":case"keyup":c=rd;break;case"focusin":u="focus",c=rr;break;case"focusout":u="blur",c=rr;break;case"beforeblur":case"afterblur":c=rr;break;case"click":if(2===r.button)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":c=re;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":c=rt;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":c=rh;break;case r9:case r8:case ne:case nt:c=rn;break;case na:c=rm;break;case"scroll":case"scrollend":c=t9;break;case"wheel":c=rg;break;case"copy":case"cut":case"paste":c=ro;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":c=rf;break;case"submit":c=rp;break;case"toggle":case"beforetoggle":c=rv}var d=0!=(4&t),f=!d&&("scroll"===e||"scrollend"===e||"toggle"===e||"beforetoggle"===e),p=d?null!==s?s+"Capture":null:s;d=[];for(var h,m=n;null!==m;){var g=m;if(h=g.stateNode,5!==(g=g.tag)&&26!==g&&27!==g||null===h||null===p||null!=(g=tZ(m,p))&&d.push(uo(m,g,h)),f)break;m=m.return}0<d.length&&(s=new c(s,u,null,r,o),i.push({event:s,listeners:d}))}}if(0==(7&t)){c="mouseover"===e||"pointerover"===e,s="mouseout"===e||"pointerout"===e,!(c&&r!==tO&&(u=r.relatedTarget||r.fromElement)&&(e6(u)||u[eQ]))&&(s||c)&&(u=o.window===o?o:(c=o.ownerDocument)?c.defaultView||c.parentWindow:window,s?(c=r.relatedTarget||r.toElement,s=n,null!==(c=c?e6(c):null)&&(f=l(c),d=c.tag,c!==f||5!==d&&27!==d&&6!==d)&&(c=null)):(s=null,c=n),s!==c&&(d=re,g="onMouseLeave",p="onMouseEnter",m="mouse",("pointerout"===e||"pointerover"===e)&&(d=rf,g="onPointerLeave",p="onPointerEnter",m="pointer"),f=null==s?u:e9(s),h=null==c?u:e9(c),(u=new d(g,m+"leave",s,r,o)).target=f,u.relatedTarget=h,g=null,e6(o)===n&&((d=new d(p,m+"enter",c,r,o)).target=h,d.relatedTarget=f,g=d),f=g,d=s&&c?_(s,c,ui):null,null!==s&&us(i,u,s,d,!1),null!==c&&null!==f&&us(i,f,c,d,!0)));e:{if("select"===(c=(s=n?e9(n):window).nodeName&&s.nodeName.toLowerCase())||"input"===c&&"file"===s.type)var v,x=rL;else if(rT(s))if(rO)x=rq;else{x=rU;var y=r$}else(c=s.nodeName)&&"input"===c.toLowerCase()&&("checkbox"===s.type||"radio"===s.type)?x=rZ:n&&tI(n.elementType)&&(x=rL);if(x&&(x=x(e,n))){rN(i,x,r,o);break e}y&&y(e,s,n)}switch(y=n?e9(n):window,e){case"focusin":(rT(y)||"true"===y.contentEditable)&&(rQ=y,rJ=n,r0=null);break;case"focusout":r0=rJ=rQ=null;break;case"mousedown":r1=!0;break;case"contextmenu":case"mouseup":case"dragend":r1=!1,r2(i,r,o);break;case"selectionchange":if(rX)break;case"keydown":case"keyup":r2(i,r,o)}if(ry)t:{switch(e){case"compositionstart":var b="onCompositionStart";break t;case"compositionend":b="onCompositionEnd";break t;case"compositionupdate":b="onCompositionUpdate";break t}b=void 0}else rC?rj(e,r)&&(b="onCompositionEnd"):"keydown"===e&&229===r.keyCode&&(b="onCompositionStart");b&&(r_&&"ko"!==r.locale&&(rC||"onCompositionStart"!==b?"onCompositionEnd"===b&&rC&&(v=tK()):(tW="value"in(tH=o)?tH.value:tH.textContent,rC=!0)),0<(y=ua(n,b)).length&&(b=new ra(b,e,null,r,o),i.push({event:b,listeners:y}),v?b.data=v:null!==(v=rS(r))&&(b.data=v))),(v=rw?function(e,t){switch(e){case"compositionend":return rS(t);case"keypress":if(32!==t.which)return null;return rk=!0," ";case"textInput":return" "===(e=t.data)&&rk?null:e;default:return null}}(e,r):function(e,t){if(rC)return"compositionend"===e||!ry&&rj(e,t)?(e=tK(),tG=tW=tH=null,rC=!1,e):null;switch(e){case"paste":default:return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return r_&&"ko"!==t.locale?null:t.data}}(e,r))&&0<(b=ua(n,"onBeforeInput")).length&&(y=new ra("onBeforeInput","beforeinput",null,r,o),i.push({event:y,listeners:b}),y.data=v);var w=e;if("submit"===w&&n&&n.stateNode===o){var k=c2((o[eX]||null).action),j=r.submitter;j&&null!==(w=(w=j[eX]||null)?c2(w.formAction):j.getAttribute("formAction"))&&(k=w,j=null);var S=new t6("action","action",null,r,o);i.push({event:S,listeners:[{instance:null,listener:function(){if(r.defaultPrevented){if(0!==cW){var e=new FormData(o,j);ix(n,{pending:!0,data:e,method:o.method,action:k},null,e)}}else"function"==typeof k&&(S.preventDefault(),ix(n,{pending:!0,data:e=new FormData(o,j),method:o.method,action:k},k,e))},currentTarget:o}]})}}c7(i,t)})}function uo(e,t,r){return{instance:e,listener:t,currentTarget:r}}function ua(e,t){for(var r=t+"Capture",n=[];null!==e;){var o=e,a=o.stateNode;if(5!==(o=o.tag)&&26!==o&&27!==o||null===a||(null!=(o=tZ(e,r))&&n.unshift(uo(e,o,a)),null!=(o=tZ(e,t))&&n.push(uo(e,o,a))),3===e.tag)return n;e=e.return}return[]}function ui(e){if(null===e)return null;do e=e.return;while(e&&5!==e.tag&&27!==e.tag);return e||null}function us(e,t,r,n,o){for(var a=t._reactName,i=[];null!==r&&r!==n;){var s=r,l=s.alternate,c=s.stateNode;if(s=s.tag,null!==l&&l===n)break;5!==s&&26!==s&&27!==s||null===c||(l=c,o?null!=(c=tZ(r,a))&&i.unshift(uo(r,c,l)):o||null!=(c=tZ(r,a))&&i.push(uo(r,c,l))),r=r.return}0!==i.length&&e.push({event:t,listeners:i})}var ul=/\r\n?/g,uc=/\u0000|\uFFFD/g;function uu(e){return("string"==typeof e?e:""+e).replace(ul,"\n").replace(uc,"")}function ud(e,t){return t=uu(t),uu(e)===t}function uf(e,t,r,n,o,a){switch(r){case"children":if("string"==typeof n)"body"===t||"textarea"===t&&""===n||tC(e,n);else{if("number"!=typeof n&&"bigint"!=typeof n)return;"body"!==t&&tC(e,""+n)}break;case"className":tf(e,"class",n);break;case"tabIndex":tf(e,"tabindex",n);break;case"dir":case"role":case"viewBox":case"width":case"height":tf(e,r,n);break;case"style":tN(e,n,a);return;case"data":if("object"!==t){tf(e,"data",n);break}case"src":case"href":if(""===n&&("a"!==t||"href"!==r)||null==n||"function"==typeof n||"symbol"==typeof n||"boolean"==typeof n){e.removeAttribute(r);break}n=tP(n),e.setAttribute(r,n);break;case"action":case"formAction":if("function"==typeof n){e.setAttribute(r,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}if("function"==typeof a&&("formAction"===r?("input"!==t&&uf(e,t,"name",o.name,o,null),uf(e,t,"formEncType",o.formEncType,o,null),uf(e,t,"formMethod",o.formMethod,o,null),uf(e,t,"formTarget",o.formTarget,o,null)):(uf(e,t,"encType",o.encType,o,null),uf(e,t,"method",o.method,o,null),uf(e,t,"target",o.target,o,null))),null==n||"symbol"==typeof n||"boolean"==typeof n){e.removeAttribute(r);break}n=tP(n),e.setAttribute(r,n);break;case"onClick":null!=n&&(e.onclick=tL);return;case"onScroll":null!=n&&c9("scroll",e);return;case"onScrollEnd":null!=n&&c9("scrollend",e);return;case"dangerouslySetInnerHTML":if(null!=n){if("object"!=typeof n||!("__html"in n))throw Error(s(61));if(null!=(r=n.__html)){if(null!=o.children)throw Error(s(60));(null!=a?a.__html:void 0)!==r&&(e.innerHTML=r)}}break;case"multiple":e.multiple=n&&"function"!=typeof n&&"symbol"!=typeof n;break;case"muted":e.muted=n&&"function"!=typeof n&&"symbol"!=typeof n;break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":case"autoFocus":break;case"xlinkHref":if(null==n||"function"==typeof n||"boolean"==typeof n||"symbol"==typeof n){e.removeAttribute("xlink:href");break}r=tP(n),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",r);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":null!=n&&"function"!=typeof n&&"symbol"!=typeof n?e.setAttribute(r,n):e.removeAttribute(r);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":n&&"function"!=typeof n&&"symbol"!=typeof n?e.setAttribute(r,""):e.removeAttribute(r);break;case"capture":case"download":!0===n?e.setAttribute(r,""):!1!==n&&null!=n&&"function"!=typeof n&&"symbol"!=typeof n?e.setAttribute(r,n):e.removeAttribute(r);break;case"cols":case"rows":case"size":case"span":null!=n&&"function"!=typeof n&&"symbol"!=typeof n&&!isNaN(n)&&1<=n?e.setAttribute(r,n):e.removeAttribute(r);break;case"rowSpan":case"start":null==n||"function"==typeof n||"symbol"==typeof n||isNaN(n)?e.removeAttribute(r):e.setAttribute(r,n);break;case"popover":c9("beforetoggle",e),c9("toggle",e),td(e,"popover",n);break;case"xlinkActuate":tp(e,"http://www.w3.org/1999/xlink","xlink:actuate",n);break;case"xlinkArcrole":tp(e,"http://www.w3.org/1999/xlink","xlink:arcrole",n);break;case"xlinkRole":tp(e,"http://www.w3.org/1999/xlink","xlink:role",n);break;case"xlinkShow":tp(e,"http://www.w3.org/1999/xlink","xlink:show",n);break;case"xlinkTitle":tp(e,"http://www.w3.org/1999/xlink","xlink:title",n);break;case"xlinkType":tp(e,"http://www.w3.org/1999/xlink","xlink:type",n);break;case"xmlBase":tp(e,"http://www.w3.org/XML/1998/namespace","xml:base",n);break;case"xmlLang":tp(e,"http://www.w3.org/XML/1998/namespace","xml:lang",n);break;case"xmlSpace":tp(e,"http://www.w3.org/XML/1998/namespace","xml:space",n);break;case"is":td(e,"is",n);break;case"innerText":case"textContent":return;default:if(2<r.length&&("o"===r[0]||"O"===r[0])&&("n"===r[1]||"N"===r[1]))return;td(e,r=tz.get(r)||r,n)}tc=!0}function up(e,t,r,n,o,a){switch(r){case"style":tN(e,n,a);return;case"dangerouslySetInnerHTML":if(null!=n){if("object"!=typeof n||!("__html"in n))throw Error(s(61));if(null!=(r=n.__html)){if(null!=o.children)throw Error(s(60));(null!=a?a.__html:void 0)!==r&&(e.innerHTML=r)}}break;case"children":if("string"==typeof n)tC(e,n);else{if("number"!=typeof n&&"bigint"!=typeof n)return;tC(e,""+n)}break;case"onScroll":null!=n&&c9("scroll",e);return;case"onScrollEnd":null!=n&&c9("scrollend",e);return;case"onClick":null!=n&&(e.onclick=tL);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":case"innerText":case"textContent":return;default:if(!tn.hasOwnProperty(r))e:{if("o"===r[0]&&"n"===r[1]&&(o=r.endsWith("Capture"),a=r.slice(2,o?r.length-7:void 0),"function"==typeof(t=null!=(t=e[eX]||null)?t[r]:null)&&e.removeEventListener(a,t,o),"function"==typeof n)){"function"!=typeof t&&null!==t&&(r in e?e[r]=null:e.hasAttribute(r)&&e.removeAttribute(r)),e.addEventListener(a,n,o);break e}tc=!0,r in e?e[r]=n:!0===n?e.setAttribute(r,""):td(e,r,n)}return}tc=!0}function uh(e,t,r){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":c9("error",e),c9("load",e);var n,o=!1,a=!1;for(n in r)if(r.hasOwnProperty(n)){var i=r[n];if(null!=i)switch(n){case"src":o=!0;break;case"srcSet":a=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(s(137,t));default:uf(e,t,n,i,r,null)}}a&&uf(e,t,"srcSet",r.srcSet,r,null),o&&uf(e,t,"src",r.src,r,null);return;case"input":c9("invalid",e);var l=n=i=a=null,c=null,u=null;for(o in r)if(r.hasOwnProperty(o)){var d=r[o];if(null!=d)switch(o){case"name":a=d;break;case"type":i=d;break;case"checked":c=d;break;case"defaultChecked":u=d;break;case"value":n=d;break;case"defaultValue":l=d;break;case"children":case"dangerouslySetInnerHTML":if(null!=d)throw Error(s(137,t));break;default:uf(e,t,o,d,r,null)}}tw(e,n,l,c,u,i,a,!1);return;case"select":for(a in c9("invalid",e),o=i=n=null,r)if(r.hasOwnProperty(a)&&null!=(l=r[a]))switch(a){case"value":n=l;break;case"defaultValue":i=l;break;case"multiple":o=l;default:uf(e,t,a,l,r,null)}t=n,r=i,e.multiple=!!o,null!=t?tk(e,!!o,t,!1):null!=r&&tk(e,!!o,r,!0);return;case"textarea":for(i in c9("invalid",e),n=a=o=null,r)if(r.hasOwnProperty(i)&&null!=(l=r[i]))switch(i){case"value":o=l;break;case"defaultValue":a=l;break;case"children":n=l;break;case"dangerouslySetInnerHTML":if(null!=l)throw Error(s(91));break;default:uf(e,t,i,l,r,null)}tS(e,o,a,n);return;case"option":for(c in r)r.hasOwnProperty(c)&&null!=(o=r[c])&&("selected"===c?e.selected=o&&"function"!=typeof o&&"symbol"!=typeof o:uf(e,t,c,o,r,null));return;case"dialog":c9("beforetoggle",e),c9("toggle",e),c9("cancel",e),c9("close",e);break;case"iframe":case"object":c9("load",e);break;case"video":case"audio":for(o=0;o<c4.length;o++)c9(c4[o],e);break;case"image":c9("error",e),c9("load",e);break;case"details":c9("toggle",e);break;case"embed":case"source":case"link":c9("error",e),c9("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(u in r)if(r.hasOwnProperty(u)&&null!=(o=r[u]))switch(u){case"children":case"dangerouslySetInnerHTML":throw Error(s(137,t));default:uf(e,t,u,o,r,null)}return;default:if(tI(t)){for(d in r)r.hasOwnProperty(d)&&void 0!==(o=r[d])&&up(e,t,d,o,r,void 0);return}}for(l in r)r.hasOwnProperty(l)&&null!=(o=r[l])&&uf(e,t,l,o,r,null)}var um={};function ug(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}var uv=null,ux=null;function uy(e){return 9===e.nodeType?e:e.ownerDocument}function ub(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function uw(e,t){if(0===e)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return 1===e&&"foreignObject"===t?0:e}function u_(e,t,r,n){return(r=uy(r).createElement(e))[eY]=n,r[eX]=t,uh(r,e,t),te(r),r}function uk(e,t){return"textarea"===e||"noscript"===e||"string"==typeof t.children||"number"==typeof t.children||"bigint"==typeof t.children||"object"==typeof t.dangerouslySetInnerHTML&&null!==t.dangerouslySetInnerHTML&&null!=t.dangerouslySetInnerHTML.__html}var uj=null,uS="function"==typeof setTimeout?setTimeout:void 0,uC="function"==typeof clearTimeout?clearTimeout:void 0,uE="function"==typeof Promise?Promise:void 0,uT="function"==typeof requestAnimationFrame?requestAnimationFrame:uS,uN="function"==typeof queueMicrotask?queueMicrotask:void 0!==uE?function(e){return uE.resolve(null).then(e).catch(uI)}:uS;function uI(e){setTimeout(function(){throw e})}function uz(e){return"head"===e}function uR(e,t){var r=t,n=0;do{var o=r.nextSibling;if(e.removeChild(r),o&&8===o.nodeType)if("/$"===(r=o.data)||"/&"===r){if(0===n){e.removeChild(o),fi(t);return}n--}else if("$"===r||"$?"===r||"$~"===r||"$!"===r||"&"===r)n++;else if("html"===r)ds(e.ownerDocument.documentElement);else if("head"===r){ds(r=e.ownerDocument.head);for(var a=r.firstChild;a;){var i=a.nextSibling,s=a.nodeName;a[e3]||"SCRIPT"===s||"STYLE"===s||"LINK"===s&&"stylesheet"===a.rel.toLowerCase()||r.removeChild(a),a=i}}else"body"===r&&ds(e.ownerDocument.body);r=o}while(r);fi(t)}function uP(e,t){var r=e;e=0;do{var n=r.nextSibling;if(1===r.nodeType?t?(r._stashedDisplay=r.style.display,r.style.display="none"):(r.style.display=r._stashedDisplay||"",""===r.getAttribute("style")&&r.removeAttribute("style")):3===r.nodeType&&(t?(r._stashedText=r.nodeValue,r.nodeValue=""):r.nodeValue=r._stashedText||""),n&&8===n.nodeType)if("/$"===(r=n.data))if(0===e)break;else e--;else"$"!==r&&"$?"!==r&&"$~"!==r&&"$!"!==r||e++;r=n}while(r)}function uL(e,t,r){if(t=CSS.escape(t)!==t?"r-"+btoa(t).replace(/=/g,""):t,e.style.viewTransitionName=t,null!=r&&(e.style.viewTransitionClass=r),"inline"===(r=getComputedStyle(e)).display){if(1===(t=e.getClientRects()).length)var n=1;else for(var o=n=0;o<t.length;o++){var a=t[o];0<a.width&&0<a.height&&n++}1===n&&((e=e.style).display=1===t.length?"inline-block":"block",e.marginTop="-"+r.paddingTop,e.marginBottom="-"+r.paddingBottom)}}function uO(e,t){e=e.style;var r=null!=(t=t.style)?t.hasOwnProperty("viewTransitionName")?t.viewTransitionName:t.hasOwnProperty("view-transition-name")?t["view-transition-name"]:null:null;e.viewTransitionName=null==r||"boolean"==typeof r?"":(""+r).trim(),r=null!=t?t.hasOwnProperty("viewTransitionClass")?t.viewTransitionClass:t.hasOwnProperty("view-transition-class")?t["view-transition-class"]:null:null,e.viewTransitionClass=null==r||"boolean"==typeof r?"":(""+r).trim(),"inline-block"===e.display&&(null==t?e.display=e.margin="":(r=t.display,e.display=null==r||"boolean"==typeof r?"":r,null!=(r=t.margin)?e.margin=r:(r=t.hasOwnProperty("marginTop")?t.marginTop:t["margin-top"],e.marginTop=null==r||"boolean"==typeof r?"":r,t=t.hasOwnProperty("marginBottom")?t.marginBottom:t["margin-bottom"],e.marginBottom=null==t||"boolean"==typeof t?"":t)))}function uM(e,t,r){return r=r.ownerDocument.defaultView,{rect:e,abs:"absolute"===t.position||"fixed"===t.position,clip:"none"!==t.clipPath||"visible"!==t.overflow||"none"!==t.filter||"none"!==t.mask||"none"!==t.mask||"0px"!==t.borderRadius,view:0<=e.bottom&&0<=e.right&&e.top<=r.innerHeight&&e.left<=r.innerWidth}}function uA(e){return uM(e.getBoundingClientRect(),getComputedStyle(e),e)}function uD(e){var t=e.getBoundingClientRect();return uM(t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height),getComputedStyle(e),e)}function uF(e){this.addEventListener("load",e),this.addEventListener("error",e)}function u$(e,t){this._scope=document.documentElement,this._selector="::view-transition-"+e+"("+t+")"}function uU(e){return{name:e,group:new u$("group",e),imagePair:new u$("image-pair",e),old:new u$("old",e),new:new u$("new",e)}}function uZ(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}function uq(e,t,r,n){return g(e).addEventListener(t,r,n),!1}function uB(e,t,r,n){return g(e).removeEventListener(t,r,n),!1}function uV(e){return null!=e&&"boolean"!=typeof e&&(!0===e.once||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function uH(e){return null==e?"c=0":"boolean"==typeof e?"c="+(e?"1":"0"):"c="+(e.capture?"1":"0")}function uW(e,t,r,n){if(0===e.length)return -1;n=uH(n);for(var o=0;o<e.length;o++){var a=e[o];if(a.type===t&&a.listener===r&&uH(a.optionsOrUseCapture)===n)return o}return -1}function uG(e,t){return 6!==e.tag&&function(e,t){function r(){n=!0}if(e.ownerDocument.activeElement===e)return!0;var n=!1;try{e.ownerDocument.addEventListener("focus",r,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener("focus",r,!0)}return n}(e=g(e),t)}function uK(e,t){return t.push(e),!1}function uY(e,t){return 6!==e.tag&&!!((e=g(e))===t||e.contains(t))&&(t.blur(),!0)}function uX(e,t){return 6!==e.tag&&(e=g(e),t.observe(e),!1)}function uQ(e,t){return 6!==e.tag&&(e=g(e),t.unobserve(e),!1)}u$.prototype.animate=function(e,t){return(t="number"==typeof t?{duration:t}:k({},t)).pseudoElement=this._selector,this._scope.animate(e,t)},u$.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,r=e.getAnimations({subtree:!0}),n=[],o=0;o<r.length;o++){var a=r[o].effect;null!==a&&a.target===e&&a.pseudoElement===t&&n.push(r[o])}return n},u$.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)},uZ.prototype.addEventListener=function(e,t,r){var n=null,o=null;if(null==r||"boolean"==typeof r||null===(n=r.signal||null)||!n.aborted){null===this._eventListeners&&(this._eventListeners=[]);var a=this._eventListeners;if(-1===uW(a,e,t,r)){var i=this,s=t;null!=r&&"boolean"!=typeof r&&!0===r.once&&(s=function(n){i.removeEventListener(e,t,r),"function"==typeof t?t.call(this,n):t.handleEvent(n)}),null!==n&&(o=i.removeEventListener.bind(i,e,t,r),n.addEventListener("abort",o,{once:!0}),o=n.removeEventListener.bind(n,"abort",o)),n=uV(r),a.push({type:e,listener:t,optionsOrUseCapture:r,attachedListener:s,cleanup:o}),f(this._fragmentFiber.child,!1,uq,e,s,n)}this._eventListeners=a}},uZ.prototype.removeEventListener=function(e,t,r){var n=this._eventListeners;if(null!==n&&-1!==(t=uW(n,e,t,r))){var o=n[t];r=o.attachedListener;var a=o.cleanup;o=uV(o.optionsOrUseCapture),f(this._fragmentFiber.child,!1,uB,e,r,o),n.splice(t,1),null!==a&&a()}},uZ.prototype.dispatchEvent=function(e){var t=p(this._fragmentFiber);if(null===t)return!0;t=g(t);var r=this._eventListeners;if(null!==r&&0<r.length||!e.bubbles){var n=9===t.nodeType?t.createComment(""):document.createTextNode("");if(r)for(var o=0;o<r.length;o++){var a=r[o];n.addEventListener(a.type,a.attachedListener,uV(a.optionsOrUseCapture))}if(t.appendChild(n),e=n.dispatchEvent(e),r)for(o=0;o<r.length;o++)a=r[o],n.removeEventListener(a.type,a.attachedListener,uV(a.optionsOrUseCapture));return t.removeChild(n),e}return t.dispatchEvent(e)},uZ.prototype.focus=function(e){f(this._fragmentFiber.child,!0,uG,e,void 0,void 0)},uZ.prototype.focusLast=function(e){var t=[];f(this._fragmentFiber.child,!0,uK,t,void 0,void 0);for(var r=t.length-1;0<=r&&!uG(t[r],e);r--);},uZ.prototype.blur=function(){var e=p(this._fragmentFiber);null!==e&&null!==(e=uy(e=g(e)).activeElement)&&f(this._fragmentFiber.child,!1,uY,e,void 0,void 0)},uZ.prototype.observeUsing=function(e){null===this._observers&&(this._observers=new Set),this._observers.add(e),f(this._fragmentFiber.child,!1,uX,e,void 0,void 0)},uZ.prototype.unobserveUsing=function(e){var t=this._observers;if(null!==t&&t.has(e)){t.delete(e),f(this._fragmentFiber.child,!1,uQ,e,void 0,void 0);for(var r=t=0;r<uJ.length;r++){var n=uJ[r];n.fragmentInstance===this&&n.observer===e?e.unobserve(n.instance):uJ[t++]=n}uJ.length=t}};var uJ=[],u0=!1;function u1(e,t){if(6===e.tag){var r=(e=e.stateNode).ownerDocument.createRange();r.selectNodeContents(e),t.push.apply(t,r.getClientRects())}else e=g(e),t.push.apply(t,e.getClientRects());return!1}function u2(e,t){var r=e.ownerDocument.createRange();r.selectNodeContents(e),e=r.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}function u3(e,t){return u5(e=g(e),t),!1}function u5(e,t){null==e.reactFragments&&(e.reactFragments=new Set),e.reactFragments.add(t)}function u4(e,t){var r=t._eventListeners;if(null!==r)for(var n=0;n<r.length;n++){var o=r[n];e.addEventListener(o.type,o.attachedListener,uV(o.optionsOrUseCapture))}3!==e.nodeType&&(null!==(r=t._observers)&&r.forEach(function(r){for(var n=0,o=0;o<uJ.length;o++){var a=uJ[o];(a.fragmentInstance!==t||a.observer!==r||a.instance!==e)&&(uJ[n++]=a)}uJ.length=n,r.observe(e)}),u5(e,t))}function u6(e){var t=e.firstChild;for(t&&10===t.nodeType&&(t=t.nextSibling);t;){var r=t;switch(t=t.nextSibling,r.nodeName){case"HTML":case"HEAD":case"BODY":u6(r),e4(r);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if("stylesheet"===r.rel.toLowerCase())continue}e.removeChild(r)}}function u7(e,t){for(;8!==e.nodeType;)if((1!==e.nodeType||"INPUT"!==e.nodeName||"hidden"!==e.type)&&!t||null===(e=de(e.nextSibling)))return null;return e}function u9(e){return"$?"===e.data||"$~"===e.data}function u8(e){return"$!"===e.data||"$?"===e.data&&"loading"!==e.ownerDocument.readyState}function de(e){for(;null!=e;e=e.nextSibling){var t=e.nodeType;if(1===t||3===t)break;if(8===t){if("$"===(t=e.data)||"$!"===t||"$?"===t||"$~"===t||"&"===t||"F!"===t||"F"===t)break;if("/$"===t||"/&"===t)return null}}return e}uZ.prototype.getClientRects=function(){var e=[];return f(this._fragmentFiber.child,!1,u1,e,void 0,void 0),e},uZ.prototype.getRootNode=function(e){var t=p(this._fragmentFiber);return null===t?this:g(t).getRootNode(e)},uZ.prototype.compareDocumentPosition=function(e){var t=p(this._fragmentFiber);if(null===t)return Node.DOCUMENT_POSITION_DISCONNECTED;var r=[];f(this._fragmentFiber.child,!1,uK,r,void 0,void 0);var n=g(t);if(0===r.length){if(r=n,h(this._fragmentFiber)){e:{for(t=this._fragmentFiber.return;null!==t;){if(4===t.tag){t=t.stateNode.containerInfo;break e}if(3===t.tag||5===t.tag||27===t.tag)break;t=t.return}t=null}null!=t&&(r=t)}t=this._fragmentFiber;var o=n=r.compareDocumentPosition(e);return r===e?o=Node.DOCUMENT_POSITION_CONTAINS:n&Node.DOCUMENT_POSITION_CONTAINED_BY&&(o=null===(r=m(t)[1])?Node.DOCUMENT_POSITION_PRECEDING:0===(e=g(r).compareDocumentPosition(e))||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING),o|Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=g(r[0]),o=g(r[r.length-1]);var a=h(this._fragmentFiber)?t.parentElement:n;if(null==a)return Node.DOCUMENT_POSITION_DISCONNECTED;n=a.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,a=a.compareDocumentPosition(o)&Node.DOCUMENT_POSITION_CONTAINED_BY;var i=t.compareDocumentPosition(e),s=o.compareDocumentPosition(e),l=i&Node.DOCUMENT_POSITION_CONTAINED_BY||s&Node.DOCUMENT_POSITION_CONTAINED_BY;return s=n&&a&&i&Node.DOCUMENT_POSITION_FOLLOWING&&s&Node.DOCUMENT_POSITION_PRECEDING,(t=n&&t===e||a&&o===e||l||s?Node.DOCUMENT_POSITION_CONTAINED_BY:(n||t!==e)&&(a||o!==e)?i:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC)&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||function(e,t,r,n,o){var a=e6(o);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(r=!!a)e:{for(;null!==a;){if(7===a.tag&&(a===t||a.alternate===t)){r=!0;break e}a=a.return}r=!1}return r}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(null===a){e:{for(a=t.return;null!==a;){if(3===a.tag){a=a.stateNode.containerInfo;break e}a=a.return}a=null}return null!==a&&o.contains(a)}e:{for(a=t,t=p(t);null!==a;){if((5===a.tag||3===a.tag||27===a.tag)&&(a===t||a.alternate===t)){a=!0;break e}a=a.return}a=!1}return a}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!a)&&!(t=a===r)&&(null===(t=_(r,a,w))?t=!1:(f(t,!0,y,a,r),a=v,v=null,t=null!==a)),t):!!(e&Node.DOCUMENT_POSITION_FOLLOWING)&&((t=!!a)&&!(t=a===n)&&(null===(t=_(n,a,w))?t=!1:(f(t,!0,b,a,n),a=v,x=v=null,t=null!==a)),t)}(t,this._fragmentFiber,r[0],r[r.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC},uZ.prototype.scrollIntoView=function(e){if("object"==typeof e)throw Error(s(566));var t=[];f(this._fragmentFiber.child,!1,uK,t,void 0,void 0);var r=!1!==e;if(0===t.length){var n=m(this._fragmentFiber);if(null===(n=r?n[1]||n[0]||p(this._fragmentFiber):n[0]||n[1]))return;if(6===n.tag)return void u2(e=g(n),r);if(9!==(n=g(n)).nodeType){if(11===n.nodeType){null!==(r="host"in n?n.host:null)&&r.scrollIntoView(e);return}n.scrollIntoView(e)}}for(n=r?t.length-1:0;n!==(r?-1:t.length);){var o=t[n];6===o.tag?u2(o=g(o),r):g(o).scrollIntoView(e),n+=r?-1:1}};var dt=null;function dr(e){e=e.nextSibling;for(var t=0;e;){if(8===e.nodeType){var r=e.data;if("/$"===r||"/&"===r){if(0===t)return de(e.nextSibling);t--}else"$"!==r&&"$!"!==r&&"$?"!==r&&"$~"!==r&&"&"!==r||t++}e=e.nextSibling}return null}function dn(e){e=e.previousSibling;for(var t=0;e;){if(8===e.nodeType){var r=e.data;if("$"===r||"$!"===r||"$?"===r||"$~"===r||"&"===r){if(0===t)return e;t--}else"/$"!==r&&"/&"!==r||t++}e=e.previousSibling}return null}function da(e,t,r){switch(t=uy(r),e){case"html":if(!(e=t.documentElement))throw Error(s(452));return e;case"head":if(!(e=t.head))throw Error(s(453));return e;case"body":if(!(e=t.body))throw Error(s(454));return e;default:throw Error(s(451))}}function di(e,t,r){for(var n in r){var o=r[n];r.hasOwnProperty(n)&&null!=o&&uf(e,t,n,null,um,o)}null!=r.dangerouslySetInnerHTML&&(e.textContent=""),e.onclick===tL&&(e.onclick=null),e4(e)}function ds(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);e4(e)}var dl=new Map,dc=new Set;function du(e){if("function"==typeof e.getRootNode){var t=e.getRootNode();if(9===t.nodeType||11===t.nodeType)return t}return 9===e.nodeType?e:e.ownerDocument}var dd=W.d;W.d={f:function(){var e=dd.f(),t=cf();return e||t},r:function(e){var t=e7(e);null!==t&&5===t.tag&&"form"===t.type?ib(t):dd.r(e)},D:function(e){dd.D(e),dp("dns-prefetch",e,null)},C:function(e,t){dd.C(e,t),dp("preconnect",e,t)},L:function(e,t,r){if(dd.L(e,t,r),df&&e&&t){var n='link[rel="preload"][as="'+ty(t)+'"]';"image"===t&&r&&r.imageSrcSet?(n+='[imagesrcset="'+ty(r.imageSrcSet)+'"]',"string"==typeof r.imageSizes&&(n+='[imagesizes="'+ty(r.imageSizes)+'"]')):n+='[href="'+ty(e)+'"]';var o=n;switch(t){case"style":o=dm(e);break;case"script":o=dx(e)}if(!(dl.has(o)||(e=k({rel:"preload",href:"image"===t&&r&&r.imageSrcSet?void 0:e,as:t},r),dl.set(o,e),null!==df.querySelector(n)||"style"===t&&df.querySelector(dg(o))||"script"===t&&df.querySelector(dy(o))))){var a=df.createElement("link");uh(a,"link",e),"style"===t&&(a[e5]=!0,a.onload=a.onerror=function(){tt(a)}),te(a),df.head.appendChild(a)}}},m:function(e,t){if(dd.m(e,t),df&&e){var r=t&&"string"==typeof t.as?t.as:"script",n='link[rel="modulepreload"][as="'+ty(r)+'"][href="'+ty(e)+'"]',o=n;switch(r){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":o=dx(e)}if(!dl.has(o)&&(e=k({rel:"modulepreload",href:e},t),dl.set(o,e),null===df.querySelector(n))){switch(r){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(df.querySelector(dy(o)))return}uh(r=df.createElement("link"),"link",e),te(r),df.head.appendChild(r)}}},X:function(e,t){if(dd.X(e,t),df&&e){var r=e8(df).hoistableScripts,n=dx(e),o=r.get(n);o||((o=df.querySelector(dy(n)))||(e=k({src:e,async:!0},t),(t=dl.get(n))&&dk(e,t),te(o=df.createElement("script")),uh(o,"link",e),df.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},r.set(n,o))}},S:function(e,t,r){if(dd.S(e,t,r),df&&e){var n=e8(df).hoistableStyles,o=dm(e);t=t||"default";var a=n.get(o);if(!a){var i={loading:0,preload:null};if(a=df.querySelector(dg(o)))i.loading=5;else{e=k({rel:"stylesheet",href:e,"data-precedence":t},r),(r=dl.get(o))&&d_(e,r);var s=a=df.createElement("link");te(s),uh(s,"link",e),s._p=new Promise(function(e,t){s.onload=e,s.onerror=t}),s.addEventListener("load",function(){i.loading|=1}),s.addEventListener("error",function(){i.loading|=2}),i.loading|=4,dw(a,t,df)}a={type:"stylesheet",instance:a,count:1,state:i},n.set(o,a)}}},M:function(e,t){if(dd.M(e,t),df&&e){var r=e8(df).hoistableScripts,n=dx(e),o=r.get(n);o||((o=df.querySelector(dy(n)))||(e=k({src:e,async:!0,type:"module"},t),(t=dl.get(n))&&dk(e,t),te(o=df.createElement("script")),uh(o,"link",e),df.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},r.set(n,o))}}};var df="undefined"==typeof document?null:document;function dp(e,t,r){if(df&&"string"==typeof t&&t){var n=ty(t);n='link[rel="'+e+'"][href="'+n+'"]',"string"==typeof r&&(n+='[crossorigin="'+r+'"]'),dc.has(n)||(dc.add(n),e={rel:e,crossOrigin:r,href:t},null===df.querySelector(n)&&(uh(t=df.createElement("link"),"link",e),te(t),df.head.appendChild(t)))}}function dh(e,t,r,n){var o=(o=er.current)?du(o):null;if(!o)throw Error(s(446));switch(e){case"meta":case"title":return null;case"style":return"string"==typeof r.precedence&&"string"==typeof r.href?(r=dm(r.href),(n=(t=e8(o).hoistableStyles).get(r))||(n={type:"style",instance:null,count:0,state:null},t.set(r,n)),n):{type:"void",instance:null,count:0,state:null};case"link":if("stylesheet"===r.rel&&"string"==typeof r.href&&"string"==typeof r.precedence){e=dm(r.href);var a=e8(o).hoistableStyles,i=a.get(e);if(i||(o=o.ownerDocument||o,i={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},a.set(e,i),(a=o.querySelector(dg(e)))?a._p||(i.instance=a,i.state.loading=5):((a=dl.get(e))||(a={rel:"preload",as:"style",href:r.href,crossOrigin:r.crossOrigin,integrity:r.integrity,media:r.media,hrefLang:r.hrefLang,referrerPolicy:r.referrerPolicy},dl.set(e,a)),function(e,t,r,n){if(t=e.querySelector('link[rel="preload"][as="style"]['+t+"]")){if(!0!==t[e5]){n.loading=1;return}}else(t=e.createElement("link"))[e5]=!0,t.onload=t.onerror=tt.bind(null,t),uh(t,"link",r),te(t),e.head.appendChild(t);n.preload=t,t.addEventListener("load",function(){return n.loading|=1}),t.addEventListener("error",function(){return n.loading|=2})}(o,e,a,i.state))),t&&null===n)throw Error(s(528,""));return i}if(t&&null!==n)throw Error(s(529,""));return null;case"script":return t=r.async,"string"==typeof(r=r.src)&&t&&"function"!=typeof t&&"symbol"!=typeof t?(r=dx(r),(n=(t=e8(o).hoistableScripts).get(r))||(n={type:"script",instance:null,count:0,state:null},t.set(r,n)),n):{type:"void",instance:null,count:0,state:null};default:throw Error(s(444,e))}}function dm(e){return'href="'+ty(e)+'"'}function dg(e){return'link[rel="stylesheet"]['+e+"]"}function dv(e){return k({},e,{"data-precedence":e.precedence,precedence:null})}function dx(e){return'[src="'+ty(e)+'"]'}function dy(e){return"script[async]"+e}function db(e,t,r){if(t.count++,null===t.instance)switch(t.type){case"style":var n=e.querySelector('style[data-href~="'+ty(r.href)+'"]');if(n)return t.instance=n,te(n),n;var o=k({},r,{"data-href":r.href,"data-precedence":r.precedence,href:null,precedence:null});return te(n=(e.ownerDocument||e).createElement("style")),uh(n,"style",o),dw(n,r.precedence,e),t.instance=n;case"stylesheet":o=dm(r.href);var a=e.querySelector(dg(o));if(a)return t.state.loading|=4,t.instance=a,te(a),a;n=dv(r),(o=dl.get(o))&&d_(n,o),te(a=(e.ownerDocument||e).createElement("link"));var i=a;return i._p=new Promise(function(e,t){i.onload=e,i.onerror=t}),uh(a,"link",n),t.state.loading|=4,dw(a,r.precedence,e),t.instance=a;case"script":if(a=dx(r.src),o=e.querySelector(dy(a)))return t.instance=o,te(o),o;return n=r,(o=dl.get(a))&&dk(n=k({},r),o),te(o=(e=e.ownerDocument||e).createElement("script")),uh(o,"link",n),e.head.appendChild(o),t.instance=o;case"void":return null;default:throw Error(s(443,t.type))}return"stylesheet"===t.type&&0==(4&t.state.loading)&&(n=t.instance,t.state.loading|=4,dw(n,r.precedence,e)),t.instance}function dw(e,t,r){for(var n=r.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),o=n.length?n[n.length-1]:null,a=o,i=0;i<n.length;i++){var s=n[i];if(s.dataset.precedence===t)a=s;else if(a!==o)break}a?a.parentNode.insertBefore(e,a.nextSibling):(t=9===r.nodeType?r.head:r).insertBefore(e,t.firstChild)}function d_(e,t){null==e.crossOrigin&&(e.crossOrigin=t.crossOrigin),null==e.referrerPolicy&&(e.referrerPolicy=t.referrerPolicy),null==e.title&&(e.title=t.title)}function dk(e,t){null==e.crossOrigin&&(e.crossOrigin=t.crossOrigin),null==e.referrerPolicy&&(e.referrerPolicy=t.referrerPolicy),null==e.integrity&&(e.integrity=t.integrity)}var dj=null;function dS(e,t,r){if(null===dj){var n=new Map,o=dj=new Map;o.set(r,n)}else(n=(o=dj).get(r))||(n=new Map,o.set(r,n));if(n.has(e))return n;for(n.set(e,null),r=r.getElementsByTagName(e),o=0;o<r.length;o++){var a=r[o];if(!(a[e3]||a[eY]||"link"===e&&"stylesheet"===a.getAttribute("rel"))&&"http://www.w3.org/2000/svg"!==a.namespaceURI){var i=a.getAttribute(t)||"";i=e+i;var s=n.get(i);s?s.push(a):n.set(i,[a])}}return n}function dC(e,t,r){(e=e.ownerDocument||e).head.insertBefore(r,"title"===t?e.querySelector("head > title"):null)}function dE(e,t){return"img"===e&&null!=t.src&&""!==t.src&&null==t.onLoad&&"lazy"!==t.loading}function dT(e){return"stylesheet"!==e.type||0!=(3&e.state.loading)}function dN(e){return(e.width||100)*(e.height||100)*("number"==typeof devicePixelRatio?devicePixelRatio:1)*.25}function dI(e,t){"function"==typeof t.decode&&(e.imgCount++,t.complete||(e.imgBytes+=dN(t),e.suspenseyImages.push(t)),e=dL.bind(e),t.decode().then(e,e))}var dz=0;function dR(e){if(0===e.count&&(0===e.imgCount||!e.waitingForImages)){if(e.stylesheets)dM(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function dP(){this.count--,dR(this)}function dL(){this.imgCount--,dR(this)}var dO=null;function dM(e,t){e.stylesheets=null,null!==e.unsuspend&&(e.count++,dO=new Map,t.forEach(dA,e),dO=null,dP.call(e))}function dA(e,t){if(!(4&t.state.loading)){var r=dO.get(e);if(r)var n=r.get(null);else{r=new Map,dO.set(e,r);for(var o=e.querySelectorAll("link[data-precedence],style[data-precedence]"),a=0;a<o.length;a++){var i=o[a];("LINK"===i.nodeName||"not all"!==i.getAttribute("media"))&&(r.set(i.dataset.precedence,i),n=i)}n&&r.set(null,n)}i=(o=t.instance).getAttribute("data-precedence"),(a=r.get(i)||n)===n&&r.set(null,o),r.set(i,o),this.count++,n=dP.bind(this),o.addEventListener("load",n),o.addEventListener("error",n),a?a.parentNode.insertBefore(o,a.nextSibling):(e=9===e.nodeType?e.head:e).insertBefore(o,e.firstChild),t.state.loading|=4}}var dD={$$typeof:z,Provider:null,Consumer:null,_currentValue:G,_currentValue2:G,_threadCount:0};function dF(e,t,r,n,o,a,i,s,l){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=e$(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=e$(0),this.hiddenUpdates=e$(null),this.identifierPrefix=n,this.onUncaughtError=o,this.onCaughtError=a,this.onRecoverableError=i,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=l,this.transitionTypes=null,this.incompleteTransitions=new Map}function d$(e,t,r,n,o,a){o=o?nk:nk,null===n.context?n.context=o:n.pendingContext=o,(n=oX(t)).payload={element:r},null!==(a=void 0===a?null:a)&&(n.callback=a),null!==(r=oQ(e,n,t))&&(cl(r,e,t),oJ(r,e,t))}function dU(e,t){if(null!==(e=e.memoizedState)&&null!==e.dehydrated){var r=e.retryLane;e.retryLane=0!==r&&r<t?r:t}}function dZ(e,t){dU(e,t),(e=e.alternate)&&dU(e,t)}function dq(e){if(13===e.tag||31===e.tag){var t=nb(e,0x4000000);null!==t&&cl(t,e,0x4000000),dZ(e,0x4000000)}}function dB(e){if(13===e.tag||31===e.tag){var t=ca(),r=nb(e,t=eV(t));null!==r&&cl(r,e,t),dZ(e,t)}}var dV=!0;function dH(e,t,r,n){var o=H.T;H.T=null;var a=W.p;try{W.p=2,dG(e,t,r,n)}finally{W.p=a,H.T=o}}function dW(e,t,r,n){var o=H.T;H.T=null;var a=W.p;try{W.p=8,dG(e,t,r,n)}finally{W.p=a,H.T=o}}function dG(e,t,r,n){if(dV){var o=dK(n);if(null===o)un(e,t,n,dY,r),d7(e,n);else if(function(e,t,r,n,o){switch(t){case"focusin":return d0=d9(d0,e,t,r,n,o),!0;case"dragenter":return d1=d9(d1,e,t,r,n,o),!0;case"mouseover":return d2=d9(d2,e,t,r,n,o),!0;case"pointerover":var a=o.pointerId;return d3.set(a,d9(d3.get(a)||null,e,t,r,n,o)),!0;case"gotpointercapture":return a=o.pointerId,d5.set(a,d9(d5.get(a)||null,e,t,r,n,o)),!0}return!1}(o,e,t,r,n))n.stopPropagation();else if(d7(e,n),4&t&&-1<d6.indexOf(e)){for(;null!==o;){var a=e7(o);if(null!==a)switch(a.tag){case 3:if((a=a.stateNode).current.memoizedState.isDehydrated){var i=eO(a.pendingLanes);if(0!==i){var s=a;for(s.pendingLanes|=2,s.entangledLanes|=2;i;){var l=1<<31-eN(i);s.entanglements[1]|=l,i&=~l}cG(a),0==(6&lP)&&(l0=ev()+500,cK(0,!1))}}break;case 31:case 13:null!==(s=nb(a,2))&&cl(s,a,2),cf(),dZ(a,2)}if(null===(a=dK(n))&&un(e,t,n,dY,r),a===o)break;o=a}null!==o&&n.stopPropagation()}else un(e,t,n,null,r)}}function dK(e){return dX(e=tM(e))}var dY=null;function dX(e){if(dY=null,null!==(e=e6(e))){var t=l(e);if(null===t)e=null;else{var r=t.tag;if(13===r){if(null!==(e=c(t)))return e;e=null}else if(31===r){if(null!==(e=u(t)))return e;e=null}else if(3===r){if(t.stateNode.current.memoizedState.isDehydrated)return 3===t.tag?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return dY=e,null}function dQ(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(ex()){case ey:return 2;case eb:return 8;case ew:case e_:return 32;case ek:return 0x10000000;default:return 32}default:return 32}}var dJ=!1,d0=null,d1=null,d2=null,d3=new Map,d5=new Map,d4=[],d6="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function d7(e,t){switch(e){case"focusin":case"focusout":d0=null;break;case"dragenter":case"dragleave":d1=null;break;case"mouseover":case"mouseout":d2=null;break;case"pointerover":case"pointerout":d3.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":d5.delete(t.pointerId)}}function d9(e,t,r,n,o,a){return null===e||e.nativeEvent!==a?(e={blockedOn:t,domEventName:r,eventSystemFlags:n,nativeEvent:a,targetContainers:[o]},null!==t&&null!==(t=e7(t))&&dq(t)):(e.eventSystemFlags|=n,t=e.targetContainers,null!==o&&-1===t.indexOf(o)&&t.push(o)),e}function d8(e){var t=e6(e.target);if(null!==t){var r=l(t);if(null!==r){if(13===(t=r.tag)){if(null!==(t=c(r))){e.blockedOn=t,eG(e.priority,function(){dB(r)});return}}else if(31===t){if(null!==(t=u(r))){e.blockedOn=t,eG(e.priority,function(){dB(r)});return}}else if(3===t&&r.stateNode.current.memoizedState.isDehydrated){e.blockedOn=3===r.tag?r.stateNode.containerInfo:null;return}}}e.blockedOn=null}function fe(e){if(null!==e.blockedOn)return!1;for(var t=e.targetContainers;0<t.length;){var r=dK(e.nativeEvent);if(null!==r)return null!==(t=e7(r))&&dq(t),e.blockedOn=r,!1;var n=new(r=e.nativeEvent).constructor(r.type,r);tO=n,r.target.dispatchEvent(n),tO=null,t.shift()}return!0}function ft(e,t,r){fe(e)&&r.delete(t)}function fr(){dJ=!1,null!==d0&&fe(d0)&&(d0=null),null!==d1&&fe(d1)&&(d1=null),null!==d2&&fe(d2)&&(d2=null),d3.forEach(ft),d5.forEach(ft)}function fn(e,t){e.blockedOn===t&&(e.blockedOn=null,dJ||(dJ=!0,o.unstable_scheduleCallback(o.unstable_NormalPriority,fr)))}var fo=null;function fa(e){fo!==e&&(fo=e,o.unstable_scheduleCallback(o.unstable_NormalPriority,function(){fo===e&&(fo=null);for(var t=0;t<e.length;t+=3){var r=e[t],n=e[t+1],o=e[t+2];if("function"!=typeof n)if(null===dX(n||r))continue;else break;var a=e7(r);null!==a&&(e.splice(t,3),t-=3,ix(a,{pending:!0,data:o,method:r.method,action:n},n,o))}}))}function fi(e){function t(t){return fn(t,e)}null!==d0&&fn(d0,e),null!==d1&&fn(d1,e),null!==d2&&fn(d2,e),d3.forEach(t),d5.forEach(t);for(var r=0;r<d4.length;r++){var n=d4[r];n.blockedOn===e&&(n.blockedOn=null)}for(;0<d4.length&&null===(r=d4[0]).blockedOn;)d8(r),null===r.blockedOn&&d4.shift();if(null!=(r=(e.ownerDocument||e).$$reactFormReplay))for(n=0;n<r.length;n+=3){var o=r[n],a=r[n+1],i=o[eX]||null;if("function"==typeof a)i||fa(r);else if(i){var s=null;if(a&&a.hasAttribute("formAction")){if(o=a,i=a[eX]||null)s=i.formAction;else if(null!==dX(o))continue}else s=i.action;"function"==typeof s?r[n+1]=s:(r.splice(n,3),n-=3),fa(r)}}}function fs(){function e(e){e.canIntercept&&"react-transition"===e.info&&e.intercept({handler:function(){return new Promise(function(e){return o=e})},focusReset:"manual",scroll:"manual"})}function t(){null!==o&&(o(),o=null),n||setTimeout(r,20)}function r(){if(!n&&!navigation.transition){var e=navigation.currentEntry;e&&null!=e.url&&navigation.navigate(e.url,{state:e.getState(),info:"react-transition",history:"replace"})}}if("object"==typeof navigation){var n=!1,o=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(r,100),function(){n=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),null!==o&&(o(),o=null)}}}function fl(e){this._internalRoot=e}function fc(e){this._internalRoot=e}fc.prototype.render=fl.prototype.render=function(e){var t=this._internalRoot;if(null===t)throw Error(s(409));d$(t.current,ca(),e,t,null,null)},fc.prototype.unmount=fl.prototype.unmount=function(){var e=this._internalRoot;if(null!==e){this._internalRoot=null;var t=e.containerInfo;d$(e.current,2,null,e,null,null),cf(),t[eQ]=null}},fc.prototype.unstable_scheduleHydration=function(e){if(e){var t=eW();e={blockedOn:null,target:e,priority:t};for(var r=0;r<d4.length&&0!==t&&t<d4[r].priority;r++);d4.splice(r,0,e),0===r&&d8(e)}};var fu=a.version;if("19.3.0-canary-278794d7-20261002"!==fu)throw Error(s(527,fu,"19.3.0-canary-278794d7-20261002"));if(W.findDOMNode=function(e){var t=e._reactInternals;if(void 0===t){if("function"==typeof e.render)throw Error(s(188));throw Error(s(268,e=Object.keys(e).join(",")))}return null===(e=null!==(e=function(e){var t=e.alternate;if(!t){if(null===(t=l(e)))throw Error(s(188));return t!==e?null:e}for(var r=e,n=t;;){var o=r.return;if(null===o)break;var a=o.alternate;if(null===a){if(null!==(n=o.return)){r=n;continue}break}if(o.child===a.child){for(a=o.child;a;){if(a===r)return d(o),e;if(a===n)return d(o),t;a=a.sibling}throw Error(s(188))}if(r.return!==n.return)r=o,n=a;else{for(var i=!1,c=o.child;c;){if(c===r){i=!0,r=o,n=a;break}if(c===n){i=!0,n=o,r=a;break}c=c.sibling}if(!i){for(c=a.child;c;){if(c===r){i=!0,r=a,n=o;break}if(c===n){i=!0,n=a,r=o;break}c=c.sibling}if(!i)throw Error(s(189))}}if(r.alternate!==n)throw Error(s(190))}if(3!==r.tag)throw Error(s(188));return r.stateNode.current===r?e:t}(t))?function e(t){var r=t.tag;if(5===r||26===r||27===r||6===r)return t;for(t=t.child;null!==t;){if(null!==(r=e(t)))return r;t=t.sibling}return null}(e):null)?null:e.stateNode},"undefined"!=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var fd=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!fd.isDisabled&&fd.supportsFiber)try{eC=fd.inject({bundleType:0,version:"19.3.0-canary-278794d7-20261002",rendererPackageName:"react-dom",currentDispatcherRef:H,reconcilerVersion:"19.3.0-canary-278794d7-20261002"}),eE=fd}catch(e){}}t.createRoot=function(e,t){if(!(r=e)||1!==r.nodeType&&9!==r.nodeType&&11!==r.nodeType)throw Error(s(299));var r,n,o,a,i,l,c,u,d=!1,f="",p=iU,h=iZ,m=iq;return null!=t&&(!0===t.unstable_strictMode&&(d=!0),void 0!==t.identifierPrefix&&(f=t.identifierPrefix),void 0!==t.onUncaughtError&&(p=t.onUncaughtError),void 0!==t.onCaughtError&&(h=t.onCaughtError),void 0!==t.onRecoverableError&&(m=t.onRecoverableError)),n=e,o=1,a=!1,i=null,l=0,c=d,u=null,n=new dF(n,o,a,f,p,h,m,fs,null),o=1,!0===c&&(o|=24),c=nS(3,null,null,o),n.current=c,c.stateNode=n,o=og(),o.refCount++,n.pooledCache=o,o.refCount++,c.memoizedState={element:null,isDehydrated:a,cache:o},oK(c),t=n,e[eQ]=t.current,ut(e),new fl(t)}},"./dist/compiled/react-dom/cjs/react-dom.production.js"(e,t,r){"use strict";var n=r("./dist/compiled/react/index.js");function o(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var r=2;r<arguments.length;r++)t+="&args[]="+encodeURIComponent(arguments[r])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function a(){}var i={d:{f:a,r:function(){throw Error(o(522))},D:a,C:a,L:a,m:a,X:a,S:a,M:a},p:0,findDOMNode:null},s=Symbol.for("react.portal"),l=Symbol.for("react.recoverable"),c=Symbol.for("react.optimistic_key"),u=n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function d(e,t){return"font"===e?"":"string"==typeof t?"use-credentials"===t?t:"":void 0}t.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=i,t.browser=function(e){return{$$typeof:l,_reason:e}},t.createPortal=function(e,t){var r=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!t||1!==t.nodeType&&9!==t.nodeType&&11!==t.nodeType)throw Error(o(299));return function(e,t,r){var n=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:s,key:null==n?null:n===c?c:""+n,children:e,containerInfo:t,implementation:r}}(e,t,null,r)},t.flushSync=function(e){var t=u.T,r=i.p;try{if(u.T=null,i.p=2,e)return e()}finally{u.T=t,i.p=r,i.d.f()}},t.preconnect=function(e,t){"string"==typeof e&&(t=t?"string"==typeof(t=t.crossOrigin)?"use-credentials"===t?t:"":void 0:null,i.d.C(e,t))},t.prefetchDNS=function(e){"string"==typeof e&&i.d.D(e)},t.preinit=function(e,t){if("string"==typeof e&&t&&"string"==typeof t.as){var r=t.as,n=d(r,t.crossOrigin),o="string"==typeof t.integrity?t.integrity:void 0,a="string"==typeof t.fetchPriority?t.fetchPriority:void 0;"style"===r?i.d.S(e,"string"==typeof t.precedence?t.precedence:void 0,{crossOrigin:n,integrity:o,fetchPriority:a}):"script"===r&&i.d.X(e,{crossOrigin:n,integrity:o,fetchPriority:a,nonce:"string"==typeof t.nonce?t.nonce:void 0})}},t.preinitModule=function(e,t){if("string"==typeof e)if("object"==typeof t&&null!==t){if(null==t.as||"script"===t.as){var r=d(t.as,t.crossOrigin);i.d.M(e,{crossOrigin:r,integrity:"string"==typeof t.integrity?t.integrity:void 0,nonce:"string"==typeof t.nonce?t.nonce:void 0,fetchPriority:"string"==typeof t.fetchPriority?t.fetchPriority:void 0})}}else null==t&&i.d.M(e)},t.preload=function(e,t){if("string"==typeof e&&"object"==typeof t&&null!==t&&"string"==typeof t.as){var r=t.as,n=d(r,t.crossOrigin);i.d.L(e,r,{crossOrigin:n,integrity:"string"==typeof t.integrity?t.integrity:void 0,nonce:"string"==typeof t.nonce?t.nonce:void 0,type:"string"==typeof t.type?t.type:void 0,fetchPriority:"string"==typeof t.fetchPriority?t.fetchPriority:void 0,referrerPolicy:"string"==typeof t.referrerPolicy?t.referrerPolicy:void 0,imageSrcSet:"string"==typeof t.imageSrcSet?t.imageSrcSet:void 0,imageSizes:"string"==typeof t.imageSizes?t.imageSizes:void 0,media:"string"==typeof t.media?t.media:void 0})}},t.preloadModule=function(e,t){if("string"==typeof e)if(t){var r=d(t.as,t.crossOrigin);i.d.m(e,{as:"string"==typeof t.as&&"script"!==t.as?t.as:void 0,crossOrigin:r,integrity:"string"==typeof t.integrity?t.integrity:void 0,nonce:"string"==typeof t.nonce?t.nonce:void 0,fetchPriority:"string"==typeof t.fetchPriority?t.fetchPriority:void 0})}else i.d.m(e)},t.requestFormReset=function(e){i.d.r(e)},t.unstable_batchedUpdates=function(e,t){return e(t)},t.useFormState=function(e,t,r){return u.H.useFormState(e,t,r)},t.useFormStatus=function(){return u.H.useHostTransitionStatus()},t.version="19.3.0-canary-278794d7-20261002"},"./dist/compiled/react-dom/client.js"(e,t,r){"use strict";!function e(){if("undefined"!=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__&&"function"==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(e){console.error(e)}}(),e.exports=r("./dist/compiled/react-dom/cjs/react-dom-client.production.js")},"./dist/compiled/react-dom/index.js"(e,t,r){"use strict";!function e(){if("undefined"!=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__&&"function"==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(e){console.error(e)}}(),e.exports=r("./dist/compiled/react-dom/cjs/react-dom.production.js")},"./dist/compiled/react/cjs/react-compiler-runtime.production.js"(e,t,r){"use strict";var n=r("./dist/compiled/react/index.js").__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;t.c=function(e){return n.H.useMemoCache(e)}},"./dist/compiled/react/cjs/react-jsx-runtime.production.js"(e,t){"use strict";var r=Symbol.for("react.transitional.element");function n(e,t,n){var o=null;if(void 0!==n&&(o=""+n),void 0!==t.key&&(o=""+t.key),"key"in t)for(var a in n={},t)"key"!==a&&(n[a]=t[a]);else n=t;return{$$typeof:r,type:e,key:o,ref:void 0!==(t=n.ref)?t:null,props:n}}t.Fragment=Symbol.for("react.fragment"),t.jsx=n,t.jsxs=n},"./dist/compiled/react/cjs/react.production.js"(e,t){"use strict";var r=Symbol.for("react.transitional.element"),n=Symbol.for("react.portal"),o=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),i=Symbol.for("react.profiler"),s=Symbol.for("react.consumer"),l=Symbol.for("react.context"),c=Symbol.for("react.forward_ref"),u=Symbol.for("react.suspense"),d=Symbol.for("react.memo"),f=Symbol.for("react.lazy"),p=Symbol.for("react.activity"),h=Symbol.for("react.view_transition"),m=Symbol.iterator,g={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},v=Object.assign,x={};function y(e,t,r){this.props=e,this.context=t,this.refs=x,this.updater=r||g}function b(){}function w(e,t,r){this.props=e,this.context=t,this.refs=x,this.updater=r||g}y.prototype.isReactComponent={},y.prototype.setState=function(e,t){if("object"!=typeof e&&"function"!=typeof e&&null!=e)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")},y.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")},b.prototype=y.prototype;var _=w.prototype=new b;_.constructor=w,v(_,y.prototype),_.isPureReactComponent=!0;var k=Array.isArray;function j(){}var S={H:null,A:null,T:null,S:null},C=Object.prototype.hasOwnProperty;function E(e,t,n){var o=n.ref;return{$$typeof:r,type:e,key:t,ref:void 0!==o?o:null,props:n}}function T(e){return"object"==typeof e&&null!==e&&e.$$typeof===r}var N=/\/+/g;function I(e,t){var r,n;return"object"==typeof e&&null!==e&&null!=e.key?(r=""+e.key,n={"=":"=0",":":"=2"},"$"+r.replace(/[=:]/g,function(e){return n[e]})):t.toString(36)}function z(e,t,o){if(null==e)return e;var a=[],i=0;return!function e(t,o,a,i,s){var l,c,u,d=typeof t;("undefined"===d||"boolean"===d)&&(t=null);var p=!1;if(null===t)p=!0;else switch(d){case"bigint":case"string":case"number":p=!0;break;case"object":switch(t.$$typeof){case r:case n:p=!0;break;case f:return e((p=t._init)(t._payload),o,a,i,s)}}if(p)return s=s(t),p=""===i?"."+I(t,0):i,k(s)?(a="",null!=p&&(a=p.replace(N,"$&/")+"/"),e(s,o,a,"",function(e){return e})):null!=s&&(T(s)&&(l=s,c=a+(null==s.key||t&&t.key===s.key?"":(""+s.key).replace(N,"$&/")+"/")+p,s=E(l.type,c,l.props)),o.push(s)),1;p=0;var h=""===i?".":i+":";if(k(t))for(var g=0;g<t.length;g++)d=h+I(i=t[g],g),p+=e(i,o,a,d,s);else if("function"==typeof(g=null===(u=t)||"object"!=typeof u?null:"function"==typeof(u=m&&u[m]||u["@@iterator"])?u:null))for(t=g.call(t),g=0;!(i=t.next()).done;)d=h+I(i=i.value,g++),p+=e(i,o,a,d,s);else if("object"===d){if("function"==typeof t.then)return e(function(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch("string"==typeof e.status?e.then(j,j):(e.status="pending",e.then(function(t){"pending"===e.status&&(e.status="fulfilled",e.value=t)},function(t){"pending"===e.status&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}(t),o,a,i,s);throw Error("Objects are not valid as a React child (found: "+("[object Object]"===(o=String(t))?"object with keys {"+Object.keys(t).join(", ")+"}":o)+"). If you meant to render a collection of children, use an array instead.")}return p}(e,a,"","",function(e){return t.call(o,e,i++)}),a}function R(e){if(-1===e._status){var t=(0,e._result)();t.then(function(r){(0===e._status||-1===e._status)&&(e._status=1,e._result=r,void 0===t.status&&(t.status="fulfilled",t.value=r))},function(r){(0===e._status||-1===e._status)&&(e._status=2,e._result=r,void 0===t.status&&(t.status="rejected",t.reason=r))}),-1===e._status&&(e._status=0,e._result=t)}if(1===e._status)return e._result.default;throw e._result}var P="function"==typeof reportError?reportError:function(e){if("object"==typeof window&&"function"==typeof window.ErrorEvent){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:"object"==typeof e&&null!==e&&"string"==typeof e.message?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if("object"==typeof process&&"function"==typeof process.emit)return void process.emit("uncaughtException",e);console.error(e)};function L(e){var t=S.T,r={};r.types=null!==t?t.types:null,S.T=r;try{var n=e(),o=S.S;null!==o&&o(r,n),"object"==typeof n&&null!==n&&"function"==typeof n.then&&n.then(j,P)}catch(e){P(e)}finally{null!==t&&null!==r.types&&(t.types=r.types),S.T=t}}function O(e){var t=S.T;if(null!==t){var r=t.types;null===r?t.types=[e]:-1===r.indexOf(e)&&r.push(e)}else L(O.bind(null,e))}t.Activity=p,t.Children={map:z,forEach:function(e,t,r){z(e,function(){t.apply(this,arguments)},r)},count:function(e){var t=0;return z(e,function(){t++}),t},toArray:function(e){return z(e,function(e){return e})||[]},only:function(e){if(!T(e))throw Error("React.Children.only expected to receive a single React element child.");return e}},t.Component=y,t.Fragment=o,t.Profiler=i,t.PureComponent=w,t.StrictMode=a,t.Suspense=u,t.ViewTransition=h,t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=S,t.__COMPILER_RUNTIME={__proto__:null,c:function(e){return S.H.useMemoCache(e)}},t.addTransitionType=O,t.cache=function(e){return function(){return e.apply(null,arguments)}},t.cacheSignal=function(){return null},t.cloneElement=function(e,t,r){if(null==e)throw Error("The argument must be a React element, but you passed "+e+".");var n=v({},e.props),o=e.key;if(null!=t)for(a in void 0!==t.key&&(o=""+t.key),t)C.call(t,a)&&"key"!==a&&"__self"!==a&&"__source"!==a&&("ref"!==a||void 0!==t.ref)&&(n[a]=t[a]);var a=arguments.length-2;if(1===a)n.children=r;else if(1<a){for(var i=Array(a),s=0;s<a;s++)i[s]=arguments[s+2];n.children=i}return E(e.type,o,n)},t.createContext=function(e){return(e={$$typeof:l,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null}).Provider=e,e.Consumer={$$typeof:s,_context:e},e},t.createElement=function(e,t,r){var n,o={},a=null;if(null!=t)for(n in void 0!==t.key&&(a=""+t.key),t)C.call(t,n)&&"key"!==n&&"__self"!==n&&"__source"!==n&&(o[n]=t[n]);var i=arguments.length-2;if(1===i)o.children=r;else if(1<i){for(var s=Array(i),l=0;l<i;l++)s[l]=arguments[l+2];o.children=s}if(e&&e.defaultProps)for(n in i=e.defaultProps)void 0===o[n]&&(o[n]=i[n]);return E(e,a,o)},t.createRef=function(){return{current:null}},t.forwardRef=function(e){return{$$typeof:c,render:e}},t.isValidElement=T,t.lazy=function(e){return{$$typeof:f,_payload:{_status:-1,_result:e},_init:R}},t.memo=function(e,t){return{$$typeof:d,type:e,compare:void 0===t?null:t}},t.startTransition=L,t.unstable_useCacheRefresh=function(){return S.H.useCacheRefresh()},t.use=function(e){return S.H.use(e)},t.useActionState=function(e,t,r){return S.H.useActionState(e,t,r)},t.useCallback=function(e,t){return S.H.useCallback(e,t)},t.useContext=function(e){return S.H.useContext(e)},t.useDebugValue=function(){},t.useDeferredValue=function(e,t){return S.H.useDeferredValue(e,t)},t.useEffect=function(e,t){return S.H.useEffect(e,t)},t.useEffectEvent=function(e){return S.H.useEffectEvent(e)},t.useId=function(){return S.H.useId()},t.useImperativeHandle=function(e,t,r){return S.H.useImperativeHandle(e,t,r)},t.useInsertionEffect=function(e,t){return S.H.useInsertionEffect(e,t)},t.useLayoutEffect=function(e,t){return S.H.useLayoutEffect(e,t)},t.useMemo=function(e,t){return S.H.useMemo(e,t)},t.useOptimistic=function(e,t){return S.H.useOptimistic(e,t)},t.useReducer=function(e,t,r){return S.H.useReducer(e,t,r)},t.useRef=function(e){return S.H.useRef(e)},t.useState=function(e){return S.H.useState(e)},t.useSyncExternalStore=function(e,t,r){return S.H.useSyncExternalStore(e,t,r)},t.useTransition=function(){return S.H.useTransition()},t.version="19.3.0-canary-278794d7-20261002"},"./dist/compiled/react/compiler-runtime.js"(e,t,r){"use strict";e.exports=r("./dist/compiled/react/cjs/react-compiler-runtime.production.js")},"./dist/compiled/react/index.js"(e,t,r){"use strict";e.exports=r("./dist/compiled/react/cjs/react.production.js")},"./dist/compiled/react/jsx-runtime.js"(e,t,r){"use strict";e.exports=r("./dist/compiled/react/cjs/react-jsx-runtime.production.js")},"./dist/compiled/scheduler/cjs/scheduler.production.js"(e,t){"use strict";function r(e,t){var r=e.length;for(e.push(t);0<r;){var n=r-1>>>1,o=e[n];if(0<a(o,t))e[n]=t,e[r]=o,r=n;else break}}function n(e){return 0===e.length?null:e[0]}function o(e){if(0===e.length)return null;var t=e[0],r=e.pop();if(r!==t){e[0]=r;for(var n=0,o=e.length,i=o>>>1;n<i;){var s=2*(n+1)-1,l=e[s],c=s+1,u=e[c];if(0>a(l,r))c<o&&0>a(u,l)?(e[n]=u,e[c]=r,n=c):(e[n]=l,e[s]=r,n=s);else if(c<o&&0>a(u,r))e[n]=u,e[c]=r,n=c;else break}}return t}function a(e,t){var r=e.sortIndex-t.sortIndex;return 0!==r?r:e.id-t.id}if(t.unstable_now=void 0,"object"==typeof performance&&"function"==typeof performance.now){var i,s=performance;t.unstable_now=function(){return s.now()}}else{var l=Date,c=l.now();t.unstable_now=function(){return l.now()-c}}var u=[],d=[],f=1,p=null,h=3,m=!1,g=!1,v=!1,x=!1,y="function"==typeof setTimeout?setTimeout:null,b="function"==typeof clearTimeout?clearTimeout:null,w="undefined"!=typeof setImmediate?setImmediate:null;function _(e){for(var t=n(d);null!==t;){if(null===t.callback)o(d);else if(t.startTime<=e)o(d),t.sortIndex=t.expirationTime,r(u,t);else break;t=n(d)}}function k(e){if(v=!1,_(e),!g)if(null!==n(u))g=!0,j||(j=!0,i());else{var t=n(d);null!==t&&R(k,t.startTime-e)}}var j=!1,S=-1,C=5,E=-1;function T(){return!!x||!(t.unstable_now()-E<C)}function N(){if(x=!1,j){var e=t.unstable_now();E=e;var r=!0;try{e:{g=!1,v&&(v=!1,b(S),S=-1),m=!0;var a=h;try{t:{for(_(e),p=n(u);null!==p&&!(p.expirationTime>e&&T());){var s=p.callback;if("function"==typeof s){p.callback=null,h=p.priorityLevel;var l=s(p.expirationTime<=e);if(e=t.unstable_now(),"function"==typeof l){p.callback=l,_(e),r=!0;break t}p===n(u)&&o(u),_(e)}else o(u);p=n(u)}if(null!==p)r=!0;else{var c=n(d);null!==c&&R(k,c.startTime-e),r=!1}}break e}finally{p=null,h=a,m=!1}}}finally{r?i():j=!1}}}if("function"==typeof w)i=function(){w(N)};else if("undefined"!=typeof MessageChannel){var I=new MessageChannel,z=I.port2;I.port1.onmessage=N,i=function(){z.postMessage(null)}}else i=function(){y(N,0)};function R(e,r){S=y(function(){e(t.unstable_now())},r)}t.unstable_IdlePriority=5,t.unstable_ImmediatePriority=1,t.unstable_LowPriority=4,t.unstable_NormalPriority=3,t.unstable_Profiling=null,t.unstable_UserBlockingPriority=2,t.unstable_cancelCallback=function(e){e.callback=null},t.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):C=0<e?Math.floor(1e3/e):5},t.unstable_getCurrentPriorityLevel=function(){return h},t.unstable_next=function(e){switch(h){case 1:case 2:case 3:var t=3;break;default:t=h}var r=h;h=t;try{return e()}finally{h=r}},t.unstable_requestPaint=function(){x=!0},t.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var r=h;h=e;try{return t()}finally{h=r}},t.unstable_scheduleCallback=function(e,o,a){var s=t.unstable_now();switch(a="object"==typeof a&&null!==a&&"number"==typeof(a=a.delay)&&0<a?s+a:s,e){case 1:var l=-1;break;case 2:l=250;break;case 5:l=0x3fffffff;break;case 4:l=1e4;break;default:l=5e3}return l=a+l,e={id:f++,callback:o,priorityLevel:e,startTime:a,expirationTime:l,sortIndex:-1},a>s?(e.sortIndex=a,r(d,e),null===n(u)&&e===n(d)&&(v?(b(S),S=-1):v=!0,R(k,a-s))):(e.sortIndex=l,r(u,e),g||m||(g=!0,j||(j=!0,i()))),e},t.unstable_shouldYield=T,t.unstable_wrapCallback=function(e){var t=h;return function(){var r=h;h=t;try{return e.apply(this,arguments)}finally{h=r}}}},"./dist/compiled/scheduler/index.js"(e,t,r){"use strict";e.exports=r("./dist/compiled/scheduler/cjs/scheduler.production.js")},"./dist/compiled/stacktrace-parser/stack-trace-parser.cjs.js"(e){(()=>{"use strict";"undefined"!=typeof __nccwpck_require__&&(__nccwpck_require__.ab="//");var t,r,n,o,a,i,s,l,c={};Object.defineProperty(c,"__esModule",{value:!0}),t="<unknown>",r=/^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|webpack-internal|rsc|about|turbopack|<anonymous>|\/|[a-z]:\\|\\\\).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,n=/\((\S*)(?::(\d+))(?::(\d+))\)/,o=/^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|webpack-internal|rsc|about|turbopack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i,a=/^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|webpack-internal|rsc|about|turbopack|resource|\[native).*?|[^@]*bundle)(?::(\d+))?(?::(\d+))?\s*$/i,i=/(\S+) line (\d+)(?: > eval line \d+)* > eval/i,s=/^\s*([^@]*)(?:\((.*?)\))?@(\S.*?):(\d+)(?::(\d+))?\s*$/i,l=/^\s*at (?:((?:\[object object\])?[^\\/]+(?: \[as \S+\])?) )?\(?(.*?):(\d+)(?::(\d+))?\)?\s*$/i,c.parse=function(e){return e.split("\n").reduce(function(e,c){var u,d,f,p,h,m,g=function(e){var o=r.exec(e);if(!o)return null;var a=o[2]&&0===o[2].indexOf("native"),i=o[2]&&0===o[2].indexOf("eval"),s=n.exec(o[2]);return i&&null!=s&&(o[2]=s[1],o[3]=s[2],o[4]=s[3]),{file:a?null:o[2],methodName:o[1]||t,arguments:a?[o[2]]:[],lineNumber:o[3]?+o[3]:null,column:o[4]?+o[4]:null}}(c)||(u=c,(d=o.exec(u))?{file:d[2],methodName:d[1]||t,arguments:[],lineNumber:+d[3],column:d[4]?+d[4]:null}:null)||function(e){var r=a.exec(e);if(!r)return null;var n=r[3]&&r[3].indexOf(" > eval")>-1,o=i.exec(r[3]);return n&&null!=o&&(r[3]=o[1],r[4]=o[2],r[5]=null),{file:r[3],methodName:r[1]||t,arguments:r[2]?r[2].split(","):[],lineNumber:r[4]?+r[4]:null,column:r[5]?+r[5]:null}}(c)||(f=c,(p=l.exec(f))?{file:p[2],methodName:p[1]||t,arguments:[],lineNumber:+p[3],column:p[4]?+p[4]:null}:null)||(h=c,(m=s.exec(h))?{file:m[3],methodName:m[1]||t,arguments:[],lineNumber:+m[4],column:m[5]?+m[5]:null}:null);return g&&e.push(g),e},[])},e.exports=c})()},"./dist/compiled/strip-ansi/index.js"(e){(()=>{"use strict";var t={371:e=>{e.exports=({onlyFirst:e=!1}={})=>RegExp("[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)|(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))",e?void 0:"g")},173:(e,t,r)=>{let n=r(371);e.exports=e=>"string"==typeof e?e.replace(n(),""):e}},r={};function n(e){var o=r[e];if(void 0!==o)return o.exports;var a=r[e]={exports:{}},i=!0;try{t[e](a,a.exports,n),i=!1}finally{i&&delete r[e]}return a.exports}n.ab="//",e.exports=n(173)})()},"./src/build/webpack/loaders/devtool/devtool-style-inject.js"(e){function t(){let e=window._nextjsDevtoolsStyleCache;if(e.cachedShadowRoot)return e.cachedShadowRoot;let t=document.querySelector("nextjs-portal"),r=t?.shadowRoot||null;return r&&(e.cachedShadowRoot=r),r}function r(e,t){let r=window._nextjsDevtoolsStyleCache;r.lastInsertedElement?r.lastInsertedElement.nextSibling?t.insertBefore(e,r.lastInsertedElement.nextSibling):t.appendChild(e):t.insertBefore(e,t.firstChild),r.lastInsertedElement=e}function n(){let e=window._nextjsDevtoolsStyleCache,n=t();n&&(e.pendingElements.forEach(e=>{r(e,n)}),e.pendingElements=[])}"undefined"!=typeof window&&(window._nextjsDevtoolsStyleCache=window._nextjsDevtoolsStyleCache||{pendingElements:[],isObserving:!1,lastInsertedElement:null,cachedShadowRoot:null}),e.exports=function(e){e.setAttribute("data-nextjs-dev-tool-style","true");let o=t();o?r(e,o):(window._nextjsDevtoolsStyleCache.pendingElements.push(e),function(){let e=window._nextjsDevtoolsStyleCache;if(e.isObserving)return;if(e.isObserving=!0,t())return n();let r=new MutationObserver(o=>{if(0!==o.length){for(let a of o)if(0!==a.addedNodes.length)for(let o of a.addedNodes){if(o.nodeType!==Node.ELEMENT_NODE)continue;let a=null;if("SCRIPT"===o.tagName&&o.getAttribute("data-nextjs-dev-overlay")?a=o.firstChild:"NEXTJS-PORTAL"===o.tagName&&(a=o),a){let o=()=>{t()?(n(),r.disconnect(),e.isObserving=!1):setTimeout(o,20)};o();return}}}});r.observe(document.body,{childList:!0,subtree:!0})}())}},"./src/next-devtools/dev-overlay-ux.ts"(e,t,r){"use strict";r.r(t),r.d(t,{DevOverlay:()=>l_,FontStyles:()=>N});var n,o,a,i,s,l,c=r("../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.23__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js"),u=r.n(c),d=r("../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.23__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/styleDomAPI.js"),f=r.n(d),p=r("./src/build/webpack/loaders/devtool/devtool-style-inject.js"),h=r.n(p),m=r("../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.23__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js"),g=r.n(m),v=r("../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.23__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/insertStyleElement.js"),x=r.n(v),y=r("../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.23__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/styleTagTransform.js"),b=r.n(y),w=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/global.css"),_={};_.styleTagTransform=b(),_.setAttributes=g(),_.insert=h(),_.domAPI=f(),_.insertStyleElement=x(),u()(w.A,_),w.A&&w.A.locals&&w.A.locals;var k=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/toast/style.css"),j={};j.styleTagTransform=b(),j.setAttributes=g(),j.insert=h(),j.domAPI=f(),j.insertStyleElement=x(),u()(k.A,j),k.A&&k.A.locals&&k.A.locals;var S=r("./dist/compiled/react/compiler-runtime.js"),C=r("./src/next-devtools/dev-overlay/utils/css.ts"),E=r("./dist/compiled/react/index.js"),T=r.t(E,2);let N=()=>{let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=[],t[0]=e):e=t[0],(0,E.useInsertionEffect)(I,e),null};function I(){let e=document.createElement("style");return e.textContent=(0,C.A)`
      /* latin-ext */
      @font-face {
        font-family: '__nextjs-Geist';
        font-style: normal;
        font-weight: 400 600;
        font-display: swap;
        src: url(/__nextjs_font/geist-latin-ext.woff2) format('woff2');
        unicode-range:
          U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF,
          U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020,
          U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
      }
      /* latin-ext */
      @font-face {
        font-family: '__nextjs-Geist Mono';
        font-style: normal;
        font-weight: 400 600;
        font-display: swap;
        src: url(/__nextjs_font/geist-mono-latin-ext.woff2) format('woff2');
        unicode-range:
          U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF,
          U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020,
          U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
      }
      /* latin */
      @font-face {
        font-family: '__nextjs-Geist';
        font-style: normal;
        font-weight: 400 600;
        font-display: swap;
        src: url(/__nextjs_font/geist-latin.woff2) format('woff2');
        unicode-range:
          U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC,
          U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193,
          U+2212, U+2215, U+FEFF, U+FFFD;
      }
      /* latin */
      @font-face {
        font-family: '__nextjs-Geist Mono';
        font-style: normal;
        font-weight: 400 600;
        font-display: swap;
        src: url(/__nextjs_font/geist-mono-latin.woff2) format('woff2');
        unicode-range:
          U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC,
          U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193,
          U+2212, U+2215, U+FEFF, U+FFFD;
      }
    `,document.head.appendChild(e),()=>{document.head.removeChild(e)}}var z=r("./dist/compiled/react/jsx-runtime.js"),R=r("./dist/compiled/react-dom/index.js"),P=r("./src/next-devtools/dev-overlay.browser.tsx");function L(e){let t,r=(0,S.c)(3),{children:n}=e,{shadowRoot:o}=(0,P.OS)();return r[0]!==n||r[1]!==o?(t=(0,R.createPortal)(n,o),r[0]=n,r[1]=o,r[2]=t):t=r[2],t}var O=r("./src/next-devtools/dev-overlay/components/code-frame/code-frame.tsx"),M=r("./src/next-devtools/dev-overlay/components/dialog/index.ts"),A=r("./src/next-devtools/dev-overlay/components/errors/error-overlay-layout/error-overlay-layout.tsx"),D=r("./src/next-devtools/dev-overlay/components/errors/error-overlay-pagination/error-overlay-pagination.tsx");let F=(0,C.A)`
  [data-nextjs-dialog-overlay] {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    /* secondary z-index, -1 than toast z-index */
    z-index: 2147483646;

    display: flex;
    align-content: center;
    align-items: center;
    flex-direction: column;
    padding: 10vh 15px 0;
    /* color schemes we handle. Every other scheme the UA would need to overwrite */
    color-scheme: dark light;
  }

  @media (max-height: 812px) {
    [data-nextjs-dialog-overlay] {
      padding: 15px 15px 0;
    }
  }

  [data-nextjs-dialog-backdrop] {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: var(--color-backdrop);
    backdrop-filter: blur(10px);
    pointer-events: all;
    z-index: -1;
  }

  [data-nextjs-dialog-backdrop-fixed] {
    cursor: not-allowed;
    -webkit-backdrop-filter: blur(8px);
    backdrop-filter: blur(8px);
  }
`;var $=r("./dist/compiled/anser/index.js"),U=r.n($),Z=r("./src/next-devtools/dev-overlay/components/hot-linked-text/index.tsx"),q=r("./src/next-devtools/dev-overlay/utils/use-open-in-editor.ts");function B(e){let t,r,n,o=(0,S.c)(9),{file:a,location:i}=e,s=i?.line??1,l=i?.column??1;o[0]!==a||o[1]!==s||o[2]!==l?(t={file:a,line1:s,column1:l},o[0]=a,o[1]=s,o[2]=l,o[3]=t):t=o[3];let c=(0,q.Y)(t),u=i?`:${i.line}:${i.column}`:null;return o[4]===Symbol.for("react.memo_cache_sentinel")?(r=(0,z.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,z.jsx)("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"}),(0,z.jsx)("polyline",{points:"15 3 21 3 21 9"}),(0,z.jsx)("line",{x1:"10",y1:"14",x2:"21",y2:"3"})]}),o[4]=r):r=o[4],o[5]!==a||o[6]!==c||o[7]!==u?(n=(0,z.jsxs)("div",{"data-with-open-in-editor-link":!0,"data-with-open-in-editor-link-import-trace":!0,role:"link",onClick:c,title:"Click to open in your editor",children:[a,u,r]}),o[5]=a,o[6]=c,o[7]=u,o[8]=n):n=o[8],n}let V=`
  [data-with-open-in-editor-link] svg {
    width: auto;
    height: var(--size-14);
    margin-left: 8px;
  }
  [data-with-open-in-editor-link] {
    cursor: pointer;
  }
  [data-with-open-in-editor-link]:hover {
    text-decoration: underline dotted;
  }
  [data-with-open-in-editor-link-import-trace] {
    margin-left: 16px;
  }
`;var H=r("./src/next-devtools/dev-overlay/icons/external.tsx"),W=r("./src/next-devtools/shared/stack-frame.ts"),G=r("./src/next-devtools/dev-overlay/icons/file.tsx");let K=function(e){let t,r,n,o,a,i,s,l,c,u,d,f,p,h,m,g,v,x,y=(0,S.c)(42),{content:b}=e;if(y[0]!==b){let e,r,n;r=function(e){let t=e.shift();if(!t)return null;let[r,n,o]=t.split(":",3),a=Number(n),i=Number(o),s=!Number.isNaN(a)&&!Number.isNaN(i);return{fileName:s?r:t,location:s?{line1:a,column1:i}:void 0}}(e=b.split("\n")),n=function(e){if(e.some(e=>/ReactServerComponentsError:/.test(e))||e.some(e=>/Import trace for requested module:/.test(e))){let t=[];for(;/.+\..+/.test(e[e.length-1])&&!e[e.length-1].includes(":");){let r=e.pop().trim();t.unshift(r)}return t}return[]}(e),t={file:r,source:e.join("\n"),importTraceFiles:n},y[0]=b,y[1]=t}else t=y[1];let{file:w,source:_,importTraceFiles:k}=t;y[2]!==_?(r=U().ansiToJson(_,{json:!0,use_classes:!0,remove_empty:!0}),y[2]=_,y[3]=r):r=y[3];let j=r,C=w?.fileName,E=w?.location?.line1??1,T=w?.location?.column1??1;y[4]!==C||y[5]!==E||y[6]!==T?(n={file:C,line1:E,column1:T},y[4]=C,y[5]=E,y[6]=T,y[7]=n):n=y[7];let N=(0,q.Y)(n),I=w?.fileName??null;if(y[8]!==w?.location?.column1||y[9]!==w?.location?.line1||y[10]!==I){let e={file:I,methodName:"",arguments:[],line1:w?.location?.line1??null,column1:w?.location?.column1??null},t=e?.file?.split(".").pop();s=!0,i="code-frame-header",o="code-frame-link",a=(0,z.jsx)("span",{className:"code-frame-icon",children:(0,z.jsx)(G.o,{lang:t})}),l=!0,c=(0,W.Q)(e),y[8]=w?.location?.column1,y[9]=w?.location?.line1,y[10]=I,y[11]=o,y[12]=a,y[13]=i,y[14]=s,y[15]=l,y[16]=c}else o=y[11],a=y[12],i=y[13],s=y[14],l=y[15],c=y[16];return y[17]!==l||y[18]!==c?(u=(0,z.jsx)("span",{"data-text":l,children:c}),y[17]=l,y[18]=c,y[19]=u):u=y[19],y[20]===Symbol.for("react.memo_cache_sentinel")?(d=(0,z.jsx)("span",{className:"code-frame-icon","data-icon":"right",children:(0,z.jsx)(H.X,{width:16,height:16})}),y[20]=d):d=y[20],y[21]!==N?(f=(0,z.jsx)("button",{"aria-label":"Open in editor","data-with-open-in-editor-link-source-file":!0,onClick:N,children:d}),y[21]=N,y[22]=f):f=y[22],y[23]!==o||y[24]!==a||y[25]!==u||y[26]!==f?(p=(0,z.jsxs)("div",{className:o,children:[a,u,f]}),y[23]=o,y[24]=a,y[25]=u,y[26]=f,y[27]=p):p=y[27],y[28]!==i||y[29]!==p?(h=(0,z.jsx)("div",{className:i,children:p}),y[28]=i,y[29]=p,y[30]=h):h=y[30],y[31]!==j?(m=j.map(X),y[31]=j,y[32]=m):m=y[32],y[33]!==k?(g=k.map(Q),y[33]=k,y[34]=g):g=y[34],y[35]!==m||y[36]!==g?(v=(0,z.jsx)("pre",{className:"code-frame-pre",children:(0,z.jsxs)("div",{className:"code-frame-lines",children:[m,g]})}),y[35]=m,y[36]=g,y[37]=v):v=y[37],y[38]!==s||y[39]!==h||y[40]!==v?(x=(0,z.jsxs)("div",{"data-nextjs-codeframe":s,children:[h,v]}),y[38]=s,y[39]=h,y[40]=v,y[41]=x):x=y[41],x},Y=`
  [data-nextjs-terminal]::selection,
  [data-nextjs-terminal] *::selection {
    background-color: var(--color-ansi-selection);
  }

  [data-nextjs-terminal] * {
    color: inherit;
    background-color: transparent;
    font-family: var(--font-stack-monospace);
  }

  [data-nextjs-terminal] > div > p {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
    margin: 0;
  }
  [data-nextjs-terminal] > div > p:hover {
    text-decoration: underline dotted;
  }
  [data-nextjs-terminal] div > pre {
    overflow: hidden;
    display: inline-block;
  }
`;function X(e,t){return(0,z.jsx)("span",{style:{color:e.fg?`var(--color-${e.fg})`:void 0,..."bold"===e.decoration?{fontWeight:500}:"italic"===e.decoration?{fontStyle:"italic"}:void 0},children:(0,z.jsx)(Z.E,{text:e.content})},`terminal-entry-${t}`)}function Q(e){return(0,z.jsx)(B,{isSourceFile:!1,file:e},e)}var J=r("./src/next-devtools/dev-overlay/components/version-staleness-info/version-staleness-info.tsx"),ee=r("./dist/compiled/strip-ansi/index.js"),et=r.n(ee);let er=function(e){let t,r,n,o,a,i,s,l=(0,S.c)(19);l[0]!==e?({message:t,...r}=e,l[0]=e,l[1]=t,l[2]=r):(t=l[1],r=l[2]),l[3]!==t?(n=Error(t),l[3]=t,l[4]=n):n=l[4];let c=n;if(l[5]!==t){let e;e=t.split("\n"),o=et()(e[1]||"").replace(/^Error: /,"")||"Failed to compile",l[5]=t,l[6]=o}else o=l[6];let u=o;l[7]!==u||l[8]!==t||l[9]!==r.versionInfo.installed?(a=async()=>{let e=[];if(e.push("## Error Type\nBuild Error"),u&&e.push(`## Error Message
${u}`),t){let r=et()(t);e.push(`## Build Output
${r}`)}return`${e.join("\n\n")}

Next.js version: ${r.versionInfo.installed} (${process.env.__NEXT_BUNDLER})
`},l[7]=u,l[8]=t,l[9]=r.versionInfo.installed,l[10]=a):a=l[10];let d=a;return l[11]!==t?(i=(0,z.jsx)(K,{content:t}),l[11]=t,l[12]=i):i=l[12],l[13]!==c||l[14]!==u||l[15]!==d||l[16]!==r||l[17]!==i?(s=(0,z.jsx)(A.V,{errorType:"Build Error",errorMessage:u,onClose:en,error:c,generateErrorInfo:d,...r,children:i}),l[13]=c,l[14]=u,l[15]=d,l[16]=r,l[17]=i,l[18]=s):s=l[18],s};function en(){}var eo=r("./src/next-devtools/dev-overlay/container/errors.tsx"),ea=r("./src/next-devtools/dev-overlay/container/runtime-error/index.tsx"),ei=r("./src/next-devtools/dev-overlay/components/copy-button/index.tsx"),es=r("./src/next-devtools/dev-overlay/components/call-stack-frame/call-stack-frame.tsx"),el=r("./src/next-devtools/dev-overlay/components/errors/environment-name-label/environment-name-label.tsx");function ec(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",fill:"none",children:(0,z.jsx)("path",{fill:"currentColor",fillRule:"evenodd",d:"m.191 2.063.56.498 13.5 12 .561.498.997-1.121-.56-.498-1.81-1.608 2.88-3.342v-.98l-3.204-3.72C10.645.923 6.365.686 3.594 3.08L1.748 1.44 1.188.94.19 2.063ZM14.761 8l-2.442 2.836-1.65-1.466a3.001 3.001 0 0 0-4.342-3.86l-1.6-1.422a5.253 5.253 0 0 1 7.251.682L14.76 8ZM7.526 6.576l1.942 1.727a1.499 1.499 0 0 0-1.942-1.727Zm-7.845.935 1.722-2 1.137.979L1.24 8l2.782 3.23A5.25 5.25 0 0 0 9.9 12.703l.54 1.4a6.751 6.751 0 0 1-7.555-1.892L-.318 8.49v-.98Z",clipRule:"evenodd"})}),t[0]=e):e=t[0],e}var eu=r("./src/next-devtools/dev-overlay/shared.ts");function ed(){let e,t,r=(0,S.c)(2);return r[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("g",{clipPath:"url(#light_icon_clip_path)",children:(0,z.jsx)("path",{fill:"currentColor",fillRule:"evenodd",d:"M8.75.75V0h-1.5v2h1.5V.75ZM3.26 4.32l-.53-.53-.354-.353-.53-.53 1.06-1.061.53.53.354.354.53.53-1.06 1.06Zm8.42-1.06.53-.53.353-.354.53-.53 1.061 1.06-.53.53-.354.354-.53.53-1.06-1.06ZM8 11.25a3.25 3.25 0 1 0 0-6.5 3.25 3.25 0 0 0 0 6.5Zm0 1.5a4.75 4.75 0 1 0 0-9.5 4.75 4.75 0 0 0 0 9.5Zm6-5.5h2v1.5h-2v-1.5Zm-13.25 0H0v1.5h2v-1.5H.75Zm1.62 5.32-.53.53 1.06 1.06.53-.53.354-.353.53-.53-1.06-1.061-.53.53-.354.354Zm10.2 1.06.53.53 1.06-1.06-.53-.53-.354-.354-.53-.53-1.06 1.06.53.53.353.354ZM8.75 14v2h-1.5v-2h1.5Z",clipRule:"evenodd"})}),r[0]=e):e=r[0],r[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"16",viewBox:"0 0 16 16",fill:"none",children:[e,(0,z.jsx)("defs",{children:(0,z.jsx)("clipPath",{id:"light_icon_clip_path",children:(0,z.jsx)("path",{fill:"currentColor",d:"M0 0h16v16H0z"})})})]}),r[1]=t):t=r[1],t}function ef(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{"data-testid":"geist-icon",height:"16",strokeLinejoin:"round",viewBox:"0 0 16 16",width:"16",children:(0,z.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M1.5 8.00005C1.5 5.53089 2.99198 3.40932 5.12349 2.48889C4.88136 3.19858 4.75 3.95936 4.75 4.7501C4.75 8.61609 7.88401 11.7501 11.75 11.7501C11.8995 11.7501 12.048 11.7454 12.1953 11.7361C11.0955 13.1164 9.40047 14.0001 7.5 14.0001C4.18629 14.0001 1.5 11.3138 1.5 8.00005ZM6.41706 0.577759C2.78784 1.1031 0 4.22536 0 8.00005C0 12.1422 3.35786 15.5001 7.5 15.5001C10.5798 15.5001 13.2244 13.6438 14.3792 10.9921L13.4588 9.9797C12.9218 10.155 12.3478 10.2501 11.75 10.2501C8.71243 10.2501 6.25 7.78767 6.25 4.7501C6.25 3.63431 6.58146 2.59823 7.15111 1.73217L6.41706 0.577759ZM13.25 1V1.75V2.75L14.25 2.75H15V4.25H14.25H13.25V5.25V6H11.75V5.25V4.25H10.75L10 4.25V2.75H10.75L11.75 2.75V1.75V1H13.25Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function ep(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{width:"16",height:"16",strokeLinejoin:"round",children:(0,z.jsx)("path",{fill:"currentColor",fillRule:"evenodd",d:"M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v8.5a1 1 0 0 1-1 1H8.75v3h1.75V16h-5v-1.5h1.75v-3H1a1 1 0 0 1-1-1V2Zm1.5.5V10h13V2.5h-13Z",clipRule:"evenodd"})}),t[0]=e):e=t[0],e}let eh=["Meta","Control","Ctrl","Alt","Option","Shift"];function em(e){let t,r,n,o,a,i,s,l,c,u,d,f,p,h=(0,S.c)(33),{value:m,onChange:g}=e,[v,x]=(0,E.useState)(!0),[y,b]=(0,E.useState)(!1);h[0]!==m?(t=m??[],h[0]=m,h[1]=t):t=h[1];let[w,_]=(0,E.useState)(t),[k,j]=(0,E.useState)(!1),C=(0,E.useRef)(null),T=(0,E.useRef)(null),N=!!m||w.length>0;h[2]!==g||h[3]!==v||h[4]!==y?(r=function(e){if(e.target!==T.current||"Tab"===e.key)return;C.current&&clearTimeout(C.current),y||b(!0),v&&(_([]),x(!1));let t=function(e){C.current=window.setTimeout(()=>{j(!0),g(e.join("+")),C.current=window.setTimeout(()=>{b(!1)},1e3)},180)};e.preventDefault(),e.stopPropagation(),_(r=>{if(r.includes(e.code)||r.includes(e.key))return r;if(!eh.includes(e.key)){let n=r.findIndex(ex);if(-1!==n){let o=[...r];return o[n]=e.code,t(o),o}let o=[...r,e.code];return t(o),o}let n=[...r],o=eh.indexOf(e.key),a=0;for(let e=0;e<n.length;e++)if(eh.includes(n[e])){if(o<eh.indexOf(n[e])){a=e;break}a=e+1}else break;return n.splice(a,0,e.key),t(n),n})},h[2]=g,h[3]=v,h[4]=y,h[5]=r):r=h[5];let I=r;h[6]!==g?(n=function(){T.current?.focus(),_([]),j(!1),setTimeout(()=>{b(!0)}),g(null)},h[6]=g,h[7]=n):n=h[7];let R=n;h[8]===Symbol.for("react.memo_cache_sentinel")?(o=function(){j(!1),b(!1),x(!0)},h[8]=o):o=h[8];let P=o;h[9]===Symbol.for("react.memo_cache_sentinel")?(a=function(){C.current&&clearTimeout(C.current),b(!0),T.current?.focus()},h[9]=a):a=h[9];let L=a;h[10]!==N||h[11]!==w?(i=N?(0,z.jsx)("div",{className:"shortcut-recorder-keys",children:w.map(ev)}):"Record Shortcut",h[10]=N,h[11]=w,h[12]=i):i=h[12],h[13]!==R||h[14]!==N?(s=N&&(0,z.jsx)("div",{className:"shortcut-recorder-clear-button",role:"button",onClick:R,onFocus:eg,onKeyDown:e=>{("Enter"===e.key||" "===e.key)&&(R(),e.stopPropagation())},"aria-label":"Clear shortcut",tabIndex:0,children:(0,z.jsx)(e_,{})}),h[13]=R,h[14]=N,h[15]=s):s=h[15],h[16]!==I||h[17]!==N||h[18]!==i||h[19]!==s?(l=(0,z.jsxs)("button",{className:"shortcut-recorder-button",ref:T,onClick:L,onFocus:L,onBlur:P,onKeyDown:I,"data-has-shortcut":N,"data-shortcut-recorder":"true",children:[i,s]}),h[16]=I,h[17]=N,h[18]=i,h[19]=s,h[20]=l):l=h[20],h[21]!==k?(c=(0,z.jsx)("div",{className:"shortcut-recorder-status-icon","data-success":k}),h[21]=k,h[22]=c):c=h[22];let O=k?"Shortcut set":"Recording";return h[23]!==O||h[24]!==c?(u=(0,z.jsxs)("div",{className:"shortcut-recorder-status",children:[c,O]}),h[23]=O,h[24]=c,h[25]=u):u=h[25],h[26]===Symbol.for("react.memo_cache_sentinel")?(d=(0,z.jsx)(ey,{}),h[26]=d):d=h[26],h[27]!==y||h[28]!==u?(f=(0,z.jsxs)("div",{className:"shortcut-recorder-tooltip","data-show":y,children:[u,d]}),h[27]=y,h[28]=u,h[29]=f):f=h[29],h[30]!==f||h[31]!==l?(p=(0,z.jsxs)("div",{className:"shortcut-recorder",children:[l,f]}),h[30]=f,h[31]=l,h[32]=p):p=h[32],p}function eg(e){return e.stopPropagation()}function ev(e){return(0,z.jsx)(eb,{children:e},e)}function ex(e){return!eh.includes(e)}function ey(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{fill:"none",height:"6",viewBox:"0 0 14 6",width:"14",xmlns:"http://www.w3.org/2000/svg",children:(0,z.jsx)("path",{d:"M13.8284 0H0.17157C0.702003 0 1.21071 0.210714 1.58578 0.585787L5.58578 4.58579C6.36683 5.36684 7.63316 5.36683 8.41421 4.58579L12.4142 0.585786C12.7893 0.210714 13.298 0 13.8284 0Z",fill:"var(--background)"})}),t[0]=e):e=t[0],e}function eb(e){let t,r,n,o,a=(0,S.c)(9),{children:i}=e;a[0]!==i?(t=function(e){switch(e){case"Meta":return(0,z.jsx)(ew,{});case"Alt":case"Option":return"⌥";case"Control":case"Ctrl":return"Ctrl";case"Shift":return"⇧";case"Enter":return"⏎";case"Escape":case"Esc":return"Esc";case" ":case"Space":case"Spacebar":return"Space";case"ArrowUp":return"↑";case"ArrowDown":return"↓";case"ArrowLeft":return"←";case"ArrowRight":return"→";case"Tab":return"Tab";case"Backspace":return"⌫";case"Delete":return"⌦";default:if(1===i.length)return i.toUpperCase();return i}},a[0]=i,a[1]=t):t=a[1];let s=t;if(a[2]!==i||a[3]!==s){let e=s(i);r="string"==typeof e&&1===e.length,n=function(e){if("string"!=typeof e)return e;let t={Minus:"-",Equal:"=",BracketLeft:"[",BracketRight:"]",Backslash:"\\",Semicolon:";",Quote:"'",Comma:",",Period:".",Backquote:"`",Space:" ",Slash:"/",IntlBackslash:"\\"};return t[e]?t[e]:/^Key([A-Z])$/.test(e)?e.replace(/^Key/,""):/^Digit([0-9])$/.test(e)?e.replace(/^Digit/,""):/^Numpad([0-9])$/.test(e)?e.replace(/^Numpad/,""):"NumpadAdd"===e?"+":"NumpadSubtract"===e?"-":"NumpadMultiply"===e?"*":"NumpadDivide"===e?"/":"NumpadDecimal"===e?".":"NumpadEnter"===e?"Enter":e}(e),a[2]=i,a[3]=s,a[4]=r,a[5]=n}else r=a[4],n=a[5];return a[6]!==r||a[7]!==n?(o=(0,z.jsx)("kbd",{"data-symbol":r,children:n}),a[6]=r,a[7]=n,a[8]=o):o=a[8],o}function ew(){let e,t=(0,S.c)(1),r=ej(/^Mac/)||ej(/^iPhone/)||ej(/^iPad/)||ej(/^Mac/)&&navigator.maxTouchPoints>1?"⌘":"Ctrl";return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("span",{style:{minWidth:"1em",display:"inline-block"},children:r}),t[0]=e):e=t[0],e}function e_(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{height:"16",strokeLinejoin:"round",viewBox:"0 0 16 16",width:"16",children:(0,z.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12.4697 13.5303L13 14.0607L14.0607 13L13.5303 12.4697L9.06065 7.99999L13.5303 3.53032L14.0607 2.99999L13 1.93933L12.4697 2.46966L7.99999 6.93933L3.53032 2.46966L2.99999 1.93933L1.93933 2.99999L2.46966 3.53032L6.93933 7.99999L2.46966 12.4697L1.93933 13L2.99999 14.0607L3.53032 13.5303L7.99999 9.06065L12.4697 13.5303Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}let ek=(0,C.A)`
  .shortcut-recorder {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    position: relative;
    font-family: var(--font-stack-sans);

    .shortcut-recorder-button {
      display: flex;
      align-items: center;
      gap: 4px;
      background: transparent;
      border: 1px dashed var(--color-gray-500);
      border-radius: var(--rounded-lg);
      padding: 6px 8px;
      font-weight: 400;
      font-size: var(--size-14);
      color: var(--color-gray-1000);
      transition: border-color 150ms var(--timing-swift);

      &[data-has-shortcut='true'] {
        border: 1px solid var(--color-gray-alpha-400);

        &:hover {
          border-color: var(--color-gray-500);
        }
      }

      &:hover {
        border-color: var(--color-gray-600);
      }

      &::placeholder {
        color: var(--color-gray-900);
      }

      &[data-pristine='false']::placeholder {
        color: transparent;
      }

      &:focus-visible {
        outline: var(--focus-ring);
        outline-offset: -1px;
      }
    }

    kbd {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-family: var(--font-stack-sans);
      background: var(--color-gray-200);
      min-width: 20px;
      height: 20px;
      font-size: 14px;
      border-radius: 4px;
      color: var(--color-gray-1000);

      &[data-symbol='false'] {
        padding: 0 4px;
      }
    }

    .shortcut-recorder-clear-button {
      cursor: pointer;
      color: var(--color-gray-1000);
      width: 20px;
      height: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
      transition: background 150ms var(--timing-swift);

      &:hover {
        background: var(--color-gray-300);
      }

      &:focus-visible {
        outline: var(--focus-ring);
      }

      svg {
        width: 14px;
        height: 14px;
      }
    }
  }

  .shortcut-recorder-keys {
    pointer-events: none;
    user-select: none;
    display: flex;
    align-items: center;
    gap: 2px;
  }

  .shortcut-recorder-tooltip {
    --gap: 8px;
    --background: var(--color-gray-1000);
    background: var(--background);
    color: var(--color-background-100);
    font-size: var(--size-14);
    padding: 4px 8px;
    border-radius: 8px;
    position: absolute;
    bottom: calc(100% + var(--gap));
    text-align: center;
    opacity: 0;
    scale: 0.96;
    white-space: nowrap;
    user-select: none;
    transition:
      opacity 150ms var(--timing-swift),
      scale 150ms var(--timing-swift);

    &[data-show='true'] {
      opacity: 1;
      scale: 1;
    }

    svg {
      position: absolute;
      transform: translateX(-50%);
      bottom: -6px;
      left: 50%;
    }

    .shortcut-recorder-status {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .shortcut-recorder-status-icon {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      flex-shrink: 0;
      background: var(--color-red-700);

      &[data-success='true'] {
        background: var(--color-green-700);
      }
    }
  }
`;function ej(e){return null!=window.navigator?e.test(window.navigator.platform):void 0}var eS=r("./dist/compiled/zod/index.cjs");let eC=eS.z.object({theme:eS.z.enum(["light","dark","system"]).optional(),disableDevIndicator:eS.z.boolean().optional(),devToolsPosition:eS.z.enum(["top-left","top-right","bottom-left","bottom-right"]).optional(),devToolsPanelPosition:eS.z.record(eS.z.string(),eS.z.enum(["top-left","top-right","bottom-left","bottom-right"])).optional(),devToolsPanelSize:eS.z.record(eS.z.string(),eS.z.object({width:eS.z.number(),height:eS.z.number()})).optional(),scale:eS.z.number().optional(),hideShortcut:eS.z.string().nullable().optional(),requestInsights:eS.z.object({showInternal:eS.z.boolean().optional(),verbose:eS.z.boolean().optional()}).optional()}),eE={},eT=null;function eN(){if(0===Object.keys(eE).length)return;let e=JSON.stringify(eE);eE={},fetch("/__nextjs_devtools_config",{method:"POST",headers:{"Content-Type":"application/json"},body:e,keepalive:!0}).catch(t=>{console.warn("[Next.js DevTools] Failed to save config:",{data:e,error:t})})}function eI(e){let t=eC.safeParse(e);t.success?(eE=function e(t,r){if(!r||"object"!=typeof r||Array.isArray(r)||!t||"object"!=typeof t||Array.isArray(t))return r;let n={...t};for(let o in r){let a=r[o],i=t[o];void 0!==a&&(a&&"object"==typeof a&&!Array.isArray(a)&&i&&"object"==typeof i&&!Array.isArray(i)?n[o]=e(i,a):n[o]=a)}return n}(eE,e),eT&&clearTimeout(eT),eT=setTimeout(eN,120)):console.warn("[Next.js DevTools] Invalid config patch:",t.error.message)}function ez(e){let t,r,n,o,a,i,s,l,c,u,d,f,p,h,m,g,v,x,y,b,w,_,k,j,C,T,N,I,R,L,O,M,A,D,F=(0,S.c)(61),{theme:$,hide:U,hideShortcut:Z,setHideShortcut:q,scale:B,setPosition:V,setScale:H,position:W}=e,{restartServer:G,isPending:K}=function(){let[e,t]=(0,E.useState)(!1);return{restartServer:async({invalidateFileSystemCache:e})=>{t(!0);let r=!1;try{let t=await fetch("/__nextjs_server_status").then(e=>e.json()).then(e=>e.executionId).catch(e=>(console.log("[Next.js DevTools] Failed to fetch server status while restarting dev server.",e),null));if(!t)return void console.log("[Next.js DevTools] Failed to get the current server execution ID while restarting dev server.");let n=await fetch(e?"/__nextjs_restart_dev?invalidateFileSystemCache=1":"/__nextjs_restart_dev",{method:"POST"});if(!n.ok)return void console.log("[Next.js DevTools] Failed to fetch restart server endpoint. Status:",n.status);for(let e=0;e<10;e++){await new Promise(e=>setTimeout(e,1e3));try{let e=await fetch("/__nextjs_server_status").then(e=>e.json()).then(e=>e.executionId);if(t!==e){r=!0,window.location.reload();return}}catch(e){continue}}console.log("[Next.js DevTools] Failed to restart server. Exhausted all polling attempts.");return}catch(e){console.log("[Next.js DevTools] Failed to restart server.",e);return}finally{r||t(!1)}},isPending:e}}(),{shadowRoot:Y}=(0,P.OS)();F[0]!==Y.host?(t=e=>{let t=Y.host;if("system"===e.target.value){t.classList.remove("dark"),t.classList.remove("light"),eI({theme:"system"});return}"dark"===e.target.value?(t.classList.add("dark"),t.classList.remove("light"),eI({theme:"dark"})):(t.classList.remove("dark"),t.classList.add("light"),eI({theme:"light"}))},F[0]=Y.host,F[1]=t):t=F[1];let X=t;F[2]!==V?(r=function(e){V(e.target.value),eI({devToolsPosition:e.target.value})},F[2]=V,F[3]=r):r=F[3];let Q=r;F[4]!==H?(n=function(e){let{target:t}=e,r=Number(t.value);H(r),eI({scale:r})},F[4]=H,F[5]=n):n=F[5];let J=n;return F[6]===Symbol.for("react.memo_cache_sentinel")?(o=(0,z.jsxs)("div",{className:"preference-header",children:[(0,z.jsx)("label",{htmlFor:"theme",children:"Theme"}),(0,z.jsx)("p",{className:"preference-description",children:"Select your theme preference."})]}),F[6]=o):o=F[6],F[7]!==$?(a=(0,z.jsx)(eL,{theme:$}),F[7]=$,F[8]=a):a=F[8],F[9]===Symbol.for("react.memo_cache_sentinel")?(i=(0,z.jsx)("option",{value:"system",children:"System"}),s=(0,z.jsx)("option",{value:"light",children:"Light"}),l=(0,z.jsx)("option",{value:"dark",children:"Dark"}),F[9]=i,F[10]=s,F[11]=l):(i=F[9],s=F[10],l=F[11]),F[12]!==X||F[13]!==a||F[14]!==$?(c=(0,z.jsxs)("div",{className:"preference-section",children:[o,(0,z.jsxs)(eP,{id:"theme",name:"theme",prefix:a,value:$,onChange:X,children:[i,s,l]})]}),F[12]=X,F[13]=a,F[14]=$,F[15]=c):c=F[15],F[16]===Symbol.for("react.memo_cache_sentinel")?(u=(0,z.jsxs)("div",{className:"preference-header",children:[(0,z.jsx)("label",{htmlFor:"position",children:"Position"}),(0,z.jsx)("p",{className:"preference-description",children:"Adjust the placement of your dev tools."})]}),F[16]=u):u=F[16],F[17]===Symbol.for("react.memo_cache_sentinel")?(d=(0,z.jsx)("option",{value:"bottom-left",children:"Bottom Left"}),f=(0,z.jsx)("option",{value:"bottom-right",children:"Bottom Right"}),p=(0,z.jsx)("option",{value:"top-left",children:"Top Left"}),h=(0,z.jsx)("option",{value:"top-right",children:"Top Right"}),F[17]=d,F[18]=f,F[19]=p,F[20]=h):(d=F[17],f=F[18],p=F[19],h=F[20]),F[21]!==Q||F[22]!==W?(m=(0,z.jsxs)("div",{className:"preference-section",children:[u,(0,z.jsxs)(eP,{id:"position",name:"position",value:W,onChange:Q,children:[d,f,p,h]})]}),F[21]=Q,F[22]=W,F[23]=m):m=F[23],F[24]===Symbol.for("react.memo_cache_sentinel")?(g=(0,z.jsxs)("div",{className:"preference-header",children:[(0,z.jsx)("label",{htmlFor:"size",children:"Size"}),(0,z.jsx)("p",{className:"preference-description",children:"Adjust the size of your dev tools."})]}),F[24]=g):g=F[24],F[25]===Symbol.for("react.memo_cache_sentinel")?(v=Object.entries(eu.Lf).map(eR),F[25]=v):v=F[25],F[26]!==J||F[27]!==B?(x=(0,z.jsxs)("div",{className:"preference-section",children:[g,(0,z.jsx)(eP,{id:"size",name:"size",value:B,onChange:J,children:v})]}),F[26]=J,F[27]=B,F[28]=x):x=F[28],F[29]===Symbol.for("react.memo_cache_sentinel")?(y=(0,z.jsxs)("div",{className:"preference-header",children:[(0,z.jsx)("label",{id:"hide-dev-tools",children:"Hide Dev Tools for this session"}),(0,z.jsx)("p",{className:"preference-description",children:"Hide Dev Tools until you restart your dev server, or 1 day."})]}),F[29]=y):y=F[29],F[30]===Symbol.for("react.memo_cache_sentinel")?(b=(0,z.jsx)(ec,{}),w=(0,z.jsx)("span",{children:"Hide"}),F[30]=b,F[31]=w):(b=F[30],w=F[31]),F[32]!==U?(_=(0,z.jsxs)("div",{className:"preference-section",children:[y,(0,z.jsx)("div",{className:"preference-control",children:(0,z.jsxs)("button",{"aria-describedby":"hide-dev-tools",name:"hide-dev-tools","data-hide-dev-tools":!0,className:"action-button",onClick:U,children:[b,w]})})]}),F[32]=U,F[33]=_):_=F[33],F[34]===Symbol.for("react.memo_cache_sentinel")?(k=(0,z.jsxs)("div",{className:"preference-header",children:[(0,z.jsx)("label",{id:"hide-dev-tools",children:"Hide Dev Tools shortcut"}),(0,z.jsx)("p",{className:"preference-description",children:"Set a custom keyboard shortcut to toggle visibility."})]}),F[34]=k):k=F[34],F[35]!==Z?(j=Z?.split("+")??null,F[35]=Z,F[36]=j):j=F[36],F[37]!==q||F[38]!==j?(C=(0,z.jsxs)("div",{className:"preference-section",children:[k,(0,z.jsx)("div",{className:"preference-control",children:(0,z.jsx)(em,{value:j,onChange:q})})]}),F[37]=q,F[38]=j,F[39]=C):C=F[39],F[40]===Symbol.for("react.memo_cache_sentinel")?(T=(0,z.jsx)("label",{children:"Disable Dev Tools for this project"}),F[40]=T):T=F[40],F[41]===Symbol.for("react.memo_cache_sentinel")?(N=(0,z.jsx)("code",{className:"dev-tools-info-code",children:"devIndicators: false"}),F[41]=N):N=F[41],F[42]===Symbol.for("react.memo_cache_sentinel")?(I=(0,z.jsx)("div",{className:"preference-section",children:(0,z.jsxs)("div",{className:"preference-header",children:[T,(0,z.jsxs)("p",{className:"preference-description",children:["To disable this UI completely, set"," ",N," in your ",(0,z.jsx)("code",{className:"dev-tools-info-code",children:"next.config"})," file."]})]})}),F[42]=I):I=F[42],F[43]===Symbol.for("react.memo_cache_sentinel")?(R=(0,z.jsxs)("div",{className:"preference-header",children:[(0,z.jsx)("label",{id:"restart-dev-server",children:"Restart Dev Server"}),(0,z.jsx)("p",{className:"preference-description",children:"Restarts the development server without needing to leave the browser."})]}),F[43]=R):R=F[43],F[44]!==G?(L=()=>G({invalidateFileSystemCache:!1}),F[44]=G,F[45]=L):L=F[45],F[46]===Symbol.for("react.memo_cache_sentinel")?(O=(0,z.jsx)("span",{children:"Restart"}),F[46]=O):O=F[46],F[47]!==K||F[48]!==L?(M=(0,z.jsxs)("div",{className:"preference-section",children:[R,(0,z.jsx)("div",{className:"preference-control",children:(0,z.jsx)("button",{"aria-describedby":"restart-dev-server",title:"Restarts the development server without needing to leave the browser.",name:"restart-dev-server","data-restart-dev-server":!0,className:"action-button",onClick:L,disabled:K,children:O})})]}),F[47]=K,F[48]=L,F[49]=M):M=F[49],F[50]!==K||F[51]!==G?(A=process.env.__NEXT_BUNDLER_HAS_PERSISTENT_CACHE?(0,z.jsxs)("div",{className:"preference-section",children:[(0,z.jsxs)("div",{className:"preference-header",children:[(0,z.jsx)("label",{id:"reset-bundler-cache",children:"Reset Bundler Cache"}),(0,z.jsx)("p",{className:"preference-description",children:"Clears the bundler cache and restarts the dev server. Helpful if you are seeing stale errors or changes are not appearing."})]}),(0,z.jsx)("div",{className:"preference-control",children:(0,z.jsx)("button",{"aria-describedby":"reset-bundler-cache",title:"Clears the bundler cache and restarts the dev server. Helpful if you are seeing stale errors or changes are not appearing.",name:"reset-bundler-cache","data-reset-bundler-cache":!0,className:"action-button",onClick:()=>G({invalidateFileSystemCache:!0}),disabled:K,children:(0,z.jsx)("span",{children:"Reset Cache"})})})]}):null,F[50]=K,F[51]=G,F[52]=A):A=F[52],F[53]!==c||F[54]!==m||F[55]!==x||F[56]!==_||F[57]!==C||F[58]!==M||F[59]!==A?(D=(0,z.jsxs)("div",{className:"preferences-container",children:[c,m,x,_,C,I,M,A]}),F[53]=c,F[54]=m,F[55]=x,F[56]=_,F[57]=C,F[58]=M,F[59]=A,F[60]=D):D=F[60],D}function eR(e){let[t,r]=e;return(0,z.jsx)("option",{value:r,children:t},t)}function eP(e){let t,r,n,o,a,i,s=(0,S.c)(11);return s[0]!==e?({children:t,prefix:r,...n}=e,s[0]=e,s[1]=t,s[2]=r,s[3]=n):(t=s[1],r=s[2],n=s[3]),s[4]!==t||s[5]!==n?(o=(0,z.jsx)("select",{...n,children:t}),s[4]=t,s[5]=n,s[6]=o):o=s[6],s[7]===Symbol.for("react.memo_cache_sentinel")?(a=(0,z.jsx)(eM,{}),s[7]=a):a=s[7],s[8]!==r||s[9]!==o?(i=(0,z.jsxs)("div",{className:"select-button",children:[r,o,a]}),s[8]=r,s[9]=o,s[10]=i):i=s[10],i}function eL(e){let t=(0,S.c)(3),{theme:r}=e;switch(r){case"system":{let e;return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)(ep,{}),t[0]=e):e=t[0],e}case"dark":{let e;return t[1]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)(ef,{}),t[1]=e):e=t[1],e}case"light":{let e;return t[2]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)(ed,{}),t[2]=e):e=t[2],e}default:return null}}let eO=(0,C.A)`
  .preferences-container {
    width: 100%;
  }

  @media (min-width: 576px) {
    .preferences-container {
      width: 480px;
    }
  }

  .preference-section:first-child {
    padding-top: 0;
  }

  .preference-section {
    padding: 12px 0;
    border-bottom: 1px solid var(--color-gray-400);
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 24px;
  }

  .preference-section:last-child {
    border-bottom: none;
  }

  .preference-header {
    margin-bottom: 0;
    flex: 1;
  }

  .preference-header label {
    font-size: var(--size-14);
    font-weight: 500;
    color: var(--color-gray-1000);
    margin: 0;
  }

  .preference-description {
    color: var(--color-gray-900);
    font-size: var(--size-14);
    margin: 0;
  }

  .select-button,
  .action-button {
    display: flex;
    align-items: center;
    gap: 8px;
    background: var(--color-background-100);
    border: 1px solid var(--color-gray-400);
    border-radius: var(--rounded-lg);
    font-weight: 400;
    font-size: var(--size-14);
    color: var(--color-gray-1000);
    padding: 6px 8px;
    transition: border-color 150ms var(--timing-swift);

    &:hover {
      border-color: var(--color-gray-500);
    }

    svg {
      width: 14px;
      height: 14px;
      overflow: visible;
    }
  }

  .select-button {
    &:focus-within {
      outline: var(--focus-ring);
      outline-offset: -1px;
    }

    select {
      all: unset;
    }

    option {
      color: var(--color-gray-1000);
      background: var(--color-background-100);
    }
  }

  .preference-section button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  :global(.icon) {
    width: 18px;
    height: 18px;
    color: #666;
  }
`;function eM(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16","aria-hidden":!0,children:(0,z.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M14.0607 5.49999L13.5303 6.03032L8.7071 10.8535C8.31658 11.2441 7.68341 11.2441 7.29289 10.8535L2.46966 6.03032L1.93933 5.49999L2.99999 4.43933L3.53032 4.96966L7.99999 9.43933L12.4697 4.96966L13 4.43933L14.0607 5.49999Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}var eA=r("./src/next-devtools/dev-overlay/components/call-stack/call-stack.tsx"),eD=r("./src/next-devtools/dev-overlay/components/instant/instant-guidance.tsx"),eF=r("./src/next-devtools/dev-overlay/components/instant/unrendered-segment-info.tsx");function e$(){return(0,z.jsx)("style",{children:(0,C.A)`
        ${ei.KY}
        ${es.l}
        ${eA.b}
        ${el.o}
        ${F}
        ${M.R7}
        ${A.R}
        ${D.i}
        ${O.V}
        ${Y}
        ${V}
        ${""}
        ${eo.R7}
        ${ea.R}
        ${J.R}
        ${eO}
        ${ek}
        ${eD.Qz}
        ${eF.r}
      `})}function eU(e,t){let r,n,o,a,i=(0,S.c)(10),s=void 0!==e&&e;i[0]!==t?(r=void 0===t?{}:t,i[0]=t,i[1]=r):r=i[1];let l=r,[c,u]=(0,E.useState)(s),[d,f]=(0,E.useState)(!1),{enterDelay:p,exitDelay:h}=l,m=void 0===p?1:p,g=void 0===h?0:h;return i[2]!==s||i[3]!==m||i[4]!==g?(n=()=>{let e,t;return s?(u(!0),m<=0?f(!0):e=setTimeout(()=>{f(!0)},m)):(f(!1),g<=0?u(!1):t=setTimeout(()=>{u(!1)},g)),()=>{clearTimeout(e),clearTimeout(t)}},o=[s,m,g],i[2]=s,i[3]=m,i[4]=g,i[5]=n,i[6]=o):(n=i[5],o=i[6]),(0,E.useEffect)(n,o),i[7]!==c||i[8]!==d?(a={mounted:c,rendered:d},i[7]=c,i[8]=d,i[9]=a):a=i[9],a}function eZ(e){let t,r,n,o,a,i=(0,S.c)(21),{state:s,dispatch:l,getSquashedHydrationErrorDetails:c,runtimeErrors:u,errorCount:d}=e,f=!!process.env.TURBOPACK;i[0]===Symbol.for("react.memo_cache_sentinel")?(t={exitDelay:200},i[0]=t):t=i[0];let{mounted:p,rendered:h}=eU(s.isErrorOverlayOpen,t);i[1]!==d||i[2]!==h||i[3]!==s.versionInfo?(r={rendered:h,transitionDurationMs:200,isTurbopack:f,versionInfo:s.versionInfo,errorCount:d},i[1]=d,i[2]=h,i[3]=s.versionInfo,i[4]=r):r=i[4];let m=r;if(null!==s.buildError){let e;return i[5]!==m||i[6]!==s.buildError?(e=(0,z.jsx)(er,{...m,message:s.buildError,rendered:!0}),i[5]=m,i[6]=s.buildError,i[7]=e):e=i[7],e}if(!u.length&&!s.hasVulnerabilityInsight)return null;let g=u.some(eB),v=u.some(eq),x=`${g?"n":""}${v?"i":""}`,y=p?"visible":"hidden";return i[8]!==l?(n=()=>{l({type:eu.kO})},i[8]=l,i[9]=n):n=i[9],i[10]!==m||i[11]!==c||i[12]!==u||i[13]!==s.debugInfo||i[14]!==s.hasVulnerabilityInsight||i[15]!==n||i[16]!==x?(o=(0,z.jsx)(eo.I,{...m,debugInfo:s.debugInfo,getSquashedHydrationErrorDetails:c,runtimeErrors:u,hasVulnerabilityInsight:s.hasVulnerabilityInsight,onClose:n},x),i[10]=m,i[11]=c,i[12]=u,i[13]=s.debugInfo,i[14]=s.hasVulnerabilityInsight,i[15]=n,i[16]=x,i[17]=o):o=i[17],i[18]!==y||i[19]!==o?(a=(0,z.jsx)(E.Activity,{mode:y,children:o}),i[18]=y,i[19]=o,i[20]=a):a=i[20],a}function eq(e){return(0,eo.go)(e.error)}function eB(e){return!(0,eo.go)(e.error)}var eV=r("./src/next-devtools/dev-overlay/utils/get-error-by-type.ts");let eH=e=>{let t=(0,S.c)(4),{state:r}=e;if(r.buildError){let r;return t[0]!==e?(r=(0,z.jsx)(eG,{...e}),t[0]=e,t[1]=r):r=t[1],r}{let r;return t[2]!==e?(r=(0,z.jsx)(eW,{...e}),t[2]=e,t[3]=r):r=t[3],r}},eW=e=>{let t,r,n,o,a,i,s=(0,S.c)(16),{children:l,state:c,isAppDir:u}=e,{errors:d}=c;s[0]===Symbol.for("react.memo_cache_sentinel")?(t={},s[0]=t):t=s[0];let[f,p]=(0,E.useState)(t);if(s[1]!==d||s[2]!==f){let e=[],t=null;for(let r=0;r<d.length;++r){let n=d[r],{id:o}=n;if(o in f){let r=f[o];if(!("event"in r)){e.push(r);continue}let a=r.resolved;if(r.event!==n){null===t&&(t=n),e.push(a.type===n.type?a:{...a,type:n.type});continue}e.push(a);continue}null===t&&(t=n);break}r=[e,t],s[1]=d,s[2]=f,s[3]=r}else r=s[3];let[h,m]=r;s[4]!==u||s[5]!==m?(n=()=>{if(null==m)return;let e=(0,eV.W)(m,u);p(t=>({...t,[e.id]:"isFatal"in m?{event:m,resolved:e}:e}))},o=[m,u],s[4]=u,s[5]=m,s[6]=n,s[7]=o):(n=s[6],o=s[7]),(0,E.useEffect)(n,o);let g=d.length;s[8]!==h?(a=h.filter(eK),s[8]=h,s[9]=a):a=s[9];let v=a.length,x=h.length-v;return s[10]!==l||s[11]!==v||s[12]!==x||s[13]!==h||s[14]!==g?(i=l({runtimeErrors:h,totalErrorCount:g,normalErrorCount:x,instantErrorCount:v}),s[10]=l,s[11]=v,s[12]=x,s[13]=h,s[14]=g,s[15]=i):i=s[15],i},eG=({children:e})=>e({runtimeErrors:[],totalErrorCount:1,normalErrorCount:1,instantErrorCount:0});function eK(e){return(0,eo.go)(e.error)}function eY(){let e,t,r=(0,S.c)(4),{shadowRoot:n,state:o}=(0,P.OS)();return r[0]!==n||r[1]!==o.scale?(e=()=>{n?.host&&n.host.style.setProperty("--nextjs-dev-tools-scale",String(o.scale||1))},t=[n,o.scale],r[0]=n,r[1]=o.scale,r[2]=e,r[3]=t):(e=r[2],t=r[3]),(0,E.useLayoutEffect)(e,t),null}var eX=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/devtools-indicator/devtools-indicator.css"),eQ={};function eJ(e,t){let r,n,o=(0,S.c)(4),a=void 0===t?0:t,i=(0,E.useRef)(null),[s,l]=(0,E.useState)(!1);return o[0]!==a||o[1]!==e?(r=()=>{if(e>0){let e=i.current?Date.now()-i.current:-1;if(i.current=Date.now(),e<=a)return;l(!0);let t=window.setTimeout(()=>{l(!1)},a);return()=>{clearTimeout(t)}}},n=[e,a],o[0]=a,o[1]=e,o[2]=r,o[3]=n):(r=o[2],n=o[3]),(0,E.useEffect)(r,n),s}function e0(e){let t,r,n=(0,S.c)(3);return n[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3.08889 11.8384L2.62486 12.3024L1.69678 11.3744L2.16082 10.9103L6.07178 6.99937L2.16082 3.08841L1.69678 2.62437L2.62486 1.69629L3.08889 2.16033L6.99986 6.07129L10.9108 2.16033L11.3749 1.69629L12.3029 2.62437L11.8389 3.08841L7.92793 6.99937L11.8389 10.9103L12.3029 11.3744L11.3749 12.3024L10.9108 11.8384L6.99986 7.92744L3.08889 11.8384Z",fill:"currentColor"}),n[0]=t):t=n[0],n[1]!==e?(r=(0,z.jsx)("svg",{width:"12",height:"12",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e,children:t}),n[1]=e,n[2]=r):r=n[2],r}function e1(e){let t,r,n=(0,S.c)(3);return n[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3.98071 1.125L1.125 3.98071L1.125 8.01929L3.98071 10.875H8.01929L10.875 8.01929V3.98071L8.01929 1.125H3.98071ZM3.82538 0C3.62647 0 3.4357 0.0790176 3.29505 0.21967L0.21967 3.29505C0.0790176 3.4357 0 3.62647 0 3.82538V8.17462C0 8.37353 0.0790178 8.5643 0.21967 8.70495L3.29505 11.7803C3.4357 11.921 3.62647 12 3.82538 12H8.17462C8.37353 12 8.5643 11.921 8.70495 11.7803L11.7803 8.70495C11.921 8.5643 12 8.37353 12 8.17462V3.82538C12 3.62647 11.921 3.4357 11.7803 3.29505L8.70495 0.21967C8.5643 0.0790177 8.37353 0 8.17462 0H3.82538ZM6.5625 2.8125V3.375V6V6.5625H5.4375V6V3.375V2.8125H6.5625ZM6 9C6.41421 9 6.75 8.66421 6.75 8.25C6.75 7.83579 6.41421 7.5 6 7.5C5.58579 7.5 5.25 7.83579 5.25 8.25C5.25 8.66421 5.58579 9 6 9Z",fill:"currentColor"}),n[0]=t):t=n[0],n[1]!==e?(r=(0,z.jsx)("svg",{width:"12",height:"12",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e,children:t}),n[1]=e,n[2]=r):r=n[2],r}eQ.styleTagTransform=b(),eQ.setAttributes=g(),eQ.insert=h(),eQ.domAPI=f(),eQ.insertStyleElement=x(),u()(eX.A,eQ),eX.A&&eX.A.locals&&eX.A.locals;var e2=((n={}).None="none",n.Rendering="rendering",n.RenderingColdCache="rendering-cold-cache",n.RenderingCacheDisabled="rendering-cache-disabled",n.Compiling="compiling",n);function e3(e){let t,r,n,o,a,i,s=(0,S.c)(12),{status:l,onClick:c}=e;s[0]===Symbol.for("react.memo_cache_sentinel")?(t={none:"",compiling:"Compiling",rendering:"Rendering","rendering-cold-cache":"Rendering (cold cache)","rendering-cache-disabled":"Rendering (cache disabled)"},s[0]=t):t=s[0];let u=t;s[1]===Symbol.for("react.memo_cache_sentinel")?(r={none:"",compiling:"#f5a623",rendering:"#50e3c2","rendering-cold-cache":"#f5a623","rendering-cache-disabled":"#f5a623"},s[1]=r):r=s[1];let d=r;if("none"===l)return null;s[2]===Symbol.for("react.memo_cache_sentinel")?(n=(0,z.jsx)("style",{children:(0,C.A)`
          [data-indicator-status] {
            --padding-left: 8px;
            display: flex;
            gap: 6px;
            align-items: center;
            padding-left: 12px;
            padding-right: 8px;
            height: var(--size-32);
            margin-right: 2px;
            border-radius: var(--rounded-full);
            transition: background var(--duration-short) ease;
            color: white;
            font-size: var(--size-13);
            font-weight: 500;
            white-space: nowrap;
            border: none;
            background: transparent;
            cursor: pointer;
            outline: none;
          }

          [data-indicator-status]:focus-visible {
            outline: 2px solid var(--color-blue-800, #3b82f6);
            outline-offset: 3px;
          }

          [data-status-dot] {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            flex-shrink: 0;
          }

          [data-status-text-animation] {
            display: inline-flex;
            align-items: center;
            position: relative;
            overflow: hidden;
            height: 100%;

            > * {
              white-space: nowrap;
              line-height: 1;
            }

            [data-status-text-enter] {
              animation: slotMachineEnter 150ms cubic-bezier(0, 0, 0.2, 1)
                forwards;
            }
          }

          [data-status-ellipsis] {
            display: inline-flex;
            margin-left: 2px;
          }

          [data-status-ellipsis] span {
            animation: ellipsisFade 1.2s infinite;
            margin: 0 1px;
          }

          [data-status-ellipsis] span:nth-child(2) {
            animation-delay: 0.2s;
          }

          [data-status-ellipsis] span:nth-child(3) {
            animation-delay: 0.4s;
          }

          @keyframes ellipsisFade {
            0%,
            60%,
            100% {
              opacity: 0.2;
            }
            30% {
              opacity: 1;
            }
          }

          @keyframes slotMachineEnter {
            0% {
              transform: translateY(0.8em);
              opacity: 0;
            }
            50% {
              opacity: 0.8;
            }
            100% {
              transform: translateY(0);
              opacity: 1;
            }
          }
        `}),s[2]=n):n=s[2],s[3]!==l?(o=d[l]&&(0,z.jsx)("div",{"data-status-dot":!0,style:{backgroundColor:d[l]}}),s[3]=l,s[4]=o):o=s[4];let f=u[l];return s[5]!==l||s[6]!==f?(a=(0,z.jsx)(e5,{statusKey:l,showEllipsis:!0,children:f},l),s[5]=l,s[6]=f,s[7]=a):a=s[7],s[8]!==c||s[9]!==o||s[10]!==a?(i=(0,z.jsxs)(z.Fragment,{children:[n,(0,z.jsxs)("button",{"data-indicator-status":!0,"data-nextjs-dev-tools-button":!0,onClick:c,"aria-label":"Open Next.js Dev Tools",children:[o,a]})]}),s[8]=c,s[9]=o,s[10]=a,s[11]=i):i=s[11],i}function e5(e){let t,r,n=(0,S.c)(5),{children:o,showEllipsis:a}=e,i=void 0===a||a;return n[0]!==i?(t=i&&(0,z.jsxs)("span",{"data-status-ellipsis":!0,children:[(0,z.jsx)("span",{children:"."}),(0,z.jsx)("span",{children:"."}),(0,z.jsx)("span",{children:"."})]}),n[0]=i,n[1]=t):t=n[1],n[2]!==t||n[3]!==o?(r=(0,z.jsx)("div",{"data-status-text-animation":!0,children:(0,z.jsxs)("div",{"data-status-text-enter":!0,children:[o,t]})}),n[2]=t,n[3]=o,n[4]=r):r=n[4],r}let e4=!!process.env.__NEXT_EXPERIMENTAL_COLD_CACHE_BADGE;function e6(e,t){if("timer"===t.type)return"entering"===e.phase?{phase:"pill",status:e.status}:"exiting"===e.phase?{phase:"idle"}:e;let{intent:r}=t;switch(e.phase){case"idle":if("pill"===r.kind)return{phase:"entering",status:r.status,under:null};if("badge"===r.kind)return{phase:"badge",badge:r.cache};return e;case"entering":if("pill"===r.kind)return{phase:"entering",status:r.status,under:e.under};if("badge"===r.kind)return{phase:"badge",badge:r.cache};return{phase:"idle"};case"pill":if("pill"===r.kind)return e.status===r.status?e:{phase:"pill",status:r.status};if("badge"===r.kind)return{phase:"badge",badge:r.cache};return{phase:"exiting",status:e.status};case"exiting":if("pill"===r.kind)return{phase:"pill",status:r.status};if("badge"===r.kind)return{phase:"badge",badge:r.cache};return e;case"badge":if("pill"===r.kind)return{phase:"entering",status:r.status,under:e.badge};if("badge"===r.kind)return e.badge===r.cache?e:{phase:"badge",badge:r.cache};return{phase:"idle"}}}function e7(e){switch(e.kind){case"pill":return{phase:"pill",status:e.status};case"badge":return{phase:"badge",badge:e.cache};case"idle":return{phase:"idle"}}}let e9=(0,E.createContext)(null),e8=()=>(0,E.useContext)(e9);function te(e,t){let r=e>0,n=t>0,o=!r&&n;return{hasNormal:r,hasInstant:n,hasAny:r||n,insightsOnly:o,variant:o?"insight":"issue"}}function tt(e){return tx+36/e.scale+9}function tr(e){let t,r=(0,S.c)(2),{count:n,animate:o}=e;return n<=1?null:(r[0]!==o?(t=(0,z.jsx)("span",{"aria-hidden":!0,"data-issues-count-plural":!0,"data-animate":o,children:"s"}),r[0]=o,r[1]=t):t=r[1],t)}function tn(e){let t,r,n,o=(0,S.c)(13),{normalCount:a,instantCount:i,normalCountAnimating:s,instantCountAnimating:l}=e,c=a>0,u=i>0;o[0]!==c||o[1]!==a||o[2]!==s?(t=c&&(0,z.jsxs)(z.Fragment,{children:["Issue",(0,z.jsx)(tr,{count:a,animate:s&&2===a})]}),o[0]=c,o[1]=a,o[2]=s,o[3]=t):t=o[3];let d=c&&u&&" \xb7 ";return o[4]!==u||o[5]!==c||o[6]!==i||o[7]!==l?(r=u&&(0,z.jsxs)(z.Fragment,{children:[c&&(0,z.jsxs)(z.Fragment,{children:[i," "]}),"Insight",(0,z.jsx)(tr,{count:i,animate:l&&2===i})]}),o[4]=u,o[5]=c,o[6]=i,o[7]=l,o[8]=r):r=o[8],o[9]!==t||o[10]!==d||o[11]!==r?(n=(0,z.jsxs)(z.Fragment,{children:[t,d,r]}),o[9]=t,o[10]=d,o[11]=r,o[12]=n):n=o[12],n}function to(e){let t,r,n,o,a,i,s,l,c,u,d,f,p=(0,S.c)(57);p[0]!==e?({onTriggerClick:r,...t}=e,p[0]=e,p[1]=t,p[2]=r):(t=p[1],r=p[2]);let{state:h,dispatch:m}=(0,P.OS)(),{totalErrorCount:g,normalErrorCount:v,instantErrorCount:x}=lw(),y=36/h.scale,{panel:b,triggerRef:w,setPanel:_}=e8(),k="panel-selector"===b,j=g>0;p[3]!==x||p[4]!==v?(n=te(v,x),p[3]=x,p[4]=v,p[5]=n):n=p[5];let{insightsOnly:T}=n,[N,I]=(0,E.useState)(j),[R,L]=(0,E.useState)(j);R!==j&&(L(j),I(j));let[O,M]=(0,E.useState)(!1),A=eJ(v,150),D=eJ(x,150),F=A||D,$=v>0?v:x,U=v>0?A:D,{status:Z,cacheBadge:q}=function(e,t,r){let n,o,a,i,s,l=(0,S.c)(11);if(l[0]!==e||l[1]!==r||l[2]!==t){var c,u,d;let o;c=e,u=t,d=r,n=(o=c?"compiling":u?"cold"===d?"rendering-cold-cache":"bypass"===d?"rendering-cache-disabled":"rendering":"none")!==e2.None?{kind:"pill",status:o}:"bypass"===r||"cold"===r&&e4?{kind:"badge",cache:r}:{kind:"idle"},l[0]=e,l[1]=r,l[2]=t,l[3]=n}else n=l[3];let f=n,[p,h]=(0,E.useReducer)(e6,f,e7);l[4]!==f?(o=function(e){switch(e.kind){case"pill":return`pill:${e.status}`;case"badge":return`badge:${e.cache}`;case"idle":return"idle"}}(f),l[4]=f,l[5]=o):o=l[5];let m=o,[g,v]=(0,E.useState)(m);g!==m&&(v(m),h({type:"intent",intent:f}));let{phase:x}=p;return l[6]!==x?(a=()=>{if("entering"!==x&&"exiting"!==x)return;let e=setTimeout(()=>h({type:"timer"}),200);return()=>clearTimeout(e)},i=[x],l[6]=x,l[7]=a,l[8]=i):(a=l[7],i=l[8]),(0,E.useEffect)(a,i),l[9]!==p?(s=function(e){switch(e.phase){case"idle":return{status:e2.None,cacheBadge:null};case"entering":return null===e.under?{status:e2.None,cacheBadge:null}:{status:e2.None,cacheBadge:e.under};case"pill":case"exiting":return{status:e.status,cacheBadge:null};case"badge":return{status:e2.None,cacheBadge:e.badge}}}(p),l[9]=p,l[10]=s):s=l[10],s}(h.buildingIndicator,h.renderingIndicator,h.cacheIndicator),B=Z!==e2.None,V=(0,E.useRef)(null),H=function(e){let t,r,n=(0,S.c)(3),[o,a]=(0,E.useState)(0);return n[0]!==e?(t=()=>{let t=e.current;if(!t)return;let r=new ResizeObserver(e=>{let[t]=e,{contentRect:r}=t;a(r.width)});return r.observe(t),()=>r.disconnect()},r=[e],n[0]=e,n[1]=t,n[2]=r):(t=n[1],r=n[2]),(0,E.useEffect)(t,r),o}(V),W=N||null!==q||B||h.disableDevIndicator,G=0===H?"auto":H,K=`${y}px`,Y=h.disableDevIndicator&&(!j||O)?"none":"block";p[6]!==K||p[7]!==Y?(o={"--size":K,"--duration-short":"150ms",display:Y},p[6]=K,p[7]=Y,p[8]=o):o=p[8];let X=o;p[9]===Symbol.for("react.memo_cache_sentinel")?(a=(0,z.jsx)("style",{children:(0,C.A)`
          [data-next-badge-root] {
            --timing: cubic-bezier(0.23, 0.88, 0.26, 0.92);
            --duration-long: 250ms;
            --color-outer-border: #171717;
            --color-inner-border: hsla(0, 0%, 100%, 0.14);
            --color-hover-alpha-subtle: hsla(0, 0%, 100%, 0.13);
            --color-hover-alpha-error: hsla(0, 0%, 100%, 0.2);
            --color-hover-alpha-error-2: hsla(0, 0%, 100%, 0.25);
            --mark-size: calc(var(--size) - var(--size-2) * 2);

            --focus-color: var(--color-blue-800);
            --focus-ring: 2px solid var(--focus-color);

            &:has([data-next-badge][data-error='true']) {
              --focus-color: #fff;
            }
          }

          [data-disabled-icon] {
            display: flex;
            align-items: center;
            justify-content: center;
            padding-right: 4px;
          }

          [data-next-badge] {
            width: var(--size);
            height: var(--size);
            display: flex;
            align-items: center;
            position: relative;
            background: rgba(0, 0, 0, 0.8);
            box-shadow:
              0 0 0 1px var(--color-outer-border),
              inset 0 0 0 1px var(--color-inner-border),
              0px 16px 32px -8px rgba(0, 0, 0, 0.24);
            backdrop-filter: blur(48px);
            border-radius: var(--rounded-full);
            user-select: none;
            cursor: pointer;
            scale: 1;
            overflow: hidden;
            will-change: scale, box-shadow, width, background;
            transition:
              scale var(--duration-short) var(--timing),
              width var(--duration-long) var(--timing),
              box-shadow var(--duration-long) var(--timing),
              background var(--duration-short) ease;

            &:active[data-error='false'] {
              scale: 0.95;
            }

            &[data-animate='true']:not(:hover) {
              scale: 1.02;
            }

            &[data-error='false']:has([data-next-mark]:focus-visible) {
              outline: var(--focus-ring);
              outline-offset: 3px;
            }

            &[data-error='true'] {
              background: #ca2a30;
              --color-inner-border: #e5484d;

              [data-next-mark] {
                background: var(--color-hover-alpha-error);
                outline-offset: 0px;

                &:focus-visible {
                  outline: var(--focus-ring);
                  outline-offset: -1px;
                }

                &:hover {
                  background: var(--color-hover-alpha-error-2);
                }
              }
            }

            &[data-cache-badge]:not([data-error='true']) {
              background: rgba(217, 119, 6, 0.95);
              --color-inner-border: rgba(245, 158, 11, 0.9);

              [data-issues-open] {
                color: white;
              }
            }

            &[data-insights-only='true']:not([data-error='true']) {
              background: rgba(217, 119, 6, 0.95);
              --color-inner-border: rgba(245, 158, 11, 0.9);

              [data-issues-open] {
                color: white;
              }
            }

            &[data-error-expanded='false'][data-error='true'] ~ [data-dot] {
              scale: 1;
            }

            > div {
              display: flex;
            }
          }

          [data-issues-collapse]:focus-visible {
            outline: var(--focus-ring);
          }

          [data-toast-pill]:has([data-issues-open]:focus-visible) {
            outline: var(--focus-ring);
            outline-offset: -1px;
          }

          [data-dot] {
            content: '';
            width: var(--size-8);
            height: var(--size-8);
            background: #fff;
            box-shadow: 0 0 0 1px var(--color-outer-border);
            border-radius: 50%;
            position: absolute;
            top: 2px;
            right: 0px;
            scale: 0;
            pointer-events: none;
            transition: scale 200ms var(--timing);
            transition-delay: var(--duration-short);
          }

          /* Shared pill layout for the errors toast and the cache badge. Keyed
             on data-toast-pill rather than data-issues so it applies to both,
             while data-issues stays exclusive to the errors toast. */
          [data-toast-pill] {
            --padding-left: 8px;
            display: flex;
            gap: 2px;
            align-items: center;
            padding-left: 8px;
            padding-right: 8px;
            height: var(--size-32);
            margin-right: 2px;
            border-radius: var(--rounded-full);
            transition: background var(--duration-short) ease;

            &:has([data-issues-open]:hover) {
              background: var(--color-hover-alpha-error);
            }

            &:has([data-issues-collapse]) {
              padding-right: calc(var(--padding-left) / 2);
            }
          }

          [data-issues-open] {
            font-size: var(--size-13);
            color: white;
            width: fit-content;
            height: 100%;
            display: flex;
            gap: 2px;
            align-items: center;
            margin: 0;
            line-height: var(--size-36);
            font-weight: 500;
            z-index: 2;
            white-space: nowrap;

            &:focus-visible {
              outline: 0;
            }
          }

          [data-issues-collapse] {
            width: var(--size-24);
            height: var(--size-24);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: var(--rounded-full);
            transition: background var(--duration-short) ease;

            &:hover {
              background: var(--color-hover-alpha-error);
            }
          }

          [data-cross] {
            color: #fff;
            width: var(--size-12);
            height: var(--size-12);
          }

          [data-next-mark] {
            width: var(--mark-size);
            height: var(--mark-size);
            margin: 0 2px;
            display: flex;
            align-items: center;
            border-radius: var(--rounded-full);
            transition: background var(--duration-long) var(--timing);

            &:focus-visible {
              outline: 0;
            }

            &:hover {
              background: var(--color-hover-alpha-subtle);
            }

            svg {
              flex-shrink: 0;
              width: var(--size-40);
              height: var(--size-40);
            }
          }

          [data-issues-count-animation] {
            display: grid;
            place-items: center center;
            font-variant-numeric: tabular-nums;

            &[data-animate='false'] {
              [data-issues-count-exit],
              [data-issues-count-enter] {
                animation-duration: 0ms;
              }
            }

            > * {
              grid-area: 1 / 1;
            }

            [data-issues-count-exit] {
              animation: fadeOut 300ms var(--timing) forwards;
            }

            [data-issues-count-enter] {
              animation: fadeIn 300ms var(--timing) forwards;
            }
          }

          [data-issues-count-plural] {
            display: inline-block;
            &[data-animate='true'] {
              animation: fadeIn 300ms var(--timing) forwards;
            }
          }

          .paused {
            stroke-dashoffset: 0;
          }

          @keyframes fadeIn {
            0% {
              opacity: 0;
              filter: blur(2px);
              transform: translateY(8px);
            }
            100% {
              opacity: 1;
              filter: blur(0px);
              transform: translateY(0);
            }
          }

          @keyframes fadeOut {
            0% {
              opacity: 1;
              filter: blur(0px);
              transform: translateY(0);
            }
            100% {
              opacity: 0;
              transform: translateY(-12px);
              filter: blur(2px);
            }
          }

          @media (prefers-reduced-motion) {
            [data-issues-count-exit],
            [data-issues-count-enter],
            [data-issues-count-plural] {
              animation-duration: 0ms !important;
            }
          }
        `}),p[9]=a):a=p[9];let Q=j&&!T,J=j?e2.None:Z,ee=q??void 0;return p[10]!==G?(i={width:G},p[10]=G,p[11]=i):i=p[11],p[12]!==t||p[13]!==j||p[14]!==k||p[15]!==r||p[16]!==B||p[17]!==h.disableDevIndicator||p[18]!==w?(s=!h.disableDevIndicator&&(0,z.jsx)("button",{id:"next-logo",ref:w,"data-next-mark":!0,onClick:r,disabled:h.disableDevIndicator,"aria-haspopup":"menu","aria-expanded":k,"aria-controls":"nextjs-dev-tools-menu","aria-label":`${k?"Close":"Open"} Next.js Dev Tools`,"data-nextjs-dev-tools-button":!0,style:{display:B&&!j?"none":"flex"},...t,children:(0,z.jsx)(ts,{})}),p[12]=t,p[13]=j,p[14]=k,p[15]=r,p[16]=B,p[17]=h.disableDevIndicator,p[18]=w,p[19]=s):s=p[19],p[20]!==q||p[21]!==m||p[22]!==Z||p[23]!==j||p[24]!==D||p[25]!==x||p[26]!==N||p[27]!==W||p[28]!==$||p[29]!==U||p[30]!==A||p[31]!==v||p[32]!==r||p[33]!==b||p[34]!==_||p[35]!==B||p[36]!==h.buildError||p[37]!==h.disableDevIndicator||p[38]!==h.isErrorOverlayOpen||p[39]!==w?(l=W&&(0,z.jsxs)(z.Fragment,{children:[(N||h.disableDevIndicator)&&(0,z.jsxs)("div",{"data-issues":!0,"data-toast-pill":!0,children:[(0,z.jsxs)("button",{"data-issues-open":!0,"aria-label":"Open issues overlay",onClick:()=>{h.isErrorOverlayOpen?m({type:eu.kO}):(m({type:eu.Wv}),"instant-navs"!==b&&_(null))},children:[h.disableDevIndicator&&(0,z.jsx)("div",{"data-disabled-icon":!0,children:(0,z.jsx)(e1,{})}),(0,z.jsx)(ta,{animate:U,"data-issues-count-animation":!0,children:$},$)," ",(0,z.jsx)("div",{children:(0,z.jsx)(tn,{normalCount:v,instantCount:x,normalCountAnimating:A,instantCountAnimating:D})})]}),!h.buildError&&(0,z.jsx)("button",{"data-issues-collapse":!0,"aria-label":"Collapse issues badge",onClick:()=>{h.disableDevIndicator?M(!0):I(!1),w.current?.focus()},children:(0,z.jsx)(e0,{"data-cross":!0})})]}),q&&!j&&!h.disableDevIndicator&&(0,z.jsx)(ti,{kind:q,onTriggerClick:r,triggerRef:w}),B&&!j&&!h.disableDevIndicator&&(0,z.jsx)(e3,{status:Z,onClick:r})]}),p[20]=q,p[21]=m,p[22]=Z,p[23]=j,p[24]=D,p[25]=x,p[26]=N,p[27]=W,p[28]=$,p[29]=U,p[30]=A,p[31]=v,p[32]=r,p[33]=b,p[34]=_,p[35]=B,p[36]=h.buildError,p[37]=h.disableDevIndicator,p[38]=h.isErrorOverlayOpen,p[39]=w,p[40]=l):l=p[40],p[41]!==s||p[42]!==l?(c=(0,z.jsxs)("div",{ref:V,children:[s,l]}),p[41]=s,p[42]=l,p[43]=c):c=p[43],p[44]!==T||p[45]!==W||p[46]!==F||p[47]!==i||p[48]!==c||p[49]!==Q||p[50]!==J||p[51]!==ee?(u=(0,z.jsx)("div",{"data-next-badge":!0,"data-error":Q,"data-insights-only":T,"data-error-expanded":W,"data-status":J,"data-cache-badge":ee,"data-animate":F,style:i,children:c}),p[44]=T,p[45]=W,p[46]=F,p[47]=i,p[48]=c,p[49]=Q,p[50]=J,p[51]=ee,p[52]=u):u=p[52],p[53]===Symbol.for("react.memo_cache_sentinel")?(d=(0,z.jsx)("div",{"aria-hidden":!0,"data-dot":!0}),p[53]=d):d=p[53],p[54]!==u||p[55]!==X?(f=(0,z.jsxs)("div",{"data-next-badge-root":!0,style:X,children:[a,u,d]}),p[54]=u,p[55]=X,p[56]=f):f=p[56],f}function ta(e){let t,r,n,o,a,i,s=(0,S.c)(13);s[0]!==e?({children:t,animate:n,...r}=e,s[0]=e,s[1]=t,s[2]=r,s[3]=n):(t=s[1],r=s[2],n=s[3]);let l=void 0===n||n,c=t-1;return s[4]!==c?(o=(0,z.jsx)("div",{"aria-hidden":!0,"data-issues-count-exit":!0,children:c}),s[4]=c,s[5]=o):o=s[5],s[6]!==t?(a=(0,z.jsx)("div",{"data-issues-count":!0,"data-issues-count-enter":!0,children:t}),s[6]=t,s[7]=a):a=s[7],s[8]!==l||s[9]!==r||s[10]!==o||s[11]!==a?(i=(0,z.jsxs)("div",{...r,"data-animate":l,children:[o,a]}),s[8]=l,s[9]=r,s[10]=o,s[11]=a,s[12]=i):i=s[12],i}function ti(e){let t,r,n,o,a,i=(0,S.c)(14),{kind:s,onTriggerClick:l,triggerRef:c}=e,[u,d]=(0,E.useState)(!1);if(u)return null;let f="bypass"===s?"Cache disabled":"Cold cache",p="bypass"===s||void 0,h="cold"===s||void 0;i[0]!==f||i[1]!==l?(t=(0,z.jsx)("button",{"data-issues-open":!0,"data-nextjs-dev-tools-button":!0,"aria-label":"Open Next.js Dev Tools",onClick:l,children:f}),i[0]=f,i[1]=l,i[2]=t):t=i[2];let m=`Collapse ${f} badge`;return i[3]!==c?(r=()=>{d(!0),c.current?.focus()},i[3]=c,i[4]=r):r=i[4],i[5]===Symbol.for("react.memo_cache_sentinel")?(n=(0,z.jsx)(e0,{"data-cross":!0}),i[5]=n):n=i[5],i[6]!==m||i[7]!==r?(o=(0,z.jsx)("button",{"data-issues-collapse":!0,"aria-label":m,onClick:r,children:n}),i[6]=m,i[7]=r,i[8]=o):o=i[8],i[9]!==p||i[10]!==h||i[11]!==t||i[12]!==o?(a=(0,z.jsxs)("div",{"data-toast-pill":!0,"data-cache-bypass-badge":p,"data-cold-cache-badge":h,children:[t,o]}),i[9]=p,i[10]=h,i[11]=t,i[12]=o,i[13]=a):a=i[13],a}function ts(){let e,t,r,n,o=(0,S.c)(4);return o[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsxs)("g",{transform:"translate(8.5, 13)",children:[(0,z.jsx)("path",{className:"paused",d:"M13.3 15.2 L2.34 1 V12.6",fill:"none",stroke:"url(#next_logo_paint0_linear_1357_10853)",strokeWidth:"1.86",mask:"url(#next_logo_mask0)",strokeDasharray:"29.6",strokeDashoffset:"29.6"}),(0,z.jsx)("path",{className:"paused",d:"M11.825 1.5 V13.1",strokeWidth:"1.86",stroke:"url(#next_logo_paint1_linear_1357_10853)",strokeDasharray:"11.6",strokeDashoffset:"11.6"})]}),o[0]=e):e=o[0],o[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsxs)("linearGradient",{id:"next_logo_paint0_linear_1357_10853",x1:"9.95555",y1:"11.1226",x2:"15.4778",y2:"17.9671",gradientUnits:"userSpaceOnUse",children:[(0,z.jsx)("stop",{stopColor:"white"}),(0,z.jsx)("stop",{offset:"0.604072",stopColor:"white",stopOpacity:"0"}),(0,z.jsx)("stop",{offset:"1",stopColor:"white",stopOpacity:"0"})]}),o[1]=t):t=o[1],o[2]===Symbol.for("react.memo_cache_sentinel")?(r=(0,z.jsxs)("linearGradient",{id:"next_logo_paint1_linear_1357_10853",x1:"11.8222",y1:"1.40039",x2:"11.791",y2:"9.62542",gradientUnits:"userSpaceOnUse",children:[(0,z.jsx)("stop",{stopColor:"white"}),(0,z.jsx)("stop",{offset:"1",stopColor:"white",stopOpacity:"0"})]}),o[2]=r):r=o[2],o[3]===Symbol.for("react.memo_cache_sentinel")?(n=(0,z.jsxs)("svg",{width:"40",height:"40",viewBox:"0 0 40 40",fill:"none",children:[e,(0,z.jsxs)("defs",{children:[t,r,(0,z.jsxs)("mask",{id:"next_logo_mask0",children:[(0,z.jsx)("rect",{width:"100%",height:"100%",fill:"white"}),(0,z.jsx)("rect",{width:"5",height:"1.5",fill:"black"})]})]})]}),o[3]=n):n=o[3],n}var tl=r("./src/next-devtools/dev-overlay/utils/cx.ts");let tc=E.forwardRef(function(e,t){let r,n,o,a,i,s,l,c=(0,S.c)(15);return c[0]!==e?({onClick:o,children:r,className:n,...a}=e,c[0]=e,c[1]=r,c[2]=n,c[3]=o,c[4]=a):(r=c[1],n=c[2],o=c[3],a=c[4]),c[5]!==o?(i=e=>(e.target.closest("a")||e.preventDefault(),o?.()),c[5]=o,c[6]=i):i=c[6],c[7]!==n?(s=(0,tl.cx)("nextjs-toast",n),c[7]=n,c[8]=s):s=c[8],c[9]!==r||c[10]!==a||c[11]!==t||c[12]!==i||c[13]!==s?(l=(0,z.jsx)("div",{...a,ref:t,onClick:i,className:s,children:r}),c[9]=r,c[10]=a,c[11]=t,c[12]=i,c[13]=s,c[14]=l):l=c[14],l});var tu=r("./src/next-devtools/dev-overlay/components/errors/dev-tools-indicator/utils.ts");let td=(0,E.createContext)(null);function tf({children:e,disabled:t=!1}){let r=(0,E.useRef)(new Set),n=(0,E.useCallback)(e=>{r.current.add(e)},[]),o=(0,E.useCallback)(e=>{r.current.delete(e)},[]),a=(0,E.useMemo)(()=>({register:n,unregister:o,handles:r.current,disabled:t}),[n,o,t]);return(0,z.jsx)(td.Provider,{value:a,children:e})}function tp(){return(0,E.useContext)(td)}function th(e){let t,r,n,o,a,i,s,l,c,u=(0,S.c)(19);u[0]!==e?({children:t,ref:n,...r}=e,u[0]=e,u[1]=t,u[2]=r,u[3]=n):(t=u[1],r=u[2],n=u[3]);let d=(0,E.useRef)(null),f=tp();u[4]!==n?(o=e=>{d.current=e??null,"function"==typeof n?n(e):n&&"object"==typeof n&&(n.current=e)},u[4]=n,u[5]=o):o=u[5];let p=o;u[6]!==f?(a=()=>{if(!f||!d.current||f.disabled)return;let e=d.current;return f.register(e),()=>f.unregister(e)},i=[f],u[6]=f,u[7]=a,u[8]=i):(a=u[7],i=u[8]),(0,E.useEffect)(a,i);let h=f?.disabled?"default":"grab";return u[9]!==r.style?(s=r.style||{},u[9]=r.style,u[10]=s):s=u[10],u[11]!==h||u[12]!==s?(l={cursor:h,...s},u[11]=h,u[12]=s,u[13]=l):l=u[13],u[14]!==t||u[15]!==r||u[16]!==p||u[17]!==l?(c=(0,z.jsx)("div",{ref:p,...r,style:l,children:t}),u[14]=t,u[15]=r,u[16]=p,u[17]=l,u[18]=c):c=u[18],c}function tm(e){let t,r,n,o,a,i,s,l,c,u,d,f=(0,S.c)(18);f[0]!==e?({children:r,padding:i,position:n,setPosition:l,onDragStart:a,dragHandleSelector:o,disableDrag:c,avoidZone:t,...s}=e,f[0]=e,f[1]=t,f[2]=r,f[3]=n,f[4]=o,f[5]=a,f[6]=i,f[7]=s,f[8]=l,f[9]=c):(t=f[1],r=f[2],n=f[3],o=f[4],a=f[5],i=f[6],s=f[7],l=f[8],c=f[9]);let{ref:p,animate:h,...m}=function(e){let t=(0,E.useRef)(null),r=(0,E.useRef)({state:"idle"}),n=(0,E.useRef)(null),o=(0,E.useRef)({x:0,y:0}),a=(0,E.useRef)({x:0,y:0}),i=(0,E.useRef)(0),s=(0,E.useRef)([]),l=(0,E.useCallback)(()=>{if("drag"===r.current.state){let{pointerId:e}=r.current;t.current?.hasPointerCapture(e)&&t.current.releasePointerCapture(e)}r.current="drag"===r.current.state?{state:"drag-end"}:{state:"idle"},null!==n.current&&(n.current(),n.current=null),s.current=[],t.current?.classList.remove("dev-tools-grabbing"),t.current?.style.removeProperty("-webkit-user-select"),document.body.style.removeProperty("user-select"),document.body.style.removeProperty("-webkit-user-select")},[]);function c(e){t.current&&(a.current=e,t.current.style.translate=`${e.x}px ${e.y}px`)}function u(r){let n=t.current;null!==n&&(n.style.transition="translate 491.22ms var(--timing-bounce)",n.addEventListener("transitionend",function t(o){"translate"===o.propertyName&&(e.onAnimationEnd?.(r),a.current={x:0,y:0},n.style.transition="",n.removeEventListener("transitionend",t))}),c(r.translation))}function d(e){"drag-end"===r.current.state&&(e.preventDefault(),e.stopPropagation(),r.current={state:"idle"},t.current?.removeEventListener("click",d))}function f(n){if("press"===r.current.state){let a=n.clientX-o.current.x,i=n.clientY-o.current.y;Math.sqrt(a*a+i*i)>=e.threshold&&(r.current={state:"drag",pointerId:n.pointerId},t.current?.setPointerCapture(n.pointerId),t.current?.classList.add("dev-tools-grabbing"),t.current?.style.setProperty("-webkit-user-select","none"),document.body.style.userSelect="none",document.body.style.webkitUserSelect="none",e.onDragStart?.())}if("drag"!==r.current.state)return;let l={x:n.clientX,y:n.clientY},u=l.x-o.current.x,d=l.y-o.current.y;o.current=l,c({x:a.current.x+u,y:a.current.y+d});let f=Date.now();f-i.current>=10&&(s.current=[...s.current.slice(-5),{position:l,timestamp:f}]),i.current=f,e.onDrag?.(a.current)}function p(){let t=function(e){if(e.length<2)return{x:0,y:0};let t=e[0],r=e[e.length-1],n=r.timestamp-t.timestamp;return 0===n?{x:0,y:0}:{x:1e3*((r.position.x-t.position.x)/n),y:1e3*((r.position.y-t.position.y)/n)}}(s.current);l(),e.onDragEnd?.(a.current,t)}return(0,E.useLayoutEffect)(()=>{e.disabled&&l()},[l,e.disabled]),e.disabled?{ref:t,animate:u}:{ref:t,onPointerDown:function(a){0!==a.button||function(r){if(!r||!t.current)return!0;if(e.handles&&e.handles.size>0){let n=r;for(;n&&n!==t.current;){if(e.handles.has(n))return!0;n=n.parentElement}return!1}return!e.dragHandleSelector||null!==r.closest(e.dragHandleSelector)}(a.target)&&(o.current={x:a.clientX,y:a.clientY},r.current={state:"press"},window.addEventListener("pointermove",f),window.addEventListener("pointerup",p),window.addEventListener("pointercancel",p),null!==n.current&&(n.current(),n.current=null),n.current=()=>{window.removeEventListener("pointermove",f),window.removeEventListener("pointerup",p),window.removeEventListener("pointercancel",p)},t.current?.addEventListener("click",d))},animate:u}}({disabled:void 0!==c&&c,handles:tp()?.handles,threshold:5,onDragStart:a,onDragEnd:function(e,r){0===Math.sqrt(e.x*e.x+e.y*e.y)?p.current?.style.removeProperty("translate"):h(function(e){let r,o,a,s,l,c,u,{x:d,y:f}=e,h=(r=2*i,o=p.current?.offsetWidth||0,a=p.current?.offsetHeight||0,s=window.innerWidth-document.documentElement.clientWidth,c=(l=function(e){let n=e.includes("right"),i=e.includes("bottom"),l=n?window.innerWidth-s-r-o:0,c=i?window.innerHeight-r-a:0;if(t&&t.corner===e){let e=t.square+t.padding;i?c-=e:c+=e}return{x:l,y:c}})(n),{"top-left":(u=function(e){return{x:e.x-c.x,y:e.y-c.y}})(l("top-left")),"top-right":u(l("top-right")),"bottom-left":u(l("bottom-left")),"bottom-right":u(l("bottom-right"))}),m=Object.entries(h).map(e=>{let[t,r]=e;return{key:t,distance:Math.sqrt((d-r.x)**2+(f-r.y)**2)}}),g=Math.min(...m.map(tg)),v=m.find(e=>e.distance===g);return v?{translation:h[v.key],corner:v.key}:{corner:n,translation:h[n]}}({x:e.x+tv(r.x),y:e.y+tv(r.y)}))},onAnimationEnd:function(e){let{corner:t}=e;setTimeout(()=>{p.current?.style.removeProperty("translate"),l(t)})},dragHandleSelector:o});return f[10]!==s.style?(u={touchAction:"none",...s.style},f[10]=s.style,f[11]=u):u=f[11],f[12]!==r||f[13]!==m||f[14]!==s||f[15]!==p||f[16]!==u?(d=(0,z.jsx)("div",{...s,...m,ref:p,style:u,children:r}),f[12]=r,f[13]=m,f[14]=s,f[15]=p,f[16]=u,f[17]=d):d=f[17],d}function tg(e){return e.distance}function tv(e,t=.999){return e/1e3*t/(1-t)}let tx=20;function ty(){let e,t,r,n,o,a,i=(0,S.c)(20),{state:s,dispatch:l}=(0,P.OS)(),{panel:c,setPanel:u,setSelectedIndex:d}=e8(),f=tb();i[0]!==s.devToolsPosition?(e=s.devToolsPosition.split("-",2),i[0]=s.devToolsPosition,i[1]=e):e=i[1];let[p,h]=e;i[2]!==h||i[3]!==p?(t={"--animate-out-duration-ms":`${tu.ay}ms`,"--animate-out-timing-function":tu.OB,boxShadow:"none",[p]:`${tx}px`,[h]:`${tx}px`},i[2]=h,i[3]=p,i[4]=t):t=i[4];let m=t,g=null!==c;return i[5]!==l||i[6]!==f?(r=e=>{l({type:eu.Gu,devToolsPosition:e}),eI({devToolsPosition:e}),f(e)},i[5]=l,i[6]=f,i[7]=r):r=i[7],i[8]!==c||i[9]!==u||i[10]!==d?(n=(0,z.jsx)(to,{onTriggerClick:()=>{let e="panel-selector"===c?null:"panel-selector";if(u(e),!e)return void d(-1)}}),i[8]=c,i[9]=u,i[10]=d,i[11]=n):n=i[11],i[12]!==s.devToolsPosition||i[13]!==g||i[14]!==r||i[15]!==n?(o=(0,z.jsx)(tm,{disableDrag:g,padding:tx,position:s.devToolsPosition,setPosition:r,children:n}),i[12]=s.devToolsPosition,i[13]=g,i[14]=r,i[15]=n,i[16]=o):o=i[16],i[17]!==m||i[18]!==o?(a=(0,z.jsx)(tc,{id:"devtools-indicator","data-nextjs-toast":!0,style:m,children:o}),i[17]=m,i[18]=o,i[19]=a):a=i[19],a}let tb=()=>{let e,t=(0,S.c)(3),{state:r,dispatch:n}=(0,P.OS)();return t[0]!==n||t[1]!==r.devToolsPanelPosition?(e=e=>{n({type:eu.Zl,devToolsPanelPosition:e,key:eu.TA});let t=Object.keys(r.devToolsPanelPosition).filter(tw),o={[eu.TA]:e};t.forEach(t=>{n({type:eu.Zl,devToolsPanelPosition:e,key:t}),o[t]=e}),eI({devToolsPanelPosition:o})},t[0]=n,t[1]=r.devToolsPanelPosition,t[2]=e):e=t[2],e};function tw(e){return e.startsWith(eu.Ou)}let t_=(0,E.createContext)({});function tk(e){let t,r,n,o,a,i,s,l,c,u,d,f,p,h=(0,S.c)(37);h[0]!==e?({index:r,label:n,value:i,onClick:o,href:t,...a}=e,h[0]=e,h[1]=t,h[2]=r,h[3]=n,h[4]=o,h[5]=a,h[6]=i):(t=h[1],r=h[2],n=h[3],o=h[4],a=h[5],i=h[6]);let m="function"==typeof o||"string"==typeof t,{closeMenu:g,selectedIndex:v,setSelectedIndex:x}=(0,E.useContext)(t_),y=v===r;h[7]!==g||h[8]!==t||h[9]!==m||h[10]!==o?(s=function(){m&&(o?.(),g?.(),t&&window.open(t,"_blank","noopener, noreferrer"))},h[7]=g,h[8]=t,h[9]=m,h[10]=o,h[11]=s):s=h[11];let b=s;h[12]!==r||h[13]!==m||h[14]!==v||h[15]!==x?(l=()=>{m&&void 0!==r&&v!==r&&x(r)},h[12]=r,h[13]=m,h[14]=v,h[15]=x,h[16]=l):l=h[16],h[17]!==x?(c=()=>x(-1),h[17]=x,h[18]=c):c=h[18],h[19]!==b?(u=e=>{("Enter"===e.key||" "===e.key)&&b()},h[19]=b,h[20]=u):u=h[20];let w=m?"menuitem":void 0,_=y?0:-1;return h[21]!==n?(d=(0,z.jsx)("span",{className:"dev-tools-indicator-label",children:n}),h[21]=n,h[22]=d):d=h[22],h[23]!==i?(f=(0,z.jsx)("span",{className:"dev-tools-indicator-value",children:i}),h[23]=i,h[24]=f):f=h[24],h[25]!==b||h[26]!==r||h[27]!==a||h[28]!==y||h[29]!==l||h[30]!==c||h[31]!==u||h[32]!==w||h[33]!==_||h[34]!==d||h[35]!==f?(p=(0,z.jsxs)("div",{className:"dev-tools-indicator-item","data-index":r,"data-selected":y,onClick:b,onMouseMove:l,onMouseLeave:c,onKeyDown:u,role:w,tabIndex:_,...a,children:[d,f]}),h[25]=b,h[26]=r,h[27]=a,h[28]=y,h[29]=l,h[30]=c,h[31]=u,h[32]=w,h[33]=_,h[34]=d,h[35]=f,h[36]=p):p=h[36],p}let tj=e=>{let t,r,n,o,a,i,s,l,c,u,d,f,p,h,m,g,v,x,y,b,w,_,k,j,C=(0,S.c)(63),{closeOnClickOutside:T,items:N}=e,I=void 0===T||T,{state:R}=(0,P.OS)(),{setPanel:L,triggerRef:O,setSelectedIndex:M,selectedIndex:A}=e8(),{mounted:D}=lg();C[0]!==R.devToolsPosition?(t=R.devToolsPosition.split("-",2),C[0]=R.devToolsPosition,C[1]=t):t=C[1];let[F,$]=t,U=(0,E.useRef)(null);C[2]!==I||C[3]!==L||C[4]!==M?(r=e=>{switch(e){case"escape":L(null),M(-1);return;case"outside":if(!I)return;L(null),M(-1);return;default:return null}},C[2]=I,C[3]=L,C[4]=M,C[5]=r):r=C[5],(0,tu.xj)(U,O,I&&D,r),C[6]!==A||C[7]!==M?(n=()=>{tT({index:-1===A?"first":A,menuRef:U,setSelectedIndex:M})},C[6]=A,C[7]=M,C[8]=n):n=C[8];let Z=(0,E.useEffectEvent)(n);C[9]!==Z?(o=()=>{U.current?.focus(),Z()},C[9]=Z,C[10]=o):o=C[10],C[11]===Symbol.for("react.memo_cache_sentinel")?(a=[],C[11]=a):a=C[11],(0,E.useLayoutEffect)(o,a),C[12]!==R?(i=tt(R),C[12]=R,C[13]=i):i=C[13];let q=i,[B,V]=R.devToolsPosition.split("-",2),H=F===B&&$===V?q:tx,W=`${H}px`,G="top"===F?"bottom":"top",K="left"===$?"right":"left";C[14]!==$||C[15]!==K||C[16]!==W||C[17]!==G||C[18]!==F?(s={[F]:W,[$]:`${tx}px`,[G]:"auto",[K]:"auto"},C[14]=$,C[15]=K,C[16]=W,C[17]=G,C[18]=F,C[19]=s):s=C[19];let Y=s;if(C[20]!==N||C[21]!==Y||C[22]!==A||C[23]!==M){let e,t=N.filter(tN),r=t.filter(tI),n=t.filter(tz);p=U,h=function(e){e.preventDefault();let r=t.filter(tR).length;switch(e.key){case"ArrowDown":tT({index:A>=r-1?0:A+1,menuRef:U,setSelectedIndex:M});break;case"ArrowUp":tT({index:A<=0?r-1:A-1,menuRef:U,setSelectedIndex:M});break;case"Home":tT({index:"first",menuRef:U,setSelectedIndex:M});break;case"End":tT({index:"last",menuRef:U,setSelectedIndex:M});break;case"n":e.ctrlKey&&tT({index:A>=r-1?0:A+1,menuRef:U,setSelectedIndex:M});break;case"p":e.ctrlKey&&tT({index:A<=0?r-1:A-1,menuRef:U,setSelectedIndex:M})}},m="nextjs-dev-tools-menu",g="menu",v="ltr",x="vertical",y="Next.js Dev Tools Items",b=-1,C[38]!==Y?(w={outline:0,WebkitFontSmoothing:"antialiased",display:"flex",flexDirection:"column",alignItems:"flex-start",background:"var(--color-background-100)",backgroundClip:"padding-box",boxShadow:"var(--shadow-menu)",borderRadius:"var(--rounded-xl)",position:"fixed",fontFamily:"var(--font-stack-sans)",zIndex:"var(--top-z-index)",overflow:"hidden",opacity:1,minWidth:"248px",transition:"opacity var(--animate-out-duration-ms) var(--animate-out-timing-function)",border:"1px solid var(--color-gray-alpha-400)",...Y},C[38]=Y,C[39]=w):w=C[39],l=t_,C[40]!==A||C[41]!==M?(d={selectedIndex:A,setSelectedIndex:M},C[40]=A,C[41]=M,C[42]=d):d=C[42],C[43]===Symbol.for("react.memo_cache_sentinel")?(e={padding:"6px",width:"100%"},C[43]=e):e=C[43],f=(0,z.jsx)("div",{style:e,children:r.map((e,t)=>(0,z.jsx)(tk,{title:e.title,label:e.label,value:e.value,onClick:e.onClick,index:e.onClick?tS(r,t):void 0,...e.attributes},e.label))}),c="dev-tools-indicator-footer",u=n.map((e,t)=>(0,z.jsx)(tk,{title:e.title,label:e.label,value:e.value,onClick:e.onClick,...e.attributes,index:e.onClick?tS(n,t)+r.filter(e=>e.onClick).length:void 0},e.label)),C[20]=N,C[21]=Y,C[22]=A,C[23]=M,C[24]=l,C[25]=c,C[26]=u,C[27]=d,C[28]=f,C[29]=p,C[30]=h,C[31]=m,C[32]=g,C[33]=v,C[34]=x,C[35]=y,C[36]=b,C[37]=w}else l=C[24],c=C[25],u=C[26],d=C[27],f=C[28],p=C[29],h=C[30],m=C[31],g=C[32],v=C[33],x=C[34],y=C[35],b=C[36],w=C[37];return C[44]!==c||C[45]!==u?(_=(0,z.jsx)("div",{className:c,children:u}),C[44]=c,C[45]=u,C[46]=_):_=C[46],C[47]!==l||C[48]!==d||C[49]!==f||C[50]!==_?(k=(0,z.jsxs)(l,{value:d,children:[f,_]}),C[47]=l,C[48]=d,C[49]=f,C[50]=_,C[51]=k):k=C[51],C[52]!==p||C[53]!==h||C[54]!==m||C[55]!==g||C[56]!==v||C[57]!==x||C[58]!==y||C[59]!==b||C[60]!==w||C[61]!==k?(j=(0,z.jsx)("div",{ref:p,onKeyDown:h,id:m,role:g,dir:v,"aria-orientation":x,"aria-label":y,tabIndex:b,style:w,children:k}),C[52]=p,C[53]=h,C[54]=m,C[55]=g,C[56]=v,C[57]=x,C[58]=y,C[59]=b,C[60]=w,C[61]=k,C[62]=j):j=C[62],j};function tS(e,t){let r=0;for(let n=0;n<=t&&n<e.length;n++)if(e[n].onClick){if(n===t)return r;r++}return r}function tC(e){let t,r,n=(0,S.c)(5),{children:o,variant:a}=e,i=void 0===a?"issue":a,s=o>0;return n[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("span",{className:"dev-tools-indicator-issue-count-indicator"}),n[0]=t):t=n[0],n[1]!==o||n[2]!==s||n[3]!==i?(r=(0,z.jsxs)("span",{className:"dev-tools-indicator-issue-count","data-has-issues":s,"data-variant":i,children:[t,o]}),n[1]=o,n[2]=s,n[3]=i,n[4]=r):r=n[4],r}function tE(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",children:(0,z.jsx)("path",{fill:"#666",fillRule:"evenodd",clipRule:"evenodd",d:"M5.50011 1.93945L6.03044 2.46978L10.8537 7.293C11.2442 7.68353 11.2442 8.31669 10.8537 8.70722L6.03044 13.5304L5.50011 14.0608L4.43945 13.0001L4.96978 12.4698L9.43945 8.00011L4.96978 3.53044L4.43945 3.00011L5.50011 1.93945Z"})}),t[0]=e):e=t[0],e}function tT({index:e,menuRef:t,setSelectedIndex:r}){if("first"===e)return void setTimeout(()=>{let e=t.current?.querySelectorAll('[role="menuitem"]');e&&tT({index:Number(e[0].getAttribute("data-index")),menuRef:t,setSelectedIndex:r})});if("last"===e)return void setTimeout(()=>{let e=t.current?.querySelectorAll('[role="menuitem"]');e&&tT({index:e.length-1,menuRef:t,setSelectedIndex:r})});let n=t.current?.querySelector(`[data-index="${e}"]`);n&&(r(e),n?.focus())}function tN(e){return!!e}function tI(e){return!e.footer}function tz(e){return e.footer}function tR(e){return e.onClick}let tP=(0,E.createContext)(null),tL=e=>{let t=.95*window.innerWidth,r=.95*window.innerHeight;return{width:Math.min(t,Math.max(e.minWidth,e.width)),height:Math.min(r,Math.max(e.minHeight,e.height))}},tO=e=>{let t,r,n,o,a,i,s,l,c=(0,S.c)(34),{value:u,children:d}=e,f=u.minWidth??100,p=u.minHeight??80,h=u.maxWidth,m=u.maxHeight,[g,v]=(0,E.useState)(null),x=u.storageKey??eu.BI,{resizeRef:y}=u;c[0]!==g||c[1]!==p||c[2]!==f||c[3]!==y||c[4]!==x||c[5]!==u.devToolsPanelSize?(t=()=>{if(!y.current||null!==g)return;let e=u.devToolsPanelSize[x];if(!e)return;let{height:t,width:r}=tL({...e,minWidth:f??100,minHeight:p??80});return y.current.style.width=`${r}px`,y.current.style.height=`${t}px`,!0},c[0]=g,c[1]=p,c[2]=f,c[3]=y,c[4]=x,c[5]=u.devToolsPanelSize,c[6]=t):t=c[6];let b=t;c[7]!==b||c[8]!==p||c[9]!==f||c[10]!==y||c[11]!==u.initialSize?(r=()=>{if(!b()&&y.current&&u.initialSize?.height&&u.initialSize.width){let{height:e,width:t}=tL({height:u.initialSize.height,width:u.initialSize.width,minWidth:f??100,minHeight:p??80});y.current.style.width=`${t}px`,y.current.style.height=`${e}px`}},c[7]=b,c[8]=p,c[9]=f,c[10]=y,c[11]=u.initialSize,c[12]=r):r=c[12];let w=(0,E.useEffectEvent)(r);c[13]!==w?(n=()=>{w()},c[13]=w,c[14]=n):n=c[14],c[15]===Symbol.for("react.memo_cache_sentinel")?(o=[],c[15]=o):o=c[15],(0,E.useLayoutEffect)(n,o),c[16]!==b?(a=()=>(window.addEventListener("resize",b),()=>window.removeEventListener("resize",b)),c[16]=b,c[17]=a):a=c[17];let _=u.initialSize?.height,k=u.initialSize?.width;return c[18]!==b||c[19]!==_||c[20]!==k||c[21]!==u.resizeRef?(i=[b,_,k,u.resizeRef],c[18]=b,c[19]=_,c[20]=k,c[21]=u.resizeRef,c[22]=i):i=c[22],(0,E.useLayoutEffect)(a,i),c[23]!==g||c[24]!==m||c[25]!==h||c[26]!==p||c[27]!==f||c[28]!==x||c[29]!==u.resizeRef?(s={resizeRef:u.resizeRef,minWidth:f,minHeight:p,maxWidth:h,maxHeight:m,draggingDirection:g,setDraggingDirection:v,storageKey:x},c[23]=g,c[24]=m,c[25]=h,c[26]=p,c[27]=f,c[28]=x,c[29]=u.resizeRef,c[30]=s):s=c[30],c[31]!==d||c[32]!==s?(l=(0,z.jsx)(tP.Provider,{value:s,children:d}),c[31]=d,c[32]=s,c[33]=l):l=c[33],l};var tM=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/devtools-panel/resize/resize-handle.css"),tA={};tA.styleTagTransform=b(),tA.setAttributes=g(),tA.insert=h(),tA.domAPI=f(),tA.insertStyleElement=x(),u()(tM.A,tA),tM.A&&tM.A.locals&&tM.A.locals;let tD=e=>{let t,r,n,o,a,i,s,l,c=(0,S.c)(31),{direction:u,position:d}=e,{resizeRef:f,minWidth:p,minHeight:h,maxWidth:m,maxHeight:g,storageKey:v,draggingDirection:x,setDraggingDirection:y}=(()=>{let e=(0,E.useContext)(tP);if(!e)throw Error("useResize must be used within a Resize provider");return e})();c[0]===Symbol.for("react.memo_cache_sentinel")?(t={top:0,right:0,bottom:0,left:0},c[0]=t):t=c[0];let[b,w]=(0,E.useState)(t);c[1]!==f?(r=()=>{if(!f.current)return;let e=f.current,t=window.getComputedStyle(e);w({top:parseFloat(t.borderTopWidth)||0,right:parseFloat(t.borderRightWidth)||0,bottom:parseFloat(t.borderBottomWidth)||0,left:parseFloat(t.borderLeftWidth)||0})},n=[f],c[1]=f,c[2]=r,c[3]=n):(r=c[2],n=c[3]),(0,E.useLayoutEffect)(r,n),c[4]!==u||c[5]!==g||c[6]!==m||c[7]!==h||c[8]!==p||c[9]!==f||c[10]!==y||c[11]!==v?(o=e=>{if(e.preventDefault(),!f.current)return;y(u);let t=f.current,r=t.getBoundingClientRect(),n=e.clientX,o=e.clientY,a=e=>{let{newWidth:a,newHeight:i}=tF(u,e.clientX-n,e.clientY-o,r,p,h,m,g);void 0!==a&&(t.style.width=`${a}px`),void 0!==i&&(t.style.height=`${i}px`)},i=()=>{if(y(null),document.removeEventListener("mousemove",a),document.removeEventListener("mouseup",i),!f.current)return;let{width:e,height:t}=f.current.getBoundingClientRect();eI({devToolsPanelSize:{[v]:{width:e,height:t}}})};document.addEventListener("mousemove",a),document.addEventListener("mouseup",i)},c[4]=u,c[5]=g,c[6]=m,c[7]=h,c[8]=p,c[9]=f,c[10]=y,c[11]=v,c[12]=o):o=c[12];let _=o;if(!(!d.split("-").includes(u)&&(!u.includes("-")||u===function(e){switch(e){case"top-left":return"bottom-right";case"top-right":return"bottom-left";case"bottom-left":return"top-right";case"bottom-right":return"top-left";default:return null}}(d))))return null;let k=b.left+b.right,j=b.top+b.bottom;c[13]!==u?(a=u.includes("-"),c[13]=u,c[14]=a):a=c[14];let C=a,T=`resize-container ${u} ${x&&x!==u?"no-hover":""}`;return c[15]!==_||c[16]!==T?(i=(0,z.jsx)("div",{className:T,onMouseDown:_}),c[15]=_,c[16]=T,c[17]=i):i=c[17],c[18]!==b.bottom||c[19]!==b.left||c[20]!==b.right||c[21]!==b.top||c[22]!==u||c[23]!==x||c[24]!==C||c[25]!==k||c[26]!==j?(s=!C&&(0,z.jsx)("div",{className:`resize-line ${u} ${x===u?"dragging":""}`,style:{"--border-horizontal":`${k}px`,"--border-vertical":`${j}px`,"--border-top":`${b.top}px`,"--border-right":`${b.right}px`,"--border-bottom":`${b.bottom}px`,"--border-left":`${b.left}px`}}),c[18]=b.bottom,c[19]=b.left,c[20]=b.right,c[21]=b.top,c[22]=u,c[23]=x,c[24]=C,c[25]=k,c[26]=j,c[27]=s):s=c[27],c[28]!==i||c[29]!==s?(l=(0,z.jsxs)(z.Fragment,{children:[i,s]}),c[28]=i,c[29]=s,c[30]=l):l=c[30],l},tF=(e,t,r,n,o,a,i,s)=>{let l=i??.95*window.innerWidth,c=s??.95*window.innerHeight;switch(e){case"right":return{newWidth:Math.min(l,Math.max(o,n.width+t)),newHeight:n.height};case"left":return{newWidth:Math.min(l,Math.max(o,n.width-t)),newHeight:n.height};case"bottom":return{newWidth:n.width,newHeight:Math.min(c,Math.max(a,n.height+r))};case"top":return{newWidth:n.width,newHeight:Math.min(c,Math.max(a,n.height-r))};case"top-left":return{newWidth:Math.min(l,Math.max(o,n.width-t)),newHeight:Math.min(c,Math.max(a,n.height-r))};case"top-right":return{newWidth:Math.min(l,Math.max(o,n.width+t)),newHeight:Math.min(c,Math.max(a,n.height-r))};case"bottom-left":return{newWidth:Math.min(l,Math.max(o,n.width-t)),newHeight:Math.min(c,Math.max(a,n.height+r))};case"bottom-right":return{newWidth:Math.min(l,Math.max(o,n.width+t)),newHeight:Math.min(c,Math.max(a,n.height+r))};default:return null}};var t$=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/panel/dynamic-panel.css"),tU={};function tZ(e,t="width"){if("number"==typeof e)return e;let r=document.createElement("div");r.style.position="absolute",r.style.visibility="hidden","width"===t?r.style.width=e:r.style.height=e,document.body.appendChild(r);let n="width"===t?r.offsetWidth:r.offsetHeight;return document.body.removeChild(r),n}function tq(e){let t,r,n,o,a,i,s,l,c,u,d,f,p,h,m,g,v,x,y,b,w,_,k,j,C=(0,S.c)(93),{header:T,children:N,draggable:I,sizeConfig:R,closeOnClickOutside:L,sharePanelSizeGlobally:O,sharePanelPositionGlobally:M,containerProps:A,onClose:D,keepBehindErrorOverlay:F}=e,$=void 0!==I&&I;C[0]!==R?(t=void 0===R?{kind:"resizable",minWidth:400,minHeight:350,maxWidth:1e3,maxHeight:1e3,initialSize:{height:400,width:500}}:R,C[0]=R,C[1]=t):t=C[1];let U=t,Z=void 0!==L&&L,{setPanel:q}=e8(),{name:B,mounted:V}=lg(),H=void 0===O||O?eu.BI:`${eu.ef}_${B}`,W=void 0===M||M?eu.TA:`${eu.Ou}_${B}`,{dispatch:G,state:K}=(0,P.OS)(),Y=K.devToolsPanelPosition[W]??K.devToolsPosition;C[2]!==Y?(r=Y.split("-",2),C[2]=Y,C[3]=r):r=C[3];let[X,Q]=r,J=(0,E.useRef)(null),{triggerRef:ee}=e8();C[4]!==Z||C[5]!==D||C[6]!==q?(n=e=>{if(D)return void D(e);switch(e){case"escape":return void q("panel-selector");case"outside":Z&&q("panel-selector");return;default:return null}},C[4]=Z,C[5]=D,C[6]=q,C[7]=n):n=C[7],(0,tu.xj)(J,ee,V,n),C[8]!==V?(o=()=>{V&&J.current?.focus()},a=[V],C[8]=V,C[9]=o,C[10]=a):(o=C[9],a=C[10]),(0,E.useEffect)(o,a),C[11]!==K?(i=tt(K),C[11]=K,C[12]=i):i=C[12];let et=i,[er,en]=K.devToolsPosition.split("-",2),eo=X===er&&Q===en?et:tx,ea=`${eo}px`,ei="top"===X?"bottom":"top",es="left"===Q?"right":"left";C[13]!==Q||C[14]!==X||C[15]!==ea||C[16]!==ei||C[17]!==es?(s={[X]:ea,[Q]:`${tx}px`,[ei]:"auto",[es]:"auto"},C[13]=Q,C[14]=X,C[15]=ea,C[16]=ei,C[17]=es,C[18]=s):s=C[18];let el=s,ec="resizable"===U.kind,ed=void 0!==F&&F&&K.isErrorOverlayOpen,ef=function(e,t,r,n){let o,a,i,s=(0,S.c)(11);s[0]!==n||s[1]!==r||s[2]!==t||s[3]!==e?(o=()=>({minWidth:e?tZ(e,"width"):void 0,minHeight:t?tZ(t,"height"):void 0,maxWidth:r?tZ(r,"width"):void 0,maxHeight:n?tZ(n,"height"):void 0}),s[0]=n,s[1]=r,s[2]=t,s[3]=e,s[4]=o):o=s[4];let[l,c]=(0,E.useState)(o);return s[5]!==n||s[6]!==r||s[7]!==t||s[8]!==e?(a=()=>{let o=()=>{c({minWidth:e?tZ(e,"width"):void 0,minHeight:t?tZ(t,"height"):void 0,maxWidth:r?tZ(r,"width"):void 0,maxHeight:n?tZ(n,"height"):void 0})};return window.addEventListener("resize",o),()=>window.removeEventListener("resize",o)},i=[e,t,r,n],s[5]=n,s[6]=r,s[7]=t,s[8]=e,s[9]=a,s[10]=i):(a=s[9],i=s[10]),(0,E.useEffect)(a,i),l}(ec?U.minWidth:void 0,ec?U.minHeight:void 0,ec?U.maxWidth:void 0,ec?U.maxHeight:void 0),ep=ef.minWidth,eh=ef.minHeight,em=ef.maxWidth,eg=ef.maxHeight,ev=B?`${eu.ef}_${B}`:eu.BI,ex=K.devToolsPanelSize[ev];C[19]!==U.height||C[20]!==U.initialSize||C[21]!==U.kind||C[22]!==U.width?(l="resizable"===U.kind?U.initialSize:"fixed"===U.kind?{height:U.height,width:U.width}:void 0,C[19]=U.height,C[20]=U.initialSize,C[21]=U.kind,C[22]=U.width,C[23]=l):l=C[23],C[24]!==eg||C[25]!==em||C[26]!==eh||C[27]!==ep||C[28]!==H||C[29]!==K.devToolsPanelSize||C[30]!==K.devToolsPosition||C[31]!==l?(c={resizeRef:J,initialSize:l,minWidth:ep,minHeight:eh,maxWidth:em,maxHeight:eg,devToolsPosition:K.devToolsPosition,devToolsPanelSize:K.devToolsPanelSize,storageKey:H},C[24]=eg,C[25]=em,C[26]=eh,C[27]=ep,C[28]=H,C[29]=K.devToolsPanelSize,C[30]=K.devToolsPosition,C[31]=l,C[32]=c):c=C[32];let ey=ed||void 0,eb=ed?0x7ffffffd:void 0;C[33]!==ec||C[34]!==eg||C[35]!==em||C[36]!==eh||C[37]!==ep||C[38]!==ex||C[39]!==U.height||C[40]!==U.kind||C[41]!==U.width?(u=ec?{"--panel-min-width":ep?`${ep}px`:void 0,"--panel-min-height":eh?`${eh}px`:void 0,"--panel-max-width":em?`${em}px`:void 0,"--panel-max-height":eg?`${eg}px`:void 0}:"auto"===U.kind?{"--panel-height":"auto","--panel-width":`${ex?ex.width:U.width}px`}:{"--panel-height":`${ex?ex.height:U.height}px`,"--panel-width":`${ex?ex.width:U.width}px`},C[33]=ec,C[34]=eg,C[35]=em,C[36]=eh,C[37]=ep,C[38]=ex,C[39]=U.height,C[40]=U.kind,C[41]=U.width,C[42]=u):u=C[42],C[43]!==el.bottom||C[44]!==el.left||C[45]!==el.right||C[46]!==el.top||C[47]!==eb||C[48]!==u?(d={zIndex:eb,"--panel-top":el.top,"--panel-bottom":el.bottom,"--panel-left":el.left,"--panel-right":el.right,...u},C[43]=el.bottom,C[44]=el.left,C[45]=el.right,C[46]=el.top,C[47]=eb,C[48]=u,C[49]=d):d=C[49];let ew=d,e_=!$,ek=25/K.scale;C[50]!==K.devToolsPosition||C[51]!==ek?(f={corner:K.devToolsPosition,square:ek,padding:tx},C[50]=K.devToolsPosition,C[51]=ek,C[52]=f):f=C[52],C[53]!==G||C[54]!==W||C[55]!==U.kind?(p=e=>{G({type:eu.Zl,devToolsPanelPosition:e,key:W}),"resizable"===U.kind&&eI({devToolsPanelPosition:{[W]:e}})},C[53]=G,C[54]=W,C[55]=U.kind,C[56]=p):p=C[56],C[57]===Symbol.for("react.memo_cache_sentinel")?(h={overflow:"auto",width:"100%",height:"100%"},C[57]=h):h=C[57];let ej=!$,eS=`panel-content-container ${A?.className||""}`,eC=A?.style;return C[58]!==eC?(m={...eC},C[58]=eC,C[59]=m):m=C[59],C[60]!==T?(g=(0,z.jsx)(th,{children:T}),C[60]=T,C[61]=g):g=C[61],C[62]!==N?(v=(0,z.jsx)("div",{"data-nextjs-scrollable-content":!0,className:"draggable-content",children:N}),C[62]=N,C[63]=v):v=C[63],C[64]!==A||C[65]!==eS||C[66]!==m||C[67]!==g||C[68]!==v?(x=(0,z.jsxs)("div",{...A,className:eS,style:m,children:[g,v]}),C[64]=A,C[65]=eS,C[66]=m,C[67]=g,C[68]=v,C[69]=x):x=C[69],C[70]!==Y||C[71]!==ec||C[72]!==U.sides?(y=ec&&(0,z.jsxs)(z.Fragment,{children:[(!U.sides||U.sides.includes("vertical"))&&(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(tD,{position:Y,direction:"top"}),(0,z.jsx)(tD,{position:Y,direction:"bottom"})]}),(!U.sides||U.sides.includes("horizontal"))&&(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(tD,{position:Y,direction:"right"}),(0,z.jsx)(tD,{position:Y,direction:"left"})]}),(!U.sides||U.sides.includes("diagonal"))&&(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(tD,{position:Y,direction:"top-left"}),(0,z.jsx)(tD,{position:Y,direction:"top-right"}),(0,z.jsx)(tD,{position:Y,direction:"bottom-left"}),(0,z.jsx)(tD,{position:Y,direction:"bottom-right"})]})]}),C[70]=Y,C[71]=ec,C[72]=U.sides,C[73]=y):y=C[73],C[74]!==x||C[75]!==y?(b=(0,z.jsxs)(z.Fragment,{children:[x,y]}),C[74]=x,C[75]=y,C[76]=b):b=C[76],C[77]!==Y||C[78]!==f||C[79]!==p||C[80]!==ej||C[81]!==b?(w=(0,z.jsx)(tm,{dragHandleSelector:".resize-container",avoidZone:f,padding:tx,position:Y,setPosition:p,style:h,disableDrag:ej,children:b}),C[77]=Y,C[78]=f,C[79]=p,C[80]=ej,C[81]=b,C[82]=w):w=C[82],C[83]!==e_||C[84]!==w?(_=(0,z.jsx)(tf,{disabled:e_,children:w}),C[83]=e_,C[84]=w,C[85]=_):_=C[85],C[86]!==ey||C[87]!==ew||C[88]!==_?(k=(0,z.jsx)("div",{tabIndex:-1,ref:J,className:"dynamic-panel-container",inert:ey,style:ew,children:_}),C[86]=ey,C[87]=ew,C[88]=_,C[89]=k):k=C[89],C[90]!==c||C[91]!==k?(j=(0,z.jsx)(tO,{value:c,children:k}),C[90]=c,C[91]=k,C[92]=j):j=C[92],j}function tB(e){let t,r,n,o,a,i,s=(0,S.c)(10);s[0]!==e?({routerType:r,...t}=e,s[0]=e,s[1]=t,s[2]=r):(t=s[1],r=s[2]),s[3]===Symbol.for("react.memo_cache_sentinel")?(n=(0,z.jsxs)("p",{className:"dev-tools-info-paragraph",children:["The path"," ",(0,z.jsx)("code",{className:"dev-tools-info-code",children:window.location.pathname})," ",'is marked as "static" since it will be prerendered during the build time.']}),s[3]=n):n=s[3];let l="pages"===r?"https://nextjs.org/docs/pages/building-your-application/data-fetching/incremental-static-regeneration":"https://nextjs.org/docs/app/building-your-application/data-fetching/incremental-static-regeneration";return s[4]!==l?(o=(0,z.jsxs)("p",{className:"dev-tools-info-paragraph",children:["With Static Rendering, routes are rendered at build time, or in the background after"," ",(0,z.jsx)("a",{className:"dev-tools-info-link",href:l,target:"_blank",rel:"noopener noreferrer",children:"data revalidation"}),"."]}),s[4]=l,s[5]=o):o=s[5],s[6]===Symbol.for("react.memo_cache_sentinel")?(a=(0,z.jsx)("p",{className:"dev-tools-info-paragraph",children:"Static rendering is useful when a route has data that is not personalized to the user and can be known at build time, such as a static blog post or a product page."}),s[6]=a):a=s[6],s[7]!==t||s[8]!==o?(i=(0,z.jsxs)("article",{className:"dev-tools-info-article",...t,children:[n,o,a]}),s[7]=t,s[8]=o,s[9]=i):i=s[9],i}function tV(e){let t,r,n,o,a,i,s,l=(0,S.c)(11);return l[0]!==e?({routerType:r,...t}=e,l[0]=e,l[1]=t,l[2]=r):(t=l[1],r=l[2]),l[3]===Symbol.for("react.memo_cache_sentinel")?(n=(0,z.jsx)("code",{className:"dev-tools-info-code",children:window.location.pathname}),l[3]=n):n=l[3],l[4]===Symbol.for("react.memo_cache_sentinel")?(o=(0,z.jsxs)("p",{className:"dev-tools-info-paragraph",children:["The path"," ",n," ",'is marked as "dynamic" since it will be rendered for each user at'," ",(0,z.jsx)("strong",{children:"request time"}),"."]}),a=(0,z.jsx)("p",{className:"dev-tools-info-paragraph",children:"Dynamic rendering is useful when a route has data that is personalized to the user or has information that can only be known at request time, such as cookies or the URL's search params."}),l[4]=o,l[5]=a):(o=l[4],a=l[5]),l[6]!==r?(i="pages"===r?(0,z.jsxs)("p",{className:"dev-tools-info-pagraph",children:["Exporting the"," ",(0,z.jsx)("a",{className:"dev-tools-info-link",href:"https://nextjs.org/docs/pages/building-your-application/data-fetching/get-server-side-props",target:"_blank",rel:"noopener noreferrer",children:"getServerSideProps"})," ","function will opt the route into dynamic rendering. This function will be called by the server on every request."]}):(0,z.jsxs)("p",{className:"dev-tools-info-paragraph",children:["During rendering, if a"," ",(0,z.jsx)("a",{className:"dev-tools-info-link",href:"https://nextjs.org/docs/app/building-your-application/rendering/server-components#dynamic-apis",target:"_blank",rel:"noopener noreferrer",children:"Dynamic API"})," ","or a"," ",(0,z.jsx)("a",{className:"dev-tools-info-link",href:"https://nextjs.org/docs/app/api-reference/functions/fetch",target:"_blank",rel:"noopener noreferrer",children:"fetch"})," ","option of"," ",(0,z.jsx)("code",{className:"dev-tools-info-code",children:"{ cache: 'no-store' }"})," ","is discovered, Next.js will switch to dynamically rendering the whole route."]}),l[6]=r,l[7]=i):i=l[7],l[8]!==t||l[9]!==i?(s=(0,z.jsxs)("article",{className:"dev-tools-info-article",...t,children:[o,a,i]}),l[8]=t,l[9]=i,l[10]=s):s=l[10],s}tU.styleTagTransform=b(),tU.setAttributes=g(),tU.insert=h(),tU.domAPI=f(),tU.insertStyleElement=x(),u()(t$.A,tU),t$.A&&t$.A.locals&&t$.A.locals;let tH={pages:{static:"https://nextjs.org/docs/pages/building-your-application/rendering/static-site-generation",dynamic:"https://nextjs.org/docs/pages/building-your-application/rendering/server-side-rendering"},app:{static:"https://nextjs.org/docs/app/building-your-application/rendering/server-components#static-rendering-default",dynamic:"https://nextjs.org/docs/app/building-your-application/rendering/server-components#dynamic-rendering"}};function tW(e){let t,r,n,o,a=(0,S.c)(8);return a[0]!==e?({routerType:n,isStaticRoute:t,...r}=e,a[0]=e,a[1]=t,a[2]=r,a[3]=n):(t=a[1],r=a[2],n=a[3]),a[4]!==t||a[5]!==r||a[6]!==n?(o=t?(0,z.jsx)(tB,{routerType:n,...r}):(0,z.jsx)(tV,{routerType:n,...r}),a[4]=t,a[5]=r,a[6]=n,a[7]=o):o=a[7],o}var tG=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/overview/segment-explorer.css"),tK={};tK.styleTagTransform=b(),tK.setAttributes=g(),tK.insert=h(),tK.domAPI=f(),tK.insertStyleElement=x(),u()(tG.A,tK),tG.A&&tG.A.locals&&tG.A.locals;var tY=r("./src/next-devtools/dev-overlay/segment-explorer-trie.ts"),tX=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/overview/segment-boundary-trigger.css"),tQ={};tQ.styleTagTransform=b(),tQ.setAttributes=g(),tQ.insert=h(),tQ.domAPI=f(),tQ.insertStyleElement=x(),u()(tX.A,tQ),tX.A&&tX.A.locals&&tX.A.locals;let tJ={};function t0(e,t){let r=E.useRef(tJ);return r.current===tJ&&(r.current=e(t)),r}let t1=[];function t2(e){E.useEffect(e,t1)}class t3{static create(){return new t3}currentId=0;start(e,t){this.clear(),this.currentId=setTimeout(()=>{this.currentId=0,t()},e)}isStarted(){return 0!==this.currentId}clear=()=>{0!==this.currentId&&(clearTimeout(this.currentId),this.currentId=0)};disposeEffect=()=>this.clear}function t5(){let e=t0(t3.create).current;return t2(e.disposeEffect),e}let t4=T[`useInsertionEffect${Math.random().toFixed(1)}`.slice(0,-3)],t6=t4&&t4!==E.useLayoutEffect?t4:e=>e();function t7(e){let t=t0(t9).current;return t.next=e,t6(t.effect),t.trampoline}function t9(){let e={next:void 0,callback:t8,trampoline:(...t)=>e.callback?.(...t),effect:()=>{e.callback=e.next}};return e}function t8(){}function re({controlled:e,default:t,name:r,state:n="value"}){let{current:o}=E.useRef(void 0!==e),[a,i]=E.useState(t),s=E.useCallback(e=>{o||i(e)},[]);return[o?e:a,s]}let rt={...T},rr=0,rn=rt.useId;function ro(e,t){if(void 0!==rn){let r=rn();return e??(t?`${t}-${r}`:r)}return function(e,t="mui"){let[r,n]=E.useState(e),o=e||r;return E.useEffect(()=>{null==r&&(rr+=1,n(`${t}-${rr}`))},[r,t]),o}(e,t)}function ra(){let e=new Map;return{emit(t,r){e.get(t)?.forEach(e=>e(r))},on(t,r){e.has(t)||e.set(t,new Set),e.get(t).add(r)},off(t,r){e.get(t)?.delete(r)}}}let ri="undefined"!=typeof document?E.useLayoutEffect:()=>{},rs=E.createContext(null),rl=E.createContext(null),rc=()=>T.useContext(rs)?.id||null;function ru(e){let{children:t,id:r}=e,n=rc();return(0,z.jsx)(rs.Provider,{value:E.useMemo(()=>({id:r,parentId:n}),[r,n]),children:t})}function rd(e){let{children:t}=e,r=E.useRef([]),n=E.useCallback(e=>{r.current=[...r.current,e]},[]),o=E.useCallback(e=>{r.current=r.current.filter(t=>t!==e)},[]),[a]=E.useState(()=>ra());return(0,z.jsx)(rl.Provider,{value:E.useMemo(()=>({nodesRef:r,addNode:n,removeNode:o,events:a}),[n,o,a]),children:t})}function rf(e){let{open:t=!1,onOpenChange:r,elements:n}=e,o=ro(),a=E.useRef({}),[i]=E.useState(()=>ra()),s=null!=rc(),[l,c]=E.useState(n.reference),u=t7((e,t,n)=>{a.current.openEvent=e?t:void 0,i.emit("openchange",{open:e,event:t,reason:n,nested:s}),r?.(e,t,n)}),d=E.useMemo(()=>({setPositionReference:c}),[]),f=E.useMemo(()=>({reference:l||n.reference||null,floating:n.floating||null,domReference:n.reference}),[l,n.reference,n.floating]);return E.useMemo(()=>({dataRef:a,open:t,onOpenChange:u,elements:f,events:i,floatingId:o,refs:d}),[t,u,f,i,o,d])}function rp(){return"undefined"!=typeof window}function rh(e){return rv(e)?(e.nodeName||"").toLowerCase():"#document"}function rm(e){var t;return(null==e||null==(t=e.ownerDocument)?void 0:t.defaultView)||window}function rg(e){var t;return null==(t=(rv(e)?e.ownerDocument:e.document)||window.document)?void 0:t.documentElement}function rv(e){return!!rp()&&(e instanceof Node||e instanceof rm(e).Node)}function rx(e){return!!rp()&&(e instanceof Element||e instanceof rm(e).Element)}function ry(e){return!!rp()&&(e instanceof HTMLElement||e instanceof rm(e).HTMLElement)}function rb(e){return!!rp()&&"undefined"!=typeof ShadowRoot&&(e instanceof ShadowRoot||e instanceof rm(e).ShadowRoot)}let rw=new Set(["inline","contents"]);function r_(e){let{overflow:t,overflowX:r,overflowY:n,display:o}=rP(e);return/auto|scroll|overlay|hidden|clip/.test(t+n+r)&&!rw.has(o)}let rk=new Set(["table","td","th"]),rj=[":popover-open",":modal"];function rS(e){return rj.some(t=>{try{return e.matches(t)}catch(e){return!1}})}let rC=["transform","translate","scale","rotate","perspective"],rE=["transform","translate","scale","rotate","perspective","filter"],rT=["paint","layout","strict","content"];function rN(e){let t=rI(),r=rx(e)?rP(e):e;return rC.some(e=>!!r[e]&&"none"!==r[e])||!!r.containerType&&"normal"!==r.containerType||!t&&!!r.backdropFilter&&"none"!==r.backdropFilter||!t&&!!r.filter&&"none"!==r.filter||rE.some(e=>(r.willChange||"").includes(e))||rT.some(e=>(r.contain||"").includes(e))}function rI(){return"undefined"!=typeof CSS&&!!CSS.supports&&CSS.supports("-webkit-backdrop-filter","none")}let rz=new Set(["html","body","#document"]);function rR(e){return rz.has(rh(e))}function rP(e){return rm(e).getComputedStyle(e)}function rL(e){return rx(e)?{scrollLeft:e.scrollLeft,scrollTop:e.scrollTop}:{scrollLeft:e.scrollX,scrollTop:e.scrollY}}function rO(e){if("html"===rh(e))return e;let t=e.assignedSlot||e.parentNode||rb(e)&&e.host||rg(e);return rb(t)?t.host:t}function rM(e,t,r){var n;void 0===t&&(t=[]),void 0===r&&(r=!0);let o=function e(t){let r=rO(t);return rR(r)?t.ownerDocument?t.ownerDocument.body:t.body:ry(r)&&r_(r)?r:e(r)}(e),a=o===(null==(n=e.ownerDocument)?void 0:n.body),i=rm(o);if(a){let e=rA(i);return t.concat(i,i.visualViewport||[],r_(o)?o:[],e&&r?rM(e):[])}return t.concat(o,rM(o,[],r))}function rA(e){return e.parent&&Object.getPrototypeOf(e.parent)?e.frameElement:null}function rD(e){let t=t0(rF,e).current;return t.next=e,ri(t.effect),t}function rF(e){let t={current:e,next:e,effect:()=>{t.current=t.next}};return t}let r$="undefined"!=typeof navigator,rU=function(){if(!r$)return{platform:"",maxTouchPoints:-1};let e=navigator.userAgentData;return e?.platform?{platform:e.platform,maxTouchPoints:navigator.maxTouchPoints}:{platform:navigator.platform??"",maxTouchPoints:navigator.maxTouchPoints??-1}}(),rZ=function(){if(!r$)return"";let e=navigator.userAgentData;return e?.platform?e.platform:navigator.platform??""}(),rq=function(){if(!r$)return"";let e=navigator.userAgentData;return e&&Array.isArray(e.brands)?e.brands.map(({brand:e,version:t})=>`${e}/${t}`).join(" "):navigator.userAgent}(),rB="undefined"!=typeof CSS&&!!CSS.supports&&CSS.supports("-webkit-backdrop-filter:none"),rV="MacIntel"===rU.platform&&rU.maxTouchPoints>1||/iP(hone|ad|od)|iOS/.test(rU.platform);r$&&/firefox/i.test(rq);let rH=r$&&/apple/i.test(navigator.vendor),rW=r$&&/android/i.test(rZ)||/android/i.test(rq),rG=r$&&rZ.toLowerCase().startsWith("mac")&&!navigator.maxTouchPoints,rK=rq.includes("jsdom/");function rY(e){e.preventDefault(),e.stopPropagation()}function rX(e){return 0===e.mozInputSource&&!!e.isTrusted||(rW&&e.pointerType?"click"===e.type&&1===e.buttons:0===e.detail&&!e.pointerType)}function rQ(e){return!rK&&(!rW&&0===e.width&&0===e.height||rW&&1===e.width&&1===e.height&&0===e.pressure&&0===e.detail&&"mouse"===e.pointerType||e.width<1&&e.height<1&&0===e.pressure&&0===e.detail&&"touch"===e.pointerType)}function rJ(e,t){let r=["mouse","pen"];return t||r.push("",void 0),r.includes(e)}let r0="data-base-ui-focusable",r1="active",r2="selected",r3="ArrowLeft",r5="ArrowRight",r4="ArrowUp",r6="ArrowDown";function r7(e){let t=e.activeElement;for(;t?.shadowRoot?.activeElement!=null;)t=t.shadowRoot.activeElement;return t}function r9(e,t){if(!e||!t)return!1;let r=t.getRootNode?.();if(e.contains(t))return!0;if(r&&rb(r)){let r=t;for(;r;){if(e===r)return!0;r=r.parentNode||r.host}}return!1}function r8(e){return"composedPath"in e?e.composedPath()[0]:e.target}function ne(e,t){return null!=t&&("composedPath"in e?e.composedPath().includes(t):null!=e.target&&t.contains(e.target))}function nt(e){return e?.ownerDocument||document}function nr(e){return ry(e)&&e.matches("input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])")}function nn(e){return!!e&&"combobox"===e.getAttribute("role")&&nr(e)}function no(e){return e?e.hasAttribute(r0)?e:e.querySelector(`[${r0}]`)||e:null}function na(e){return`data-base-ui-${e}`}let ni=na("safe-polygon");function ns(e,t,r){if(r&&!rJ(r))return 0;if("number"==typeof e)return e;if("function"==typeof e){let r=e();return"number"==typeof r?r:r?.[t]}return e?.[t]}function nl(e){return"function"==typeof e?e():e}function nc(e,t={}){let{open:r,onOpenChange:n,dataRef:o,events:a,elements:i}=e,{enabled:s=!0,delay:l=0,handleClose:c=null,mouseOnly:u=!1,restMs:d=0,move:f=!0}=t,p=E.useContext(rl),h=rc(),m=rD(c),g=rD(l),v=rD(r),x=rD(d),y=E.useRef(void 0),b=t5(),w=E.useRef(void 0),_=t5(),k=E.useRef(!0),j=E.useRef(!1),S=E.useRef(()=>{}),C=E.useRef(!1),T=t7(()=>{let e=o.current.openEvent?.type;return e?.includes("mouse")&&"mousedown"!==e});E.useEffect(()=>{if(s)return a.on("openchange",e),()=>{a.off("openchange",e)};function e({open:e}){e||(b.clear(),_.clear(),k.current=!0,C.current=!1)}},[s,a,b,_]),E.useEffect(()=>{if(!s||!m.current||!r)return;function e(e){T()&&n(!1,e,"hover")}let t=nt(i.floating).documentElement;return t.addEventListener("mouseleave",e),()=>{t.removeEventListener("mouseleave",e)}},[i.floating,r,n,s,m,T]);let N=E.useCallback((e,t=!0,r="hover")=>{let o=ns(g.current,"close",y.current);o&&!w.current?b.start(o,()=>n(!1,e,r)):t&&(b.clear(),n(!1,e,r))},[g,n,b]),I=t7(()=>{S.current(),w.current=void 0}),z=t7(()=>{if(j.current){let e=nt(i.floating).body;e.style.pointerEvents="",e.removeAttribute(ni),j.current=!1}}),R=t7(()=>!!o.current.openEvent&&["click","mousedown"].includes(o.current.openEvent.type));E.useEffect(()=>{if(s&&rx(i.domReference)){let n=i.domReference,o=i.floating;return r&&n.addEventListener("mouseleave",a),f&&n.addEventListener("mousemove",e,{once:!0}),n.addEventListener("mouseenter",e),n.addEventListener("mouseleave",t),o&&(o.addEventListener("mouseleave",a),o.addEventListener("mouseenter",l),o.addEventListener("mouseleave",c)),()=>{r&&n.removeEventListener("mouseleave",a),f&&n.removeEventListener("mousemove",e),n.removeEventListener("mouseenter",e),n.removeEventListener("mouseleave",t),o&&(o.removeEventListener("mouseleave",a),o.removeEventListener("mouseenter",l),o.removeEventListener("mouseleave",c))}}function e(e){if(b.clear(),k.current=!1,u&&!rJ(y.current)||nl(x.current)>0&&!ns(g.current,"open"))return;let t=ns(g.current,"open",y.current);t?b.start(t,()=>{v.current||n(!0,e,"hover")}):r||n(!0,e,"hover")}function t(e){if(R())return void z();S.current();let t=nt(i.floating);if(_.clear(),C.current=!1,m.current&&o.current.floatingContext){r||b.clear(),w.current=m.current({...o.current.floatingContext,tree:p,x:e.clientX,y:e.clientY,onClose(){z(),I(),R()||N(e,!0,"safe-polygon")}});let n=w.current;t.addEventListener("mousemove",n),S.current=()=>{t.removeEventListener("mousemove",n)};return}"touch"===y.current&&r9(i.floating,e.relatedTarget)||N(e)}function a(e){R()||o.current.floatingContext&&m.current?.({...o.current.floatingContext,tree:p,x:e.clientX,y:e.clientY,onClose(){z(),I(),R()||N(e)}})(e)}function l(){b.clear()}function c(e){R()||N(e,!1)}},[i,s,e,u,f,N,I,z,n,r,v,p,g,m,o,R,x,b,_]),ri(()=>{if(s&&r&&m.current?.__options?.blockPointerEvents&&T()){j.current=!0;let e=i.floating;if(rx(i.domReference)&&e){let t=nt(i.floating).body;t.setAttribute(ni,"");let r=i.domReference,n=p?.nodesRef.current.find(e=>e.id===h)?.context?.elements.floating;return n&&(n.style.pointerEvents=""),t.style.pointerEvents="none",r.style.pointerEvents="auto",e.style.pointerEvents="auto",()=>{t.style.pointerEvents="",r.style.pointerEvents="",e.style.pointerEvents=""}}}},[s,r,h,i,p,m,T]),ri(()=>{r||(y.current=void 0,C.current=!1,I(),z())},[r,I,z]),E.useEffect(()=>()=>{I(),b.clear(),_.clear(),z()},[s,i.domReference,I,z,b,_]);let P=E.useMemo(()=>{function e(e){y.current=e.pointerType}return{onPointerDown:e,onPointerEnter:e,onMouseMove(e){let{nativeEvent:t}=e;function o(){k.current||v.current||n(!0,t,"hover")}u&&!rJ(y.current)||r||0===nl(x.current)||C.current&&e.movementX**2+e.movementY**2<2||(_.clear(),"touch"===y.current?o():(C.current=!0,_.start(nl(x.current),o)))}}},[u,n,r,v,x,_]);return E.useMemo(()=>s?{reference:P}:{},[s,P])}function nu(e,t,r=!0){return e.filter(e=>e.parentId===t&&(!r||e.context?.open)).flatMap(t=>[t,...nu(e,t.id,r)])}function nd(e,t){let r=[],n=e.find(e=>e.id===t)?.parentId;for(;n;){let t=e.find(e=>e.id===n);n=t?.parentId,t&&(r=r.concat(t))}return r}function nf(e,t){let[r,n]=e,o=!1,a=t.length;for(let e=0,i=a-1;e<a;i=e++){let[a,s]=t[e]||[0,0],[l,c]=t[i]||[0,0];s>=n!=c>=n&&r<=(l-a)*(n-s)/(c-s)+a&&(o=!o)}return o}function np(e={}){let{buffer:t=.5,blockPointerEvents:r=!1,requireIntent:n=!0}=e,o=new t3,a=!1,i=null,s=null,l="undefined"!=typeof performance?performance.now():0,c=({x:e,y:r,placement:c,elements:u,onClose:d,nodeId:f,tree:p})=>function(h){function m(){o.clear(),d()}if(o.clear(),!u.domReference||!u.floating||null==c||null==e||null==r)return;let{clientX:g,clientY:v}=h,x=[g,v],y=r8(h),b="mouseleave"===h.type,w=r9(u.floating,y),_=r9(u.domReference,y),k=u.domReference.getBoundingClientRect(),j=u.floating.getBoundingClientRect(),S=c.split("-")[0],C=e>j.right-j.width/2,E=r>j.bottom-j.height/2,T=x[0]>=k.x&&x[0]<=k.x+k.width&&x[1]>=k.y&&x[1]<=k.y+k.height,N=j.width>k.width,I=j.height>k.height,z=(N?k:j).left,R=(N?k:j).right,P=(I?k:j).top,L=(I?k:j).bottom;if(w&&(a=!0,!b))return;if(_&&(a=!1),_&&!b){a=!0;return}if(b&&rx(h.relatedTarget)&&r9(u.floating,h.relatedTarget)||p&&nu(p.nodesRef.current,f).some(({context:e})=>e?.open))return;if("top"===S&&r>=k.bottom-1||"bottom"===S&&r<=k.top+1||"left"===S&&e>=k.right-1||"right"===S&&e<=k.left+1)return m();let O=[];switch(S){case"top":O=[[z,k.top+1],[z,j.bottom-1],[R,j.bottom-1],[R,k.top+1]];break;case"bottom":O=[[z,j.top+1],[z,k.bottom-1],[R,k.bottom-1],[R,j.top+1]];break;case"left":O=[[j.right-1,L],[j.right-1,P],[k.left+1,P],[k.left+1,L]];break;case"right":O=[[k.right-1,L],[k.right-1,P],[j.left+1,P],[j.left+1,L]]}if(!nf([g,v],O)){if(a&&!T)return m();if(!b&&n){let e=function(e,t){let r=performance.now(),n=r-l;if(null===i||null===s||0===n)return i=e,s=t,l=r,null;let o=e-i,a=t-s,c=Math.sqrt(o*o+a*a);return i=e,s=t,l=r,c/n}(h.clientX,h.clientY);if(null!==e&&e<.1)return m()}nf([g,v],function([e,r]){switch(S){case"top":{let n=[[j.left,C||N?j.bottom-t:j.top],[j.right,C?N?j.bottom-t:j.top:j.bottom-t]];return[[N?e+t/2:C?e+4*t:e-4*t,r+t+1],[N?e-t/2:C?e+4*t:e-4*t,r+t+1],...n]}case"bottom":{let n=[[j.left,C||N?j.top+t:j.bottom],[j.right,C?N?j.top+t:j.bottom:j.top+t]];return[[N?e+t/2:C?e+4*t:e-4*t,r-t],[N?e-t/2:C?e+4*t:e-4*t,r-t],...n]}case"left":return[[E||I?j.right-t:j.left,j.top],[E?I?j.right-t:j.left:j.right-t,j.bottom],[e+t+1,I?r+t/2:E?r+4*t:r-4*t],[e+t+1,I?r-t/2:E?r+4*t:r-4*t]];case"right":{let n=[[E||I?j.left+t:j.right,j.top],[E?I?j.left+t:j.right:j.left+t,j.bottom]];return[[e-t,I?r+t/2:E?r+4*t:r-4*t],[e-t,I?r-t/2:E?r+4*t:r-4*t],...n]}default:return[]}}([e,r]))?!a&&n&&o.start(40,m):m()}};return c.__options={blockPointerEvents:r},c}let nh=rG&&rH;function nm(e,t={}){let{open:r,onOpenChange:n,events:o,dataRef:a,elements:i}=e,{enabled:s=!0,visibleOnly:l=!0}=t,c=E.useRef(!1),u=t5(),d=E.useRef(!0);E.useEffect(()=>{if(!s)return;let e=rm(i.domReference);function t(){!r&&ry(i.domReference)&&i.domReference===r7(nt(i.domReference))&&(c.current=!0)}function n(){d.current=!0}function o(){d.current=!1}return e.addEventListener("blur",t),nh&&(e.addEventListener("keydown",n,!0),e.addEventListener("pointerdown",o,!0)),()=>{e.removeEventListener("blur",t),nh&&(e.removeEventListener("keydown",n,!0),e.removeEventListener("pointerdown",o,!0))}},[i.domReference,r,s]),E.useEffect(()=>{if(s)return o.on("openchange",e),()=>{o.off("openchange",e)};function e({reason:e}){("reference-press"===e||"escape-key"===e)&&(c.current=!0)}},[o,s]);let f=E.useMemo(()=>({onMouseLeave(){c.current=!1},onFocus(e){if(c.current)return;let t=r8(e.nativeEvent);if(l&&rx(t)){if(nh&&!e.relatedTarget){if(!d.current&&!nr(t))return}else if(!function(e){if(!e||rK)return!0;try{return e.matches(":focus-visible")}catch(e){return!0}}(t))return}n(!0,e.nativeEvent,"focus")},onBlur(e){c.current=!1;let t=e.relatedTarget,r=e.nativeEvent,o=rx(t)&&t.hasAttribute(na("focus-guard"))&&"outside"===t.getAttribute("data-type");u.start(0,()=>{let e=r7(i.domReference?i.domReference.ownerDocument:document);!t&&e===i.domReference||r9(a.current.floatingContext?.refs.floating.current,e)||r9(i.domReference,e)||o||n(!1,r,"focus")})}}),[a,i.domReference,n,l,u]);return E.useMemo(()=>s?{reference:f}:{},[s,f])}let ng=new class{callbacks=[];callbacksCount=0;nextId=1;startId=1;isScheduled=!1;tick=e=>{this.isScheduled=!1;let t=this.callbacks,r=this.callbacksCount;if(this.callbacks=[],this.callbacksCount=0,this.startId=this.nextId,r>0)for(let r=0;r<t.length;r+=1)t[r]?.(e)};request(e){let t=this.nextId;return this.nextId+=1,this.callbacks.push(e),this.callbacksCount+=1,this.isScheduled||(requestAnimationFrame(this.tick),this.isScheduled=!0),t}cancel(e){let t=e-this.startId;t<0||t>=this.callbacks.length||(this.callbacks[t]=null,this.callbacksCount-=1)}};class nv{static create(){return new nv}static request(e){return ng.request(e)}static cancel(e){return ng.cancel(e)}currentId=null;request(e){this.cancel(),this.currentId=ng.request(()=>{this.currentId=null,e()})}cancel=()=>{null!==this.currentId&&(ng.cancel(this.currentId),this.currentId=null)};disposeEffect=()=>this.cancel}function nx(){let e=t0(nv.create).current;return t2(e.disposeEffect),e}let ny={style:{transition:"none"}},nb={},nw=[],n_={fallbackAxisSide:"none"},nk={fallbackAxisSide:"end"},nj={intentional:"onClick",sloppy:"onPointerDown"};function nS(e){return{escapeKey:"boolean"==typeof e?e:e?.escapeKey??!1,outsidePress:"boolean"==typeof e?e:e?.outsidePress??!0}}function nC(e,t={}){let{open:r,onOpenChange:n,elements:o,dataRef:a}=e,{enabled:i=!0,escapeKey:s=!0,outsidePress:l=!0,outsidePressEvent:c="sloppy",referencePress:u=!1,referencePressEvent:d="sloppy",ancestorScroll:f=!1,bubbles:p,capture:h}=t,m=E.useContext(rl),g=t7("function"==typeof l?l:()=>!1),v="function"==typeof l?g:l,x=E.useRef(!1),{escapeKey:y,outsidePress:b}=nS(p),{escapeKey:w,outsidePress:_}=nS(h),k=E.useRef(null),j=t5(),S=t5(),C=E.useRef(!1),T=E.useRef(""),N=t7(e=>{T.current=e.pointerType}),I=t7(()=>{let e=T.current;return"string"==typeof c?c:c["pen"!==e&&e?e:"mouse"]}),z=t7(e=>{if(!r||!i||!s||"Escape"!==e.key||C.current)return;let t=a.current.floatingContext?.nodeId,o=m?nu(m.nodesRef.current,t):[];if(!y&&(e.stopPropagation(),o.length>0)){let e=!0;if(o.forEach(t=>{t.context?.open&&!t.context.dataRef.current.__escapeKeyBubbles&&(e=!1)}),!e)return}n(!1,"nativeEvent"in e?e.nativeEvent:e,"escape-key")}),R=t7(e=>{let t=I();return"intentional"===t&&"click"!==e.type||"sloppy"===t&&"click"===e.type}),P=t7(e=>{let t=()=>{z(e),r8(e)?.removeEventListener("keydown",t)};r8(e)?.addEventListener("keydown",t)}),L=t7(e=>{if(R(e))return;let t=a.current.insideReactTree;a.current.insideReactTree=!1;let r=x.current;if(x.current=!1,"intentional"===I()&&r||t||"function"==typeof v&&!v(e))return;let i=r8(e),s=`[${na("inert")}]`,l=nt(o.floating).querySelectorAll(s),c=rx(i)?i:null;for(;c&&!rR(c);){let e=rO(c);if(rR(e)||!rx(e))break;c=e}if(l.length&&rx(i)&&!i.matches("html,body")&&!r9(i,o.floating)&&Array.from(l).every(e=>!r9(c,e)))return;if(ry(i)){let t=rR(i),r=rP(i),n=/auto|scroll/,o=t||n.test(r.overflowX),a=t||n.test(r.overflowY),s=o&&i.clientWidth>0&&i.scrollWidth>i.clientWidth,l=a&&i.clientHeight>0&&i.scrollHeight>i.clientHeight,c="rtl"===r.direction,u=l&&(c?e.offsetX<=i.offsetWidth-i.clientWidth:e.offsetX>i.clientWidth),d=s&&e.offsetY>i.clientHeight;if(u||d)return}let u=a.current.floatingContext?.nodeId,d=m&&nu(m.nodesRef.current,u).some(t=>ne(e,t.context?.elements.floating));if(ne(e,o.floating)||ne(e,o.domReference)||d)return;let f=m?nu(m.nodesRef.current,u):[];if(f.length>0){let e=!0;if(f.forEach(t=>{t.context?.open&&!t.context.dataRef.current.__outsidePressBubbles&&(e=!1)}),!e)return}n(!1,e,"outside-press")}),O=t7(e=>{if(!("sloppy"!==I()||!r||!i||ne(e,o.floating)||ne(e,o.domReference))){if("touch"===e.pointerType){k.current={startTime:Date.now(),startX:e.clientX,startY:e.clientY,dismissOnPointerUp:!1,dismissOnMouseDown:!0},j.start(1e3,()=>{k.current&&(k.current.dismissOnPointerUp=!1,k.current.dismissOnMouseDown=!1)});return}L(e)}}),M=t7(e=>{if(R(e)||(j.clear(),"mousedown"===e.type&&k.current&&!k.current.dismissOnMouseDown))return;let t=()=>{"pointerdown"===e.type?O(e):L(e),r8(e)?.removeEventListener(e.type,t)};r8(e)?.addEventListener(e.type,t)}),A=t7(e=>{if("sloppy"!==I()||"touch"!==e.pointerType||!k.current||ne(e,o.floating)||ne(e,o.domReference))return;let t=Math.abs(e.clientX-k.current.startX),r=Math.abs(e.clientY-k.current.startY),n=Math.sqrt(t*t+r*r);n>5&&(k.current.dismissOnPointerUp=!0),n>10&&(L(e),j.clear(),k.current=null)}),D=t7(e=>{"sloppy"!==I()||"touch"!==e.pointerType||!k.current||ne(e,o.floating)||ne(e,o.domReference)||(k.current.dismissOnPointerUp&&L(e),j.clear(),k.current=null)});E.useEffect(()=>{if(!r||!i)return;a.current.__escapeKeyBubbles=y,a.current.__outsidePressBubbles=b;let e=new t3;function t(e){n(!1,e,"ancestor-scroll")}function l(){e.clear(),C.current=!0}function c(){e.start(5*!!rI(),()=>{C.current=!1})}let u=nt(o.floating);u.addEventListener("pointerdown",N,!0),s&&(u.addEventListener("keydown",w?P:z,w),u.addEventListener("compositionstart",l),u.addEventListener("compositionend",c)),v&&(u.addEventListener("click",_?M:L,_),u.addEventListener("pointerdown",_?M:L,_),u.addEventListener("pointermove",A,_),u.addEventListener("pointerup",D,_),u.addEventListener("mousedown",M,_));let d=[];return f&&(rx(o.domReference)&&(d=rM(o.domReference)),rx(o.floating)&&(d=d.concat(rM(o.floating))),!rx(o.reference)&&o.reference&&o.reference.contextElement&&(d=d.concat(rM(o.reference.contextElement)))),(d=d.filter(e=>e!==u.defaultView?.visualViewport)).forEach(e=>{e.addEventListener("scroll",t,{passive:!0})}),()=>{u.removeEventListener("pointerdown",N,!0),s&&(u.removeEventListener("keydown",w?P:z,w),u.removeEventListener("compositionstart",l),u.removeEventListener("compositionend",c)),v&&(u.removeEventListener("click",_?M:L,_),u.removeEventListener("pointerdown",_?M:L,_),u.removeEventListener("pointermove",A,_),u.removeEventListener("pointerup",D,_),u.removeEventListener("mousedown",M,_)),d.forEach(e=>{e.removeEventListener("scroll",t)}),e.clear()}},[a,o,s,v,c,r,n,f,i,y,b,z,w,P,L,_,M,O,A,D,N]),E.useEffect(()=>{a.current.insideReactTree=!1},[a,v]);let F=E.useMemo(()=>({onKeyDown:z,...u&&{[nj[d]]:e=>{n(!1,e.nativeEvent,"reference-press")},..."intentional"!==d&&{onClick(e){n(!1,e.nativeEvent,"reference-press")}}}}),[z,n,u,d]),$=t7(e=>{let t=r8(e.nativeEvent);r9(o.floating,t)&&(x.current=!0)}),U=t7(()=>{a.current.insideReactTree=!0,S.start(0,()=>{a.current.insideReactTree=!1})}),Z=E.useMemo(()=>({onKeyDown:z,onMouseDown:$,onMouseUp:$,onPointerDownCapture:U,onMouseDownCapture:U,onClickCapture:U}),[z,$,U]);return E.useMemo(()=>i?{reference:F,floating:Z}:{},[i,F,Z])}let nE=new Map([["select","listbox"],["combobox","listbox"],["label",!1]]),nT=["top","right","bottom","left"],nN=Math.min,nI=Math.max,nz=Math.round,nR=Math.floor,nP=e=>({x:e,y:e}),nL={left:"right",right:"left",bottom:"top",top:"bottom"},nO={start:"end",end:"start"};function nM(e,t){return"function"==typeof e?e(t):e}function nA(e){return e.split("-")[0]}function nD(e){return e.split("-")[1]}function nF(e){return"x"===e?"y":"x"}function n$(e){return"y"===e?"height":"width"}let nU=new Set(["top","bottom"]);function nZ(e){return nU.has(nA(e))?"y":"x"}function nq(e){return e.replace(/start|end/g,e=>nO[e])}let nB=["left","right"],nV=["right","left"],nH=["top","bottom"],nW=["bottom","top"];function nG(e){return e.replace(/left|right|bottom|top/g,e=>nL[e])}function nK(e){return"number"!=typeof e?{top:0,right:0,bottom:0,left:0,...e}:{top:e,right:e,bottom:e,left:e}}function nY(e){let{x:t,y:r,width:n,height:o}=e;return{width:n,height:o,top:r,left:t,right:t+n,bottom:r+o,x:t,y:r}}function nX(e,t,r){return Math.floor(e/t)!==r}function nQ(e,t){return t<0||t>=e.current.length}function nJ(e,t){return n1(e,{disabledIndices:t})}function n0(e,t){return n1(e,{decrement:!0,startingIndex:e.current.length,disabledIndices:t})}function n1(e,{startingIndex:t=-1,decrement:r=!1,disabledIndices:n,amount:o=1}={}){let a=t;do a+=r?-o:o;while(a>=0&&a<=e.current.length-1&&n2(e,a,n));return a}function n2(e,t,r){if("function"==typeof r)return r(t);if(r)return r.includes(t);let n=e.current[t];return null==n||n.hasAttribute("disabled")||"true"===n.getAttribute("aria-disabled")}let n3=0;function n5(e,t={}){let{preventScroll:r=!1,cancelPrevious:n=!0,sync:o=!1}=t;n&&cancelAnimationFrame(n3);let a=()=>e?.focus({preventScroll:r});o?a():n3=requestAnimationFrame(a)}function n4(e,t,r){switch(e){case"vertical":return t;case"horizontal":return r;default:return t||r}}function n6(e,t){return n4(t,e===r4||e===r6,e===r3||e===r5)}function n7(e,t,r){return n4(t,e===r6,r?e===r3:e===r5)||"Enter"===e||" "===e||""===e}function n9(e=[]){let t=e.map(e=>e?.reference),r=e.map(e=>e?.floating),n=e.map(e=>e?.item),o=E.useCallback(t=>n8(t,e,"reference"),t),a=E.useCallback(t=>n8(t,e,"floating"),r),i=E.useCallback(t=>n8(t,e,"item"),n);return E.useMemo(()=>({getReferenceProps:o,getFloatingProps:a,getItemProps:i}),[o,a,i])}function n8(e,t,r){let n=new Map,o="item"===r,a={};for(let t in"floating"===r&&(a.tabIndex=-1,a[r0]=""),e)o&&e&&(t===r1||t===r2)||(a[t]=e[t]);for(let i=0;i<t.length;i+=1){let s,l=t[i]?.[r];(s="function"==typeof l?e?l(e):null:l)&&oe(a,s,o,n)}return oe(a,e,o,n),a}function oe(e,t,r,n){for(let o in t){let a=t[o];r&&(o===r1||o===r2)||(o.startsWith("on")?(n.has(o)||n.set(o,[]),"function"==typeof a&&(n.get(o)?.push(a),e[o]=(...e)=>n.get(o)?.map(t=>t(...e)).find(e=>void 0!==e))):e[o]=a)}}let ot=E.createContext(void 0);function or(e){let t=E.useContext(ot);if(void 0===t&&!e)throw Error("Base UI: MenuRootContext is missing. Menu parts must be placed within <Menu.Root>.");return t}let on=E.createContext(null);function oo(e,t=!1,r=!1){let[n,o]=E.useState(e&&t?"idle":void 0),[a,i]=E.useState(e);return e&&!a&&(i(!0),o("starting")),e||!a||"ending"===n||r||o("ending"),e||a||"ending"!==n||o(void 0),ri(()=>{if(!e&&a&&"ending"!==n&&r){let e=nv.request(()=>{o("ending")});return()=>{nv.cancel(e)}}},[e,a,n,r]),ri(()=>{if(!e||t)return;let r=nv.request(()=>{R.flushSync(()=>{o(void 0)})});return()=>{nv.cancel(r)}},[t,e]),ri(()=>{if(!e||!t)return;e&&a&&"idle"!==n&&o("starting");let r=nv.request(()=>{o("idle")});return()=>{nv.cancel(r)}},[t,e,a,o,n]),E.useMemo(()=>({mounted:a,setMounted:i,transitionStatus:n}),[a,n])}function oa(e){let{enabled:t=!0,open:r,ref:n,onComplete:o}=e,a=rD(r),i=t7(o),s=function(e,t=!1){let r=nx();return t7((n,o=null)=>{let a;if(r.cancel(),null!=e){if("current"in e){if(null==e.current)return;a=e.current}else a=e;"function"!=typeof a.getAnimations||globalThis.BASE_UI_ANIMATIONS_DISABLED?n():r.request(()=>{function e(){a&&Promise.allSettled(a.getAnimations().map(e=>e.finished)).then(()=>{null!=o&&o.aborted||R.flushSync(n)})}t?r.request(e):e()})}})}(n,r);E.useEffect(()=>{t&&s(()=>{r===a.current&&i()})},[t,r,i,s,a])}let oi=E.createContext(void 0);function os(e=!0){let t=E.useContext(oi);if(void 0===t&&!e)throw Error("Base UI: DirectionContext is missing.");return t?.direction??"ltr"}function ol(e){return e?.ownerDocument||document}let oc=()=>{},ou={},od={},of="";class op{lockCount=0;restore=null;timeoutLock=t3.create();timeoutUnlock=t3.create();acquire(e){return this.lockCount+=1,1===this.lockCount&&null===this.restore&&this.timeoutLock.start(0,()=>this.lock(e)),this.release}release=()=>{this.lockCount-=1,0===this.lockCount&&this.restore&&this.timeoutUnlock.start(0,this.unlock)};unlock=()=>{0===this.lockCount&&this.restore&&(this.restore?.(),this.restore=null)};lock(e){let t,r;if(0===this.lockCount||null!==this.restore)return;let n=ol(e).documentElement,o=rm(n).getComputedStyle(n).overflowY;if("hidden"===o||"clip"===o){this.restore=oc;return}let a=rV||!function(e){if("undefined"==typeof document)return!1;let t=ol(e);return rm(t).innerWidth-t.documentElement.clientWidth>0}(e);this.restore=a?(r=(t=ol(e).documentElement).style.overflow,t.style.overflow="hidden",()=>{t.style.overflow=r}):function(e){let t=ol(e),r=t.documentElement,n=t.body,o=rm(r),a=0,i=0,s=nv.create();if(rB&&(o.visualViewport?.scale??1)!==1)return()=>{};function l(){let e=o.getComputedStyle(r),t=o.getComputedStyle(n);a=r.scrollTop,i=r.scrollLeft,ou={scrollbarGutter:r.style.scrollbarGutter,overflowY:r.style.overflowY,overflowX:r.style.overflowX},of=r.style.scrollBehavior,od={position:n.style.position,height:n.style.height,width:n.style.width,boxSizing:n.style.boxSizing,overflowY:n.style.overflowY,overflowX:n.style.overflowX,scrollBehavior:n.style.scrollBehavior};let s="undefined"!=typeof CSS&&CSS.supports?.("scrollbar-gutter","stable"),l=r.scrollHeight>r.clientHeight,c=r.scrollWidth>r.clientWidth,u="scroll"===e.overflowY||"scroll"===t.overflowY,d="scroll"===e.overflowX||"scroll"===t.overflowX,f=Math.max(0,o.innerWidth-r.clientWidth),p=Math.max(0,o.innerHeight-r.clientHeight),h=parseFloat(t.marginTop)+parseFloat(t.marginBottom),m=parseFloat(t.marginLeft)+parseFloat(t.marginRight);Object.assign(r.style,{scrollbarGutter:"stable",overflowY:!s&&(l||u)?"scroll":"hidden",overflowX:!s&&(c||d)?"scroll":"hidden"}),Object.assign(n.style,{position:"relative",height:h||p?`calc(100dvh - ${h+p}px)`:"100dvh",width:m||f?`calc(100vw - ${m+f}px)`:"100vw",boxSizing:"border-box",overflow:"hidden",scrollBehavior:"unset"}),n.scrollTop=a,n.scrollLeft=i,r.setAttribute("data-base-ui-scroll-locked",""),r.style.scrollBehavior="unset"}function c(){Object.assign(r.style,ou),Object.assign(n.style,od),r.scrollTop=a,r.scrollLeft=i,r.removeAttribute("data-base-ui-scroll-locked"),r.style.scrollBehavior=of}function u(){c(),s.request(l)}return l(),o.addEventListener("resize",u),()=>{s.cancel(),c(),o.removeEventListener("resize",u)}}(e)}}let oh=new op;function om(e){if(e)return({"focus-out":"focus-out","escape-key":"escape-key","outside-press":"outside-press","list-navigation":"list-navigation",click:"trigger-press",hover:"trigger-hover",focus:"trigger-focus","reference-press":"trigger-press","safe-polygon":"trigger-hover","ancestor-scroll":void 0})[e]}let og=E.createContext(void 0);function ov(e=!0){let t=E.useContext(og);if(void 0===t&&!e)throw Error("Base UI: ContextMenuRootContext is missing. ContextMenu parts must be placed within <ContextMenu.Root>.");return t}let ox=E.createContext(!1);function oy(e,t){return e&&!t?e:!e&&t?t:e||t?{...e,...t}:void 0}let ob={};function ow(e,t,r,n,o){let a={...oj(e,ob)};return t&&(a=o_(a,t)),r&&(a=o_(a,r)),n&&(a=o_(a,n)),o&&(a=o_(a,o)),a}function o_(e,t){return ok(t)?t(e):function(e,t){if(!t)return e;for(let r in t){let n=t[r];switch(r){case"style":e[r]=oy(e.style,n);break;case"className":e[r]=oC(e.className,n);break;default:!function(e,t){let r=e.charCodeAt(0),n=e.charCodeAt(1),o=e.charCodeAt(2);return 111===r&&110===n&&o>=65&&o<=90&&("function"==typeof t||void 0===t)}(r,n)?e[r]=n:e[r]=function(e,t){return t?e?r=>{var n;if(null!=(n=r)&&"object"==typeof n&&"nativeEvent"in n){oS(r);let n=t(r);return r.baseUIHandlerPrevented||e?.(r),n}let o=t(r);return e?.(r),o}:t:e}(e[r],n)}}return e}(e,t)}function ok(e){return"function"==typeof e}function oj(e,t){return ok(e)?e(t):e??ob}function oS(e){return e.preventBaseUIHandler=()=>{e.baseUIHandlerPrevented=!0},e}function oC(e,t){return t?e?t+" "+e:t:e}let oE=[],oT={current:!1},oN=function(e){let t,r,{children:n,open:o,onOpenChange:a,onOpenChangeComplete:i,defaultOpen:s=!1,disabled:l=!1,modal:c,loop:u=!0,orientation:d="vertical",actionsRef:f,openOnHover:p,delay:h=100,closeDelay:m=0,closeParentOnEsc:g=!0}=e,[v,x]=E.useState(null),[y,b]=E.useState(null),[w,_]=E.useState(),[k,j]=E.useState(!0),[S,C]=E.useState(null),[T,N]=E.useState(null),[I,P]=E.useState(!0),[L,O]=E.useState(!1),M=E.useRef(null),A=E.useRef(null),D=E.useRef(null),F=E.useRef([]),$=E.useRef([]),U=t5(),Z=ov(!0),q=E.useContext(ox);{let e=or(!0),r=function(e){let t=E.useContext(on);if(null===t&&!e)throw Error("Base UI: MenubarContext is missing. Menubar parts must be placed within <Menubar>.");return t}(!0);t=q&&e?{type:"menu",context:e}:r?{type:"menubar",context:r}:Z?{type:"context-menu",context:Z}:{type:void 0}}let B=ro();void 0!==t.type&&(B=t.context.rootId);let V=(void 0===t.type||"context-menu"===t.type)&&(c??!0),H="menu"===t.type?t.context.allowMouseEnter:L,W="menu"===t.type?t.context.setAllowMouseEnter:O,G=p??("menu"===t.type||"menubar"===t.type&&t.context.hasSubmenuOpen),[K,Y]=re({controlled:o,default:s,name:"MenuRoot",state:"open"}),X=E.useRef("context-menu"!==t.type),Q=t5();E.useEffect(()=>{if(K||(M.current=null),"context-menu"===t.type){if(!K){Q.clear(),X.current=!1;return}Q.start(500,()=>{X.current=!0})}},[Q,K,t.type]);let J=E.useCallback(e=>{D.current=e,b(e)},[]),{mounted:ee,setMounted:et,transitionStatus:er}=oo(K),{openMethod:en,triggerProps:eo,reset:ea}=function(e){let t,r,[n,o]=E.useState(null),a=t7((t,r)=>{e||o(r)}),i=t7(()=>{o(null)}),{onClick:s,onPointerDown:l}=(t=E.useRef(""),r=E.useCallback(e=>{e.defaultPrevented||(t.current=e.pointerType,a(e,e.pointerType))},[a]),{onClick:E.useCallback(e=>{0===e.detail?a(e,"keyboard"):("pointerType"in e&&a(e,e.pointerType),a(e,t.current),t.current="")},[a]),onPointerDown:r});return E.useMemo(()=>({openMethod:n,reset:i,triggerProps:{onClick:s,onPointerDown:l}}),[n,i,s,l])}(K);!function(e){let{enabled:t=!0,mounted:r,open:n,referenceElement:o=null}=e;ri(()=>{if(t&&rB&&r&&!n){let e=ol(o),t=e.body.style.userSelect,r=e.body.style.webkitUserSelect;return e.body.style.userSelect="none",e.body.style.webkitUserSelect="none",()=>{e.body.style.userSelect=t,e.body.style.webkitUserSelect=r}}},[t,r,n,o]),ri(()=>{if(t)return oh.acquire(o)},[t,o])}({enabled:K&&V&&"trigger-hover"!==T&&"touch"!==en,mounted:ee,open:K,referenceElement:y}),K||k||j(!0);let ei=t7(()=>{et(!1),P(!0),W(!1),i?.(!1),ea()});oa({enabled:!f,open:K,ref:A,onComplete(){K||ei()}});let es=E.useRef(!0),el=t5(),ec=t7((e,r,n)=>{if(K===e||!1===e&&r?.type==="click"&&"touch"===r.pointerType&&!es.current)return;if(!e&&null!==S){let e=F.current[S];queueMicrotask(()=>{e?.setAttribute("tabindex","-1")})}e&&"trigger-focus"===n?(es.current=!1,el.start(300,()=>{es.current=!0})):(es.current=!0,el.clear());let o=("trigger-press"===n||"item-press"===n)&&0===r.detail&&r?.isTrusted,i=!e&&("escape-key"===n||null==n);function s(){a?.(e,r,n),Y(e),N(n??null),M.current=r??null}"trigger-hover"===n?(P(!0),U.start(500,()=>{P(!1)}),R.flushSync(s)):s(),"menubar"===t.type&&("trigger-focus"===n||"focus-out"===n||"trigger-hover"===n||"list-navigation"===n||"sibling-open"===n)?_("group"):o||i?_(o?"click":"dismiss"):_(void 0)});E.useImperativeHandle(f,()=>({unmount:ei}),[ei]),"context-menu"===t.type&&(r=t.context),E.useImperativeHandle(r?.positionerRef,()=>y,[y]),E.useImperativeHandle(r?.actionsRef,()=>({setOpen:ec}),[ec]),E.useEffect(()=>{K||U.clear()},[U,K]);let eu=rf({elements:{reference:v,floating:y},open:K,onOpenChange(e,t,r){ec(e,t,om(r))}}),ed=nc(eu,{enabled:k&&G&&!l&&"context-menu"!==t.type&&("menubar"!==t.type||t.context.hasSubmenuOpen&&!K),handleClose:np({blockPointerEvents:!0}),mouseOnly:!0,move:"menu"===t.type,restMs:void 0===t.type||"menu"===t.type&&H?h:void 0,delay:"menu"===t.type?{open:H?h:1e10,close:m}:{close:m}}),ef=nm(eu,{enabled:!l&&!K&&"menubar"===t.type&&t.context.hasSubmenuOpen&&!Z}),ep=function(e,t={}){let{open:r,onOpenChange:n,dataRef:o}=e,{enabled:a=!0,event:i="click",toggle:s=!0,ignoreMouse:l=!1,stickIfOpen:c=!0}=t,u=E.useRef(void 0),d=nx(),f=E.useMemo(()=>({onPointerDown(e){u.current=e.pointerType},onMouseDown(e){let t=u.current,a=e.nativeEvent;if(0!==e.button||"click"===i||rJ(t,!0)&&l)return;let f=o.current.openEvent,p=f?.type,h=!(r&&s&&(!f||!c||"click"===p||"mousedown"===p));d.request(()=>{n(h,a,"click")})},onClick(e){let t=u.current;if("mousedown"===i&&t){u.current=void 0;return}if(rJ(t,!0)&&l)return;let a=o.current.openEvent,d=a?.type;n(!(r&&s&&(!a||!c||"click"===d||"mousedown"===d||"keydown"===d||"keyup"===d)),e.nativeEvent,"click")},onKeyDown(){u.current=void 0}}),[o,i,l,n,r,c,s,d]);return E.useMemo(()=>a?{reference:f}:nb,[a,f])}(eu,{enabled:!l&&"context-menu"!==t.type,event:K&&"menubar"===t.type?"click":"mousedown",toggle:!G||"menu"!==t.type,ignoreMouse:G&&"menu"===t.type,stickIfOpen:void 0===t.type&&I}),eh=nC(eu,{enabled:!l,bubbles:g&&"menu"===t.type,outsidePress:()=>"context-menu"!==t.type||M.current?.type==="contextmenu"||X.current}),em=function(e,t={}){let{open:r,elements:n,floatingId:o}=e,{enabled:a=!0,role:i="dialog"}=t,s=ro(),l=n.domReference?.id||s,c=E.useMemo(()=>no(n.floating)?.id||o,[n.floating,o]),u=nE.get(i)??i,d=null!=rc(),f=E.useMemo(()=>"tooltip"===u||"label"===i?{[`aria-${"label"===i?"labelledby":"describedby"}`]:r?c:void 0}:{"aria-expanded":r?"true":"false","aria-haspopup":"alertdialog"===u?"dialog":u,"aria-controls":r?c:void 0,..."listbox"===u&&{role:"combobox"},..."menu"===u&&{id:l},..."menu"===u&&d&&{role:"menuitem"},..."select"===i&&{"aria-autocomplete":"none"},..."combobox"===i&&{"aria-autocomplete":"list"}},[u,c,d,r,l,i]),p=E.useMemo(()=>{let e={id:c,...u&&{role:u}};return"tooltip"===u||"label"===i?e:{...e,..."menu"===u&&{"aria-labelledby":l}}},[u,c,l,i]),h=E.useCallback(({active:e,selected:t})=>{let r={role:"option",...e&&{id:`${c}-fui-option`}};switch(i){case"select":case"combobox":return{...r,"aria-selected":t}}return{}},[c,i]);return E.useMemo(()=>a?{reference:f,floating:p,item:h}:{},[a,f,p,h])}(eu,{role:"menu"}),eg=os(),ev=function(e,t){let{open:r,onOpenChange:n,elements:o,floatingId:a}=e,{listRef:i,activeIndex:s,onNavigate:l=()=>{},enabled:c=!0,selectedIndex:u=null,allowEscape:d=!1,loop:f=!1,nested:p=!1,rtl:h=!1,virtual:m=!1,focusItemOnOpen:g="auto",focusItemOnHover:v=!0,openOnArrowKeyDown:x=!0,disabledIndices:y,orientation:b="vertical",parentOrientation:w,cols:_=1,scrollItemIntoView:k=!0,virtualItemRef:j,itemSizes:S,dense:C=!1}=t,T=rD(no(o.floating)),N=rc(),I=E.useContext(rl);ri(()=>{e.dataRef.current.orientation=b},[e,b]);let z=nn(o.domReference),R=E.useRef(g),P=E.useRef(u??-1),L=E.useRef(null),O=E.useRef(!0),M=t7(()=>{l(-1===P.current?null:P.current)}),A=E.useRef(M),D=E.useRef(!!o.floating),F=E.useRef(r),$=E.useRef(!1),U=E.useRef(!1),Z=rD(y),q=rD(r),B=rD(k),V=rD(u),[H,W]=E.useState(),G=t7(()=>{function e(e){m?(e.id?.endsWith("-fui-option")&&(e.id=`${a}-${Math.random().toString(16).slice(2,10)}`),W(e.id),I?.events.emit("virtualfocus",e),j&&(j.current=e)):n5(e,{sync:$.current,preventScroll:!0})}let t=i.current[P.current],r=U.current;t&&e(t),($.current?e=>e():requestAnimationFrame)(()=>{let n=i.current[P.current]||t;if(!n)return;t||e(n);let o=B.current;o&&Y&&(r||!O.current)&&n.scrollIntoView?.("boolean"==typeof o?{block:"nearest",inline:"nearest"}:o)})});ri(()=>{c&&(r&&o.floating?R.current&&null!=u&&(U.current=!0,P.current=u,M()):D.current&&(P.current=-1,A.current()))},[c,r,o.floating,u,M]),ri(()=>{if(c&&r&&o.floating)if(null==s){if($.current=!1,null!=V.current)return;if(D.current&&(P.current=-1,G()),(!F.current||!D.current)&&R.current&&(null!=L.current||!0===R.current&&null==L.current)){let e=0,t=()=>{null==i.current[0]?(e<2&&(e?requestAnimationFrame:queueMicrotask)(t),e+=1):(P.current=null==L.current||n7(L.current,b,h)||p?nJ(i,Z.current):n0(i,Z.current),L.current=null,M())};t()}}else nQ(i,s)||(P.current=s,G(),U.current=!1)},[c,r,o.floating,s,V,p,i,b,h,M,G,Z]),ri(()=>{if(!c||o.floating||!I||m||!D.current)return;let e=I.nodesRef.current,t=e.find(e=>e.id===N)?.context?.elements.floating,r=r7(nt(o.floating)),n=e.some(e=>e.context&&r9(e.context.elements.floating,r));t&&!n&&O.current&&t.focus({preventScroll:!0})},[c,o.floating,I,N,m]),ri(()=>{A.current=M,F.current=r,D.current=!!o.floating}),ri(()=>{r||(L.current=null,R.current=g)},[r,g]);let K=null!=s,Y=E.useMemo(()=>{function e(e){if(!q.current)return;let t=i.current.indexOf(e);-1!==t&&P.current!==t&&(P.current=t,M())}return{onFocus({currentTarget:t}){$.current=!0,e(t)},onClick:({currentTarget:e})=>e.focus({preventScroll:!0}),onMouseMove({currentTarget:t}){$.current=!0,U.current=!1,v&&e(t)},onPointerLeave({pointerType:e}){!O.current||"touch"===e||($.current=!0,v&&(P.current=-1,M(),m||T.current?.focus({preventScroll:!0})))}}},[q,T,v,i,M,m]),X=E.useCallback(()=>w??I?.nodesRef.current.find(e=>e.id===N)?.context?.dataRef?.current.orientation,[N,I,w]),Q=t7(e=>{var t,a;if(O.current=!1,$.current=!0,229===e.which||!q.current&&e.currentTarget===T.current)return;if(p&&(t=e.key,"both"===b||"horizontal"===b&&_&&_>1?"Escape"===t:n4(b,h?t===r5:t===r3,t===r4))){n6(e.key,X())||rY(e),n(!1,e.nativeEvent,"list-navigation"),ry(o.domReference)&&(m?I?.events.emit("virtualfocus",o.domReference):o.domReference.focus());return}let s=P.current,l=nJ(i,y),c=n0(i,y);if(z||("Home"===e.key&&(rY(e),P.current=l,M()),"End"===e.key&&(rY(e),P.current=c,M())),_>1){let t,r,n=S||Array.from({length:i.current.length},()=>({width:1,height:1})),o=(t=[],r=0,n.forEach(({width:e,height:n},o)=>{let a=!1;for(C&&(r=0);!a;){let i=[];for(let t=0;t<e;t+=1)for(let e=0;e<n;e+=1)i.push(r+t+e*_);r%_+e<=_&&i.every(e=>null==t[e])?(i.forEach(e=>{t[e]=o}),a=!0):r+=1}}),[...t]),s=o.findIndex(e=>null!=e&&!n2(i,e,y)),u=o.reduce((e,t,r)=>null==t||n2(i,t,y)?e:r,-1),d=o[function(e,{event:t,orientation:r,loop:n,rtl:o,cols:a,disabledIndices:i,minIndex:s,maxIndex:l,prevIndex:c,stopEvent:u=!1}){let d=c;if(t.key===r4){if(u&&rY(t),-1===c)d=l;else if(d=n1(e,{startingIndex:d,amount:a,decrement:!0,disabledIndices:i}),n&&(c-a<s||d<0)){let e=c%a,t=l%a,r=l-(t-e);d=t===e?l:t>e?r:r-a}nQ(e,d)&&(d=c)}if(t.key===r6&&(u&&rY(t),-1===c?d=s:(d=n1(e,{startingIndex:c,amount:a,disabledIndices:i}),n&&c+a>l&&(d=n1(e,{startingIndex:c%a-a,amount:a,disabledIndices:i}))),nQ(e,d)&&(d=c)),"both"===r){let r=nR(c/a);t.key===(o?r3:r5)&&(u&&rY(t),c%a!=a-1?(d=n1(e,{startingIndex:c,disabledIndices:i}),n&&nX(d,a,r)&&(d=n1(e,{startingIndex:c-c%a-1,disabledIndices:i}))):n&&(d=n1(e,{startingIndex:c-c%a-1,disabledIndices:i})),nX(d,a,r)&&(d=c)),t.key===(o?r5:r3)&&(u&&rY(t),c%a!=0?(d=n1(e,{startingIndex:c,decrement:!0,disabledIndices:i}),n&&nX(d,a,r)&&(d=n1(e,{startingIndex:c+(a-c%a),decrement:!0,disabledIndices:i}))):n&&(d=n1(e,{startingIndex:c+(a-c%a),decrement:!0,disabledIndices:i})),nX(d,a,r)&&(d=c));let s=nR(l/a)===r;nQ(e,d)&&(d=n&&s?t.key===(o?r5:r3)?l:n1(e,{startingIndex:c-c%a-1,disabledIndices:i}):c)}return d}({current:o.map(e=>null!=e?i.current[e]:null)},{event:e,orientation:b,loop:f,rtl:h,cols:_,disabledIndices:(a=[...("function"!=typeof y?y:null)||i.current.map((e,t)=>n2(i,t,y)?t:void 0),void 0],o.flatMap((e,t)=>a.includes(e)?[t]:[])),minIndex:s,maxIndex:u,prevIndex:function(e,t,r,n,o){if(-1===e)return -1;let a=r.indexOf(e),i=t[e];switch(o){case"tl":return a;case"tr":if(!i)return a;return a+i.width-1;case"bl":if(!i)return a;return a+(i.height-1)*n;case"br":return r.lastIndexOf(e);default:return -1}}(P.current>c?l:P.current,n,o,_,e.key===r6?"bl":e.key===(h?r3:r5)?"tr":"tl"),stopEvent:!0})];if(null!=d&&(P.current=d,M()),"both"===b)return}if(n6(e.key,b)){if(rY(e),r&&!m&&r7(e.currentTarget.ownerDocument)===e.currentTarget){P.current=n7(e.key,b,h)?l:c,M();return}n7(e.key,b,h)?f?P.current=s>=c?d&&s!==i.current.length?-1:l:n1(i,{startingIndex:s,disabledIndices:y}):P.current=Math.min(c,n1(i,{startingIndex:s,disabledIndices:y})):f?P.current=s<=l?d&&-1!==s?i.current.length:c:n1(i,{startingIndex:s,decrement:!0,disabledIndices:y}):P.current=Math.max(l,n1(i,{startingIndex:s,decrement:!0,disabledIndices:y})),nQ(i,P.current)&&(P.current=-1),M()}}),J=E.useMemo(()=>m&&r&&K&&{"aria-activedescendant":H},[m,r,K,H]),ee=E.useMemo(()=>({"aria-orientation":"both"===b?void 0:b,...!z?J:{},onKeyDown(e){if("Tab"===e.key&&e.shiftKey&&r&&!m){rY(e),n(!1,e.nativeEvent,"list-navigation"),ry(o.domReference)&&o.domReference.focus();return}Q(e)},onPointerMove(){O.current=!0}}),[J,Q,b,z,n,r,m,o.domReference]),et=E.useMemo(()=>{function e(e){"auto"===g&&rX(e.nativeEvent)&&(R.current=!0)}function t(e){R.current=g,"auto"===g&&rQ(e.nativeEvent)&&(R.current=!0)}return{...J,onKeyDown(e){var t;O.current=!1;let o=e.key.startsWith("Arrow"),a=(t=e.key,n4(X(),h?t===r3:t===r5,t===r6)),s=n6(e.key,b),l=(p?a:s)||"Enter"===e.key||""===e.key.trim();if(m&&r)return Q(e);if(r||x||!o){if(l){let t=n6(e.key,X());L.current=p&&t?null:e.key}if(p){a&&(rY(e),r?(P.current=nJ(i,Z.current),M()):n(!0,e.nativeEvent,"list-navigation"));return}s&&(null!=u&&(P.current=u),rY(e),!r&&x?n(!0,e.nativeEvent,"list-navigation"):Q(e),r&&M())}},onFocus(){r&&!m&&(P.current=-1,M())},onPointerDown:t,onPointerEnter:t,onMouseDown:e,onClick:e}},[J,Q,Z,g,i,p,M,n,r,x,b,X,h,u,m]);return E.useMemo(()=>c?{reference:et,floating:ee,item:Y}:{},[c,et,ee,Y])}(eu,{enabled:!l,listRef:F,activeIndex:S,nested:void 0!==t.type,loop:u,orientation:d,parentOrientation:"menubar"===t.type?t.context.orientation:void 0,rtl:"rtl"===eg,disabledIndices:oE,onNavigate:C,openOnArrowKeyDown:"context-menu"!==t.type}),ex=E.useRef(!1),ey=function(e,t){let{open:r,dataRef:n}=e,{listRef:o,activeIndex:a,onMatch:i,onTypingChange:s,enabled:l=!0,findMatch:c=null,resetMs:u=750,ignoreKeys:d=[],selectedIndex:f=null}=t,p=t5(),h=E.useRef(""),m=E.useRef(f??a??-1),g=E.useRef(null),v=t7(i),x=t7(s),y=rD(c),b=rD(d);ri(()=>{r&&(p.clear(),g.current=null,h.current="")},[r,p]),ri(()=>{r&&""===h.current&&(m.current=f??a??-1)},[r,f,a]);let w=t7(e=>{e?n.current.typing||(n.current.typing=e,x(e)):n.current.typing&&(n.current.typing=e,x(e))}),_=t7(e=>{function t(e,t,r){let n=y.current?y.current(t,r):t.find(e=>e?.toLocaleLowerCase().indexOf(r.toLocaleLowerCase())===0);return n?e.indexOf(n):-1}let n=o.current;if(h.current.length>0&&" "!==h.current[0]&&(-1===t(n,n,h.current)?w(!1):" "===e.key&&rY(e)),null==n||b.current.includes(e.key)||1!==e.key.length||e.ctrlKey||e.metaKey||e.altKey)return;r&&" "!==e.key&&(rY(e),w(!0)),n.every(e=>!e||e[0]?.toLocaleLowerCase()!==e[1]?.toLocaleLowerCase())&&h.current===e.key&&(h.current="",m.current=g.current),h.current+=e.key,p.start(u,()=>{h.current="",m.current=g.current,w(!1)});let a=m.current,i=t(n,[...n.slice((a||0)+1),...n.slice(0,(a||0)+1)],h.current);-1!==i?(v(i),g.current=i):" "!==e.key&&(h.current="",w(!1))}),k=E.useMemo(()=>({onKeyDown:_}),[_]),j=E.useMemo(()=>({onKeyDown:_,onKeyUp(e){" "===e.key&&w(!1)}}),[_,w]);return E.useMemo(()=>l?{reference:k,floating:j}:{},[l,k,j])}(eu,{listRef:$,activeIndex:S,resetMs:500,onMatch:e=>{K&&e!==S&&C(e)},onTypingChange:E.useCallback(e=>{ex.current=e},[])}),{getReferenceProps:eb,getFloatingProps:ew,getItemProps:e_}=n9([ed,ep,eh,ef,em,ev,ey]),ek=function(e){let{enabled:t=!0,mouseDownAction:r,open:n}=e,o=E.useRef(!1);return E.useMemo(()=>t?{onMouseDown:e=>{("open"===r&&!n||"close"===r&&n)&&(o.current=!0,ol(e.currentTarget).addEventListener("click",()=>{o.current=!1},{once:!0}))},onClick:e=>{o.current&&(o.current=!1,e.preventBaseUIHandler())}}:nb,[t,r,n])}({open:K,enabled:"menubar"===t.type,mouseDownAction:"open"}),ej=E.useMemo(()=>{let e=ow(eb(),{onMouseEnter(){j(!0)},onMouseMove(){W(!0)}},eo,ek);return delete e.role,e},[eb,ek,W,eo]),eS=E.useMemo(()=>ew({onMouseEnter(){G&&"menu"!==t.type||j(!1)},onMouseMove(){W(!0)},onClick(){G&&j(!1)}}),[ew,G,t.type,W]),eC=E.useMemo(()=>e_(),[e_]),eE=E.useMemo(()=>({activeIndex:S,setActiveIndex:C,allowMouseUpTriggerRef:t.type?t.context.allowMouseUpTriggerRef:oT,floatingRootContext:eu,itemProps:eC,popupProps:eS,triggerProps:ej,itemDomElements:F,itemLabels:$,mounted:ee,open:K,popupRef:A,positionerRef:D,setOpen:ec,setPositionerElement:J,triggerElement:v,setTriggerElement:x,transitionStatus:er,lastOpenChangeReason:T,instantType:w,onOpenChangeComplete:i,setHoverEnabled:j,typingRef:ex,modal:V,disabled:l,parent:t,rootId:B,allowMouseEnter:H,setAllowMouseEnter:W}),[S,eu,eC,eS,ej,F,$,ee,K,D,ec,er,v,J,T,w,i,V,l,t,B,H,W]),eT=(0,z.jsx)(ot.Provider,{value:eE,children:n});return void 0===t.type||"context-menu"===t.type?(0,z.jsx)(rd,{children:eT}):eT};function oI(e,t,r,n){var o,a,i,s,l;let c=t0(oz).current;return o=c,a=e,i=t,s=r,l=n,(o.refs[0]!==a||o.refs[1]!==i||o.refs[2]!==s||o.refs[3]!==l)&&oR(c,[e,t,r,n]),c.callback}function oz(){return{callback:null,cleanup:null,refs:[]}}function oR(e,t){if(e.refs=t,t.every(e=>null==e)){e.callback=null;return}e.callback=r=>{if(e.cleanup&&(e.cleanup(),e.cleanup=null),null!=r){let n=Array(t.length).fill(null);for(let e=0;e<t.length;e+=1){let o=t[e];if(null!=o)switch(typeof o){case"function":{let t=o(r);"function"==typeof t&&(n[e]=t);break}case"object":o.current=r}}e.cleanup=()=>{for(let e=0;e<t.length;e+=1){let r=t[e];if(null!=r)switch(typeof r){case"function":{let t=n[e];"function"==typeof t?t():r(null);break}case"object":r.current=null}}}}}}let oP=((o={}).startingStyle="data-starting-style",o.endingStyle="data-ending-style",o),oL={[oP.startingStyle]:""},oO={[oP.endingStyle]:""},oM={transitionStatus:e=>"starting"===e?oL:"ending"===e?oO:null},oA=((a={}).open="data-open",a.closed="data-closed",a[a.startingStyle=oP.startingStyle]="startingStyle",a[a.endingStyle=oP.endingStyle]="endingStyle",a.anchorHidden="data-anchor-hidden",a),oD=((i={}).popupOpen="data-popup-open",i.pressed="data-pressed",i),oF={[oD.popupOpen]:""},o$={[oD.popupOpen]:"",[oD.pressed]:""},oU={[oA.open]:""},oZ={[oA.closed]:""},oq={[oA.anchorHidden]:""},oB={open:e=>e?oF:null},oV={open:e=>e?o$:null},oH={open:e=>e?oU:oZ,anchorHidden:e=>e?oq:null},oW=parseInt(E.version,10);function oG(e,t,r={}){let n=t.render,o=function(e,t={}){var r,n,o;let a,{className:i,render:s}=e,{state:l=nb,ref:c,props:u,disableStyleHooks:d,customStyleHookMapping:f,enabled:p=!0}=t,h=p?"function"==typeof i?i(l):i:void 0;!0!==d&&(a=E.useMemo(()=>p?function(e,t){let r={};for(let n in e){let o=e[n];if(t?.hasOwnProperty(n)){let e=t[n](o);null!=e&&Object.assign(r,e);continue}!0===o?r[`data-${n.toLowerCase()}`]="":o&&(r[`data-${n.toLowerCase()}`]=o.toString())}return r}(l,f):nb,[l,f,p]));let m=p?oy(a,Array.isArray(u)?function(e){if(0===e.length)return ob;if(1===e.length)return oj(e[0],ob);let t={...oj(e[0],ob)};for(let r=1;r<e.length;r+=1)t=o_(t,e[r]);return t}(u):u)??nb:nb;if("undefined"!=typeof document)if(p)if(Array.isArray(c)){let e;r=[m.ref,oK(s),...c],n=e=t0(oz).current,o=r,(n.refs.length!==o.length||n.refs.some((e,t)=>e!==o[t]))&&oR(e,r),m.ref=e.callback}else m.ref=oI(m.ref,oK(s),c);else oI(null,null);return p?(void 0!==h&&(m.className=oC(m.className,h)),m):nb}(t,r);return!1===r.enabled?null:function(e,t,r,n){if(t){if("function"==typeof t)return t(r,n);let e=ow(r,t.props);return e.ref=r.ref,E.cloneElement(t,e)}if(e&&"string"==typeof e){var o,a;return o=e,a=r,"button"===o?(0,z.jsx)("button",{type:"button",...a}):"img"===o?(0,z.jsx)("img",{alt:"",...a}):E.createElement(o,a)}throw Error("Base UI: Render element or function are not defined.")}(e,n,o,r.state??nb)}function oK(e){return e&&"function"!=typeof e?oW>=19?e.props.ref:e.ref:null}let oY=E.createContext(void 0);function oX(e=!1){let t=E.useContext(oY);if(void 0===t&&!e)throw Error("Base UI: CompositeRootContext is missing. Composite parts must be placed within <Composite.Root>.");return t}function oQ(e={}){let{disabled:t=!1,focusableWhenDisabled:r,tabIndex:n=0,native:o=!0}=e,a=E.useRef(null),i=void 0!==oX(!0),s=t7(()=>{let e=a.current;return!!(e?.tagName==="A"&&e?.href)}),{props:l}=function(e){let{focusableWhenDisabled:t,disabled:r,composite:n=!1,tabIndex:o=0,isNativeButton:a}=e,i=n&&!1!==t,s=n&&!1===t;return{props:E.useMemo(()=>{let e={onKeyDown(e){r&&t&&"Tab"!==e.key&&e.preventDefault()}};return n||(e.tabIndex=o,!a&&r&&(e.tabIndex=t?o:-1)),(a&&(t||i)||!a&&r)&&(e["aria-disabled"]=r),a&&(!t||s)&&(e.disabled=r),e},[n,r,t,i,s,a,o])}}({focusableWhenDisabled:r,disabled:t,composite:i,tabIndex:n,isNativeButton:o});return ri(()=>{let e=a.current;e instanceof HTMLButtonElement&&i&&t&&void 0===l.disabled&&e.disabled&&(e.disabled=!1)},[t,l.disabled,i]),{getButtonProps:E.useCallback((e={})=>{let{onClick:r,onMouseDown:n,onKeyUp:a,onKeyDown:i,onPointerDown:c,...u}=e;return ow({type:o?"button":void 0,onClick(e){t?e.preventDefault():r?.(e)},onMouseDown(e){t||n?.(e)},onKeyDown(e){if(t||(oS(e),i?.(e)),e.baseUIHandlerPrevented)return;let n=e.target===e.currentTarget&&!o&&!s()&&!t,a="Enter"===e.key,l=" "===e.key;n&&((l||a)&&e.preventDefault(),a&&r?.(e))},onKeyUp(e){t||(oS(e),a?.(e)),!e.baseUIHandlerPrevented&&(e.target!==e.currentTarget||o||t||" "!==e.key||r?.(e))},onPointerDown(e){t?e.preventDefault():c?.(e)}},o?void 0:{role:"button"},l,u)},[t,l,o,s]),buttonRef:a}}let oJ=E.createContext({register:()=>{},unregister:()=>{},subscribeMapChange:()=>()=>{},elementsRef:{current:[]},nextIndexRef:{current:0}}),o0=((s={})[s.None=0]="None",s[s.GuessFromOrder=1]="GuessFromOrder",s);function o1(e={}){let{label:t,metadata:r,textRef:n,indexGuessBehavior:o}=e,{register:a,unregister:i,subscribeMapChange:s,elementsRef:l,labelsRef:c,nextIndexRef:u}=E.useContext(oJ),d=E.useRef(-1),[f,p]=E.useState(o===o0.GuessFromOrder?()=>{if(-1===d.current){let e=u.current;u.current+=1,d.current=e}return d.current}:-1),h=E.useRef(null),m=E.useCallback(e=>{if(h.current=e,-1!==f&&null!==e&&(l.current[f]=e,c)){let r=void 0!==t;c.current[f]=r?t:n?.current?.textContent??e.textContent}},[f,l,c,t,n]);return ri(()=>{let e=h.current;if(e)return a(e,r),()=>{i(e)}},[a,i,r]),ri(()=>s(e=>{let t=h.current?e.get(h.current)?.index:null;null!=t&&p(t)}),[s,p]),E.useMemo(()=>({ref:m,index:f}),[f,m])}function o2(e){let{render:t,className:r,state:n=nb,props:o=nw,refs:a=nw,metadata:i,customStyleHookMapping:s,tag:l="div",...c}=e,{compositeProps:u,compositeRef:d}=function(e={}){let{highlightItemOnHover:t,highlightedIndex:r,onHighlightedIndexChange:n}=oX(),{ref:o,index:a}=o1(e),i=r===a,s=E.useRef(null),l=oI(o,s);return{compositeProps:E.useMemo(()=>({tabIndex:i?0:-1,onFocus(){n(a)},onMouseMove(){let e=s.current;if(!t||!e)return;let r=e.hasAttribute("disabled")||"true"===e.ariaDisabled;i||r||e.focus()}}),[i,n,a,t]),compositeRef:l,index:a}}({metadata:i});return oG(l,e,{state:n,ref:[...a,d],props:[u,...o,c],customStyleHookMapping:s})}let o3=E.forwardRef(function(e,t){let{render:r,className:n,disabled:o=!1,nativeButton:a=!0,...i}=e,{triggerProps:s,disabled:l,setTriggerElement:c,open:u,allowMouseUpTriggerRef:d,positionerRef:f,parent:p,lastOpenChangeReason:h,rootId:m}=or(),g=o||l,v=E.useRef(null),x=t5(),{getButtonProps:y,buttonRef:b}=oQ({disabled:g,native:a}),w=oI(b,c),{events:_}=E.useContext(rl);E.useEffect(()=>{u||void 0!==p.type||(d.current=!1)},[d,u,p.type]);let k=t7(e=>{if(!v.current)return;x.clear(),d.current=!1;let t=e.target;if(r9(v.current,t)||r9(f.current,t)||t===v.current||null!=t&&function e(t){return ry(t)&&t.hasAttribute("data-rootownerid")?t.getAttribute("data-rootownerid")??void 0:rR(t)?void 0:e(rO(t))}(t)===m)return;let r=function(e){let t=e.getBoundingClientRect(),r=window.getComputedStyle(e,"::before"),n=window.getComputedStyle(e,"::after");if("none"===r.content&&"none"===n.content)return t;let o=parseFloat(r.width)||0,a=parseFloat(r.height)||0,i=parseFloat(n.width)||0,s=parseFloat(n.height)||0,l=Math.max(t.width,o,i),c=Math.max(t.height,a,s),u=l-t.width,d=c-t.height;return{left:t.left-u/2,right:t.right+u/2,top:t.top-d/2,bottom:t.bottom+d/2}}(v.current);e.clientX>=r.left-2&&e.clientX<=r.right+2&&e.clientY>=r.top-2&&e.clientY<=r.bottom+2||_.emit("close",{domEvent:e,reason:"cancel-open"})});E.useEffect(()=>{u&&"trigger-hover"===h&&ol(v.current).addEventListener("mouseup",k,{once:!0})},[u,k,h]);let j="menubar"===p.type,S=E.useCallback(e=>ow(j?{role:"menuitem"}:{},{"aria-haspopup":"menu",ref:w,onMouseDown:e=>{u||(x.start(200,()=>{d.current=!0}),ol(e.currentTarget).addEventListener("mouseup",k,{once:!0}))}},e,y),[y,w,u,d,x,k,j]),C=E.useMemo(()=>({disabled:g,open:u}),[g,u]),T=[v,t,b],N=[s,i,S],I=oG("button",e,{enabled:!j,customStyleHookMapping:oV,state:C,ref:T,props:N});return j?(0,z.jsx)(o2,{tag:"button",render:r,className:n,state:C,refs:T,props:N,customStyleHookMapping:oV}):I}),o5={clip:"rect(0 0 0 0)",overflow:"hidden",whiteSpace:"nowrap",position:"fixed",top:0,left:0,border:0,padding:0,width:1,height:1,margin:-1},o4=E.forwardRef(function(e,t){let[r,n]=E.useState();return ri(()=>{rH&&n("button")},[]),(0,z.jsx)("span",{...e,ref:t,tabIndex:0,role:r,"aria-hidden":!r||void 0,style:o5,"data-base-ui-focus-guard":""})});var o6='input:not([inert]),select:not([inert]),textarea:not([inert]),a[href]:not([inert]),button:not([inert]),[tabindex]:not(slot):not([inert]),audio[controls]:not([inert]),video[controls]:not([inert]),[contenteditable]:not([contenteditable="false"]):not([inert]),details>summary:first-of-type:not([inert]),details:not([inert])',o7="undefined"==typeof Element,o9=o7?function(){}:Element.prototype.matches||Element.prototype.msMatchesSelector||Element.prototype.webkitMatchesSelector,o8=!o7&&Element.prototype.getRootNode?function(e){var t;return null==e||null==(t=e.getRootNode)?void 0:t.call(e)}:function(e){return null==e?void 0:e.ownerDocument},ae=function e(t,r){void 0===r&&(r=!0);var n,o=null==t||null==(n=t.getAttribute)?void 0:n.call(t,"inert");return""===o||"true"===o||r&&t&&e(t.parentNode)},at=function(e){var t,r=null==e||null==(t=e.getAttribute)?void 0:t.call(e,"contenteditable");return""===r||"true"===r},ar=function(e,t,r){if(ae(e))return[];var n=Array.prototype.slice.apply(e.querySelectorAll(o6));return t&&o9.call(e,o6)&&n.unshift(e),n=n.filter(r)},an=function e(t,r,n){for(var o=[],a=Array.from(t);a.length;){var i=a.shift();if(!ae(i,!1))if("SLOT"===i.tagName){var s=i.assignedElements(),l=e(s.length?s:i.children,!0,n);n.flatten?o.push.apply(o,l):o.push({scopeParent:i,candidates:l})}else{o9.call(i,o6)&&n.filter(i)&&(r||!t.includes(i))&&o.push(i);var c=i.shadowRoot||"function"==typeof n.getShadowRoot&&n.getShadowRoot(i),u=!ae(c,!1)&&(!n.shadowRootFilter||n.shadowRootFilter(i));if(c&&u){var d=e(!0===c?i.children:c.children,!0,n);n.flatten?o.push.apply(o,d):o.push({scopeParent:i,candidates:d})}else a.unshift.apply(a,i.children)}}return o},ao=function(e){return!isNaN(parseInt(e.getAttribute("tabindex"),10))},aa=function(e){if(!e)throw Error("No node provided");return e.tabIndex<0&&(/^(AUDIO|VIDEO|DETAILS)$/.test(e.tagName)||at(e))&&!ao(e)?0:e.tabIndex},ai=function(e,t){var r=aa(e);return r<0&&t&&!ao(e)?0:r},as=function(e,t){return e.tabIndex===t.tabIndex?e.documentOrder-t.documentOrder:e.tabIndex-t.tabIndex},al=function(e){return"INPUT"===e.tagName},ac=function(e,t){for(var r=0;r<e.length;r++)if(e[r].checked&&e[r].form===t)return e[r]},au=function(e){if(!e.name)return!0;var t,r=e.form||o8(e),n=function(e){return r.querySelectorAll('input[type="radio"][name="'+e+'"]')};if("undefined"!=typeof window&&void 0!==window.CSS&&"function"==typeof window.CSS.escape)t=n(window.CSS.escape(e.name));else try{t=n(e.name)}catch(e){return console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s",e.message),!1}var o=ac(t,e.form);return!o||o===e},ad=function(e){return al(e)&&"radio"===e.type&&!au(e)},af=function(e){var t,r,n,o,a,i,s,l=e&&o8(e),c=null==(t=l)?void 0:t.host,u=!1;if(l&&l!==e)for(u=!!(null!=(r=c)&&null!=(n=r.ownerDocument)&&n.contains(c)||null!=e&&null!=(o=e.ownerDocument)&&o.contains(e));!u&&c;)u=!!(null!=(i=c=null==(a=l=o8(c))?void 0:a.host)&&null!=(s=i.ownerDocument)&&s.contains(c));return u},ap=function(e){var t=e.getBoundingClientRect(),r=t.width,n=t.height;return 0===r&&0===n},ah=function(e,t){var r=t.displayCheck,n=t.getShadowRoot;if("hidden"===getComputedStyle(e).visibility)return!0;var o=o9.call(e,"details>summary:first-of-type")?e.parentElement:e;if(o9.call(o,"details:not([open]) *"))return!0;if(r&&"full"!==r&&"legacy-full"!==r){if("non-zero-area"===r)return ap(e)}else{if("function"==typeof n){for(var a=e;e;){var i=e.parentElement,s=o8(e);if(i&&!i.shadowRoot&&!0===n(i))return ap(e);e=e.assignedSlot?e.assignedSlot:i||s===e.ownerDocument?i:s.host}e=a}if(af(e))return!e.getClientRects().length;if("legacy-full"!==r)return!0}return!1},am=function(e){if(/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(e.tagName))for(var t=e.parentElement;t;){if("FIELDSET"===t.tagName&&t.disabled){for(var r=0;r<t.children.length;r++){var n=t.children.item(r);if("LEGEND"===n.tagName)return!!o9.call(t,"fieldset[disabled] *")||!n.contains(e)}return!0}t=t.parentElement}return!1},ag=function(e,t){return!(t.disabled||ae(t)||al(t)&&"hidden"===t.type||ah(t,e)||"DETAILS"===t.tagName&&Array.prototype.slice.apply(t.children).some(function(e){return"SUMMARY"===e.tagName})||am(t))},av=function(e,t){return!(ad(t)||0>aa(t))&&!!ag(e,t)},ax=function(e){var t=parseInt(e.getAttribute("tabindex"),10);return!!isNaN(t)||!!(t>=0)},ay=function e(t){var r=[],n=[];return t.forEach(function(t,o){var a=!!t.scopeParent,i=a?t.scopeParent:t,s=ai(i,a),l=a?e(t.candidates):i;0===s?a?r.push.apply(r,l):r.push(i):n.push({documentOrder:o,tabIndex:s,item:t,isScope:a,content:l})}),n.sort(as).reduce(function(e,t){return t.isScope?e.push.apply(e,t.content):e.push(t.content),e},[]).concat(r)},ab=function(e,t){return ay((t=t||{}).getShadowRoot?an([e],t.includeContainer,{filter:av.bind(null,t),flatten:!1,getShadowRoot:t.getShadowRoot,shadowRootFilter:ax}):ar(e,t.includeContainer,av.bind(null,t)))},aw=function(e,t){return(t=t||{}).getShadowRoot?an([e],t.includeContainer,{filter:ag.bind(null,t),flatten:!0,getShadowRoot:t.getShadowRoot}):ar(e,t.includeContainer,ag.bind(null,t))},a_=function(e,t){if(t=t||{},!e)throw Error("No node provided");return!1!==o9.call(e,o6)&&av(t,e)};let ak=()=>({getShadowRoot:!0,displayCheck:"function"==typeof ResizeObserver&&ResizeObserver.toString().includes("[native code]")?"full":"none"});function aj(e,t){let r=ab(e,ak()),n=r.length;if(0===n)return;let o=r7(nt(e)),a=r.indexOf(o);return r[-1===a?1===t?0:n-1:a+t]}function aS(e){return aj(nt(e).body,1)||e}function aC(e){return aj(nt(e).body,-1)||e}function aE(e,t){let r=t||e.currentTarget,n=e.relatedTarget;return!n||!r9(r,n)}function aT(e){e.querySelectorAll("[data-tabindex]").forEach(e=>{let t=e.dataset.tabindex;delete e.dataset.tabindex,t?e.setAttribute("tabindex",t):e.removeAttribute("tabindex")})}let aN=E.createContext(null),aI=na("portal");function az(e={}){let{id:t,root:r}=e,n=ro(),o=E.useContext(aN),[a,i]=E.useState(null),s=E.useRef(null);return ri(()=>()=>{a?.remove(),queueMicrotask(()=>{s.current=null})},[a]),ri(()=>{if(!n||s.current)return;let e=t?document.getElementById(t):null;if(!e)return;let r=document.createElement("div");r.id=n,r.setAttribute(aI,""),e.appendChild(r),s.current=r,i(r)},[t,n]),ri(()=>{if(null===r||!n||s.current)return;let e=r||o?.portalNode;e&&!rv(e)&&(e=e.current),e=e||document.body;let a=null;t&&((a=document.createElement("div")).id=t,e.appendChild(a));let l=document.createElement("div");l.id=n,l.setAttribute(aI,""),(e=a||e).appendChild(l),s.current=l,i(l)},[t,r,n,o]),a}function aR(e){let{children:t,id:r,root:n,preserveTabOrder:o=!0}=e,a=az({id:r,root:n}),[i,s]=E.useState(null),l=E.useRef(null),c=E.useRef(null),u=E.useRef(null),d=E.useRef(null),f=i?.modal,p=i?.open,h=!!i&&!i.modal&&i.open&&o&&!!(n||a);return E.useEffect(()=>{if(a&&o&&!f)return a.addEventListener("focusin",e,!0),a.addEventListener("focusout",e,!0),()=>{a.removeEventListener("focusin",e,!0),a.removeEventListener("focusout",e,!0)};function e(e){a&&aE(e)&&("focusin"===e.type?aT:function(e){ab(e,ak()).forEach(e=>{e.dataset.tabindex=e.getAttribute("tabindex")||"",e.setAttribute("tabindex","-1")})})(a)}},[a,o,f]),E.useEffect(()=>{!a||p||aT(a)},[p,a]),(0,z.jsxs)(aN.Provider,{value:E.useMemo(()=>({preserveTabOrder:o,beforeOutsideRef:l,afterOutsideRef:c,beforeInsideRef:u,afterInsideRef:d,portalNode:a,setFocusManagerState:s}),[o,a]),children:[h&&a&&(0,z.jsx)(o4,{"data-type":"outside",ref:l,onFocus:e=>{if(aE(e,a))u.current?.focus();else{let e=aC(i?i.domReference:null);e?.focus()}}}),h&&a&&(0,z.jsx)("span",{"aria-owns":a.id,style:o5}),a&&R.createPortal(t,a),h&&a&&(0,z.jsx)(o4,{"data-type":"outside",ref:c,onFocus:e=>{if(aE(e,a))d.current?.focus();else{let t=aS(i?i.domReference:null);t?.focus(),i?.closeOnFocusOut&&i?.onOpenChange(!1,e.nativeEvent,"focus-out")}}})]})}let aP=E.createContext(void 0);function aL(e){let{children:t,keepMounted:r=!1,container:n}=e,{mounted:o}=or();return o||r?(0,z.jsx)(aP.Provider,{value:r,children:(0,z.jsx)(aR,{root:n,children:t})}):null}let aO=E.createContext(void 0);function aM(e,t,r){let n,{reference:o,floating:a}=e,i=nZ(t),s=nF(nZ(t)),l=n$(s),c=nA(t),u="y"===i,d=o.x+o.width/2-a.width/2,f=o.y+o.height/2-a.height/2,p=o[l]/2-a[l]/2;switch(c){case"top":n={x:d,y:o.y-a.height};break;case"bottom":n={x:d,y:o.y+o.height};break;case"right":n={x:o.x+o.width,y:f};break;case"left":n={x:o.x-a.width,y:f};break;default:n={x:o.x,y:o.y}}switch(nD(t)){case"start":n[s]-=p*(r&&u?-1:1);break;case"end":n[s]+=p*(r&&u?-1:1)}return n}let aA=async(e,t,r)=>{let{placement:n="bottom",strategy:o="absolute",middleware:a=[],platform:i}=r,s=a.filter(Boolean),l=await (null==i.isRTL?void 0:i.isRTL(t)),c=await i.getElementRects({reference:e,floating:t,strategy:o}),{x:u,y:d}=aM(c,n,l),f=n,p={},h=0;for(let r=0;r<s.length;r++){let{name:a,fn:m}=s[r],{x:g,y:v,data:x,reset:y}=await m({x:u,y:d,initialPlacement:n,placement:f,strategy:o,middlewareData:p,rects:c,platform:i,elements:{reference:e,floating:t}});u=null!=g?g:u,d=null!=v?v:d,p={...p,[a]:{...p[a],...x}},y&&h<=50&&(h++,"object"==typeof y&&(y.placement&&(f=y.placement),y.rects&&(c=!0===y.rects?await i.getElementRects({reference:e,floating:t,strategy:o}):y.rects),{x:u,y:d}=aM(c,f,l)),r=-1)}return{x:u,y:d,placement:f,strategy:o,middlewareData:p}};async function aD(e,t){var r;void 0===t&&(t={});let{x:n,y:o,platform:a,rects:i,elements:s,strategy:l}=e,{boundary:c="clippingAncestors",rootBoundary:u="viewport",elementContext:d="floating",altBoundary:f=!1,padding:p=0}=nM(t,e),h=nK(p),m=s[f?"floating"===d?"reference":"floating":d],g=nY(await a.getClippingRect({element:null==(r=await (null==a.isElement?void 0:a.isElement(m)))||r?m:m.contextElement||await (null==a.getDocumentElement?void 0:a.getDocumentElement(s.floating)),boundary:c,rootBoundary:u,strategy:l})),v="floating"===d?{x:n,y:o,width:i.floating.width,height:i.floating.height}:i.reference,x=await (null==a.getOffsetParent?void 0:a.getOffsetParent(s.floating)),y=await (null==a.isElement?void 0:a.isElement(x))&&await (null==a.getScale?void 0:a.getScale(x))||{x:1,y:1},b=nY(a.convertOffsetParentRelativeRectToViewportRelativeRect?await a.convertOffsetParentRelativeRectToViewportRelativeRect({elements:s,rect:v,offsetParent:x,strategy:l}):v);return{top:(g.top-b.top+h.top)/y.y,bottom:(b.bottom-g.bottom+h.bottom)/y.y,left:(g.left-b.left+h.left)/y.x,right:(b.right-g.right+h.right)/y.x}}function aF(e,t){return{top:e.top-t.height,right:e.right-t.width,bottom:e.bottom-t.height,left:e.left-t.width}}function a$(e){return nT.some(t=>e[t]>=0)}let aU=new Set(["left","top"]);async function aZ(e,t){let{placement:r,platform:n,elements:o}=e,a=await (null==n.isRTL?void 0:n.isRTL(o.floating)),i=nA(r),s=nD(r),l="y"===nZ(r),c=aU.has(i)?-1:1,u=a&&l?-1:1,d=nM(t,e),{mainAxis:f,crossAxis:p,alignmentAxis:h}="number"==typeof d?{mainAxis:d,crossAxis:0,alignmentAxis:null}:{mainAxis:d.mainAxis||0,crossAxis:d.crossAxis||0,alignmentAxis:d.alignmentAxis};return s&&"number"==typeof h&&(p="end"===s?-1*h:h),l?{x:p*u,y:f*c}:{x:f*c,y:p*u}}function aq(e){let t=rP(e),r=parseFloat(t.width)||0,n=parseFloat(t.height)||0,o=ry(e),a=o?e.offsetWidth:r,i=o?e.offsetHeight:n,s=nz(r)!==a||nz(n)!==i;return s&&(r=a,n=i),{width:r,height:n,$:s}}function aB(e){return rx(e)?e:e.contextElement}function aV(e){let t=aB(e);if(!ry(t))return nP(1);let r=t.getBoundingClientRect(),{width:n,height:o,$:a}=aq(t),i=(a?nz(r.width):r.width)/n,s=(a?nz(r.height):r.height)/o;return i&&Number.isFinite(i)||(i=1),s&&Number.isFinite(s)||(s=1),{x:i,y:s}}let aH=nP(0);function aW(e){let t=rm(e);return rI()&&t.visualViewport?{x:t.visualViewport.offsetLeft,y:t.visualViewport.offsetTop}:aH}function aG(e,t,r,n){var o;void 0===t&&(t=!1),void 0===r&&(r=!1);let a=e.getBoundingClientRect(),i=aB(e),s=nP(1);t&&(n?rx(n)&&(s=aV(n)):s=aV(e));let l=(void 0===(o=r)&&(o=!1),n&&(!o||n===rm(i))&&o)?aW(i):nP(0),c=(a.left+l.x)/s.x,u=(a.top+l.y)/s.y,d=a.width/s.x,f=a.height/s.y;if(i){let e=rm(i),t=n&&rx(n)?rm(n):n,r=e,o=rA(r);for(;o&&n&&t!==r;){let e=aV(o),t=o.getBoundingClientRect(),n=rP(o),a=t.left+(o.clientLeft+parseFloat(n.paddingLeft))*e.x,i=t.top+(o.clientTop+parseFloat(n.paddingTop))*e.y;c*=e.x,u*=e.y,d*=e.x,f*=e.y,c+=a,u+=i,o=rA(r=rm(o))}}return nY({width:d,height:f,x:c,y:u})}function aK(e,t){let r=rL(e).scrollLeft;return t?t.left+r:aG(rg(e)).left+r}function aY(e,t,r){void 0===r&&(r=!1);let n=e.getBoundingClientRect();return{x:n.left+t.scrollLeft-(r?0:aK(e,n)),y:n.top+t.scrollTop}}let aX=new Set(["absolute","fixed"]);function aQ(e,t,r){var n;let o;if("viewport"===t)o=function(e,t){let r=rm(e),n=rg(e),o=r.visualViewport,a=n.clientWidth,i=n.clientHeight,s=0,l=0;if(o){a=o.width,i=o.height;let e=rI();(!e||e&&"fixed"===t)&&(s=o.offsetLeft,l=o.offsetTop)}return{width:a,height:i,x:s,y:l}}(e,r);else if("document"===t){let t,r,a,i,s,l,c;n=rg(e),t=rg(n),r=rL(n),a=n.ownerDocument.body,i=nI(t.scrollWidth,t.clientWidth,a.scrollWidth,a.clientWidth),s=nI(t.scrollHeight,t.clientHeight,a.scrollHeight,a.clientHeight),l=-r.scrollLeft+aK(n),c=-r.scrollTop,"rtl"===rP(a).direction&&(l+=nI(t.clientWidth,a.clientWidth)-i),o={width:i,height:s,x:l,y:c}}else if(rx(t)){let e,n,a,i,s,l;n=(e=aG(t,!0,"fixed"===r)).top+t.clientTop,a=e.left+t.clientLeft,i=ry(t)?aV(t):nP(1),s=t.clientWidth*i.x,l=t.clientHeight*i.y,o={width:s,height:l,x:a*i.x,y:n*i.y}}else{let r=aW(e);o={x:t.x-r.x,y:t.y-r.y,width:t.width,height:t.height}}return nY(o)}function aJ(e){return"static"===rP(e).position}function a0(e,t){if(!ry(e)||"fixed"===rP(e).position)return null;if(t)return t(e);let r=e.offsetParent;return rg(e)===r&&(r=r.ownerDocument.body),r}function a1(e,t){var r;let n=rm(e);if(rS(e))return n;if(!ry(e)){let t=rO(e);for(;t&&!rR(t);){if(rx(t)&&!aJ(t))return t;t=rO(t)}return n}let o=a0(e,t);for(;o&&(r=o,rk.has(rh(r)))&&aJ(o);)o=a0(o,t);return o&&rR(o)&&aJ(o)&&!rN(o)?n:o||function(e){let t=rO(e);for(;ry(t)&&!rR(t);){if(rN(t))return t;if(rS(t))break;t=rO(t)}return null}(e)||n}let a2=async function(e){let t=this.getOffsetParent||a1,r=this.getDimensions,n=await r(e.floating);return{reference:function(e,t,r){let n=ry(t),o=rg(t),a="fixed"===r,i=aG(e,!0,a,t),s={scrollLeft:0,scrollTop:0},l=nP(0);if(n||!n&&!a)if(("body"!==rh(t)||r_(o))&&(s=rL(t)),n){let e=aG(t,!0,a,t);l.x=e.x+t.clientLeft,l.y=e.y+t.clientTop}else o&&(l.x=aK(o));a&&!n&&o&&(l.x=aK(o));let c=!o||n||a?nP(0):aY(o,s);return{x:i.left+s.scrollLeft-l.x-c.x,y:i.top+s.scrollTop-l.y-c.y,width:i.width,height:i.height}}(e.reference,await t(e.floating),e.strategy),floating:{x:0,y:0,width:n.width,height:n.height}}},a3={convertOffsetParentRelativeRectToViewportRelativeRect:function(e){let{elements:t,rect:r,offsetParent:n,strategy:o}=e,a="fixed"===o,i=rg(n),s=!!t&&rS(t.floating);if(n===i||s&&a)return r;let l={scrollLeft:0,scrollTop:0},c=nP(1),u=nP(0),d=ry(n);if((d||!d&&!a)&&(("body"!==rh(n)||r_(i))&&(l=rL(n)),ry(n))){let e=aG(n);c=aV(n),u.x=e.x+n.clientLeft,u.y=e.y+n.clientTop}let f=!i||d||a?nP(0):aY(i,l,!0);return{width:r.width*c.x,height:r.height*c.y,x:r.x*c.x-l.scrollLeft*c.x+u.x+f.x,y:r.y*c.y-l.scrollTop*c.y+u.y+f.y}},getDocumentElement:rg,getClippingRect:function(e){let{element:t,boundary:r,rootBoundary:n,strategy:o}=e,a=[..."clippingAncestors"===r?rS(t)?[]:function(e,t){let r=t.get(e);if(r)return r;let n=rM(e,[],!1).filter(e=>rx(e)&&"body"!==rh(e)),o=null,a="fixed"===rP(e).position,i=a?rO(e):e;for(;rx(i)&&!rR(i);){let t=rP(i),r=rN(i);r||"fixed"!==t.position||(o=null),(a?!r&&!o:!r&&"static"===t.position&&!!o&&aX.has(o.position)||r_(i)&&!r&&function e(t,r){let n=rO(t);return!(n===r||!rx(n)||rR(n))&&("fixed"===rP(n).position||e(n,r))}(e,i))?n=n.filter(e=>e!==i):o=t,i=rO(i)}return t.set(e,n),n}(t,this._c):[].concat(r),n],i=a[0],s=a.reduce((e,r)=>{let n=aQ(t,r,o);return e.top=nI(n.top,e.top),e.right=nN(n.right,e.right),e.bottom=nN(n.bottom,e.bottom),e.left=nI(n.left,e.left),e},aQ(t,i,o));return{width:s.right-s.left,height:s.bottom-s.top,x:s.left,y:s.top}},getOffsetParent:a1,getElementRects:a2,getClientRects:function(e){return Array.from(e.getClientRects())},getDimensions:function(e){let{width:t,height:r}=aq(e);return{width:t,height:r}},getScale:aV,isElement:rx,isRTL:function(e){return"rtl"===rP(e).direction}};function a5(e,t){return e.x===t.x&&e.y===t.y&&e.width===t.width&&e.height===t.height}function a4(e,t,r,n){let o;void 0===n&&(n={});let{ancestorScroll:a=!0,ancestorResize:i=!0,elementResize:s="function"==typeof ResizeObserver,layoutShift:l="function"==typeof IntersectionObserver,animationFrame:c=!1}=n,u=aB(e),d=a||i?[...u?rM(u):[],...rM(t)]:[];d.forEach(e=>{a&&e.addEventListener("scroll",r,{passive:!0}),i&&e.addEventListener("resize",r)});let f=u&&l?function(e,t){let r,n=null,o=rg(e);function a(){var e;clearTimeout(r),null==(e=n)||e.disconnect(),n=null}return!function i(s,l){void 0===s&&(s=!1),void 0===l&&(l=1),a();let c=e.getBoundingClientRect(),{left:u,top:d,width:f,height:p}=c;if(s||t(),!f||!p)return;let h={rootMargin:-nR(d)+"px "+-nR(o.clientWidth-(u+f))+"px "+-nR(o.clientHeight-(d+p))+"px "+-nR(u)+"px",threshold:nI(0,nN(1,l))||1},m=!0;function g(t){let n=t[0].intersectionRatio;if(n!==l){if(!m)return i();n?i(!1,n):r=setTimeout(()=>{i(!1,1e-7)},1e3)}1!==n||a5(c,e.getBoundingClientRect())||i(),m=!1}try{n=new IntersectionObserver(g,{...h,root:o.ownerDocument})}catch(e){n=new IntersectionObserver(g,h)}n.observe(e)}(!0),a}(u,r):null,p=-1,h=null;s&&(h=new ResizeObserver(e=>{let[n]=e;n&&n.target===u&&h&&(h.unobserve(t),cancelAnimationFrame(p),p=requestAnimationFrame(()=>{var e;null==(e=h)||e.observe(t)})),r()}),u&&!c&&h.observe(u),h.observe(t));let m=c?aG(e):null;return c&&function t(){let n=aG(e);m&&!a5(m,n)&&r(),m=n,o=requestAnimationFrame(t)}(),r(),()=>{var e;d.forEach(e=>{a&&e.removeEventListener("scroll",r),i&&e.removeEventListener("resize",r)}),null==f||f(),null==(e=h)||e.disconnect(),h=null,c&&cancelAnimationFrame(o)}}var a6="undefined"!=typeof document?E.useLayoutEffect:function(){};function a7(e,t){let r,n,o;if(e===t)return!0;if(typeof e!=typeof t)return!1;if("function"==typeof e&&e.toString()===t.toString())return!0;if(e&&t&&"object"==typeof e){if(Array.isArray(e)){if((r=e.length)!==t.length)return!1;for(n=r;0!=n--;)if(!a7(e[n],t[n]))return!1;return!0}if((r=(o=Object.keys(e)).length)!==Object.keys(t).length)return!1;for(n=r;0!=n--;)if(!({}).hasOwnProperty.call(t,o[n]))return!1;for(n=r;0!=n--;){let r=o[n];if(("_owner"!==r||!e.$$typeof)&&!a7(e[r],t[r]))return!1}return!0}return e!=e&&t!=t}function a9(e){return"undefined"==typeof window?1:(e.ownerDocument.defaultView||window).devicePixelRatio||1}function a8(e,t){let r=a9(e);return Math.round(t*r)/r}function ie(e){let t=E.useRef(e);return a6(()=>{t.current=e}),t}function it(e,t,r){let n="inline-start"===e||"inline-end"===e;return({top:"top",right:n?r?"inline-start":"inline-end":"right",bottom:"bottom",left:n?r?"inline-end":"inline-start":"left"})[t]}function ir(e,t,r){let{rects:n,placement:o}=e;return{side:it(t,nA(o),r),align:nD(o)||"center",anchor:{width:n.reference.width,height:n.reference.height},positioner:{width:n.floating.width,height:n.floating.height}}}function io(e){var t,r,n,o,a,i,s,l,c,u,d,f,p,h,m,g,v;let{anchor:x,positionMethod:y="absolute",side:b="bottom",sideOffset:w=0,align:_="center",alignOffset:k=0,collisionBoundary:j,collisionPadding:S=5,sticky:C=!1,arrowPadding:T=5,trackAnchor:N=!0,keepMounted:I=!1,floatingRootContext:z,mounted:P,collisionAvoidance:L,shiftCrossAxis:O=!1,nodeId:M,adaptiveOrigin:A}=e,D=L.side||"flip",F=L.align||"flip",$=L.fallbackAxisSide||"end",U="function"==typeof x?x:void 0,Z=t7(U),q=U?Z:x,B=rD(x),V="rtl"===os(),H={top:"top",right:"right",bottom:"bottom",left:"left","inline-end":V?"left":"right","inline-start":V?"right":"left"}[b],W="center"===_?H:`${H}-${_}`,G={boundary:"clipping-ancestors"===j?"clippingAncestors":j,padding:S},K=E.useRef(null),Y=rD(w),X=rD(k),Q="function"!=typeof w?w:0,J=[(t=e=>{let t=ir(e,b,V),r="function"==typeof Y.current?Y.current(t):Y.current,n="function"==typeof X.current?X.current(t):X.current;return{mainAxis:r,crossAxis:n,alignmentAxis:n}},r=[Q,"function"!=typeof k?k:0,V,b],{...(void 0===(n=t)&&(n=0),{name:"offset",options:n,async fn(e){var t,r;let{x:o,y:a,placement:i,middlewareData:s}=e,l=await aZ(e,n);return i===(null==(t=s.offset)?void 0:t.placement)&&null!=(r=s.arrow)&&r.alignmentOffset?{}:{x:o+l.x,y:a+l.y,data:{...l,placement:i}}}}),options:[t,r]})],ee="none"===F&&"shift"!==D,et=!ee&&(C||O||"shift"===D),er="none"===D?null:{...{name:"flip",options:i=o={...G,mainAxis:!O&&"flip"===D,crossAxis:"flip"===F&&"alignment",fallbackAxisSideDirection:$},async fn(e){var t,r,n,o,a,s,l,c;let u,d,f,{placement:p,middlewareData:h,rects:m,initialPlacement:g,platform:v,elements:x}=e,{mainAxis:y=!0,crossAxis:b=!0,fallbackPlacements:w,fallbackStrategy:_="bestFit",fallbackAxisSideDirection:k="none",flipAlignment:j=!0,...S}=nM(i,e);if(null!=(t=h.arrow)&&t.alignmentOffset)return{};let C=nA(p),E=nZ(g),T=nA(g)===g,N=await (null==v.isRTL?void 0:v.isRTL(x.floating)),I=w||(T||!j?[nG(g)]:(u=nG(g),[nq(g),u,nq(u)])),z="none"!==k;!w&&z&&I.push(...(d=nD(g),f=function(e,t,r){switch(e){case"top":case"bottom":if(r)return t?nV:nB;return t?nB:nV;case"left":case"right":return t?nH:nW;default:return[]}}(nA(g),"start"===k,N),d&&(f=f.map(e=>e+"-"+d),j&&(f=f.concat(f.map(nq)))),f));let R=[g,...I],P=await aD(e,S),L=[],O=(null==(r=h.flip)?void 0:r.overflows)||[];if(y&&L.push(P[C]),b){let e,t,r,n,o=(s=p,l=m,void 0===(c=N)&&(c=!1),e=nD(s),r=n$(t=nF(nZ(s))),n="x"===t?e===(c?"end":"start")?"right":"left":"start"===e?"bottom":"top",l.reference[r]>l.floating[r]&&(n=nG(n)),[n,nG(n)]);L.push(P[o[0]],P[o[1]])}if(O=[...O,{placement:p,overflows:L}],!L.every(e=>e<=0)){let e=((null==(n=h.flip)?void 0:n.index)||0)+1,t=R[e];if(t&&("alignment"!==b||E===nZ(t)||O.every(e=>nZ(e.placement)!==E||e.overflows[0]>0)))return{data:{index:e,overflows:O},reset:{placement:t}};let r=null==(o=O.filter(e=>e.overflows[0]<=0).sort((e,t)=>e.overflows[1]-t.overflows[1])[0])?void 0:o.placement;if(!r)switch(_){case"bestFit":{let e=null==(a=O.filter(e=>{if(z){let t=nZ(e.placement);return t===E||"y"===t}return!0}).map(e=>[e.placement,e.overflows.filter(e=>e>0).reduce((e,t)=>e+t,0)]).sort((e,t)=>e[1]-t[1])[0])?void 0:a[0];e&&(r=e);break}case"initialPlacement":r=g}if(p!==r)return{reset:{placement:r}}}return{}}},options:[o,a]},en=ee?null:(s=e=>{var t,r,n;let o=ol(e.elements.floating).documentElement;return{...G,rootBoundary:O?{x:0,y:0,width:o.clientWidth,height:o.clientHeight}:void 0,mainAxis:"none"!==F,crossAxis:et,limiter:C||O?void 0:{...(void 0===(n=t=()=>{if(!K.current)return{};let{height:e}=K.current.getBoundingClientRect();return{offset:e/2+("number"==typeof S?S:0)}})&&(n={}),{options:n,fn(e){let{x:t,y:r,placement:o,rects:a,middlewareData:i}=e,{offset:s=0,mainAxis:l=!0,crossAxis:c=!0}=nM(n,e),u={x:t,y:r},d=nZ(o),f=nF(d),p=u[f],h=u[d],m=nM(s,e),g="number"==typeof m?{mainAxis:m,crossAxis:0}:{mainAxis:0,crossAxis:0,...m};if(l){let e="y"===f?"height":"width",t=a.reference[f]-a.floating[e]+g.mainAxis,r=a.reference[f]+a.reference[e]-g.mainAxis;p<t?p=t:p>r&&(p=r)}if(c){var v,x;let e="y"===f?"width":"height",t=aU.has(nA(o)),r=a.reference[d]-a.floating[e]+(t&&(null==(v=i.offset)?void 0:v[d])||0)+(t?0:g.crossAxis),n=a.reference[d]+a.reference[e]+(t?0:(null==(x=i.offset)?void 0:x[d])||0)-(t?g.crossAxis:0);h<r?h=r:h>n&&(h=n)}return{[f]:p,[d]:h}}}),options:[t,r]}}},l=[G,C,O,S,F],{...(void 0===(c=s)&&(c={}),{name:"shift",options:c,async fn(e){let{x:t,y:r,placement:n}=e,{mainAxis:o=!0,crossAxis:a=!1,limiter:i={fn:e=>{let{x:t,y:r}=e;return{x:t,y:r}}},...s}=nM(c,e),l={x:t,y:r},u=await aD(e,s),d=nZ(nA(n)),f=nF(d),p=l[f],h=l[d];if(o){let e="y"===f?"top":"left",t="y"===f?"bottom":"right",r=p+u[e],n=p-u[t];p=nI(r,nN(p,n))}if(a){let e="y"===d?"top":"left",t="y"===d?"bottom":"right",r=h+u[e],n=h-u[t];h=nI(r,nN(h,n))}let m=i.fn({...e,[f]:p,[d]:h});return{...m,data:{x:m.x-t,y:m.y-r,enabled:{[f]:o,[d]:a}}}}}),options:[s,l]});"shift"===D||"shift"===F||"center"===_?J.push(en,er):J.push(er,en),J.push({...{name:"size",options:f=u={...G,apply({elements:{floating:e},rects:{reference:t},availableWidth:r,availableHeight:n}){Object.entries({"--available-width":`${r}px`,"--available-height":`${n}px`,"--anchor-width":`${t.width}px`,"--anchor-height":`${t.height}px`}).forEach(([t,r])=>{e.style.setProperty(t,r)})}},async fn(e){var t,r;let n,o,{placement:a,rects:i,platform:s,elements:l}=e,{apply:c=()=>{},...u}=nM(f,e),d=await aD(e,u),p=nA(a),h=nD(a),m="y"===nZ(a),{width:g,height:v}=i.floating;"top"===p||"bottom"===p?(n=p,o=h===(await (null==s.isRTL?void 0:s.isRTL(l.floating))?"start":"end")?"left":"right"):(o=p,n="end"===h?"top":"bottom");let x=v-d.top-d.bottom,y=g-d.left-d.right,b=nN(v-d[n],x),w=nN(g-d[o],y),_=!e.middlewareData.shift,k=b,j=w;if(null!=(t=e.middlewareData.shift)&&t.enabled.x&&(j=y),null!=(r=e.middlewareData.shift)&&r.enabled.y&&(k=x),_&&!h){let e=nI(d.left,0),t=nI(d.right,0),r=nI(d.top,0),n=nI(d.bottom,0);m?j=g-2*(0!==e||0!==t?e+t:nI(d.left,d.right)):k=v-2*(0!==r||0!==n?r+n:nI(d.top,d.bottom))}await c({...e,availableWidth:j,availableHeight:k});let S=await s.getDimensions(l.floating);return g!==S.width||v!==S.height?{reset:{rects:!0}}:{}}},options:[u,d]},(p=()=>({element:K.current||document.createElement("div"),padding:T,offsetParent:"floating"}),h=[T],{name:"arrow",options:p,async fn(e){let{x:t,y:r,placement:n,rects:o,platform:a,elements:i,middlewareData:s}=e,{element:l,padding:c=0,offsetParent:u="real"}=nM(p,e)||{};if(null==l)return{};let d=nK(c),f={x:t,y:r},h=nF(nZ(n)),m=n$(h),g=await a.getDimensions(l),v="y"===h,x=v?"clientHeight":"clientWidth",y=o.reference[m]+o.reference[h]-f[h]-o.floating[m],b=f[h]-o.reference[h],w="real"===u?await a.getOffsetParent?.(l):i.floating,_=i.floating[x]||o.floating[m];_&&await a.isElement?.(w)||(_=i.floating[x]||o.floating[m]);let k=_/2-g[m]/2-1,j=Math.min(d[v?"top":"left"],k),S=Math.min(d[v?"bottom":"right"],k),C=_-g[m]-S,E=_/2-g[m]/2+(y/2-b/2),T=nI(j,nN(E,C)),N=!s.arrow&&null!=nD(n)&&E!==T&&o.reference[m]/2-(E<j?j:S)-g[m]/2<0,I=N?E<j?E-j:E-C:0;return{[h]:f[h]+I,data:{[h]:T,centerOffset:E-T-I,...N&&{alignmentOffset:I}},reset:N}},options:[p,h]}),{...(void 0===(v=m)&&(v={}),{name:"hide",options:v,async fn(e){let{rects:t}=e,{strategy:r="referenceHidden",...n}=nM(v,e);switch(r){case"referenceHidden":{let r=aF(await aD(e,{...n,elementContext:"reference"}),t.reference);return{data:{referenceHiddenOffsets:r,referenceHidden:a$(r)}}}case"escaped":{let r=aF(await aD(e,{...n,altBoundary:!0}),t.floating);return{data:{escapedOffsets:r,escaped:a$(r)}}}default:return{}}}}),options:[m,g]},{name:"transformOrigin",fn(e){let{elements:t,middlewareData:r,placement:n,rects:o,y:a}=e,i=nA(n),s=nZ(i),l=K.current,c=r.arrow?.x||0,u=r.arrow?.y||0,d=l?.clientWidth||0,f=l?.clientHeight||0,p=c+d/2,h=u+f/2,m=Math.abs(r.shift?.y||0),g=o.reference.height/2,v=m>("function"==typeof w?w(ir(e,b,V)):w),x={top:`${p}px calc(100% + ${w}px)`,bottom:`${p}px ${-w}px`,left:`calc(100% + ${w}px) ${h}px`,right:`${-w}px ${h}px`}[i],y=`${p}px ${o.reference.y+g-a}px`;return t.floating.style.setProperty("--transform-origin",et&&"y"===s&&v?y:x),{}}},A);let eo=z;!P&&z&&(eo={...z,elements:{reference:null,floating:null,domReference:null}});let ea=E.useMemo(()=>({elementResize:N&&"undefined"!=typeof ResizeObserver,layoutShift:N&&"undefined"!=typeof IntersectionObserver}),[N]),{refs:ei,elements:es,x:el,y:ec,middlewareData:eu,update:ed,placement:ef,context:ep,isPositioned:eh,floatingStyles:em}=function(e={}){let{nodeId:t}=e,r=rf({...e,elements:{reference:null,floating:null,...e.elements}}),n=e.rootContext||r,o=n.elements,[a,i]=E.useState(null),[s,l]=E.useState(null),c=o?.domReference||a,u=E.useRef(null),d=E.useContext(rl);ri(()=>{c&&(u.current=c)},[c]);let f=function(e){void 0===e&&(e={});let{placement:t="bottom",strategy:r="absolute",middleware:n=[],platform:o,elements:{reference:a,floating:i}={},transform:s=!0,whileElementsMounted:l,open:c}=e,[u,d]=E.useState({x:0,y:0,strategy:r,placement:t,middlewareData:{},isPositioned:!1}),[f,p]=E.useState(n);a7(f,n)||p(n);let[h,m]=E.useState(null),[g,v]=E.useState(null),x=E.useCallback(e=>{e!==_.current&&(_.current=e,m(e))},[]),y=E.useCallback(e=>{e!==k.current&&(k.current=e,v(e))},[]),b=a||h,w=i||g,_=E.useRef(null),k=E.useRef(null),j=E.useRef(u),S=null!=l,C=ie(l),T=ie(o),N=ie(c),I=E.useCallback(()=>{var e,n;let o,a,i;if(!_.current||!k.current)return;let s={placement:t,strategy:r,middleware:f};T.current&&(s.platform=T.current),(e=_.current,n=k.current,o=new Map,i={...(a={platform:a3,...s}).platform,_c:o},aA(e,n,{...a,platform:i})).then(e=>{let t={...e,isPositioned:!1!==N.current};z.current&&!a7(j.current,t)&&(j.current=t,R.flushSync(()=>{d(t)}))})},[f,t,r,T,N]);a6(()=>{!1===c&&j.current.isPositioned&&(j.current.isPositioned=!1,d(e=>({...e,isPositioned:!1})))},[c]);let z=E.useRef(!1);a6(()=>(z.current=!0,()=>{z.current=!1}),[]),a6(()=>{if(b&&(_.current=b),w&&(k.current=w),b&&w){if(C.current)return C.current(b,w,I);I()}},[b,w,I,C,S]);let P=E.useMemo(()=>({reference:_,floating:k,setReference:x,setFloating:y}),[x,y]),L=E.useMemo(()=>({reference:b,floating:w}),[b,w]),O=E.useMemo(()=>{let e={position:r,left:0,top:0};if(!L.floating)return e;let t=a8(L.floating,u.x),n=a8(L.floating,u.y);return s?{...e,transform:"translate("+t+"px, "+n+"px)",...a9(L.floating)>=1.5&&{willChange:"transform"}}:{position:r,left:t,top:n}},[r,s,L.floating,u.x,u.y]);return E.useMemo(()=>({...u,update:I,refs:P,elements:L,floatingStyles:O}),[u,I,P,L,O])}({...e,elements:{...o,...s&&{reference:s}}}),p=E.useCallback(e=>{let t=rx(e)?{getBoundingClientRect:()=>e.getBoundingClientRect(),getClientRects:()=>e.getClientRects(),contextElement:e}:e;l(t),f.refs.setReference(t)},[f.refs]),h=E.useCallback(e=>{(rx(e)||null===e)&&(u.current=e,i(e)),(rx(f.refs.reference.current)||null===f.refs.reference.current||null!==e&&!rx(e))&&f.refs.setReference(e)},[f.refs]),m=E.useMemo(()=>({...f.refs,setReference:h,setPositionReference:p,domReference:u}),[f.refs,h,p]),g=E.useMemo(()=>({...f.elements,domReference:c}),[f.elements,c]),v=E.useMemo(()=>({...f,...n,refs:m,elements:g,nodeId:t}),[f,m,g,t,n]);return ri(()=>{n.dataRef.current.floatingContext=v;let e=d?.nodesRef.current.find(e=>e.id===t);e&&(e.context=v)}),E.useMemo(()=>({...f,context:v,refs:m,elements:g}),[f,m,g,v])}({rootContext:eo,placement:W,middleware:J,strategy:y,whileElementsMounted:I?void 0:(...e)=>a4(...e,ea),nodeId:M}),{sideX:eg,sideY:ev}=eu.adaptiveOrigin||{},ex=E.useMemo(()=>A?{position:y,[eg]:`${el}px`,[ev]:`${ec}px`}:em,[A,eg,ev,y,el,ec,em]),ey=E.useRef(null);ri(()=>{if(!P)return;let e=B.current,t="function"==typeof e?e():e,r=(ia(t)?t.current:t)||null;r!==ey.current&&(ei.setPositionReference(r),ey.current=r)},[P,ei,q,B]),E.useEffect(()=>{if(!P)return;let e=B.current;"function"!=typeof e&&ia(e)&&e.current!==ey.current&&(ei.setPositionReference(e.current),ey.current=e.current)},[P,ei,q,B]),E.useEffect(()=>{if(I&&P&&es.domReference&&es.floating)return a4(es.domReference,es.floating,ed,ea)},[I,P,es,ed,ea]);let eb=it(b,nA(ef),V),ew=nD(ef)||"center",e_=!!eu.hide?.referenceHidden,ek=E.useMemo(()=>({position:"absolute",top:eu.arrow?.y,left:eu.arrow?.x}),[eu.arrow]),ej=eu.arrow?.centerOffset!==0;return E.useMemo(()=>({positionerStyles:ex,arrowStyles:ek,arrowRef:K,arrowUncentered:ej,side:eb,align:ew,anchorHidden:e_,refs:ei,context:ep,isPositioned:eh,update:ed}),[ex,ek,K,ej,eb,ew,e_,ei,ep,eh,ed])}function ia(e){return null!=e&&"current"in e}function ii(e){let{children:t,elementsRef:r,labelsRef:n,onMapChange:o}=e,a=E.useRef(0),i=t0(il).current,s=t0(is).current,[l,c]=E.useState(0),u=E.useRef(l),d=t7((e,t)=>{s.set(e,t??null),u.current+=1,c(u.current)}),f=t7(e=>{s.delete(e),u.current+=1,c(u.current)}),p=E.useMemo(()=>{let e=new Map;return Array.from(s.keys()).sort(ic).forEach((t,r)=>{let n=s.get(t)??{};e.set(t,{...n,index:r})}),e},[s,l]);ri(()=>{u.current===l&&(r.current.length!==p.size&&(r.current.length=p.size),n&&n.current.length!==p.size&&(n.current.length=p.size)),o?.(p)},[o,p,r,n,l,u]);let h=t7(e=>(i.add(e),()=>{i.delete(e)}));ri(()=>{i.forEach(e=>e(p))},[i,p]);let m=E.useMemo(()=>({register:d,unregister:f,subscribeMapChange:h,elementsRef:r,labelsRef:n,nextIndexRef:a}),[d,f,h,r,n,a]);return(0,z.jsx)(oJ.Provider,{value:m,children:t})}function is(){return new Map}function il(){return new Set}function ic(e,t){let r=e.compareDocumentPosition(t);return r&Node.DOCUMENT_POSITION_FOLLOWING||r&Node.DOCUMENT_POSITION_CONTAINED_BY?-1:r&Node.DOCUMENT_POSITION_PRECEDING||r&Node.DOCUMENT_POSITION_CONTAINS?1:0}let iu=E.forwardRef(function(e,t){let r,{cutout:n,...o}=e;if(n){let e=n?.getBoundingClientRect();r=`polygon(
      0% 0%,
      100% 0%,
      100% 100%,
      0% 100%,
      0% 0%,
      ${e.left}px ${e.top}px,
      ${e.left}px ${e.bottom}px,
      ${e.right}px ${e.bottom}px,
      ${e.right}px ${e.top}px,
      ${e.left}px ${e.top}px
    )`}return(0,z.jsx)("div",{ref:t,role:"presentation","data-base-ui-inert":"",...o,style:{position:"fixed",inset:0,userSelect:"none",WebkitUserSelect:"none",clipPath:r}})}),id=E.forwardRef(function(e,t){var r;let n,o,a,{anchor:i,positionMethod:s="absolute",className:l,render:c,side:u,align:d,sideOffset:f=0,alignOffset:p=0,collisionBoundary:h="clipping-ancestors",collisionPadding:m=5,arrowPadding:g=5,sticky:v=!1,trackAnchor:x=!0,collisionAvoidance:y=n_,...b}=e,{open:w,setOpen:_,floatingRootContext:k,setPositionerElement:j,itemDomElements:S,itemLabels:C,mounted:T,modal:N,lastOpenChangeReason:I,parent:R,setHoverEnabled:P,triggerElement:L}=or(),O=function(){let e=E.useContext(aP);if(void 0===e)throw Error("Base UI: <Menu.Portal> is missing.");return e}(),M=(n=ro(),o=E.useContext(rl),ri(()=>{if(!n)return;let e={id:n,parentId:a};return o?.addNode(e),()=>{o?.removeNode(e)}},[o,n,a=rc()]),n),A=rc(),D=ov(!0),F=i,$=f,U=p,Z=d;"context-menu"===R.type&&(F=R.context?.anchor??i,Z=e.align??"start",U=e.alignOffset??2,$=e.sideOffset??-5);let q=u,B=Z;"menu"===R.type?(q=q??"inline-end",B=B??"start"):"menubar"===R.type&&(q=q??"bottom",B=B??"start");let V="context-menu"===R.type,H=io({anchor:F,floatingRootContext:k,positionMethod:D?"fixed":s,mounted:T,side:q,sideOffset:$,align:B,alignOffset:U,arrowPadding:V?0:g,collisionBoundary:h,collisionPadding:m,sticky:v,nodeId:M,keepMounted:O,trackAnchor:x,collisionAvoidance:y,shiftCrossAxis:V}),{events:W}=E.useContext(rl),G=E.useMemo(()=>{let e={};return w||(e.pointerEvents="none"),{role:"presentation",hidden:!T,style:{...H.positionerStyles,...e}}},[w,T,H.positionerStyles]);E.useEffect(()=>{function e(e){e.open?(e.parentNodeId===M&&P(!1),e.nodeId!==M&&e.parentNodeId===A&&_(!1,void 0,"sibling-open")):e.parentNodeId===M&&P(!0)}return W.on("openchange",e),()=>{W.off("openchange",e)}},[W,M,A,_,P]),E.useEffect(()=>{W.emit("openchange",{open:w,nodeId:M,parentNodeId:A})},[W,w,M,A]);let K=E.useMemo(()=>({open:w,side:H.side,align:H.align,anchorHidden:H.anchorHidden,nested:"menu"===R.type}),[w,H.side,H.align,H.anchorHidden,R.type]),Y=E.useMemo(()=>({side:H.side,align:H.align,arrowRef:H.arrowRef,arrowUncentered:H.arrowUncentered,arrowStyles:H.arrowStyles,floatingContext:H.context}),[H.side,H.align,H.arrowRef,H.arrowUncentered,H.arrowStyles,H.context]),X=oG("div",e,{state:K,customStyleHookMapping:oH,ref:[t,j],props:{...G,...b}}),Q=T&&"menu"!==R.type&&("menubar"!==R.type&&N&&"trigger-hover"!==I||"menubar"===R.type&&R.context.modal),J=null;return"menubar"===R.type?J=R.context.contentElement:void 0===R.type&&(J=L),(0,z.jsxs)(aO.Provider,{value:Y,children:[Q&&(0,z.jsx)(iu,{ref:"context-menu"===R.type||"nested-context-menu"===R.type?R.context.internalBackdropRef:null,inert:(r=!w,oW>=19?r:r?"true":void 0),cutout:J}),(0,z.jsx)(ru,{id:M,children:(0,z.jsx)(ii,{elementsRef:S,labelsRef:C,children:X})})]})}),ip={inert:new WeakMap,"aria-hidden":new WeakMap,none:new WeakMap};function ih(e){return"inert"===e?ip.inert:"aria-hidden"===e?ip["aria-hidden"]:ip.none}let im=new WeakSet,ig={},iv=0,ix=e=>e&&(e.host||ix(e.parentNode)),iy=[];function ib(){iy=iy.filter(e=>e.isConnected)}function iw(){return ib(),iy[iy.length-1]}function i_(e,t){if(!t.current.includes("floating")&&!e.getAttribute("role")?.includes("dialog"))return;let r=ak(),n=aw(e,r).filter(e=>{let t=e.getAttribute("data-tabindex")||"";return a_(e,r)||e.hasAttribute("data-tabindex")&&!t.startsWith("-")}),o=e.getAttribute("tabindex");t.current.includes("floating")||0===n.length?"0"!==o&&e.setAttribute("tabindex","0"):("-1"!==o||e.hasAttribute("data-tabindex")&&"-1"!==e.getAttribute("data-tabindex"))&&(e.setAttribute("tabindex","-1"),e.setAttribute("data-tabindex","-1"))}function ik(e){let{context:t,children:r,disabled:n=!1,order:o=["content"],initialFocus:a=0,returnFocus:i=!0,restoreFocus:s=!1,modal:l=!0,closeOnFocusOut:c=!0,getInsideElements:u=()=>[]}=e,{open:d,onOpenChange:f,events:p,dataRef:h,elements:{domReference:m,floating:g}}=t,v=t7(()=>h.current.floatingContext?.nodeId),x=t7(u),y="number"==typeof a&&a<0,b=nn(m)&&y,w=rD(o),_=rD(a),k=rD(i),j=E.useContext(rl),S=E.useContext(aN),C=E.useRef(null),T=E.useRef(null),N=E.useRef(!1),I=E.useRef(!1),R=E.useRef(-1),P=t5(),L=null!=S,O=no(g),M=t7((e=O)=>e?ab(e,ak()):[]),A=t7(e=>{let t=M(e);return w.current.map(()=>t).filter(Boolean).flat()});E.useEffect(()=>{if(n||!l)return;function e(e){"Tab"===e.key&&r9(O,r7(nt(O)))&&0===M().length&&!b&&rY(e)}let t=nt(O);return t.addEventListener("keydown",e),()=>{t.removeEventListener("keydown",e)}},[n,m,O,l,w,b,M,A]),E.useEffect(()=>{if(!n&&g)return g.addEventListener("focusin",e),()=>{g.removeEventListener("focusin",e)};function e(e){let t=r8(e),r=M().indexOf(t);-1!==r&&(R.current=r)}},[n,g,M]),E.useEffect(()=>{if(n||!c)return;function e(){I.current=!0}function t(e){let t=e.relatedTarget,r=e.currentTarget,n=r8(e);queueMicrotask(()=>{let o=v(),a=!(r9(m,t)||r9(g,t)||r9(t,g)||r9(S?.portalNode,t)||t?.hasAttribute(na("focus-guard"))||j&&(nu(j.nodesRef.current,o).find(e=>r9(e.context?.elements.floating,t)||r9(e.context?.elements.domReference,t))||nd(j.nodesRef.current,o).find(e=>[e.context?.elements.floating,no(e.context?.elements.floating)].includes(t)||e.context?.elements.domReference===t)));if(r===m&&O&&i_(O,w),s&&r!==m&&!n?.isConnected&&r7(nt(O))===nt(O).body){ry(O)&&O.focus();let e=R.current,t=M(),r=t[e]||t[t.length-1]||O;ry(r)&&r.focus()}if(h.current.insideReactTree){h.current.insideReactTree=!1;return}if(I.current){I.current=!1;return}(b||!l)&&t&&a&&t!==iw()&&(N.current=!0,f(!1,e,"focus-out"))})}let r=!!(!j&&S);function o(){h.current.insideReactTree=!0,P.start(0,()=>{h.current.insideReactTree=!1})}if(g&&ry(m))return m.addEventListener("focusout",t),m.addEventListener("pointerdown",e),g.addEventListener("focusout",t),r&&g.addEventListener("focusout",o,!0),()=>{m.removeEventListener("focusout",t),m.removeEventListener("pointerdown",e),g.removeEventListener("focusout",t),r&&g.removeEventListener("focusout",o,!0)}},[n,m,g,O,l,j,S,f,c,s,M,b,v,w,h,P]);let D=E.useRef(null),F=E.useRef(null),$=oI(D,S?.beforeInsideRef),U=oI(F,S?.afterInsideRef);E.useEffect(()=>{if(n||!g)return;let e=Array.from(S?.portalNode?.querySelectorAll(`[${na("portal")}]`)||[]),t=j?nd(j.nodesRef.current,v()):[],r=function(e,t=!1,r=!1){var n;let o,a,i,s,l,c,u,d=nt(e[0]).body;return n=e.concat(Array.from(d.querySelectorAll("[aria-live]"))),o="data-base-ui-inert",a=r?"inert":t?"aria-hidden":null,i=n.map(e=>{if(d.contains(e))return e;let t=ix(e);return d.contains(t)?t:null}).filter(e=>null!=e),s=new Set,l=new Set(i),c=[],ig[o]||(ig[o]=new WeakMap),u=ig[o],i.forEach(function e(t){!(!t||s.has(t))&&(s.add(t),t.parentNode&&e(t.parentNode))}),function e(t){!t||l.has(t)||[].forEach.call(t.children,t=>{if("script"!==rh(t))if(s.has(t))e(t);else{let e=a?t.getAttribute(a):null,r=null!==e&&"false"!==e,n=ih(a),i=(n.get(t)||0)+1,s=(u.get(t)||0)+1;n.set(t,i),u.set(t,s),c.push(t),1===i&&r&&im.add(t),1===s&&t.setAttribute(o,""),!r&&a&&t.setAttribute(a,"inert"===a?"":"true")}})}(d),s.clear(),iv+=1,()=>{c.forEach(e=>{let t=ih(a),r=(t.get(e)||0)-1,n=(u.get(e)||0)-1;t.set(e,r),u.set(e,n),r||(!im.has(e)&&a&&e.removeAttribute(a),im.delete(e)),n||e.removeAttribute(o)}),(iv-=1)||(ip.inert=new WeakMap,ip["aria-hidden"]=new WeakMap,ip.none=new WeakMap,im=new WeakSet,ig={})}}([g,t.find(e=>nn(e.context?.elements.domReference||null))?.context?.elements.domReference,...e,...x(),C.current,T.current,D.current,F.current,S?.beforeOutsideRef.current,S?.afterOutsideRef.current,b?m:null].filter(e=>null!=e),l||b);return()=>{r()}},[n,m,g,l,w,S,b,j,v,x]),ri(()=>{if(n||!ry(O))return;let e=r7(nt(O));queueMicrotask(()=>{let t=A(O),r=_.current,n=("number"==typeof r?t[r]:r.current)||O,o=r9(O,e);y||o||!d||n5(n,{preventScroll:n===O})})},[n,d,O,y,A,_]),ri(()=>{var e;if(n||!O)return;let t=nt(O);function r({reason:e,event:t,nested:r}){if(["hover","safe-polygon"].includes(e)&&"mouseleave"===t.type&&(N.current=!0),"outside-press"===e)if(r)N.current=!1;else if(rX(t)||rQ(t))N.current=!1;else{let e=!1;document.createElement("div").focus({get preventScroll(){return e=!0,!1}}),e?N.current=!1:N.current=!0}}e=r7(t),ib(),e&&"body"!==rh(e)&&(iy.push(e),iy.length>20&&(iy=iy.slice(-20))),p.on("openchange",r);let o=t.createElement("span");return o.setAttribute("tabindex","-1"),o.setAttribute("aria-hidden","true"),Object.assign(o.style,o5),L&&m&&m.insertAdjacentElement("afterend",o),()=>{p.off("openchange",r);let e=r7(t),n=r9(g,e)||j&&nu(j.nodesRef.current,v(),!1).some(t=>r9(t.context?.elements.floating,e)),a=function(){if("boolean"==typeof k.current){let e=m||iw();return e&&e.isConnected?e:o}return k.current.current||o}();queueMicrotask(()=>{let r,i=a_(a,r=ak())?a:ab(a,r)[0]||a;k.current&&!N.current&&ry(i)&&(i===e||e===t.body||n)&&i.focus({preventScroll:!0}),o.remove()})}},[n,g,O,k,h,p,j,L,m,v]),E.useEffect(()=>{queueMicrotask(()=>{N.current=!1})},[n]),E.useEffect(()=>{if(n||!d)return;function e(e){let t=r8(e);t?.closest("[data-base-ui-click-trigger]")&&(I.current=!0)}let t=nt(O);return t.addEventListener("pointerdown",e,!0),()=>{t.removeEventListener("pointerdown",e,!0)}},[n,d,O]),ri(()=>{if(!n&&S)return S.setFocusManagerState({modal:l,closeOnFocusOut:c,open:d,onOpenChange:f,domReference:m}),()=>{S.setFocusManagerState(null)}},[n,S,l,d,f,c,m]),ri(()=>{if(!n&&O)return i_(O,w),()=>{queueMicrotask(ib)}},[n,O,w]);let Z=!n&&(!l||!b)&&(L||l);return(0,z.jsxs)(E.Fragment,{children:[Z&&(0,z.jsx)(o4,{"data-type":"inside",ref:$,onFocus:e=>{if(l){let e=A();n5(e[e.length-1])}else if(S?.preserveTabOrder&&S.portalNode)if(N.current=!1,aE(e,S.portalNode)){let e=aS(m);e?.focus()}else S.beforeOutsideRef.current?.focus()}}),r,Z&&(0,z.jsx)(o4,{"data-type":"inside",ref:U,onFocus:e=>{if(l)n5(A()[0]);else if(S?.preserveTabOrder&&S.portalNode)if(c&&(N.current=!0),aE(e,S.portalNode)){let e=aC(m);e?.focus()}else S.afterOutsideRef.current?.focus()}})]})}let ij={...oH,...oM},iS=E.forwardRef(function(e,t){let{render:r,className:n,finalFocus:o,...a}=e,{open:i,setOpen:s,popupRef:l,transitionStatus:c,popupProps:u,mounted:d,instantType:f,onOpenChangeComplete:p,parent:h,lastOpenChangeReason:m,rootId:g}=or(),{side:v,align:x,floatingContext:y}=function(){let e=E.useContext(aO);if(void 0===e)throw Error("Base UI: MenuPositionerContext is missing. MenuPositioner parts must be placed within <Menu.Positioner>.");return e}();oa({open:i,ref:l,onComplete(){i&&p?.(!0)}});let{events:b}=E.useContext(rl);E.useEffect(()=>{function e(e){s(!1,e.domEvent,e.reason)}return b.on("close",e),()=>{b.off("close",e)}},[b,s]);let w=oG("div",e,{state:E.useMemo(()=>({transitionStatus:c,side:v,align:x,open:i,nested:"menu"===h.type,instant:f}),[c,v,x,i,h.type,f]),ref:[t,l],customStyleHookMapping:ij,props:[u,"starting"===c?ny:nb,a,{"data-rootownerid":g}]}),_=void 0===h.type||"context-menu"===h.type;return"menubar"===h.type&&"outside-press"!==m&&(_=!0),(0,z.jsx)(ik,{context:y,modal:!1,disabled:!d,returnFocus:o||_,initialFocus:"menu"===h.type?-1:0,restoreFocus:!0,children:w})}),iC=E.createContext(void 0),iE=E.forwardRef(function(e,t){let{render:r,className:n,...o}=e,[a,i]=E.useState(void 0),s=E.useMemo(()=>({setLabelId:i}),[i]),l=oG("div",e,{ref:t,props:{role:"group","aria-labelledby":a,...o}});return(0,z.jsx)(iC.Provider,{value:s,children:l})});function iT(e){return ro(e,"base-ui")}let iN=E.forwardRef(function(e,t){let{className:r,render:n,id:o,...a}=e,i=iT(o),{setLabelId:s}=function(){let e=E.useContext(iC);if(void 0===e)throw Error("Base UI: MenuGroupRootContext is missing. Menu group parts must be used within <Menu.Group>.");return e}();return ri(()=>(s(i),()=>{s(void 0)}),[s,i]),oG("div",e,{ref:t,props:{id:i,role:"presentation",...a}})}),iI={type:"regular-item"};function iz(e){let{closeOnClick:t,disabled:r=!1,highlighted:n,id:o,menuEvents:a,allowMouseUpTriggerRef:i,typingRef:s,nativeButton:l,itemMetadata:c}=e,u=E.useRef(null),{getButtonProps:d,buttonRef:f}=oQ({disabled:r,focusableWhenDisabled:!0,native:l}),p=E.useCallback(e=>ow({id:o,role:"menuitem",tabIndex:n?0:-1,onMouseEnter(){"submenu-trigger"===c.type&&c.setActive()},onKeyUp:e=>{" "===e.key&&s.current&&e.preventBaseUIHandler()},onClick:e=>{t&&a.emit("close",{domEvent:e,reason:"item-press"})},onMouseUp:()=>{u.current&&i.current&&"regular-item"===c.type&&u.current.click()}},e,d),[o,n,d,s,t,a,i,c]),h=oI(u,f);return E.useMemo(()=>({getItemProps:p,itemRef:h}),[p,h])}let iR=E.memo(E.forwardRef(function(e,t){let{className:r,closeOnClick:n=!0,disabled:o=!1,highlighted:a,id:i,menuEvents:s,itemProps:l,render:c,allowMouseUpTriggerRef:u,typingRef:d,nativeButton:f,...p}=e,{getItemProps:h,itemRef:m}=iz({closeOnClick:n,disabled:o,highlighted:a,id:i,menuEvents:s,allowMouseUpTriggerRef:u,typingRef:d,nativeButton:f,itemMetadata:iI});return oG("div",e,{state:E.useMemo(()=>({disabled:o,highlighted:a}),[o,a]),ref:[m,t],props:[l,p,h]})})),iP=E.forwardRef(function(e,t){let{id:r,label:n,nativeButton:o=!1,...a}=e,i=E.useRef(null),s=o1({label:n}),l=oI(t,s.ref,i),{itemProps:c,activeIndex:u,allowMouseUpTriggerRef:d,typingRef:f}=or(),p=iT(r),h=s.index===u,{events:m}=E.useContext(rl);return(0,z.jsx)(iR,{...a,id:p,ref:l,highlighted:h,menuEvents:m,itemProps:c,allowMouseUpTriggerRef:d,typingRef:f,nativeButton:o})}),iL="__next_builtin__";function iO(e){return e.replace(RegExp(`^${iL}`),"").replace(RegExp("@boundary$"),"")}let iM="boundary:";function iA(e){return e.startsWith(iM)}function iD(e){return e.replace(iM,"")}function iF({nodeState:e,boundaries:t}){let{pagePath:r,boundaryType:n,setBoundaryType:o}=e,[a,i]=(0,E.useState)(!1),{shadowRoot:s}=(0,P.OS)(),l=(0,E.useRef)(null),c=(0,E.useRef)(null);(0,tu.xj)(c,l,a,()=>{i(!1)},l.current?.ownerDocument);let u=(Object.values(t).find(e=>null!==e)||"").split(".").pop()||"js",d=(0,E.useMemo)(()=>Object.fromEntries(Object.entries(t).map(([e,t])=>{let r=iO((t||"").split("/").pop()||`${e}.${u}`);return[e,r]})),[t,u]),f=(r||"").split("/").pop()||"",p=iO(n?`page.${u}`:f||`page.${u}`),h=[{label:d.loading,value:"loading",icon:(0,z.jsx)(i$,{}),disabled:!t.loading},{label:d.error,value:"error",icon:(0,z.jsx)(iU,{}),disabled:!t.error},{label:d["not-found"],value:"not-found",icon:(0,z.jsx)(iZ,{}),disabled:!t["not-found"]}],m={label:n?"Reset":p,value:"reset",icon:(0,z.jsx)(iq,{}),disabled:null===n},g=(0,E.useCallback)(({filePath:e})=>{let t=new URLSearchParams({file:e,isAppRelativePath:"1"});fetch(`${process.env.__NEXT_ROUTER_BASEPATH||""}/__nextjs_launch-editor?${t.toString()}`).catch(console.warn)},[]),v=(0,E.useCallback)(e=>{switch(e){case"not-found":case"loading":case"error":o(e);break;case"reset":o(null);break;case"open-editor":r&&g({filePath:r})}},[o,r,g]),x=(0,E.useMemo)(()=>"layout"!==e.type&&"template"!==e.type&&Object.values(t).some(e=>null!==e),[e.type,t]);return(0,z.jsxs)(oN,{delay:0,modal:!1,open:a,onOpenChange:i,children:[(0,z.jsx)(o3,{className:"segment-boundary-trigger","data-nextjs-dev-overlay-segment-boundary-trigger-button":!0,render:e=>{let t=((...e)=>t=>{e.forEach(e=>{"function"==typeof e?e(t):e&&(e.current=t)})})(e.ref,l);return(0,z.jsx)(iV,{...e,ref:t})},disabled:!x}),(0,z.jsx)(aL,{container:s,children:(0,z.jsx)(id,{className:"segment-boundary-dropdown-positioner",side:"bottom",align:"center",sideOffset:6,arrowPadding:8,ref:c,children:(0,z.jsxs)(iS,{className:"segment-boundary-dropdown",children:[(0,z.jsxs)(iE,{children:[(0,z.jsx)(iN,{className:"segment-boundary-group-label",children:"Toggle Overrides"}),h.map(e=>(0,z.jsxs)(iP,{className:"segment-boundary-dropdown-item",onClick:()=>v(e.value),disabled:e.disabled,children:[e.icon,e.label]},e.value))]}),(0,z.jsx)(iE,{children:(0,z.jsxs)(iP,{className:"segment-boundary-dropdown-item",onClick:()=>v(m.value),disabled:m.disabled,children:[m.icon,m.label]},m.value)})]})})})]})}function i$(){let e,t,r=(0,S.c)(2);return r[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("g",{clipPath:"url(#clip0_2759_1866)",children:(0,z.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 3.5C13.5899 3.5 16.5 6.41015 16.5 10C16.5 13.5899 13.5899 16.5 10 16.5C6.41015 16.5 3.5 13.5899 3.5 10C3.5 6.41015 6.41015 3.5 10 3.5ZM2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10ZM10.75 9.62402V6H9.25V9.875C9.25 10.1898 9.39858 10.486 9.65039 10.6748L11.5498 12.0996L12.1504 12.5498L13.0498 11.3496L12.4502 10.9004L10.75 9.62402Z",fill:"currentColor"})}),r[0]=e):e=r[0],r[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsxs)("svg",{width:"20px",height:"20px",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e,(0,z.jsx)("defs",{children:(0,z.jsx)("clipPath",{id:"clip0_2759_1866",children:(0,z.jsx)("rect",{width:"16",height:"16",fill:"white",transform:"translate(2 2)"})})})]}),r[1]=t):t=r[1],t}function iU(){let e,t,r=(0,S.c)(2);return r[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("g",{clipPath:"url(#clip0_2759_1881)",children:(0,z.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3.5 7.30762V12.6924L7.30762 16.5H12.6924L16.5 12.6924V7.30762L12.6924 3.5H7.30762L3.5 7.30762ZM18 12.8994L17.9951 12.998C17.9724 13.2271 17.8712 13.4423 17.707 13.6064L13.6064 17.707L13.5332 17.7734C13.3806 17.8985 13.1944 17.9757 12.998 17.9951L12.8994 18H7.10059L7.00195 17.9951C6.80562 17.9757 6.6194 17.8985 6.4668 17.7734L6.39355 17.707L2.29297 13.6064C2.12883 13.4423 2.02756 13.2271 2.00488 12.998L2 12.8994V7.10059C2 6.83539 2.10546 6.58109 2.29297 6.39355L6.39355 2.29297C6.55771 2.12883 6.77294 2.02756 7.00195 2.00488L7.10059 2H12.8994L12.998 2.00488C13.2271 2.02756 13.4423 2.12883 13.6064 2.29297L17.707 6.39355C17.8945 6.58109 18 6.83539 18 7.10059V12.8994ZM9.25 5.75H10.75L10.75 10.75H9.25L9.25 5.75ZM10 14C10.5523 14 11 13.5523 11 13C11 12.4477 10.5523 12 10 12C9.44772 12 9 12.4477 9 13C9 13.5523 9.44772 14 10 14Z",fill:"currentColor"})}),r[0]=e):e=r[0],r[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsxs)("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e,(0,z.jsx)("defs",{children:(0,z.jsx)("clipPath",{id:"clip0_2759_1881",children:(0,z.jsx)("rect",{width:"16",height:"16",fill:"white",transform:"translate(2 2)"})})})]}),r[1]=t):t=r[1],t}function iZ(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{width:"20px",height:"20px",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,z.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10.5586 2.5C11.1341 2.50004 11.6588 2.8294 11.9091 3.34766L17.8076 15.5654C18.1278 16.2292 17.6442 16.9997 16.9072 17H3.09274C2.35574 16.9997 1.8721 16.2292 2.19235 15.5654L8.09079 3.34766C8.34109 2.8294 8.86583 2.50004 9.44137 2.5H10.5586ZM3.89059 15.5H16.1093L10.5586 4H9.44137L3.89059 15.5ZM9.24997 6.75H10.75L10.75 10.75H9.24997L9.24997 6.75ZM9.99997 14C10.5523 14 11 13.5523 11 13C11 12.4477 10.5523 12 9.99997 12C9.44768 12 8.99997 12.4477 8.99997 13C8.99997 13.5523 9.44768 14 9.99997 14Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function iq(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,z.jsx)("path",{d:"M9.96484 3C13.8463 3.00018 17 6.13012 17 10C17 13.8699 13.8463 16.9998 9.96484 17C7.62404 17 5.54877 15.8617 4.27051 14.1123L3.82812 13.5068L5.03906 12.6221L5.48145 13.2275C6.48815 14.6053 8.12092 15.5 9.96484 15.5C13.0259 15.4998 15.5 13.0335 15.5 10C15.5 6.96654 13.0259 4.50018 9.96484 4.5C7.42905 4.5 5.29544 6.19429 4.63867 8.5H8V10H2.75C2.33579 10 2 9.66421 2 9.25V4H3.5V7.2373C4.57781 4.74376 7.06749 3 9.96484 3Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function iB(e){let t,r,n=(0,S.c)(3);return n[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8.7071 2.39644C8.31658 2.00592 7.68341 2.00592 7.29289 2.39644L4.46966 5.21966L3.93933 5.74999L4.99999 6.81065L5.53032 6.28032L7.99999 3.81065L10.4697 6.28032L11 6.81065L12.0607 5.74999L11.5303 5.21966L8.7071 2.39644ZM5.53032 9.71966L4.99999 9.18933L3.93933 10.25L4.46966 10.7803L7.29289 13.6035C7.68341 13.9941 8.31658 13.9941 8.7071 13.6035L11.5303 10.7803L12.0607 10.25L11 9.18933L10.4697 9.71966L7.99999 12.1893L5.53032 9.71966Z",fill:"currentColor"}),n[0]=t):t=n[0],n[1]!==e?(r=(0,z.jsx)("svg",{strokeLinejoin:"round",viewBox:"0 0 16 16",...e,children:t}),n[1]=e,n[2]=r):r=n[2],r}function iV(e){let t,r,n=(0,S.c)(3);return n[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("span",{className:"segment-boundary-trigger-text",children:(0,z.jsx)(iB,{className:"plus-icon"})}),n[0]=t):t=n[0],n[1]!==e?(r=(0,z.jsx)("button",{...e,children:t}),n[1]=e,n[2]=r):r=n[2],r}let iH=E.createContext(void 0);function iW(){let e=E.useContext(iH);if(void 0===e)throw Error("Base UI: TooltipRootContext is missing. Tooltip parts must be placed within <Tooltip.Root>.");return e}let iG=E.forwardRef(function(e,t){let{className:r,render:n,...o}=e,{open:a,setTriggerElement:i,triggerProps:s}=iW();return oG("button",e,{state:E.useMemo(()=>({open:a}),[a]),ref:[t,i],props:[s,o],customStyleHookMapping:oB})}),iK=E.createContext(void 0);function iY(){let e=E.useContext(iK);if(void 0===e)throw Error("Base UI: TooltipPositionerContext is missing. TooltipPositioner parts must be placed within <Tooltip.Positioner>.");return e}let iX=E.forwardRef(function(e,t){let{className:r,render:n,...o}=e,{open:a,arrowRef:i,side:s,align:l,arrowUncentered:c,arrowStyles:u}=iY();return oG("div",e,{state:E.useMemo(()=>({open:a,side:s,align:l,uncentered:c}),[a,s,l,c]),ref:[t,i],props:[{style:u,"aria-hidden":!0},o],customStyleHookMapping:oH})}),iQ={...oH,...oM},iJ=E.forwardRef(function(e,t){let{className:r,render:n,...o}=e,{open:a,instantType:i,transitionStatus:s,popupProps:l,popupRef:c,onOpenChangeComplete:u}=iW(),{side:d,align:f}=iY();return oa({open:a,ref:c,onComplete(){a&&u?.(!0)}}),oG("div",e,{state:E.useMemo(()=>({open:a,side:d,align:f,instant:i,transitionStatus:s}),[a,d,f,i,s]),ref:[t,c],props:[l,"starting"===s?ny:nb,o],customStyleHookMapping:iQ})}),i0=E.createContext(void 0),i1=E.forwardRef(function(e,t){let{render:r,className:n,anchor:o,positionMethod:a="absolute",side:i="top",align:s="center",sideOffset:l=0,alignOffset:c=0,collisionBoundary:u="clipping-ancestors",collisionPadding:d=5,arrowPadding:f=5,sticky:p=!1,trackAnchor:h=!0,collisionAvoidance:m=nk,...g}=e,{open:v,setPositionerElement:x,mounted:y,floatingRootContext:b,trackCursorAxis:w,hoverable:_}=iW(),k=io({anchor:o,positionMethod:a,floatingRootContext:b,mounted:y,side:i,sideOffset:l,align:s,alignOffset:c,collisionBoundary:u,collisionPadding:d,sticky:p,arrowPadding:f,trackAnchor:h,keepMounted:function(){let e=E.useContext(i0);if(void 0===e)throw Error("Base UI: <Tooltip.Portal> is missing.");return e}(),collisionAvoidance:m}),j=E.useMemo(()=>{let e={};return v&&"both"!==w&&_||(e.pointerEvents="none"),{role:"presentation",hidden:!y,style:{...k.positionerStyles,...e}}},[v,w,_,y,k.positionerStyles]),S=E.useMemo(()=>({props:j,...k}),[j,k]),C=E.useMemo(()=>({open:v,side:S.side,align:S.align,anchorHidden:S.anchorHidden}),[v,S.side,S.align,S.anchorHidden]),T=E.useMemo(()=>({...C,arrowRef:S.arrowRef,arrowStyles:S.arrowStyles,arrowUncentered:S.arrowUncentered}),[C,S.arrowRef,S.arrowStyles,S.arrowUncentered]),N=oG("div",e,{state:C,props:[S.props,g],ref:[t,x],customStyleHookMapping:oH});return(0,z.jsx)(iK.Provider,{value:T,children:N})});function i2(e){let t=az({root:e.root});return t&&R.createPortal(e.children,t)}function i3(e){let{children:t,keepMounted:r=!1,container:n}=e,{mounted:o}=iW();return o||r?(0,z.jsx)(i0.Provider,{value:r,children:(0,z.jsx)(i2,{root:n,children:t})}):null}let i5=E.createContext({hasProvider:!1,timeoutMs:0,delayRef:{current:0},initialDelayRef:{current:0},timeout:new t3,currentIdRef:{current:null},currentContextRef:{current:null}});function i4(e){let{children:t,delay:r,timeoutMs:n=0}=e,o=E.useRef(r),a=E.useRef(r),i=E.useRef(null),s=E.useRef(null),l=t5();return(0,z.jsx)(i5.Provider,{value:E.useMemo(()=>({hasProvider:!0,delayRef:o,initialDelayRef:a,currentIdRef:i,timeoutMs:n,currentContextRef:s,timeout:l}),[n,l]),children:t})}let i6=E.createContext(void 0),i7=function(e){let{delay:t,closeDelay:r,timeout:n=400}=e,o=E.useMemo(()=>({delay:t,closeDelay:r}),[t,r]),a=E.useMemo(()=>({open:t,close:r}),[t,r]);return(0,z.jsx)(i6.Provider,{value:o,children:(0,z.jsx)(i4,{delay:a,timeoutMs:n,children:e.children})})};function i9(e){return null!=e&&null!=e.clientX}function i8(e){let{disabled:t=!1,defaultOpen:r=!1,onOpenChange:n,open:o,delay:a,closeDelay:i,hoverable:s=!0,trackCursorAxis:l="none",actionsRef:c,onOpenChangeComplete:u}=e,d=a??600,f=i??0,[p,h]=E.useState(null),[m,g]=E.useState(null),[v,x]=E.useState(),y=E.useRef(null),[b,w]=re({controlled:o,default:r,name:"Tooltip",state:"open"}),_=!t&&b;function k(e,t,r){let o="trigger-hover"===r,a=e&&"trigger-focus"===r,i=!e&&("trigger-press"===r||"escape-key"===r);function s(){n?.(e,t,r),w(e)}o?R.flushSync(s):s(),a||i?x(a?"focus":"dismiss"):"trigger-hover"===r&&x(void 0)}let j=t7(k);b&&t&&k(!1,void 0,"disabled");let{mounted:S,setMounted:C,transitionStatus:T}=oo(_),N=t7(()=>{C(!1),u?.(!1)});oa({enabled:!c,open:_,ref:y,onComplete(){_||N()}}),E.useImperativeHandle(c,()=>({unmount:N}),[N]);let I=rf({elements:{reference:p,floating:m},open:_,onOpenChange(e,t,r){j(e,t,om(r))}}),P=E.useContext(i6),{delayRef:L,isInstantPhase:O,hasProvider:M}=function(e,t={}){let{open:r,onOpenChange:n,floatingId:o}=e,{enabled:a=!0}=t,{currentIdRef:i,delayRef:s,timeoutMs:l,initialDelayRef:c,currentContextRef:u,hasProvider:d,timeout:f}=E.useContext(i5),[p,h]=E.useState(!1);return ri(()=>{function e(){h(!1),u.current?.setIsInstantPhase(!1),i.current=null,u.current=null,s.current=c.current}if(a&&i.current&&!r&&i.current===o){if(h(!1),l)return f.start(l,e),()=>{f.clear()};e()}},[a,r,o,i,s,l,c,u,f]),ri(()=>{if(!a||!r)return;let e=u.current,t=i.current;u.current={onOpenChange:n,setIsInstantPhase:h},i.current=o,s.current={open:0,close:ns(c.current,"close")},null!==t&&t!==o?(f.clear(),h(!0),e?.setIsInstantPhase(!0),e?.onOpenChange(!1)):(h(!1),e?.setIsInstantPhase(!1))},[a,r,o,n,i,s,l,c,u,f]),ri(()=>()=>{u.current=null},[u]),E.useMemo(()=>({hasProvider:d,delayRef:s,isInstantPhase:p}),[d,s,p])}(I),A=O?"delay":v,{getReferenceProps:D,getFloatingProps:F}=n9([nc(I,{enabled:!t,mouseOnly:!0,move:!1,handleClose:s&&"both"!==l?np():null,restMs(){let e=P?.delay,t="object"==typeof L.current?L.current.open:void 0,r=d;return M&&(r=0!==t?a??e??d:0),r},delay(){let e="object"==typeof L.current?L.current.close:void 0,t=f;return null==i&&M&&(t=e),{close:t}}}),nm(I,{enabled:!t}),nC(I,{enabled:!t,referencePress:!0}),function(e,t={}){let{open:r,dataRef:n,elements:{floating:o,domReference:a},refs:i}=e,{enabled:s=!0,axis:l="both",x:c=null,y:u=null}=t,d=E.useRef(!1),f=E.useRef(null),[p,h]=E.useState(),[m,g]=E.useState([]),v=t7((e,t)=>{if(!d.current&&(!n.current.openEvent||i9(n.current.openEvent))){var r;let o,s,c;i.setPositionReference((r={x:e,y:t,axis:l,dataRef:n,pointerType:p},o=null,s=null,c=!1,{contextElement:a||void 0,getBoundingClientRect(){let e=a?.getBoundingClientRect()||{width:0,height:0,x:0,y:0},t="x"===r.axis||"both"===r.axis,n="y"===r.axis||"both"===r.axis,i=["mouseenter","mousemove"].includes(r.dataRef.current.openEvent?.type||"")&&"touch"!==r.pointerType,l=e.width,u=e.height,d=e.x,f=e.y;return null==o&&r.x&&t&&(o=e.x-r.x),null==s&&r.y&&n&&(s=e.y-r.y),d-=o||0,f-=s||0,l=0,u=0,!c||i?(l="y"===r.axis?e.width:0,u="x"===r.axis?e.height:0,d=t&&null!=r.x?r.x:d,f=n&&null!=r.y?r.y:f):c&&!i&&(u="x"===r.axis?e.height:u,l="y"===r.axis?e.width:l),c=!0,{width:l,height:u,x:d,y:f,top:f,right:d+l,bottom:f+u,left:d}}}))}}),x=t7(e=>{null==c&&null==u&&(r?f.current||g([]):v(e.clientX,e.clientY))}),y=rJ(p)?o:r,b=E.useCallback(()=>{if(!y||!s||null!=c||null!=u)return;let e=rm(o);function t(r){r9(o,r8(r))?(e.removeEventListener("mousemove",t),f.current=null):v(r.clientX,r.clientY)}if(!n.current.openEvent||i9(n.current.openEvent)){e.addEventListener("mousemove",t);let r=()=>{e.removeEventListener("mousemove",t),f.current=null};return f.current=r,r}i.setPositionReference(a)},[y,s,c,u,o,n,i,a,v]);E.useEffect(()=>b(),[b,m]),E.useEffect(()=>{s&&!o&&(d.current=!1)},[s,o]),E.useEffect(()=>{!s&&r&&(d.current=!0)},[s,r]),ri(()=>{s&&(null!=c||null!=u)&&(d.current=!1,v(c,u))},[s,c,u,v]);let w=E.useMemo(()=>{function e(e){h(e.pointerType)}return{onPointerDown:e,onPointerEnter:e,onMouseMove:x,onMouseEnter:x}},[x]);return E.useMemo(()=>s?{reference:w}:{},[s,w])}(I,{enabled:!t&&"none"!==l,axis:"none"===l?void 0:l})]),$=E.useMemo(()=>({open:_,setOpen:j,mounted:S,setMounted:C,setTriggerElement:h,positionerElement:m,setPositionerElement:g,popupRef:y,triggerProps:D(),popupProps:F(),floatingRootContext:I,instantType:A,transitionStatus:T,onOpenChangeComplete:u}),[_,j,S,C,h,m,g,y,D,F,I,A,T,u]),U=E.useMemo(()=>({...$,delay:d,closeDelay:f,trackCursorAxis:l,hoverable:s}),[$,d,f,l,s]);return(0,z.jsx)(iH.Provider,{value:U,children:e.children})}var se=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/tooltip/tooltip.css"),st={};st.styleTagTransform=b(),st.setAttributes=g(),st.insert=h(),st.domAPI=f(),st.insertStyleElement=x(),u()(se.A,st),se.A&&se.A.locals&&se.A.locals;let sr=(0,E.forwardRef)(function(e,t){let r,n,o,a,i,s,l,c,u,d,f,p,h=(0,S.c)(35),{className:m,children:g,title:v,direction:x,arrowSize:y,offset:b}=e,w=void 0===x?"top":x,_=void 0===y?6:y,{shadowRoot:k}=(0,P.OS)();if(!v)return g;h[0]!==g?(r=e=>(0,z.jsx)("span",{...e,children:g}),h[0]=g,h[1]=r):r=h[1],h[2]!==t||h[3]!==r?(n=(0,z.jsx)(iG,{ref:t,render:r}),h[2]=t,h[3]=r,h[4]=n):n=h[4];let j=(void 0===b?8:b)+_,C=`${_}px`,E=`${_}px`;h[5]!==C||h[6]!==E?(o={"--anchor-width":C,"--anchor-height":E},h[5]=C,h[6]=E,h[7]=o):o=h[7];let T=o;h[8]!==m?(a=(0,tl.cx)("tooltip",m),h[8]=m,h[9]=a):a=h[9];let N=`${_}px`;h[10]!==N?(i={"--arrow-size":N},h[10]=N,h[11]=i):i=h[11];let I=i,R=`tooltip-arrow--${w}`;h[12]!==R?(s=(0,tl.cx)("tooltip-arrow",R),h[12]=R,h[13]=s):s=h[13];let L=`${_}px`;h[14]!==L?(l={"--arrow-size":L},h[14]=L,h[15]=l):l=h[15];let O=l;return h[16]!==s||h[17]!==O?(c=(0,z.jsx)(iX,{className:s,style:O}),h[16]=s,h[17]=O,h[18]=c):c=h[18],h[19]!==a||h[20]!==I||h[21]!==c||h[22]!==v?(u=(0,z.jsxs)(iJ,{className:a,style:I,children:[v,c]}),h[19]=a,h[20]=I,h[21]=c,h[22]=v,h[23]=u):u=h[23],h[24]!==w||h[25]!==T||h[26]!==u||h[27]!==j?(d=(0,z.jsx)(i1,{side:w,sideOffset:j,className:"tooltip-positioner",style:T,children:u}),h[24]=w,h[25]=T,h[26]=u,h[27]=j,h[28]=d):d=h[28],h[29]!==k||h[30]!==d?(f=(0,z.jsx)(i3,{container:k,children:d}),h[29]=k,h[30]=d,h[31]=f):f=h[31],h[32]!==f||h[33]!==n?(p=(0,z.jsx)(i7,{children:(0,z.jsxs)(i8,{delay:400,children:[n,f]})}),h[32]=f,h[33]=n,h[34]=p):p=h[34],p});function sn(e){let t,r,n=(0,S.c)(3),{possibleExtension:o,missingGlobalError:a}=e,i=a?`No global-error.${o} found: Add one to ensure users see a helpful message when an unexpected error occurs.`:null;return n[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)(sf,{}),n[0]=t):t=n[0],n[1]!==i?(r=(0,z.jsx)("span",{className:"segment-explorer-suggestions",children:(0,z.jsx)(sr,{className:"segment-explorer-suggestions-tooltip",title:i,children:t})}),n[1]=i,n[2]=r):r=n[2],r}let so=e=>!!e.value?.type&&!!e.value?.pagePath;function sa(e){let t,r,n=(0,S.c)(3),{page:o}=e;return n[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)(sp,{}),n[0]=t):t=n[0],n[1]!==o?(r=(0,z.jsxs)("div",{className:"segment-explorer-page-route-bar",children:[t,(0,z.jsx)("span",{className:"segment-explorer-page-route-bar-path",children:o})]}),n[1]=o,n[2]=r):r=n[2],r}function si(e){let t,r,n,o=(0,S.c)(9),{activeBoundariesCount:a,onGlobalReset:i}=e,s=a>0,l=`segment-explorer-footer-button ${!s?"segment-explorer-footer-button--disabled":""}`,c=s?i:void 0,u=!s;return o[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("span",{className:"segment-explorer-footer-text",children:"Clear Segment Overrides"}),o[0]=t):t=o[0],o[1]!==a||o[2]!==s?(r=s&&(0,z.jsx)("span",{className:"segment-explorer-footer-badge",children:a}),o[1]=a,o[2]=s,o[3]=r):r=o[3],o[4]!==l||o[5]!==c||o[6]!==u||o[7]!==r?(n=(0,z.jsx)("div",{className:"segment-explorer-footer",children:(0,z.jsxs)("button",{className:l,onClick:c,disabled:u,type:"button",children:[t,r]})}),o[4]=l,o[5]=c,o[6]=u,o[7]=r,o[8]=n):n=o[8],n}function ss(e){let t,r,n,o,a,i=(0,S.c)(16),{type:s,isBuiltin:l,isOverridden:c,filePath:u,fileName:d}=e,f=`segment-explorer-file-label--${s}`,p=l&&"segment-explorer-file-label--builtin",h=c&&"segment-explorer-file-label--overridden";i[0]!==f||i[1]!==p||i[2]!==h?(t=(0,tl.cx)("segment-explorer-file-label",f,p,h),i[0]=f,i[1]=p,i[2]=h,i[3]=t):t=i[3];let m=`Open ${d} in editor`;return i[4]!==u?(r=()=>{!function({filePath:e}){let t=new URLSearchParams({file:e,isAppRelativePath:"1"});fetch(`${process.env.__NEXT_ROUTER_BASEPATH||""}/__nextjs_launch-editor?${t.toString()}`)}({filePath:u})},i[4]=u,i[5]=r):r=i[5],i[6]!==d?(n=(0,z.jsx)("span",{className:"segment-explorer-file-label-text",children:d}),i[6]=d,i[7]=n):n=i[7],i[8]!==l?(o=l?(0,z.jsx)(sf,{"aria-hidden":!0}):(0,z.jsx)(sh,{className:"code-icon","aria-hidden":!0}),i[8]=l,i[9]=o):o=i[9],i[10]!==t||i[11]!==m||i[12]!==r||i[13]!==n||i[14]!==o?(a=(0,z.jsxs)("button",{type:"button",className:t,"aria-label":m,onClick:r,children:[n,o]}),i[10]=t,i[11]=m,i[12]=r,i[13]=n,i[14]=o,i[15]=a):a=i[15],a}function sl(e){let t,r,n,o,a,i,s,l,c=(0,S.c)(17),{page:u}=e,d=(0,tY.j1)();c[0]!==d?(t=function e(t){let r=0;return t.value?.setBoundaryType&&null!==t.value.boundaryType&&!iA(t.value.type)&&r++,Object.values(t.children).forEach(t=>{t&&(r+=e(t))}),r}(d),c[0]=d,c[1]=t):t=c[1];let f=t;c[2]!==d?(r=()=>{!function e(t){t.value?.setBoundaryType&&t.value.setBoundaryType(null),Object.values(t.children).forEach(t=>{t&&e(t)})}(d)},c[2]=d,c[3]=r):r=c[3];let p=r;return c[4]===Symbol.for("react.memo_cache_sentinel")?(n={display:"flex",flexDirection:"column",height:"100%"},c[4]=n):n=c[4],c[5]!==u?(o=(0,z.jsx)(sa,{page:u}),c[5]=u,c[6]=o):o=c[6],c[7]===Symbol.for("react.memo_cache_sentinel")?(a={flex:"1 1 auto",overflow:"auto"},c[7]=a):a=c[7],c[8]!==d?(i=(0,z.jsx)("div",{className:"segment-explorer-content","data-nextjs-devtool-segment-explorer":!0,style:a,children:(0,z.jsx)(su,{node:d,level:0,segment:""})}),c[8]=d,c[9]=i):i=c[9],c[10]!==f||c[11]!==p?(s=(0,z.jsx)(si,{activeBoundariesCount:f,onGlobalReset:p}),c[10]=f,c[11]=p,c[12]=s):s=c[12],c[13]!==o||c[14]!==i||c[15]!==s?(l=(0,z.jsxs)("div",{"data-nextjs-devtools-panel-segments-explorer":!0,style:n,children:[o,i,s]}),c[13]=o,c[14]=i,c[15]=s,c[16]=l):l=c[16],l}let sc="global-error";function su(e){let t,r,n,o,a,i,s,l,c,u,d,f,p=(0,S.c)(38),{segment:h,node:m,level:g}=e;p[0]!==m.children?(t=Object.keys(m.children),p[0]=m.children,p[1]=t):t=p[1];let v=t;p[2]!==v||p[3]!==m.children?(r=[],v.forEach(e=>{let t=m.children[e];if(!t||!t.value)return;let n=iD(t.value.type),o=n===sc;(o&&!t.value.pagePath.startsWith(iL)||!o&&iA(t.value.type))&&r.push(n)}),p[2]=v,p[3]=m.children,p[4]=r):r=p[4];let x=0===g&&!r.includes(sc);if(p[5]!==v||p[6]!==g||p[7]!==m.children||p[8]!==h){let e;p[16]!==m.children?(e=(e,t)=>{let r=e.includes("."),n=t.includes(".");if(r&&!n)return -1;if(!r&&n)return 1;if(r&&n){let r=m.children[e]?.value?.type,n=m.children[t]?.value?.type,o=sd,a=o(r),i=o(n);if(a!==i)return a-i;let s=m.children[e]?.value?.pagePath||"",l=m.children[t]?.value?.pagePath||"";return s.localeCompare(l)}return e.localeCompare(t)},p[16]=m.children,p[17]=e):e=p[17];let t=v.sort(e);for(let e of(s=0!==g||h?h:"app",i=[],o=[],t)){let t=m.children[e];if(t){if(so(t)){o.push(e);continue}i.push(e)}}c=iO(o[0]||"").split(".").pop()||"js",a=null;for(let e=t.length-1;e>=0;e--){let r=m.children[t[e]];if(r&&r.value&&!iA(r.value.type)){a=r;break}}let r=null;for(let e of t){let t=m.children[e];if(t&&t.value&&iA(t.value.type)){r=t;break}}a=a||r,l=o.length>0,n={"not-found":null,loading:null,error:null,"global-error":null},o.forEach(e=>{let t=m.children[e];if(t&&t.value&&iA(t.value.type)){let e=iD(t.value.type);e in n&&(n[e]=t.value.pagePath||null)}}),p[5]=v,p[6]=g,p[7]=m.children,p[8]=h,p[9]=n,p[10]=o,p[11]=a,p[12]=i,p[13]=s,p[14]=l,p[15]=c}else n=p[9],o=p[10],a=p[11],i=p[12],s=p[13],l=p[14],c=p[15];return p[18]!==n||p[19]!==o||p[20]!==a||p[21]!==s||p[22]!==l||p[23]!==g||p[24]!==x||p[25]!==m||p[26]!==c||p[27]!==h?(u=l&&(0,z.jsx)("div",{className:"segment-explorer-item","data-nextjs-devtool-segment-explorer-segment":h+"-"+g,children:(0,z.jsx)("div",{className:"segment-explorer-item-row",style:{...{paddingLeft:`${(g+1)*8}px`}},children:(0,z.jsx)("div",{className:"segment-explorer-item-row-main",children:(0,z.jsxs)("div",{className:"segment-explorer-filename",children:[s&&(0,z.jsxs)("span",{className:"segment-explorer-filename--path",children:[s,(0,z.jsx)("small",{children:"/"})]}),x&&(0,z.jsx)(sn,{possibleExtension:c,missingGlobalError:x}),o.length>0&&(0,z.jsx)("span",{className:"segment-explorer-files",children:o.map(e=>{let t=m.children[e];if(!t||!t.value||iA(t.value.type))return null;let r=t.value.pagePath,n=r.split("/").pop()||"",o=r.startsWith(iL),a=iO(n),i=o?`The default Next.js ${t.value.type} is being shown. You can customize this page by adding your own ${a} file to the app/ directory.`:null,s=null!==t.value.boundaryType;return(0,z.jsx)(sr,{className:"segment-explorer-file-label-tooltip--"+(o?"lg":"sm"),direction:o?"right":"top",title:i,offset:12,children:(0,z.jsx)(ss,{type:t.value.type,isBuiltin:o,isOverridden:s,filePath:r,fileName:a})},e)})}),a&&a.value&&(0,z.jsx)(iF,{nodeState:a.value,boundaries:n})]})})})}),p[18]=n,p[19]=o,p[20]=a,p[21]=s,p[22]=l,p[23]=g,p[24]=x,p[25]=m,p[26]=c,p[27]=h,p[28]=u):u=p[28],p[29]!==i||p[30]!==l||p[31]!==g||p[32]!==m||p[33]!==h?(d=i.map(e=>{let t=m.children[e];if(!t)return null;let r=l?e:h+" / "+e;return(0,z.jsx)(su,{segment:r,node:t,level:l?g+1:g},e)}),p[29]=i,p[30]=l,p[31]=g,p[32]=m,p[33]=h,p[34]=d):d=p[34],p[35]!==u||p[36]!==d?(f=(0,z.jsxs)(z.Fragment,{children:[u,d]}),p[35]=u,p[36]=d,p[37]=f):f=p[37],f}function sd(e){return e?"layout"===e?1:"template"===e?2:"page"===e?3:iA(e)?4:5:5}function sf(e){let t,r,n,o=(0,S.c)(4);return o[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("path",{d:"M14 8C14 11.3137 11.3137 14 8 14C4.68629 14 2 11.3137 2 8C2 4.68629 4.68629 2 8 2C11.3137 2 14 4.68629 14 8Z",fill:"var(--color-gray-400)"}),r=(0,z.jsx)("path",{d:"M7.75 7C8.30228 7.00001 8.75 7.44772 8.75 8V11.25H7.25V8.5H6.25V7H7.75ZM8 4C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6C7.44772 6 7 5.55228 7 5C7 4.44772 7.44772 4 8 4Z",fill:"var(--color-gray-900)"}),o[0]=t,o[1]=r):(t=o[0],r=o[1]),o[2]!==e?(n=(0,z.jsxs)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e,children:[t,r]}),o[2]=e,o[3]=n):n=o[3],n}function sp(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"var(--color-gray-600)",xmlns:"http://www.w3.org/2000/svg",children:(0,z.jsx)("path",{d:"M4.5 11.25C4.5 11.3881 4.61193 11.5 4.75 11.5H14.4395L11.9395 9L13 7.93945L16.7803 11.7197L16.832 11.7764C17.0723 12.0709 17.0549 12.5057 16.7803 12.7803L13 16.5605L11.9395 15.5L14.4395 13H4.75C3.7835 13 3 12.2165 3 11.25V4.25H4.5V11.25Z"})}),t[0]=e):e=t[0],e}function sh(e){let t,r,n=(0,S.c)(3);return n[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M7.22763 14.1819L10.2276 2.18193L10.4095 1.45432L8.95432 1.09052L8.77242 1.81812L5.77242 13.8181L5.59051 14.5457L7.04573 14.9095L7.22763 14.1819ZM3.75002 12.0607L3.21969 11.5304L0.39647 8.70713C0.00594559 8.31661 0.00594559 7.68344 0.39647 7.29292L3.21969 4.46969L3.75002 3.93936L4.81068 5.00002L4.28035 5.53035L1.81068 8.00003L4.28035 10.4697L4.81068 11L3.75002 12.0607ZM12.25 12.0607L12.7804 11.5304L15.6036 8.70713C15.9941 8.31661 15.9941 7.68344 15.6036 7.29292L12.7804 4.46969L12.25 3.93936L11.1894 5.00002L11.7197 5.53035L14.1894 8.00003L11.7197 10.4697L11.1894 11L12.25 12.0607Z",fill:"currentColor"}),n[0]=t):t=n[0],n[1]!==e?(r=(0,z.jsx)("svg",{width:"12",height:"12",strokeLinejoin:"round",viewBox:"0 0 16 16",fill:"currentColor",...e,children:t}),n[1]=e,n[2]=r):r=n[2],r}function sm(e){let t,r,n,o,a,i,s,l,c,u=(0,S.c)(17),{title:d,children:f,onClose:p,ref:h}=e,{setPanel:m}=e8();return u[0]===Symbol.for("react.memo_cache_sentinel")?(t={width:"100%",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 20px",userSelect:"none",WebkitUserSelect:"none",borderBottom:"1px solid var(--color-gray-alpha-400)"},u[0]=t):t=u[0],u[1]===Symbol.for("react.memo_cache_sentinel")?(r={margin:0,fontSize:"14px",color:"var(--color-text-primary)",fontWeight:"normal"},u[1]=r):r=u[1],u[2]!==d?(n=(0,z.jsx)("h3",{style:r,children:d}),u[2]=d,u[3]=n):n=u[3],u[4]!==p||u[5]!==m?(o=()=>{p?p():m("panel-selector")},u[4]=p,u[5]=m,u[6]=o):o=u[6],u[7]===Symbol.for("react.memo_cache_sentinel")?(a={background:"none",border:"none",cursor:"pointer",padding:"4px",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:"4px",color:"var(--color-gray-900)"},i=(0,z.jsx)(sg,{}),u[7]=a,u[8]=i):(a=u[7],i=u[8]),u[9]!==o?(s=(0,z.jsx)("button",{id:"_next-devtools-panel-close",className:"dev-tools-info-close-button",onClick:o,"aria-label":"Close devtools panel",style:a,children:i}),u[9]=o,u[10]=s):s=u[10],u[11]===Symbol.for("react.memo_cache_sentinel")?(l=(0,z.jsx)("style",{children:(0,C.A)`
        .dev-tools-info-close-button:focus-visible {
          outline: var(--focus-ring);
        }
      `}),u[11]=l):l=u[11],u[12]!==f||u[13]!==h||u[14]!==n||u[15]!==s?(c=(0,z.jsxs)("div",{style:t,ref:h,children:[n,f,s,l]}),u[12]=f,u[13]=h,u[14]=n,u[15]=s,u[16]=c):c=u[16],c}function sg(e){let t,r,n,o=(0,S.c)(4),{size:a}=e,i=void 0===a?22:a;return o[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("path",{d:"M18 6 6 18"}),r=(0,z.jsx)("path",{d:"m6 6 12 12"}),o[0]=t,o[1]=r):(t=o[0],r=o[1]),o[2]!==i?(n=(0,z.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:i,height:i,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[t,r]}),o[2]=i,o[3]=n):n=o[3],n}function sv(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 20 20",fill:"none",children:(0,z.jsx)("path",{fill:"currentColor",fillRule:"evenodd",d:"m9.7 3.736.045-.236h.51l.044.236a2.024 2.024 0 0 0 1.334 1.536c.19.066.375.143.554.23.618.301 1.398.29 2.03-.143l.199-.136.36.361-.135.199a2.024 2.024 0 0 0-.143 2.03c.087.179.164.364.23.554.224.65.783 1.192 1.536 1.334l.236.044v.51l-.236.044a2.024 2.024 0 0 0-1.536 1.334 4.95 4.95 0 0 1-.23.554 2.024 2.024 0 0 0 .143 2.03l.136.199-.361.36-.199-.135a2.024 2.024 0 0 0-2.03-.143c-.179.087-.364.164-.554.23a2.024 2.024 0 0 0-1.334 1.536l-.044.236h-.51l-.044-.236a2.024 2.024 0 0 0-1.334-1.536 4.952 4.952 0 0 1-.554-.23 2.024 2.024 0 0 0-2.03.143l-.199.136-.36-.361.135-.199a2.024 2.024 0 0 0 .143-2.03 4.958 4.958 0 0 1-.23-.554 2.024 2.024 0 0 0-1.536-1.334l-.236-.044v-.51l.236-.044a2.024 2.024 0 0 0 1.536-1.334 4.96 4.96 0 0 1 .23-.554 2.024 2.024 0 0 0-.143-2.03l-.136-.199.361-.36.199.135a2.024 2.024 0 0 0 2.03.143c.179-.087.364-.164.554-.23a2.024 2.024 0 0 0 1.334-1.536ZM8.5 2h3l.274 1.46c.034.185.17.333.348.394.248.086.49.186.722.3.17.082.37.074.526-.033l1.226-.839 2.122 2.122-.84 1.226a.524.524 0 0 0-.032.526c.114.233.214.474.3.722.061.177.21.314.394.348L18 8.5v3l-1.46.274a.524.524 0 0 0-.394.348 6.47 6.47 0 0 1-.3.722.524.524 0 0 0 .033.526l.839 1.226-2.122 2.122-1.226-.84a.524.524 0 0 0-.526-.032 6.477 6.477 0 0 1-.722.3.524.524 0 0 0-.348.394L11.5 18h-3l-.274-1.46a.524.524 0 0 0-.348-.394 6.477 6.477 0 0 1-.722-.3.524.524 0 0 0-.526.033l-1.226.839-2.122-2.122.84-1.226a.524.524 0 0 0 .032-.526 6.453 6.453 0 0 1-.3-.722.524.524 0 0 0-.394-.348L2 11.5v-3l1.46-.274a.524.524 0 0 0 .394-.348c.086-.248.186-.49.3-.722a.524.524 0 0 0-.033-.526l-.839-1.226 2.122-2.122 1.226.84a.524.524 0 0 0 .526.032 6.46 6.46 0 0 1 .722-.3.524.524 0 0 0 .348-.394L8.5 2Zm3 8a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Zm1.5 0a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z",clipRule:"evenodd"})}),t[0]=e):e=t[0],e}function sx(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{width:"20px",height:"20px",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,z.jsx)("circle",{cx:"10",cy:"10",r:"7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeDasharray:"32 12",opacity:"0.8",children:(0,z.jsx)("animateTransform",{attributeName:"transform",type:"rotate",from:"0 10 10",to:"360 10 10",dur:"1s",repeatCount:"indefinite"})})}),t[0]=e):e=t[0],e}var sy=r("./src/next-devtools/dev-overlay/components/instant-navs/instant-nav-cookie.ts"),sb=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/instant-navs/instant-navs-panel.css"),sw={};sw.styleTagTransform=b(),sw.setAttributes=g(),sw.insert=h(),sw.domAPI=f(),sw.insertStyleElement=x(),u()(sb.A,sw),sb.A&&sb.A.locals&&sb.A.locals;let s_="next-instant-navigation-testing",sk="idle",sj=new Set;function sS(e){if(sk!==e)for(let t of(sk=e,sj))t()}function sC(e){return sj.add(e),()=>sj.delete(e)}function sE(){return sk}function sT(e){return"restarting"===e}function sN(){return[0,`p${Math.random()}`]}function sI(e){"undefined"!=typeof document&&(document.cookie=`${s_}=${JSON.stringify(e)}; Path=/`)}function sz(){"undefined"!=typeof document&&(document.cookie=`${s_}=; Path=/; Max-Age=0`)}function sR(){sS("idle"),sz()}function sP(){let e,t,r,n,o,a,i,s,l,c,u,d,f,p,h,m,g,v=(0,S.c)(37),{dispatch:x}=(0,P.OS)(),{panel:y}=e8(),b=(0,sy.Vi)();v[0]!==x?(e=()=>()=>{sS("idle"),x({type:eu.u6})},t=[x],v[0]=x,v[1]=e,v[2]=t):(e=v[1],t=v[2]),(0,E.useEffect)(e,t),v[3]!==x||v[4]!==y?(r=()=>{"instant-navs"!==y&&(sR(),x({type:eu.u6}))},n=[y,x],v[3]=x,v[4]=y,v[5]=r,v[6]=n):(r=v[5],n=v[6]),(0,E.useEffect)(r,n),v[7]!==b?.state?(o=()=>{"restarting"===sk&&b?.state==="pending"&&sS("idle")},v[7]=b?.state,v[8]=o):o=v[8];let w=b?.state;v[9]!==w?(a=[w],v[9]=w,v[10]=a):a=v[10],(0,E.useEffect)(o,a);let _=function(e){let t,r=(0,S.c)(3),n=(0,E.useSyncExternalStore)(sC,sE,sE);if(r[0]!==e||r[1]!==n)t=sT(n)?n:e?.state==="spa"?"spa":e?.state==="mpa"?"mpa":null!==e?"pending":"idle",r[0]=e,r[1]=n,r[2]=t;else t=r[2];return t}(b);if(v[11]!==_)i=sT(_)?"pending":_,v[11]=_,v[12]=i;else i=v[12];let k=i,j="idle"!==_,C="instant-navs"!==y,[T,N]=(0,E.useState)(k);C||T===k||N(k),v[13]!==b?(s=b?.state==="spa"?(0,sy.pt)(b.fromTree):null,v[13]=b,v[14]=s):s=v[14];let I=s;v[15]!==b?(l=b?.state==="spa"&&null!==b.toTree?(0,sy.pt)(b.toTree):null,v[15]=b,v[16]=l):l=v[16];let R=l,[L,O]=(0,E.useState)(I),[M,A]=(0,E.useState)(R);null!==I&&I!==L&&O(I),null!==R&&R!==M&&A(R);let D=I??L,F=R??M;v[17]===Symbol.for("react.memo_cache_sentinel")?(c=async function(){sS("restarting");let e=sN(),t="undefined"!=typeof cookieStore?new Promise(e=>{cookieStore.addEventListener("change",function t(r){for(let n of r.deleted)if(n.name===s_)return void(cookieStore.removeEventListener("change",t),e())})}):Promise.resolve();sz(),await t,sI(e)},v[17]=c):c=v[17];let $=c;v[18]!==j?(u=function(){j?sR():sI(sN())},v[18]=j,v[19]=u):u=v[19];let U=u;v[20]===Symbol.for("react.memo_cache_sentinel")?(d={exitDelay:400},v[20]=d):d=v[20];let{mounted:Z}=eU("idle"!==_,d),[q,B]=(0,E.useState)(_);_!==q&&["pending","mpa","spa"].includes(_)&&B(_);let V=225*("idle"!==_),[H,W]=(0,E.useState)(y),[G,K]=(0,E.useState)(null);H!==y&&(W(y),K("instant-navs"===y?null:V));let Y=null!==G?G:V;return v[21]!==Y?(f={transition:"height 400ms cubic-bezier(0.36, 0.66, 0.04, 1)",height:Y},v[21]=Y,v[22]=f):f=v[22],v[23]!==Z||v[24]!==q||v[25]!==D||v[26]!==F?(p=Z&&(0,z.jsx)("div",{style:{height:225},children:"pending"===q?(0,z.jsxs)("div",{className:" instant-nav-state--pending",children:[(0,z.jsxs)("div",{className:"instant-nav-waiting-status",children:[(0,z.jsx)("span",{className:"instant-nav-waiting-status-dot"}),(0,z.jsx)("h3",{className:"instant-nav-waiting-status-title",children:"Waiting for navigation..."})]}),(0,z.jsx)("p",{className:"instant-nav-waiting-description",children:"Click any link or refresh the page to inspect the shell."})]}):"mpa"===q?(0,z.jsxs)("div",{className:"",children:[(0,z.jsx)(sL,{onClick:$}),(0,z.jsxs)("div",{className:"instant-nav-state-details",children:[(0,z.jsxs)("h3",{className:"instant-nav-state-title",children:["Loading shell",(0,z.jsx)("span",{className:"instant-nav-state-title-type",children:"Page load"})]}),(0,z.jsx)("p",{className:"instant-nav-state-description",children:"You're viewing the shell for this page's initial load."}),(0,z.jsx)(sM,{label:"Target",value:"undefined"==typeof window?"/":window.location.pathname+window.location.search})]})]}):"spa"===q?(0,z.jsxs)("div",{className:"",children:[(0,z.jsx)(sL,{onClick:$}),(0,z.jsxs)("div",{className:"instant-nav-state-details",children:[(0,z.jsxs)("h3",{className:"instant-nav-state-title",children:["Loading shell",(0,z.jsx)("span",{className:"instant-nav-state-title-type",children:"Client nav"})]}),(0,z.jsx)("p",{className:"instant-nav-state-description",children:"You're viewing the shell for the current navigation."}),(0,z.jsxs)("div",{className:"instant-nav-state-url-list",children:[null!==D?(0,z.jsx)(sM,{label:"Source",value:D}):null,null!==F?(0,z.jsx)(sM,{label:"Target",value:F}):null]})]})]}):null}),v[23]=Z,v[24]=q,v[25]=D,v[26]=F,v[27]=p):p=v[27],v[28]!==f||v[29]!==p?(h=(0,z.jsx)("div",{className:"instant-nav-content",children:(0,z.jsx)("div",{className:"instant-nav-content-container",style:f,children:p})}),v[28]=f,v[29]=p,v[30]=h):h=v[30],v[31]!==j||v[32]!==U?(m=(0,z.jsx)(sO,{checked:j,onClick:U}),v[31]=j,v[32]=U,v[33]=m):m=v[33],v[34]!==h||v[35]!==m?(g=(0,z.jsxs)("div",{className:"instant-nav-panel",children:[h,m]}),v[34]=h,v[35]=m,v[36]=g):g=v[36],g}function sL(e){let t,r,n,o,a=(0,S.c)(5),{onClick:i}=e;return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)(sA,{}),r=(0,z.jsx)("span",{children:"Debugger paused"}),a[0]=t,a[1]=r):(t=a[0],r=a[1]),a[2]===Symbol.for("react.memo_cache_sentinel")?(n=(0,z.jsx)(sD,{}),a[2]=n):n=a[2],a[3]!==i?(o=(0,z.jsxs)("div",{className:"instant-nav-debugger-paused",children:[t,r,(0,z.jsxs)("button",{type:"button",className:"instant-nav-debugger-paused-button",onClick:i,"aria-label":"Resume",children:["Resume",n]})]}),a[3]=i,a[4]=o):o=a[4],o}function sO(e){let t,r,n,o=(0,S.c)(5),{checked:a,onClick:i}=e;return o[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsxs)("div",{className:"instant-nav-pause-copy",children:[(0,z.jsx)("label",{htmlFor:"instant-nav-pause-toggle",children:"Pause on navigations"}),(0,z.jsx)("p",{children:"When enabled, every navigation will pause so you can inspect the loading shell before resuming."})]}),o[0]=t):t=o[0],o[1]===Symbol.for("react.memo_cache_sentinel")?(r=(0,z.jsx)("span",{className:"instant-nav-pause-toggle-thumb"}),o[1]=r):r=o[1],o[2]!==a||o[3]!==i?(n=(0,z.jsxs)("div",{className:"instant-nav-pause-control",children:[t,(0,z.jsx)("button",{id:"instant-nav-pause-toggle",type:"button",role:"switch","aria-checked":a,"aria-label":"Pause on navigations",className:"instant-nav-pause-toggle",onClick:i,children:r})]}),o[2]=a,o[3]=i,o[4]=n):n=o[4],n}function sM(e){let t,r,n,o=(0,S.c)(7),{label:a,value:i}=e;return o[0]!==a?(t=(0,z.jsx)("span",{className:"instant-nav-url-label",children:a}),o[0]=a,o[1]=t):t=o[1],o[2]!==i?(r=(0,z.jsx)("span",{className:"instant-nav-url-value",title:i,children:i}),o[2]=i,o[3]=r):r=o[3],o[4]!==t||o[5]!==r?(n=(0,z.jsxs)("div",{className:"instant-nav-url-row",children:[t,r]}),o[4]=t,o[5]=r,o[6]=n):n=o[6],n}function sA(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{viewBox:"0 0 16 16",height:"16",width:"16","aria-hidden":"true",style:{color:"currentcolor"},children:(0,z.jsx)("path",{fill:"currentColor",fillRule:"evenodd",d:"M8 14.5a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16M6.25 7h1.5a1 1 0 0 1 1 1v4.25h-1.5V8.5h-1zM8 6a1 1 0 1 0 0-2 1 1 0 0 0 0 2",clipRule:"evenodd"})}),t[0]=e):e=t[0],e}function sD(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"currentColor",width:"12",height:"12","aria-hidden":"true",children:(0,z.jsx)("path",{d:"M6.3 2.84A1.5 1.5 0 0 0 4 4.11v11.78a1.5 1.5 0 0 0 2.3 1.27l9.344-5.891a1.5 1.5 0 0 0 0-2.538L6.3 2.841Z"})}),t[0]=e):e=t[0],e}let sF=E.createContext(void 0),s$=((l={}).checked="data-checked",l.unchecked="data-unchecked",l.disabled="data-disabled",l.highlighted="data-highlighted",l),sU={checked:e=>e?{[s$.checked]:""}:{[s$.unchecked]:""},...oM},sZ=E.memo(E.forwardRef(function(e,t){let{checked:r,defaultChecked:n,onCheckedChange:o,className:a,closeOnClick:i,disabled:s=!1,highlighted:l,id:c,menuEvents:u,itemProps:d,render:f,allowMouseUpTriggerRef:p,typingRef:h,nativeButton:m,...g}=e,[v,x]=re({controlled:r,default:n??!1,name:"MenuCheckboxItem",state:"checked"}),{getItemProps:y,itemRef:b}=iz({closeOnClick:i,disabled:s,highlighted:l,id:c,menuEvents:u,allowMouseUpTriggerRef:p,typingRef:h,nativeButton:m,itemMetadata:iI}),w=E.useMemo(()=>({disabled:s,highlighted:l,checked:v}),[s,l,v]),_=oG("div",e,{state:w,customStyleHookMapping:sU,props:[d,{role:"menuitemcheckbox","aria-checked":v,onClick:e=>{x(e=>!e),o?.(!v,e.nativeEvent)}},g,y],ref:[b,t]});return(0,z.jsx)(sF.Provider,{value:w,children:_})})),sq=E.forwardRef(function(e,t){let{id:r,label:n,closeOnClick:o=!1,nativeButton:a=!1,...i}=e,s=E.useRef(null),l=o1({label:n}),c=oI(t,l.ref,s),{itemProps:u,activeIndex:d,allowMouseUpTriggerRef:f,typingRef:p}=or(),h=iT(r),m=l.index===d,{events:g}=E.useContext(rl);return(0,z.jsx)(sZ,{...i,id:h,ref:c,highlighted:m,menuEvents:g,itemProps:u,allowMouseUpTriggerRef:f,typingRef:p,closeOnClick:o,nativeButton:a})});var sB=r("./src/shared/lib/request-insights.ts");function sV(e){return void 0===e?"-":0===e?"0 ms":e>0&&e<.1?"<0.1 ms":e<2?`${e.toFixed(1)} ms`:e<1e3?`${Math.round(e)} ms`:`${(e/1e3).toFixed(2)} s`}function sH(e,t){if(null!==t&&e.some(e=>(0,sB.v)(e)===t))return t;let r=e.find(e=>e.fetches.length>0)??e[0];return r?(0,sB.v)(r):null}function sW(e){return"request"!==(0,sB.o)(e)}let sG="AppRender.fetch",sK=new Set(["BaseServer.handleRequest","Middleware.execute","NextNodeServer.matchRoute","DevBundlerService.ensurePage","BaseServer.render","LoadComponents.loadComponents","AppRender.prepareAppPageResponse","AppRender.initializeRender","AppRender.getBodyResult","NextNodeServer.createComponentTree","AppRender.startRSCStream","AppRender.renderRSCResponse","AppRender.waitForRSC","AppRender.renderToNodeFizzStream","AppRender.waitForHTMLCompletion","AppRender.instantInsights","AppRender.instantInsights.prepareValidation","AppRender.instantInsights.runValidation",sG,"NextNodeServer.waitForFirstResponseChunk","NextNodeServer.startResponse","Render.getServerSideProps","Render.getStaticProps","Render.renderDocument","Node.runHandler","AppRouteRouteHandlers.runHandler","ResolveMetadata.generateMetadata","ResolveMetadata.generateViewport"]),sY=/\bFizz\b/gi,sX=/\bFlight\b/gi,sQ={api:"API",fizz:"HTML",flight:"RSC",html:"HTML",http:"HTTP",https:"HTTPS",id:"ID",node:"Node",rsc:"RSC",url:"URL"};function sJ(e,t){return e.startTime-t.startTime||(t.durationMs??0)-(e.durationMs??0)||e.id.localeCompare(t.id)}function s0(e){return e.attributes?.["next.span_type"]===sG}function s1(e){let t=e.attributes?.["next.fetch.idx"];return"number"==typeof t?t:void 0}function s2(e){let t=e.attributes?.["next.span_category"];return"nextjs"===t||"application"===t?t:e.attributes?.["next.span_type"]===sG?"application":"string"==typeof e.attributes?.["next.span_type"]?"nextjs":"application"}var s3=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/request-insights/request-insights-panel.css"),s5={};function s4(){let e,t,r,n,o,a,i,s,l,c,u,d,f,p,h,m,g,v,x,y,b,w,_,k,j=(0,S.c)(63),{dispatch:C,state:T,shadowRoot:N}=(0,P.OS)();j[0]!==T.requestInsights?(e=[...T.requestInsights].reverse(),j[0]=T.requestInsights,j[1]=e):e=j[1];let I=e,{showInternal:R,verbose:L}=T.requestInsightsConfig;j[2]!==C?(t=e=>{C({type:eu.$P,devToolsConfig:{requestInsights:e}}),eI({requestInsights:e})},j[2]=C,j[3]=t):t=j[3];let O=t;j[4]!==I||j[5]!==R?(r=function(e,t){if(!t)return e.filter(e=>!sW(e)).map(e=>({request:e,nested:!1}));let r=new Map,n=new Set;for(let t of e)if(sW(t)){let e=r.get(t.requestId);e?e.push(t):r.set(t.requestId,[t])}else n.add(t.requestId);let o=[];for(let t of e){if(sW(t)){n.has(t.requestId)||o.push({request:t,nested:!1});continue}o.push({request:t,nested:!1});let e=r.get(t.requestId);if(e)for(let t of e)o.push({request:t,nested:!0})}return o}(I,R),j[4]=I,j[5]=R,j[6]=r):r=j[6];let M=r;j[7]!==M?(n=M.map(s9),j[7]=M,j[8]=n):n=j[8];let A=n;j[9]!==A?(o=()=>sH(A,null),j[9]=A,j[10]=o):o=j[10];let[D,F]=(0,E.useState)(o);j[11]!==D||j[12]!==A?(a=sH(A,D),j[11]=D,j[12]=A,j[13]=a):a=j[13];let $=a;j[14]!==$||j[15]!==A?(i=A.find(e=>(0,sB.v)(e)===$)??null,j[14]=$,j[15]=A,j[16]=i):i=j[16];let U=i,Z=self.__next_r;j[17]!==I?(s=I.filter(s7),j[17]=I,j[18]=s):s=j[18];let q=s;j[19]!==q||j[20]!==R?(l=R?0:q.filter(s6).length,j[19]=q,j[20]=R,j[21]=l):l=j[21];let B=l,V=q.length>0;if(0===I.length){let e;return j[22]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("div",{className:"request-insights-empty",children:"Request insights will appear after the next App Router request."}),j[22]=e):e=j[22],e}j[23]===Symbol.for("react.memo_cache_sentinel")?(c=(0,z.jsx)("strong",{children:"Requests"}),j[23]=c):c=j[23],j[24]!==B?(u=B>0?(0,z.jsx)("span",{"aria-label":`${B} hidden internal error${1===B?"":"s"}`,className:"request-insights-settings-dot",role:"img"}):null,j[24]=B,j[25]=u):u=j[25],j[26]===Symbol.for("react.memo_cache_sentinel")?(d=(0,z.jsx)(o3,{"aria-label":"Request list settings",className:"request-insights-settings-trigger",children:(0,z.jsx)(sv,{})}),j[26]=d):d=j[26],j[27]!==O||j[28]!==R||j[29]!==V?(f=V?(0,z.jsxs)(sq,{checked:R,className:"request-insights-settings-item",closeOnClick:!1,onCheckedChange:e=>O({showInternal:e}),children:[(0,z.jsx)("span",{className:"request-insights-settings-checkbox","data-checked":R||void 0,children:R?(0,z.jsx)(lt,{}):null}),"Internal activity"]}):null,j[27]=O,j[28]=R,j[29]=V,j[30]=f):f=j[30],j[31]!==O?(p=e=>O({verbose:e}),j[31]=O,j[32]=p):p=j[32];let H=L||void 0;return j[33]!==L?(h=L?(0,z.jsx)(lt,{}):null,j[33]=L,j[34]=h):h=j[34],j[35]!==H||j[36]!==h?(m=(0,z.jsx)("span",{className:"request-insights-settings-checkbox","data-checked":H,children:h}),j[35]=H,j[36]=h,j[37]=m):m=j[37],j[38]!==p||j[39]!==m||j[40]!==L?(g=(0,z.jsxs)(sq,{checked:L,className:"request-insights-settings-item",closeOnClick:!1,onCheckedChange:p,children:[m,"Verbose traces"]}),j[38]=p,j[39]=m,j[40]=L,j[41]=g):g=j[41],j[42]!==f||j[43]!==g?(v=(0,z.jsx)(id,{align:"end",className:"request-insights-settings-positioner",side:"bottom",sideOffset:4,children:(0,z.jsxs)(iS,{className:"request-insights-settings-menu",children:[f,g]})}),j[42]=f,j[43]=g,j[44]=v):v=j[44],j[45]!==N||j[46]!==v?(x=(0,z.jsxs)(oN,{delay:0,modal:!1,children:[d,(0,z.jsx)(aL,{container:N,children:v})]}),j[45]=N,j[46]=v,j[47]=x):x=j[47],j[48]!==u||j[49]!==x?(y=(0,z.jsxs)("div",{className:"request-insights-list-toolbar",children:[c,(0,z.jsxs)("div",{className:"request-insights-settings",children:[u,x]})]}),j[48]=u,j[49]=x,j[50]=y):y=j[50],j[51]!==$||j[52]!==M?(b=0===M.length?(0,z.jsx)("div",{className:"request-insights-list-empty",children:"Only internal activity has been captured. Enable “Internal activity” to view it."}):M.map(e=>{let{request:t,nested:r}=e,n=(0,sB.v)(t);return(0,z.jsx)(s8,{nested:r,request:t,pageLoad:"request"===(0,sB.o)(t)&&t.requestId===Z,selected:n===$,onSelect:()=>F(n)},n)}),j[51]=$,j[52]=M,j[53]=b):b=j[53],j[54]!==y||j[55]!==b?(w=(0,z.jsxs)("div",{className:"request-insights-list",children:[y,b]}),j[54]=y,j[55]=b,j[56]=w):w=j[56],j[57]!==U||j[58]!==L?(_=U&&(0,z.jsx)(lr,{request:U,verbose:L}),j[57]=U,j[58]=L,j[59]=_):_=j[59],j[60]!==w||j[61]!==_?(k=(0,z.jsxs)("div",{className:"request-insights-panel",children:[w,_]}),j[60]=w,j[61]=_,j[62]=k):k=j[62],k}function s6(e){return"error"===e.status}function s7(e){return sW(e)}function s9(e){return e.request}function s8(e){let t,r,n,o,a,i,s,l,c,u,d,f,p,h=(0,S.c)(42),{request:m,nested:g,pageLoad:v,selected:x,onSelect:y}=e;h[0]!==m?(t=(0,sB.o)(m),h[0]=m,h[1]=t):t=h[1];let b="instant-insights"===t,w=m.route??m.url??"Unknown route",_=b||void 0,k=g||void 0;h[2]!==m.status?(r=(0,z.jsx)("span",{className:"request-insights-status","data-status":m.status}),h[2]=m.status,h[3]=r):r=h[3],h[4]!==g?(n=g?(0,z.jsx)(le,{}):null,h[4]=g,h[5]=n):n=h[5],h[6]!==b||h[7]!==g?(o=b&&!g?(0,z.jsx)("span",{className:"request-insights-internal-badge",children:"Internal"}):null,h[6]=b,h[7]=g,h[8]=o):o=h[8];let j=b?"Instant Insights":w;h[9]!==j?(a=(0,z.jsx)("span",{className:"request-insights-route-label",children:j}),h[9]=j,h[10]=a):a=h[10],h[11]!==b||h[12]!==g||h[13]!==v||h[14]!==w?(i=b&&!g?(0,z.jsx)("span",{className:"request-insights-item-context",children:w}):v?(0,z.jsx)("span",{className:"request-insights-page-load",children:"Page load"}):null,h[11]=b,h[12]=g,h[13]=v,h[14]=w,h[15]=i):i=h[15],h[16]!==n||h[17]!==o||h[18]!==a||h[19]!==i?(s=(0,z.jsxs)("span",{className:"request-insights-route",children:[n,o,a,i]}),h[16]=n,h[17]=o,h[18]=a,h[19]=i,h[20]=s):s=h[20],h[21]!==m.durationMs?(l=sV(m.durationMs),h[21]=m.durationMs,h[22]=l):l=h[22],h[23]!==l?(c=(0,z.jsx)("span",{className:"request-insights-duration",children:l}),h[23]=l,h[24]=c):c=h[24],h[25]!==m.startTime?(u=new Date(m.startTime).toLocaleTimeString(void 0,{hour:"2-digit",minute:"2-digit",second:"2-digit"}),h[25]=m.startTime,h[26]=u):u=h[26],h[27]!==u?(d=(0,z.jsx)("span",{className:"request-insights-meta",children:u}),h[27]=u,h[28]=d):d=h[28];let C=m.fetches.length?`${m.fetches.length} fetch${1===m.fetches.length?"":"es"}`:"No fetches";return h[29]!==C?(f=(0,z.jsx)("span",{className:"request-insights-meta request-insights-fetch-summary",children:C}),h[29]=C,h[30]=f):f=h[30],h[31]!==y||h[32]!==v||h[33]!==x||h[34]!==s||h[35]!==c||h[36]!==d||h[37]!==f||h[38]!==_||h[39]!==k||h[40]!==r?(p=(0,z.jsxs)("button",{className:"request-insights-row","data-internal":_,"data-nested":k,"data-page-load":v,"data-selected":x,onClick:y,type:"button",children:[r,s,c,d,f]}),h[31]=y,h[32]=v,h[33]=x,h[34]=s,h[35]=c,h[36]=d,h[37]=f,h[38]=_,h[39]=k,h[40]=r,h[41]=p):p=h[41],p}function le(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{"aria-hidden":"true",className:"request-insights-nested-arrow",fill:"none",height:"12",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"1.5",viewBox:"0 0 16 16",width:"12",children:(0,z.jsx)("path",{d:"M4 3v5.5A2.5 2.5 0 0 0 6.5 11H12M12 11l-3-3m3 3-3 3"})}),t[0]=e):e=t[0],e}function lt(){let e,t=(0,S.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("svg",{"aria-hidden":"true",fill:"currentColor",height:"12",viewBox:"0 0 16 16",width:"12",children:(0,z.jsx)("path",{d:"M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"})}),t[0]=e):e=t[0],e}function lr(e){var t,r;let n,o,a,i,s,l,c,u,d,f,p,h,m,g,v,x,y,b,w,_,k,j,C,E,T,N=(0,S.c)(42),{request:I,verbose:R}=e;N[0]!==I||N[1]!==R?(f=function(e,t){let r=new Map;for(let t of e.spans){let e=s1(t);s0(t)&&void 0!==e&&r.set(e,t)}let n=new Set(e.fetches.map(e=>e.index).filter(e=>void 0!==e)),o=[];e.spans.forEach((e,t)=>{var r,a;let i,s=s1(e);s0(e)&&void 0!==s&&n.has(s)||o.push((r=e,a=t,i=r.attributes?.["next.span_type"],{id:`span:${r.spanId??a}:${r.startTime}`,spanId:r.spanId,parentSpanId:r.parentSpanId,spanType:"string"==typeof i?i:void 0,category:s2(r),label:function(e){let t=e.attributes?.["next.span_name"],r=("string"==typeof t&&t.trim().length>0?t:e.name).replace(sY,"HTML").replace(sX,"RSC");if("resolve segment modules"===r)return"resolve segment";if("build component tree"===r)return"build component tree";if(!r.includes(".")&&!/[a-z][A-Z]|[_-]/.test(r))return r;let n=r.slice(r.lastIndexOf(".")+1).replace(/([a-z0-9])([A-Z])/g,"$1 $2").replace(/([A-Z]+)([A-Z][a-z])/g,"$1 $2").replace(/[_-]+/g," ").trim().split(/\s+/).map(e=>sQ[e.toLowerCase()]??e.toLowerCase()).filter((e,t,r)=>"Node"!==e&&"web"!==e||"HTML"!==r[t+1]&&"RSC"!==r[t+1]);return"wait"===n[0]&&"for"!==n[1]&&n.splice(1,0,"for"),n.join(" ")}(r),startTime:r.startTime,durationMs:r.durationMs,status:r.status??"pending",kind:"span"}))}),e.fetches.forEach((e,t)=>{var n,a,i;let s,l=void 0===e.index?void 0:r.get(e.index),c=(n=e,a=t,i=l,void 0===(s=n.startTime??i?.startTime)?null:{id:`fetch:${i?.spanId??n.index??a}:${s}`,spanId:i?.spanId,parentSpanId:i?.parentSpanId,spanType:sG,category:i?s2(i):"application",label:`${n.method??"GET"} ${function(e){if(!e)return"Unknown URL";try{let t=new URL(e,"http://localhost");return`${t.pathname}${t.search}`}catch{return e}}(n.url)}`,startTime:s,durationMs:n.durationMs??i?.durationMs,status:n.statusCode&&n.statusCode>=400?"error":i?.status??"ok",kind:"fetch"});c&&o.push(c)});let a=function(e){let t=[...e].sort(sJ),r=new Map,n=new Map,o=[];for(let e of t)e.spanId&&!r.has(e.spanId)&&r.set(e.spanId,e);for(let e of t){let t=e.parentSpanId?r.get(e.parentSpanId):void 0;if(!t||t.id===e.id){o.push(e);continue}let a=n.get(t.id)??[];a.push(e),n.set(t.id,a)}let a=[],i=new Set;function s(e,t){if(!i.has(e.id))for(let r of(i.add(e.id),a.push({...e,depth:t}),n.get(e.id)??[]))s(r,t+1)}for(let e of o)s(e,0);for(let e of t)s(e,0);return a}(o);return t?a:function(e){let t=new Map,r=new Map,n=[];for(let r of e)r.spanId&&t.set(r.spanId,r);for(let a of e){var o;if(!(void 0===(o=a).spanType||"error"===o.status||sK.has(o.spanType)))continue;let e=0,i=a.parentSpanId?t.get(a.parentSpanId):void 0,s=new Set;for(;i&&!s.has(i.id);){s.add(i.id);let n=i.spanId?r.get(i.spanId):void 0;if(void 0!==n){e=n+1;break}i=i.parentSpanId?t.get(i.parentSpanId):void 0}let l={...a,depth:e};n.push(l),l.spanId&&r.set(l.spanId,e)}return n}(a)}(I,R),N[0]=I,N[1]=R,N[2]=f):f=N[2];let P=f;N[3]!==I?(t=I,a=(o="instant-insights"===(0,sB.o)(t))?void 0:function(e,t){for(let r of e.spans){let e=r.attributes?.[t];if("string"==typeof e)return e}}(t,"http.method")??(r=t.spans[0]?.name,n=r?.match(/^(?:RSC )?(GET|HEAD|POST|PUT|PATCH|DELETE|OPTIONS)\b/),n?.[1])??"GET",i=function(e,t){for(let r of e.spans){let e=r.attributes?.[t];if("number"==typeof e)return e}}(t,"http.status_code"),s=function(e,t){for(let r of e.spans){let e=r.attributes?.[t];if("boolean"==typeof e)return e}}(t,"next.rsc"),c=(l=t.spans.find(e=>"error"===e.status||e.error))?`${l.name}: ${l.error?.message??l.error?.type??"error"}`:void 0,d=(u=t.fetches.reduce((e,t)=>("hit"===t.cacheStatus?e.hit+=1:"miss"===t.cacheStatus?e.miss+=1:"skip"===t.cacheStatus?e.skip+=1:e.unknown+=1,e),{hit:0,miss:0,skip:0,unknown:0})).hit+u.miss+u.skip,p={method:a,statusCode:i,statusLabel:i??t.status,kind:o?"Instant Insights":s?"RSC request":"HTML request",fetchSummary:t.fetches.length?`${t.fetches.length} fetch${1===t.fetches.length?"":"es"}`:"No fetches",cacheSummary:0===t.fetches.length?"No cache data":0===d?"Cache status unknown":`Cache ${u.hit} hit, ${u.miss} miss, ${u.skip} skip${u.unknown?`, ${u.unknown} unknown`:""}`,spanSummary:`${t.spans.length} span${1===t.spans.length?"":"s"}`,errorSummary:c},N[3]=I,N[4]=p):p=N[4];let L=p;N[5]!==I||N[6]!==P?(h=function(e,t){let r=t.filter(e=>e.depth>0),n=(r.length>0?r:t).reduce((e,t)=>!e||(t.durationMs??0)>(e.durationMs??0)?t:e,null),o=e.fetches.reduce((e,t)=>!e||(t.durationMs??0)>(e.durationMs??0)?t:e,null);if(o&&(!n||(o.durationMs??0)>=(n.durationMs??0))){let e=ls(o.url);return`Slowest recorded operation: ${e.path} \xb7 ${sV(o.durationMs)}${function(e){if(!e.cacheStatus)return"";let t=e.cacheReason?`, ${e.cacheReason}`:"";return` (${e.cacheStatus}${t})`}(o)}.`}return n?`Slowest recorded operation: ${n.label} \xb7 ${sV(n.durationMs)}.`:"No slow server work was captured for this request."}(I,P),N[5]=I,N[6]=P,N[7]=h):h=N[7];let O=h,M="instant-insights"===(0,sB.o)(I)?`Instant Insights \xb7 ${I.route??I.url??I.requestId}`:I.route??I.url??I.requestId;return N[8]!==M?(m=(0,z.jsx)("div",{className:"request-insights-title",children:M}),N[8]=M,N[9]=m):m=N[9],N[10]!==I?(g=JSON.stringify(I,null,2),N[10]=I,N[11]=g):g=N[11],N[12]!==g?(v=(0,z.jsx)(ei.i8,{actionLabel:"Copy request JSON",className:"request-insights-copy",content:g,successLabel:"Copied request JSON"}),N[12]=g,N[13]=v):v=N[13],N[14]!==m||N[15]!==v?(x=(0,z.jsx)("div",{className:"request-insights-heading",children:(0,z.jsxs)("div",{className:"request-insights-title-row",children:[m,v]})}),N[14]=m,N[15]=v,N[16]=x):x=N[16],N[17]!==I.durationMs?(y=sV(I.durationMs),N[17]=I.durationMs,N[18]=y):y=N[18],N[19]!==y?(b=(0,z.jsx)("div",{className:"request-insights-total",children:y}),N[19]=y,N[20]=b):b=N[20],N[21]!==b||N[22]!==x?(w=(0,z.jsxs)("div",{className:"request-insights-summary",children:[x,b]}),N[21]=b,N[22]=x,N[23]=w):w=N[23],N[24]!==L?(_=(0,z.jsx)(ln,{overview:L}),N[24]=L,N[25]=_):_=N[25],N[26]!==L.errorSummary?(k=L.errorSummary?(0,z.jsx)("div",{className:"request-insights-error",children:L.errorSummary}):null,N[26]=L.errorSummary,N[27]=k):k=N[27],N[28]!==O?(j=(0,z.jsx)("div",{className:"request-insights-diagnosis",children:O}),N[28]=O,N[29]=j):j=N[29],N[30]!==I||N[31]!==P?(C=(0,z.jsx)(lo,{items:P,request:I}),N[30]=I,N[31]=P,N[32]=C):C=N[32],N[33]!==I.fetches?(E=(0,z.jsx)(la,{fetches:I.fetches}),N[33]=I.fetches,N[34]=E):E=N[34],N[35]!==w||N[36]!==_||N[37]!==k||N[38]!==j||N[39]!==C||N[40]!==E?(T=(0,z.jsxs)("div",{className:"request-insights-details",children:[w,_,k,j,C,E]}),N[35]=w,N[36]=_,N[37]=k,N[38]=j,N[39]=C,N[40]=E,N[41]=T):T=N[41],T}function ln(e){let t,r,n,o,a,i,s,l=(0,S.c)(19),{overview:c}=e;return l[0]!==c.method?(t=c.method?(0,z.jsxs)("span",{children:["Method ",c.method]}):null,l[0]=c.method,l[1]=t):t=l[1],l[2]!==c.statusLabel?(r=(0,z.jsxs)("span",{children:["Status ",c.statusLabel]}),l[2]=c.statusLabel,l[3]=r):r=l[3],l[4]!==c.kind?(n=(0,z.jsx)("span",{children:c.kind}),l[4]=c.kind,l[5]=n):n=l[5],l[6]!==c.fetchSummary?(o=(0,z.jsx)("span",{children:c.fetchSummary}),l[6]=c.fetchSummary,l[7]=o):o=l[7],l[8]!==c.cacheSummary?(a=(0,z.jsx)("span",{children:c.cacheSummary}),l[8]=c.cacheSummary,l[9]=a):a=l[9],l[10]!==c.spanSummary?(i=(0,z.jsx)("span",{children:c.spanSummary}),l[10]=c.spanSummary,l[11]=i):i=l[11],l[12]!==t||l[13]!==r||l[14]!==n||l[15]!==o||l[16]!==a||l[17]!==i?(s=(0,z.jsxs)("div",{className:"request-insights-overview",children:[t,r,n,o,a,i]}),l[12]=t,l[13]=r,l[14]=n,l[15]=o,l[16]=a,l[17]=i,l[18]=s):s=l[18],s}function lo(e){let t,r,n,o,a,i,s,l,c,u,d,f=(0,S.c)(30),{request:p,items:h}=e;if(f[0]!==h||f[1]!==p){let e,l,c,u,d={startTime:p.startTime,durationMs:Math.max(p.durationMs??0,.1)},m=Array.from({length:5},(e,t)=>{let r=t/4;return{label:sV(d.durationMs*r),position:100*r}});i="request-insights-section",f[9]===Symbol.for("react.memo_cache_sentinel")?(e=(0,z.jsx)("div",{className:"request-insights-section-title",children:"Trace"}),f[9]=e):e=f[9],s=(0,z.jsxs)("div",{className:"request-insights-section-heading",children:[e,(0,z.jsxs)("div",{className:"request-insights-section-note",children:[h.length," span",1===h.length?"":"s"," \xb7"," ",sV(d.durationMs)]})]}),a="request-insights-trace-viewport",n="request-insights-trace",f[10]===Symbol.for("react.memo_cache_sentinel")?(l=(0,z.jsx)("span",{children:"Span"}),f[10]=l):l=f[10],f[11]!==m?(c=(0,z.jsx)("span",{className:"request-insights-trace-axis",children:m.map((e,t)=>(0,z.jsx)("span",{className:"request-insights-trace-tick","data-edge":0===t?"start":t===m.length-1?"end":void 0,style:{left:`${e.position}%`},children:e.label},e.position))}),f[11]=m,f[12]=c):c=f[12],f[13]===Symbol.for("react.memo_cache_sentinel")?(u=(0,z.jsx)("span",{className:"request-insights-trace-duration-heading",children:"Duration"}),f[13]=u):u=f[13],f[14]!==c?(o=(0,z.jsxs)("div",{className:"request-insights-trace-header",children:[l,c,u]}),f[14]=c,f[15]=o):o=f[15],t="request-insights-trace-rows",r=h.map(e=>{let t,r,n,o,a,i,s=(t=d.startTime+d.durationMs,r=Math.max(e.startTime,d.startTime),n=Math.min(e.startTime+(e.durationMs??0),t),a=Math.min((o=Math.min(Math.max(r-d.startTime,0),d.durationMs))/d.durationMs*100,100),i=Math.min(Math.max((n-r)/d.durationMs*100,0),100-a),{left:a,width:i,offsetMs:o});return(0,z.jsxs)("div",{className:"request-insights-span-row","data-kind":e.kind,title:`${e.label} \xb7 +${sV(s.offsetMs)} \xb7 ${sV(e.durationMs)}`,children:[(0,z.jsx)("span",{className:"request-insights-span-name",style:{paddingLeft:`${14*e.depth+4}px`},children:(0,z.jsxs)("span",{className:"request-insights-span-label",children:[(0,z.jsx)("span",{className:"request-insights-span-marker","data-kind":e.kind,"data-status":e.status}),(0,z.jsx)("span",{children:e.label})]})}),(0,z.jsx)("span",{className:"request-insights-span-track",children:(0,z.jsx)("span",{className:"request-insights-span-bar","data-status":e.status,style:{left:`${s.left}%`,width:`${s.width}%`}})}),(0,z.jsx)("span",{className:"request-insights-span-duration",children:sV(e.durationMs)})]},e.id)}),f[0]=h,f[1]=p,f[2]=t,f[3]=r,f[4]=n,f[5]=o,f[6]=a,f[7]=i,f[8]=s}else t=f[2],r=f[3],n=f[4],o=f[5],a=f[6],i=f[7],s=f[8];return f[16]!==t||f[17]!==r?(l=(0,z.jsx)("div",{className:t,children:r}),f[16]=t,f[17]=r,f[18]=l):l=f[18],f[19]!==n||f[20]!==o||f[21]!==l?(c=(0,z.jsxs)("div",{className:n,children:[o,l]}),f[19]=n,f[20]=o,f[21]=l,f[22]=c):c=f[22],f[23]!==a||f[24]!==c?(u=(0,z.jsx)("div",{className:a,children:c}),f[23]=a,f[24]=c,f[25]=u):u=f[25],f[26]!==u||f[27]!==i||f[28]!==s?(d=(0,z.jsxs)("div",{className:i,children:[s,u]}),f[26]=u,f[27]=i,f[28]=s,f[29]=d):d=f[29],d}function la(e){let t,r,n=(0,S.c)(3),{fetches:o}=e;return n[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("div",{className:"request-insights-section-title",children:"Fetches"}),n[0]=t):t=n[0],n[1]!==o?(r=(0,z.jsxs)("div",{className:"request-insights-section",children:[t,0===o.length?(0,z.jsx)("div",{className:"request-insights-muted",children:"No server fetches captured."}):(0,z.jsxs)("div",{className:"request-insights-fetch-table",children:[(0,z.jsxs)("div",{className:"request-insights-fetch request-insights-fetch-header",children:[(0,z.jsx)("span",{children:"Method"}),(0,z.jsx)("span",{children:"URL"}),(0,z.jsx)("span",{children:"Duration"}),(0,z.jsx)("span",{children:"Status"}),(0,z.jsx)("span",{children:"Cache"}),(0,z.jsx)("span",{children:"Reason"})]}),o.map(li)]})]}),n[1]=o,n[2]=r):r=n[2],r}function li(e,t){let r=ls(e.url);return(0,z.jsxs)("div",{className:"request-insights-fetch",children:[(0,z.jsx)("span",{className:"request-insights-method",children:e.method??"GET"}),(0,z.jsxs)("span",{className:"request-insights-fetch-url",children:[(0,z.jsx)("span",{children:r.path}),r.host?(0,z.jsx)("span",{className:"request-insights-fetch-host",children:r.host}):null]}),(0,z.jsx)("span",{children:sV(e.durationMs)}),(0,z.jsx)("span",{children:e.statusCode??"-"}),(0,z.jsx)("span",{children:e.cacheStatus??"unknown"}),(0,z.jsx)("span",{className:"request-insights-cache-reason",children:e.cacheReason??"-"})]},t)}function ls(e){if(!e)return{path:"Unknown URL"};try{let t=new URL(e,window.location.origin),r=`${t.pathname}${t.search}`,n=t.host===window.location.host;return{path:r,host:n?void 0:t.host}}catch{return{path:e}}}s5.styleTagTransform=b(),s5.setAttributes=g(),s5.insert=h(),s5.domAPI=f(),s5.insertStyleElement=x(),u()(s3.A,s5),s3.A&&s3.A.locals&&s3.A.locals;var ll=r("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.7_patch_hash=4cf28ea116b0e27c7c80b09035905f9d16a7b18d_067c284db30b31cbdc6daa7c0d971600/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/menu/panel-router.css"),lc={};function lu(e){let t,r,n,o,a=(0,S.c)(5);return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("p",{className:"dev-tools-info-paragraph",children:"While loading this page, all caches were bypassed."}),r=(0,z.jsx)("p",{className:"dev-tools-info-paragraph",children:"This is the case when the cache was disabled in the browser's devtools, the page was hard-reloaded, or draft mode is enabled."}),n=(0,z.jsx)("p",{className:"dev-tools-info-paragraph",children:"As a result, the loading experience might not be the same as in production. React's DevTools will also not accurately show information about what would normally suspend in the page, and Next.js cannot validate whether a navigation to this page would be instant or blocking."}),a[0]=t,a[1]=r,a[2]=n):(t=a[0],r=a[1],n=a[2]),a[3]!==e?(o=(0,z.jsxs)("article",{className:"dev-tools-info-article",...e,children:[t,r,n]}),a[3]=e,a[4]=o):o=a[4],o}function ld(e){let t,r,n,o,a=(0,S.c)(5);return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,z.jsx)("p",{className:"dev-tools-info-paragraph",children:"While loading this page, one or more caches were empty and had to be filled while the response was streaming."}),r=(0,z.jsx)("p",{className:"dev-tools-info-paragraph",children:"This happens on the first render after a cache is cleared, for example after a server restart, a revalidation, or an entry expiring, i.e. the request that fills the cache."}),n=(0,z.jsx)("p",{className:"dev-tools-info-paragraph",children:"As a result, this load isn't representative of production: cached content streamed in as it was computed instead of being served instantly, and React's DevTools won't accurately show what would normally suspend in the page. Reload the page, now that the caches are warm, to see the production-like loading sequence."}),a[0]=t,a[1]=r,a[2]=n):(t=a[0],r=a[1],n=a[2]),a[3]!==e?(o=(0,z.jsxs)("article",{className:"dev-tools-info-article",...e,children:[t,r,n]}),a[3]=e,a[4]=o):o=a[4],o}lc.styleTagTransform=b(),lc.setAttributes=g(),lc.insert=h(),lc.domAPI=f(),lc.insertStyleElement=x(),u()(ll.A,lc),ll.A&&ll.A.locals&&ll.A.locals;let lf=()=>{let e,t,r,n,o,a,i,s,l,c,u,d,f,p,h,m,g=(0,S.c)(55),{setPanel:v,setSelectedIndex:x}=e8(),{state:y,dispatch:b}=(0,P.OS)(),{normalErrorCount:w,instantErrorCount:_}=lw(),k="app"===y.routerType;g[0]!==_||g[1]!==w?(e=te(w,_),g[0]=_,g[1]=w,g[2]=e):e=g[2];let{hasNormal:j,hasInstant:C,hasAny:E}=e;g[3]!==C||g[4]!==j||g[5]!==_||g[6]!==w?(t=[],j&&t.push(`${w} ${1===w?"issue":"issues"}`),C&&t.push(`${_} ${1===_?"insight":"insights"}`),g[3]=C,g[4]=j,g[5]=_,g[6]=w,g[7]=t):t=g[7];let T=j&&C?"Issues \xb7 Insights":C?"Insights":"Issues";return g[8]!==b||g[9]!==E||g[10]!==C||g[11]!==j||g[12]!==_||g[13]!==T||g[14]!==w||g[15]!==v||g[16]!==x||g[17]!==y.isErrorOverlayOpen||g[18]!==t?(r=E&&{title:`${t.join(" \xb7 ")} found. Click to view details in the dev overlay.`,label:T,value:(0,z.jsxs)("span",{className:"dev-tools-indicator-issue-counts",children:[j&&(0,z.jsx)(tC,{variant:"issue",children:w}),C&&(0,z.jsx)(tC,{variant:"insight",children:_})]}),onClick:()=>{if(y.isErrorOverlayOpen){b({type:eu.kO}),v(null);return}v(null),x(-1),b({type:eu.Wv})}},g[8]=b,g[9]=E,g[10]=C,g[11]=j,g[12]=_,g[13]=T,g[14]=w,g[15]=v,g[16]=x,g[17]=y.isErrorOverlayOpen,g[18]=t,g[19]=r):r=g[19],g[20]!==v||g[21]!==y.staticIndicator?(n="disabled"===y.staticIndicator?void 0:"pending"===y.staticIndicator?{title:"Loading...",label:"Route",value:(0,z.jsx)(sx,{})}:{title:`Current route is ${y.staticIndicator}.`,label:"Route",value:"static"===y.staticIndicator?"Static":"Dynamic",onClick:()=>v("route-type"),attributes:{"data-nextjs-route-type":y.staticIndicator}},g[20]=v,g[21]=y.staticIndicator,g[22]=n):n=g[22],g[23]===Symbol.for("react.memo_cache_sentinel")?(o=process.env.TURBOPACK?{title:"Turbopack is enabled.",label:"Bundler",value:"Turbopack"}:{title:"Learn about Turbopack and how to enable it in your application.",label:"Bundler",value:(0,z.jsx)("a",{href:"https://nextjs.org/docs/app/api-reference/config/next-config-js/turbopack",target:"_blank",rel:"noreferrer noopener",className:"turbopack-upgrade-link",children:process.env.__NEXT_BUNDLER||"Turbopack"})},a=!!process.env.__NEXT_CACHE_COMPONENTS&&{title:"Cache Components is enabled.",label:"Cache Components",value:"Enabled"},g[23]=o,g[24]=a):(o=g[23],a=g[24]),g[25]!==k||g[26]!==v?(i=k&&!!process.env.__NEXT_INSTANT_NAV_TOGGLE&&{title:"Test instant navigation behavior.",label:"Navigation Inspector",value:(0,z.jsx)(tE,{}),onClick:()=>{v("instant-navs")},attributes:{"data-instant-nav":!0}},g[25]=k,g[26]=v,g[27]=i):i=g[27],g[28]!==k||g[29]!==v?(s=k&&!!process.env.__NEXT_REQUEST_INSIGHTS&&{title:"Inspect recent App Router requests.",label:"Request Insights",value:(0,z.jsx)(tE,{}),onClick:()=>{v("request-insights")},attributes:{"data-request-insights":!0}},g[28]=k,g[29]=v,g[30]=s):s=g[30],g[31]!==v||g[32]!==y.cacheIndicator?(l="bypass"===y.cacheIndicator&&{title:"Caching is currently disabled (bypassed). Click to learn more.",label:"Cache",value:"Disabled",onClick:()=>v("cache-disabled"),attributes:{"data-cache-disabled":!0}},g[31]=v,g[32]=y.cacheIndicator,g[33]=l):l=g[33],g[34]!==v||g[35]!==y.cacheIndicator?(c="cold"===y.cacheIndicator&&{title:"This load filled one or more caches while streaming, so it is not representative of production. Click to learn more.",label:"Cache",value:"Cold",onClick:()=>v("cold-cache"),attributes:{"data-cold-cache":!0}},g[34]=v,g[35]=y.cacheIndicator,g[36]=c):c=g[36],g[37]!==k||g[38]!==v?(u=k&&{label:"Route Info",value:(0,z.jsx)(tE,{}),onClick:()=>v("segment-explorer"),attributes:{"data-segment-explorer":!0}},g[37]=k,g[38]=v,g[39]=u):u=g[39],g[40]===Symbol.for("react.memo_cache_sentinel")?(d=(0,z.jsx)(sv,{}),g[40]=d):d=g[40],g[41]!==v?(f=()=>v("preferences"),g[41]=v,g[42]=f):f=g[42],g[43]===Symbol.for("react.memo_cache_sentinel")?(p={"data-preferences":!0},g[43]=p):p=g[43],g[44]!==f?(h={label:"Preferences",value:d,onClick:f,footer:!0,attributes:p},g[44]=f,g[45]=h):h=g[45],g[46]!==r||g[47]!==h||g[48]!==n||g[49]!==i||g[50]!==s||g[51]!==l||g[52]!==c||g[53]!==u?(m=(0,z.jsx)(tj,{items:[r,n,o,a,i,s,l,c,u,h]}),g[46]=r,g[47]=h,g[48]=n,g[49]=i,g[50]=s,g[51]=l,g[52]=c,g[53]=u,g[54]=m):m=g[54],m},lp=()=>{var e;let t,r,n,o,a,i,s,l,c,u,d,f,p,h,m,g,v,x,y,b=(0,S.c)(44),{state:w}=(0,P.OS)(),{triggerRef:_,setPanel:k}=e8(),j=(()=>{let e,t=(0,S.c)(4),{state:r,dispatch:n,shadowRoot:o}=(0,P.OS)();return t[0]!==n||t[1]!==o||t[2]!==r.disableDevIndicator?(e=()=>{n({type:eu.s2,disabled:!r.disableDevIndicator});let e=o.getElementById("panel-route"),t=o.getElementById("data-devtools-indicator");if(e&&e.firstElementChild){let t=e.firstElementChild,r="none"===t.style.display;t.style.display=r?"":"none"}if(t){let e="none"===t.style.display;t.style.display=e?"":"none"}},t[0]=n,t[1]=o,t[2]=r.disableDevIndicator,t[3]=e):e=t[3],e})(),C="app"===w.routerType,T=(0,E.useRef)(!1);b[0]!==w.isErrorOverlayOpen?(t=()=>{if(w.isErrorOverlayOpen){T.current=!0;return}let e=setTimeout(()=>{T.current=!1});return()=>clearTimeout(e)},r=[w.isErrorOverlayOpen],b[0]=w.isErrorOverlayOpen,b[1]=t,b[2]=r):(t=b[1],r=b[2]),(0,E.useEffect)(t,r),b[3]!==k?(n=e=>{"outside"===e||"escape"===e&&T.current||k("panel-selector")},b[3]=k,b[4]=n):n=b[4];let N=n;b[5]!==w.hideShortcut||b[6]!==j?(o=w.hideShortcut?{[w.hideShortcut]:j}:{},b[5]=w.hideShortcut,b[6]=j,b[7]=o):o=b[7],e=o,(y=(0,S.c)(4))[0]!==_||y[1]!==e?(v=()=>{let t=function(t){var r;let n;if(r=_,(n=(0,tu.bq)(r.current))&&("true"===n.contentEditable||"INPUT"===n.tagName||"TEXTAREA"===n.tagName||"SELECT"===n.tagName||"true"===n.dataset["shortcut-recorder"])&&!n.hasAttribute("readonly"))return;let o=[];t.metaKey&&o.push("Meta"),t.ctrlKey&&o.push("Control"),t.altKey&&o.push("Alt"),t.shiftKey&&o.push("Shift"),"Meta"!==t.key&&"Control"!==t.key&&"Alt"!==t.key&&"Shift"!==t.key&&o.push(t.code);let a=o.join("+");e[a]&&(t.preventDefault(),e[a]())};return window.addEventListener("keydown",t),()=>window.removeEventListener("keydown",t)},x=[_,e],y[0]=_,y[1]=e,y[2]=v,y[3]=x):(v=y[2],x=y[3]),(0,E.useEffect)(v,x),b[8]===Symbol.for("react.memo_cache_sentinel")?(a=(0,z.jsx)(lx,{name:"panel-selector",children:(0,z.jsx)(lf,{})}),b[8]=a):a=b[8];let I=500/w.scale;return b[9]!==I?(i={kind:"fixed",height:I,width:512},b[9]=I,b[10]=i):i=b[10],b[11]===Symbol.for("react.memo_cache_sentinel")?(s=(0,z.jsx)(sm,{title:"Preferences"}),l=(0,z.jsx)(lm,{}),b[11]=s,b[12]=l):(s=b[11],l=b[12]),b[13]!==i?(c=(0,z.jsx)(lx,{name:"preferences",children:(0,z.jsx)(tq,{sharePanelSizeGlobally:!1,sizeConfig:i,closeOnClickOutside:!0,header:s,children:l})}),b[13]=i,b[14]=c):c=b[14],b[15]!==w.routerType||b[16]!==w.scale||b[17]!==w.staticIndicator?(u="disabled"!==w.staticIndicator&&"pending"!==w.staticIndicator&&(0,z.jsx)(lx,{name:"route-type",children:(0,z.jsx)(tq,{sharePanelSizeGlobally:!1,sizeConfig:{kind:"fixed",height:"static"===w.staticIndicator?300/w.scale:325/w.scale,width:400/w.scale},closeOnClickOutside:!0,header:(0,z.jsx)(sm,{title:`${"static"===w.staticIndicator?"Static":"Dynamic"} Route`}),children:(0,z.jsxs)("div",{className:"panel-content",children:[(0,z.jsx)(tW,{routerType:w.routerType,isStaticRoute:"static"===w.staticIndicator}),(0,z.jsx)(lh,{href:tH[w.routerType][w.staticIndicator]})]})},w.staticIndicator)}),b[15]=w.routerType,b[16]=w.scale,b[17]=w.staticIndicator,b[18]=u):u=b[18],b[19]!==C||b[20]!==w.page||b[21]!==w.scale?(d=C&&(0,z.jsx)(lx,{name:"segment-explorer",children:(0,z.jsx)(tq,{sharePanelSizeGlobally:!1,sharePanelPositionGlobally:!1,draggable:!0,sizeConfig:{kind:"resizable",maxHeight:"90vh",maxWidth:"90vw",minHeight:200/w.scale,minWidth:250/w.scale,initialSize:{height:375/w.scale,width:400/w.scale}},header:(0,z.jsx)(sm,{title:"Route Info"}),children:(0,z.jsx)(sl,{page:w.page})})}),b[19]=C,b[20]=w.page,b[21]=w.scale,b[22]=d):d=b[22],b[23]!==N||b[24]!==C||b[25]!==w.scale?(f=C&&!!process.env.__NEXT_INSTANT_NAV_TOGGLE&&(0,z.jsx)(lx,{name:"instant-navs",children:(0,z.jsx)(tq,{sharePanelSizeGlobally:!1,sharePanelPositionGlobally:!1,draggable:!0,keepBehindErrorOverlay:!0,onClose:N,sizeConfig:{kind:"auto",width:460/w.scale},header:(0,z.jsx)(sm,{title:"Navigation Inspector",onClose:()=>N()}),children:(0,z.jsx)(sP,{})})}),b[23]=N,b[24]=C,b[25]=w.scale,b[26]=f):f=b[26],b[27]!==C||b[28]!==w.scale?(p=C&&!!process.env.__NEXT_REQUEST_INSIGHTS&&(0,z.jsx)(lx,{name:"request-insights",children:(0,z.jsx)(tq,{sharePanelSizeGlobally:!1,sharePanelPositionGlobally:!1,draggable:!0,sizeConfig:{kind:"resizable",maxHeight:"90vh",maxWidth:"90vw",minHeight:260/w.scale,minWidth:`min(${560/w.scale}px, 90vw)`,initialSize:{height:440/w.scale,width:760/w.scale}},header:(0,z.jsx)(sm,{title:"Request Insights"}),children:(0,z.jsx)(s4,{})})}),b[27]=C,b[28]=w.scale,b[29]=p):p=b[29],b[30]!==w.cacheIndicator||b[31]!==w.scale?(h="bypass"===w.cacheIndicator&&(0,z.jsx)(lx,{name:"cache-disabled",children:(0,z.jsx)(tq,{sharePanelSizeGlobally:!1,sizeConfig:{kind:"fixed",height:340/w.scale,width:480/w.scale},closeOnClickOutside:!0,header:(0,z.jsx)(sm,{title:"Cache disabled"}),children:(0,z.jsx)("div",{className:"panel-content",children:(0,z.jsx)(lu,{})})})}),b[30]=w.cacheIndicator,b[31]=w.scale,b[32]=h):h=b[32],b[33]!==w.cacheIndicator||b[34]!==w.scale?(m="cold"===w.cacheIndicator&&(0,z.jsx)(lx,{name:"cold-cache",children:(0,z.jsx)(tq,{sharePanelSizeGlobally:!1,sizeConfig:{kind:"fixed",height:400/w.scale,width:480/w.scale},closeOnClickOutside:!0,header:(0,z.jsx)(sm,{title:"Cold cache"}),children:(0,z.jsx)("div",{className:"panel-content",children:(0,z.jsx)(ld,{})})})}),b[33]=w.cacheIndicator,b[34]=w.scale,b[35]=m):m=b[35],b[36]!==u||b[37]!==d||b[38]!==f||b[39]!==p||b[40]!==h||b[41]!==m||b[42]!==c?(g=(0,z.jsxs)(z.Fragment,{children:[a,c,u,d,f,p,h,m]}),b[36]=u,b[37]=d,b[38]=f,b[39]=p,b[40]=h,b[41]=m,b[42]=c,b[43]=g):g=b[43],g},lh=e=>{let t,r=(0,S.c)(2),{href:n}=e;return r[0]!==n?(t=(0,z.jsx)("div",{className:"dev-tools-info-button-container",children:(0,z.jsx)("a",{className:"dev-tools-info-learn-more-button",href:n,target:"_blank",rel:"noreferrer noopener",children:"Learn More"})}),r[0]=n,r[1]=t):t=r[1],t},lm=()=>{let e,t,r,n,o=(0,S.c)(17),{dispatch:a,state:i}=(0,P.OS)(),{setPanel:s,setSelectedIndex:l}=e8(),c=tb();return o[0]!==a?(e=e=>{a({type:eu.xZ,scale:e})},o[0]=a,o[1]=e):e=o[1],o[2]!==a||o[3]!==c?(t=e=>{a({type:eu.Gu,devToolsPosition:e}),c(e)},o[2]=a,o[3]=c,o[4]=t):t=o[4],o[5]!==a||o[6]!==s||o[7]!==l?(r=()=>{a({type:eu.s2,disabled:!0}),l(-1),s(null),fetch("/__nextjs_disable_dev_indicator",{method:"POST"})},o[5]=a,o[6]=s,o[7]=l,o[8]=r):r=o[8],o[9]!==i.devToolsPosition||o[10]!==i.hideShortcut||o[11]!==i.scale||o[12]!==i.theme||o[13]!==e||o[14]!==t||o[15]!==r?(n=(0,z.jsx)("div",{className:"user-preferences-wrapper",children:(0,z.jsx)(ez,{theme:i.theme,position:i.devToolsPosition,scale:i.scale,setScale:e,setPosition:t,hideShortcut:i.hideShortcut,setHideShortcut:ly,hide:r})}),o[9]=i.devToolsPosition,o[10]=i.hideShortcut,o[11]=i.scale,o[12]=i.theme,o[13]=e,o[14]=t,o[15]=r,o[16]=n):n=o[16],n},lg=()=>(0,E.useContext)(lv),lv=(0,E.createContext)(null);function lx(e){let t,r,n,o,a,i=(0,S.c)(12),{children:s,name:l}=e,{panel:c}=e8();i[0]===Symbol.for("react.memo_cache_sentinel")?(t={enterDelay:0,exitDelay:tu.ay},i[0]=t):t=i[0];let{mounted:u,rendered:d}=eU(l===c,t);if(!u)return null;i[1]!==u||i[2]!==l?(r={name:l,mounted:u},i[1]=u,i[2]=l,i[3]=r):r=i[3];let f=+!!d;i[4]!==f?(n={"--panel-opacity":f,"--panel-transition":`opacity ${tu.ay}ms ${tu.OB}`},i[4]=f,i[5]=n):n=i[5];let p=n;return i[6]!==s||i[7]!==p?(o=(0,z.jsx)("div",{id:"panel-route",className:"panel-route",style:p,children:s}),i[6]=s,i[7]=p,i[8]=o):o=i[8],i[9]!==r||i[10]!==o?(a=(0,z.jsx)(lv,{value:r,children:o}),i[9]=r,i[10]=o,i[11]=a):a=i[11],a}function ly(e){eI({hideShortcut:e})}let lb=(0,E.createContext)(null),lw=()=>(0,E.useContext)(lb);function l_(){var e;let t,r,n,o,a,i,s,l,c,u=(0,S.c)(13),[d,f]=(0,E.useState)(-1),{state:p,dispatch:h,getSquashedHydrationErrorDetails:m}=(0,P.OS)();u[0]!==p.instantNavs?(t=()=>p.instantNavs?"instant-navs":null,u[0]=p.instantNavs,u[1]=t):t=u[1];let[g,v]=(0,E.useState)(t);e=p.page,l=(0,S.c)(4),c=(0,E.useRef)(null),l[0]!==h||l[1]!==e?(i=()=>{if(""!==e){if(null===c.current){c.current=e;return}e!==c.current&&(c.current=e,h({type:eu.Vv,currentPath:e}))}},s=[e,h],l[0]=h,l[1]=e,l[2]=i,l[3]=s):(i=l[2],s=l[3]),(0,E.useEffect)(i,s);let x=(0,E.useRef)(null);return u[2]===Symbol.for("react.memo_cache_sentinel")?(r=(0,z.jsx)(eY,{}),n=(0,z.jsx)(e$,{}),u[2]=r,u[3]=n):(r=u[2],n=u[3]),u[4]!==h||u[5]!==m||u[6]!==g||u[7]!==d||u[8]!==p?(o=e=>{let{runtimeErrors:t,totalErrorCount:r,normalErrorCount:n,instantErrorCount:o}=e;return(0,z.jsx)(z.Fragment,{children:p.showIndicator?(0,z.jsx)(z.Fragment,{children:(0,z.jsx)(lb,{value:{runtimeErrors:t,totalErrorCount:r+ +!!p.hasVulnerabilityInsight,normalErrorCount:n,instantErrorCount:o+ +!!p.hasVulnerabilityInsight},children:(0,z.jsxs)(e9,{value:{panel:g,setPanel:v,triggerRef:x,selectedIndex:d,setSelectedIndex:f},children:[(0,z.jsx)(eZ,{state:p,dispatch:h,getSquashedHydrationErrorDetails:m,runtimeErrors:t,errorCount:r}),(0,z.jsx)(lp,{}),(0,z.jsx)(ty,{})]})})}):null})},u[4]=h,u[5]=m,u[6]=g,u[7]=d,u[8]=p,u[9]=o):o=u[9],u[10]!==p||u[11]!==o?(a=(0,z.jsxs)(L,{children:[r,n,(0,z.jsx)(eH,{state:p,isAppDir:!0,children:o})]}),u[10]=p,u[11]=o,u[12]=a):a=u[12],a}},"./src/next-devtools/dev-overlay.browser.tsx"(e,t,r){"use strict";r.d(t,{qs:()=>p,iw:()=>m,pj:()=>_,yl:()=>T,Z8:()=>E,oh:()=>y,hu:()=>g,OS:()=>k,ac:()=>v});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/shared/lib/error-source.ts"),i=r("./src/next-devtools/dev-overlay/shared.ts"),s=r("./dist/compiled/react/index.js"),l=r("./dist/compiled/react-dom/client.js"),c=r("./src/next-devtools/dev-overlay/segment-explorer-trie.ts");let u=new class{dispatch=null;queue=[];enqueue(e){this.dispatch?e(this.dispatch):this.queue.push(e)}connect(e){try{for(let t=0;t<this.queue.length;t++)this.queue[t](e)}finally{this.queue.length=0,this.dispatch=e}}disconnect(e){this.dispatch===e&&(this.dispatch=null)}},d=null,f=null;function p(){return d?{...d,errors:d.errors.map(e=>({...e,error:e.error?{name:e.error.name,message:e.error.message,stack:e.error.stack}:null}))}:null}function h(e){return{routerType:e.routerType,errors:e.errors.map(e=>{let{error:t,isFatal:r,boundary:n,...o}=e;return{...o,fatal:r,...n?{boundary:n}:{},error:{name:t.name,message:t.message,stack:t.stack,source:(0,a.C)(t)}}})}}function m(){return d?h(d):null}function g(e){let t=f??=new Set;t.add(e);let r=m();return r&&e({errors:r.errors,routerType:r.routerType}),()=>t.delete(e)}function v(){return d?{segmentTrie:(0,c.kN)(),routerType:d.routerType}:null}function x(e){return(...t)=>{u.enqueue(r=>{e(r,...t)})}}let y={onBuildOk:x(e=>{e({type:i.Z7})}),onBuildError:x((e,t)=>{e({type:i.JS,message:t})}),onBeforeRefresh:x(e=>{e({type:i.jQ})}),onRefresh:x(e=>{e({type:i.z8})}),onVersionInfo:x((e,t)=>{e({type:i.Rm,versionInfo:t})}),onVulnerabilityInsight:x((e,t)=>{e({type:i.z9,hasVulnerabilityInsight:t})}),onCacheIndicator:x((e,t)=>{e({type:i.ei,cacheIndicator:t})}),onStaticIndicator:x((e,t)=>{e({type:i.Wq,staticIndicator:t})}),onDebugInfo:x((e,t)=>{e({type:i.cV,debugInfo:t})}),onDevIndicator:x((e,t)=>{e({type:i.VA,devIndicator:t})}),onDevToolsConfig:x((e,t)=>{e({type:i.$P,devToolsConfig:t})}),onUnhandledError:x((e,t,r)=>{e({type:i.iL,reason:t,...void 0===r?{}:{metadata:r}})}),onUnhandledRejection:x((e,t,r)=>{e({type:i.Bz,reason:t,...void 0===r?{}:{metadata:r}})}),openErrorOverlay:x(e=>{e({type:i.Wv})}),closeErrorOverlay:x(e=>{e({type:i.kO})}),toggleErrorOverlay:x(e=>{e({type:i.AE})}),buildingIndicatorHide:x(e=>{e({type:i.rS})}),buildingIndicatorShow:x(e=>{e({type:i.sG})}),renderingIndicatorHide:x(e=>{e({type:i.dP})}),renderingIndicatorShow:x(e=>{e({type:i.W7})}),segmentExplorerNodeAdd:x((e,t)=>{(0,c.JW)(t)}),segmentExplorerNodeRemove:x((e,t)=>{(0,c.YY)(t)}),segmentExplorerUpdateRouteState:x((e,t,r)=>{e({type:i.P6,page:t,tree:r})}),instantNavsToggle:x(e=>{e({type:i.TJ})}),onRequestInsightsSnapshot:x((e,t)=>{e({type:i.Ok,snapshot:t})}),onRequestInsightsUpdate:x((e,t)=>{e({type:i.xo,insight:t})})};function b(e){let t,a,l,c,f,p,h,m,g,v,x,y,b,k=(0,o.c)(29),{enableCacheIndicator:j,enableRuntimeErrorReporting:S,getOwnerStack:C,getSquashedHydrationErrorDetails:E,isRecoverableError:T,routerType:N,shadowRoot:I}=e,[z,R]=(0,i.Kr)(N,C,T,j,S);k[0]!==N||k[1]!==z?(t=()=>{d={...z,routerType:N}},a=[z,N],k[0]=N,k[1]=z,k[2]=t,k[3]=a):(t=k[2],a=k[3]),(0,s.useEffect)(t,a),k[4]!==I.host||k[5]!==z.theme?(l=()=>{let e=I.host;"dark"===z.theme?(e.classList.add("dark"),e.classList.remove("light")):"light"===z.theme?(e.classList.add("light"),e.classList.remove("dark")):(e.classList.remove("dark"),e.classList.remove("light"))},k[4]=I.host,k[5]=z.theme,k[6]=l):l=k[6],k[7]!==I||k[8]!==z.theme?(c=[I,z.theme],k[7]=I,k[8]=z.theme,k[9]=c):c=k[9],(0,s.useLayoutEffect)(l,c),k[10]!==R?(f=()=>{let e=setTimeout(()=>{u.connect(R)});return()=>{u.disconnect(R),clearTimeout(e)}},k[10]=R,k[11]=f):f=k[11],k[12]===Symbol.for("react.memo_cache_sentinel")?(p=[],k[12]=p):p=k[12],(0,s.useInsertionEffect)(f,p),k[13]!==S||k[14]!==z?(h=S?(0,n.jsx)(w,{state:z}):null,k[13]=S,k[14]=z,k[15]=h):h=k[15];let P=h;if(process.env.__NEXT_DISABLE_DEV_OVERLAY_UX)return P;k[16]===Symbol.for("react.memo_cache_sentinel")?(m=function(){let{DevOverlay:e,FontStyles:t}=r("./src/next-devtools/dev-overlay-ux.ts");return{DevOverlay:e,FontStyles:t}}(),k[16]=m):m=k[16];let{DevOverlay:L,FontStyles:O}=m;return k[17]===Symbol.for("react.memo_cache_sentinel")?(g=(0,n.jsx)(O,{}),k[17]=g):g=k[17],k[18]!==R||k[19]!==E||k[20]!==I||k[21]!==z?(v={dispatch:R,getSquashedHydrationErrorDetails:E,shadowRoot:I,state:z},k[18]=R,k[19]=E,k[20]=I,k[21]=z,k[22]=v):v=k[22],k[23]===Symbol.for("react.memo_cache_sentinel")?(x=(0,n.jsx)(L,{}),k[23]=x):x=k[23],k[24]!==v?(y=(0,n.jsx)(_,{value:v,children:x}),k[24]=v,k[25]=y):y=k[25],k[26]!==P||k[27]!==y?(b=(0,n.jsxs)(n.Fragment,{children:[P,g,y]}),k[26]=P,k[27]=y,k[28]=b):b=k[28],b}function w(e){let t,r,n=(0,o.c)(4),{state:a}=e,{errors:i,routerType:l}=a;return n[0]!==i||n[1]!==l?(t=()=>{if(f){let e=h({errors:i,routerType:l});for(let t of f)t(e)}},r=[i,l],n[0]=i,n[1]=l,n[2]=t,n[3]=r):(t=n[2],r=n[3]),(0,s.useEffect)(t,r),null}let _=(0,s.createContext)(null),k=()=>(0,s.useContext)(_),j=!1,S=!1;function C(){return null}function E(e,t,r,o){if(j)throw Error("Next DevTools: Pages Dev Overlay is already mounted. This is a bug in Next.js");if(!S){let a=!process.env.__NEXT_DISABLE_DEV_OVERLAY_UX,i=document.createElement("nextjs-portal");if(a){let e=document.createElement("script");e.style.display="block",e.style.position="absolute",e.setAttribute("data-nextjs-dev-overlay","true"),e.appendChild(i),document.body.appendChild(e)}let c=(0,l.createRoot)(i,{identifierPrefix:"ndt-",onDefaultTransitionIndicator:()=>()=>{}}),u=i.attachShadow({mode:"open"});(0,s.startTransition)(()=>{c.render((0,n.jsx)(b,{enableCacheIndicator:r,enableRuntimeErrorReporting:o,getOwnerStack:e,getSquashedHydrationErrorDetails:C,isRecoverableError:t,routerType:"app",shadowRoot:u}))}),S=!0}}function T(e,t,r){if(S)throw Error("Next DevTools: App Dev Overlay is already mounted. This is a bug in Next.js");if(!j){let o=!process.env.__NEXT_DISABLE_DEV_OVERLAY_UX,a=document.createElement("nextjs-portal");a.style.position="absolute",o&&(new MutationObserver(e=>{for(let t of e)if("childList"===t.type)for(let e of t.removedNodes)e===a&&document.body.appendChild(a)}).observe(document.body,{childList:!0}),document.body.appendChild(a));let i=(0,l.createRoot)(a,{identifierPrefix:"ndt-"}),c=a.attachShadow({mode:"open"});(0,s.startTransition)(()=>{i.render((0,n.jsx)(b,{enableCacheIndicator:!1,enableRuntimeErrorReporting:!1,getOwnerStack:e,getSquashedHydrationErrorDetails:t,isRecoverableError:r,routerType:"pages",shadowRoot:c}))}),j=!0}}},"./src/next-devtools/dev-overlay/components/call-stack-frame/call-stack-frame.tsx"(e,t,r){"use strict";r.d(t,{C:()=>c,l:()=>u});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/next-devtools/dev-overlay/components/hot-linked-text/index.tsx"),i=r("./src/next-devtools/dev-overlay/icons/external.tsx"),s=r("./src/next-devtools/shared/stack-frame.ts"),l=r("./src/next-devtools/dev-overlay/utils/use-open-in-editor.ts");let c=function(e){let t,r,c,u,d,f,p,h,m=(0,o.c)(26),{frame:g}=e,v=g.originalStackFrame??g.sourceStackFrame,x=!!g.originalCodeFrame;m[0]!==v||m[1]!==x?(t=x?{file:v.file,line1:v.line1??1,column1:v.column1??1}:void 0,m[0]=v,m[1]=x,m[2]=t):t=m[2];let y=(0,l.Y)(t);m[3]!==v?(r=(0,s.Q)(v),m[3]=v,m[4]=r):r=m[4];let b=r;if(!b)return null;let w=!x;return m[5]!==v.methodName?(c=(0,n.jsx)(a.E,{text:v.methodName}),m[5]=v.methodName,m[6]=c):c=m[6],m[7]!==v.methodName||m[8]!==x||m[9]!==y?(u=x&&(0,n.jsx)("button",{onClick:y,className:"open-in-editor-button","aria-label":`Open ${v.methodName} in editor`,children:(0,n.jsx)(i.X,{width:16,height:16})}),m[7]=v.methodName,m[8]=x,m[9]=y,m[10]=u):u=m[10],m[11]!==g.error||m[12]!==g.reason?(d=g.error?(0,n.jsx)("button",{className:"source-mapping-error-button",onClick:()=>console.error(g.reason),title:"Sourcemapping failed. Click to log cause of error.",children:(0,n.jsx)(i.N,{width:16,height:16})}):null,m[11]=g.error,m[12]=g.reason,m[13]=d):d=m[13],m[14]!==c||m[15]!==u||m[16]!==d?(f=(0,n.jsxs)("div",{className:"call-stack-frame-method-name",children:[c,u,d]}),m[14]=c,m[15]=u,m[16]=d,m[17]=f):f=m[17],m[18]!==x||m[19]!==b?(p=(0,n.jsx)("span",{className:"call-stack-frame-file","data-has-original-code-frame":x,children:b}),m[18]=x,m[19]=b,m[20]=p):p=m[20],m[21]!==g.ignored||m[22]!==w||m[23]!==f||m[24]!==p?(h=(0,n.jsxs)("div",{"data-nextjs-call-stack-frame":!0,"data-nextjs-call-stack-frame-no-source":w,"data-nextjs-call-stack-frame-ignored":g.ignored,children:[f,p]}),m[21]=g.ignored,m[22]=w,m[23]=f,m[24]=p,m[25]=h):h=m[25],h},u=`
  [data-nextjs-call-stack-frame-no-source] {
    padding: 6px 8px;

    border-radius: var(--rounded-lg);
  }

  [data-nextjs-call-stack-frame-ignored="true"] {
    opacity: 0.6;
  }

  [data-nextjs-call-stack-frame] {
    user-select: text;
    display: block;
    box-sizing: border-box;

    user-select: text;
    -webkit-user-select: text;
    -moz-user-select: text;
    -ms-user-select: text;

    padding: 0;

    border-radius: var(--rounded-lg);
  }

  .call-stack-frame-method-name {
    display: flex;
    align-items: center;
    gap: 4px;

    margin: 0;
    font-family: var(--font-stack-monospace);

    color: var(--color-gray-1000);
    font-size: var(--size-14);
    font-weight: 500;
    line-height: var(--size-20);

    svg {
      width: var(--size-16);
      height: var(--size-16);
    }
  }

  .open-in-editor-button, .source-mapping-error-button {
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--rounded-full);
    padding: 4px;
    color: var(--color-font);

    svg {
      width: var(--size-16);
      height: var(--size-16);
    }

    &:focus-visible {
      outline: var(--focus-ring);
      outline-offset: -2px;
    }

    &:hover {
      background: var(--color-gray-alpha-100);
    }

    &:active {
      background: var(--color-gray-alpha-200);
    }
  }

  .call-stack-frame-file {
    color: var(--color-gray-900);
    font-size: var(--size-13);
    line-height: var(--size-20);
    word-wrap: break-word;
  }
`},"./src/next-devtools/dev-overlay/components/call-stack/call-stack.tsx"(e,t,r){"use strict";r.d(t,{b:()=>c,N:()=>l});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/next-devtools/dev-overlay/components/call-stack-frame/call-stack-frame.tsx");function i(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,n.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8.70722 2.39641C8.3167 2.00588 7.68353 2.00588 7.29301 2.39641L4.46978 5.21963L3.93945 5.74996L5.00011 6.81062L5.53044 6.28029L8.00011 3.81062L10.4698 6.28029L11.0001 6.81062L12.0608 5.74996L11.5304 5.21963L8.70722 2.39641ZM5.53044 9.71963L5.00011 9.1893L3.93945 10.25L4.46978 10.7803L7.29301 13.6035C7.68353 13.994 8.3167 13.994 8.70722 13.6035L11.5304 10.7803L12.0608 10.25L11.0001 9.1893L10.4698 9.71963L8.00011 12.1893L5.53044 9.71963Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}var s=r("./src/next-devtools/dev-overlay/utils/css.ts");function l(e){let t,r,s,l,c,u=(0,o.c)(17),{frames:d,isIgnoreListOpen:f,ignoredFramesTally:p,onToggleIgnoreList:h}=e;if(u[0]!==d.length?(t=(0,n.jsxs)("p",{"data-nextjs-call-stack-title":!0,children:["Call Stack ",(0,n.jsx)("span",{"data-nextjs-call-stack-count":!0,children:d.length})]}),u[0]=d.length,u[1]=t):t=u[1],u[2]!==p||u[3]!==f||u[4]!==h?(r=p>0&&(0,n.jsxs)("button",{"data-nextjs-call-stack-ignored-list-toggle-button":f,onClick:h,children:[`${f?"Hide":"Show"} ${p} ignore-listed frame(s)`,(0,n.jsx)(i,{})]}),u[2]=p,u[3]=f,u[4]=h,u[5]=r):r=u[5],u[6]!==t||u[7]!==r?(s=(0,n.jsxs)("div",{"data-nextjs-call-stack-header":!0,children:[t,r]}),u[6]=t,u[7]=r,u[8]=s):s=u[8],u[9]!==d||u[10]!==f){let e;u[12]!==f?(e=(e,t)=>!e.ignored||f?(0,n.jsx)(a.C,{frame:e},t):null,u[12]=f,u[13]=e):e=u[13],l=d.map(e),u[9]=d,u[10]=f,u[11]=l}else l=u[11];return u[14]!==s||u[15]!==l?(c=(0,n.jsxs)("div",{"data-nextjs-call-stack-container":!0,children:[s,l]}),u[14]=s,u[15]=l,u[16]=c):c=u[16],c}let c=(0,s.A)`
  [data-nextjs-call-stack-container] {
    display: flex;
    flex-direction: column;
    gap: 12px;
    position: relative;
    margin: 0;
    padding: 20px 0 0;
  }

  [data-nextjs-call-stack-header] {
    display: flex;
    justify-content: space-between;
    align-items: center;
    min-height: var(--size-28);
    padding: 0;
    width: 100%;
  }

  [data-nextjs-call-stack-title] {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;

    margin: 0;

    color: var(--color-gray-1000);
    font-size: var(--size-16);
    font-weight: 500;
  }

  [data-nextjs-call-stack-count] {
    display: flex;
    justify-content: center;
    align-items: center;

    padding: 0 6px;
    height: var(--size-20);
    min-width: var(--size-20);
    gap: 4px;

    color: var(--color-gray-1000);
    text-align: center;
    font-size: var(--size-11);
    font-weight: 500;
    line-height: var(--size-16);

    border-radius: var(--rounded-full);
    background: var(--color-gray-200);
  }

  [data-nextjs-call-stack-ignored-list-toggle-button] {
    all: unset;
    display: flex;
    align-items: center;
    gap: 6px;
    color: var(--color-gray-900);
    font-size: var(--size-14);
    line-height: var(--size-20);
    border-radius: var(--rounded-md-2);
    padding: 4px 6px;
    margin-right: -6px;
    &:hover {
      background: var(--color-gray-100);
    }

    &:focus {
      outline: var(--focus-ring);
    }

    svg {
      width: var(--size-16);
      height: var(--size-16);
    }
  }
`},"./src/next-devtools/dev-overlay/components/code-frame/code-frame-shell.tsx"(e,t,r){"use strict";r.d(t,{T:()=>i});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/next-devtools/dev-overlay/icons/external.tsx");function i(e){let t,r,i,s,l=(0,o.c)(11),{header:c,onOpen:u,openLabel:d,children:f}=e;return l[0]!==u||l[1]!==d?(t=u&&(0,n.jsx)("button",{"aria-label":d??"Open in editor","data-with-open-in-editor-link-source-file":!0,onClick:u,type:"button",children:(0,n.jsx)(a.X,{})}),l[0]=u,l[1]=d,l[2]=t):t=l[2],l[3]!==c||l[4]!==t?(r=(0,n.jsx)("div",{className:"code-frame-header",children:(0,n.jsxs)("p",{className:"code-frame-link",children:[c,t]})}),l[3]=c,l[4]=t,l[5]=r):r=l[5],l[6]!==f?(i=(0,n.jsx)("pre",{className:"code-frame-pre",children:(0,n.jsx)("div",{className:"code-frame-lines",children:f})}),l[6]=f,l[7]=i):i=l[7],l[8]!==r||l[9]!==i?(s=(0,n.jsxs)("div",{"data-nextjs-codeframe":!0,children:[r,i]}),l[8]=r,l[9]=i,l[10]=s):s=l[10],s}},"./src/next-devtools/dev-overlay/components/code-frame/code-frame.tsx"(e,t,r){"use strict";r.d(t,{V:()=>h,Z:()=>d});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/next-devtools/dev-overlay/components/hot-linked-text/index.tsx"),i=r("./src/next-devtools/shared/stack-frame.ts"),s=r("./src/next-devtools/dev-overlay/utils/use-open-in-editor.ts"),l=r("./src/next-devtools/dev-overlay/icons/file.tsx"),c=r("./src/next-devtools/dev-overlay/components/code-frame/code-frame-shell.tsx"),u=r("./src/next-devtools/dev-overlay/components/code-frame/parse-code-frame.ts");function d(e){let t,r,d,p,h,m,g,v,x,y,b=(0,o.c)(29),{stackFrame:w,codeFrame:_}=e;if(b[0]!==_||b[1]!==w){let e,r=(0,u.ZG)((0,u.w5)(_));b[3]!==w?(e=e=>({line:e,parsedLine:(0,u.tI)(e,w)}),b[3]=w,b[4]=e):e=b[4],t=r.map(e),b[0]=_,b[1]=w,b[2]=t}else t=b[2];let k=t,j=w.line1??1,S=w.column1??1;b[5]!==w.file||b[6]!==j||b[7]!==S?(r={file:w.file,line1:j,column1:S},b[5]=w.file,b[6]=j,b[7]=S,b[8]=r):r=b[8];let C=(0,s.Y)(r);b[9]!==w.file?(d=w?.file?.split(".").pop(),b[9]=w.file,b[10]=d):d=b[10];let E=d;return b[11]!==E?(p=(0,n.jsx)("span",{className:"code-frame-icon",children:(0,n.jsx)(l.o,{lang:E})}),b[11]=E,b[12]=p):p=b[12],b[13]!==w?(h=(0,i.Q)(w),b[13]=w,b[14]=h):h=b[14],b[15]!==w.methodName?(m=(0,n.jsx)(a.E,{text:w.methodName}),b[15]=w.methodName,b[16]=m):m=b[16],b[17]!==h||b[18]!==m?(g=(0,n.jsxs)("span",{"data-text":!0,children:[h," @"," ",m]}),b[17]=h,b[18]=m,b[19]=g):g=b[19],b[20]!==p||b[21]!==g?(v=(0,n.jsxs)(n.Fragment,{children:[p,g]}),b[20]=p,b[21]=g,b[22]=v):v=b[22],b[23]!==k?(x=k.map(f),b[23]=k,b[24]=x):x=b[24],b[25]!==C||b[26]!==v||b[27]!==x?(y=(0,n.jsx)(c.T,{header:v,onOpen:C,children:x}),b[25]=C,b[26]=v,b[27]=x,b[28]=y):y=b[28],y}function f(e,t){let{line:r,parsedLine:o}=e,{lineNumber:a,isErroredLine:i}=o,s={};return a&&(s["data-nextjs-codeframe-line"]=a),i&&(s["data-nextjs-codeframe-line--errored"]=!0),(0,n.jsx)("div",{...s,children:r.map(p)},`line-${t}`)}function p(e,t){return(0,n.jsx)("span",{style:{color:e.fg?`var(--color-${e.fg})`:void 0,..."bold"===e.decoration?{fontWeight:500}:"italic"===e.decoration?{fontStyle:"italic"}:void 0},children:e.content},`frame-${t}`)}let h=`
  [data-nextjs-codeframe] {
    --code-frame-padding: 12px;
    --code-frame-line-height: var(--size-20);
    background-color: var(--color-background-200);
    color: var(--color-gray-1000);
    text-overflow: ellipsis;
    border: 1px solid var(--color-gray-400);
    border-radius: var(--rounded-xl);
    font-family: var(--font-stack-monospace);
    font-size: var(--size-13);
    line-height: var(--code-frame-line-height);
    margin: 0;
    overflow: hidden;

    svg {
      width: var(--size-16);
      height: var(--size-16);
    }
  }

  .code-frame-link,
  .code-frame-pre {
    padding: var(--code-frame-padding);
  }

  .code-frame-pre {
    background: var(--color-background-100) !important;
    border: 1px solid var(--color-gray-200);
    border-radius: var(--rounded-xl);
    border-bottom: none;
    margin-left: -1px !important;
    width: calc(100% + 2px);
    max-width: calc(100% + 2px) !important;
  }

  .code-frame-link svg {
    display: block;
    flex-shrink: 0;
  }

  [data-with-open-in-editor-link-source-file] svg {
    width: var(--size-14);
    height: var(--size-14);
  }

  .code-frame-lines {
    min-width: max-content;
  }

  .code-frame-link [data-text] {
    font-size: var(--size-12);
    text-align: left;
  }

  .code-frame-header {
    width: 100%;
    transition: background 100ms ease-out;
    border-radius: var(--rounded-lg) var(--rounded-lg) 0 0;
  }

  [data-with-open-in-editor-link-source-file] {
    display: flex;
    align-items: center;
    justify-content: center;
    width: var(--size-24);
    height: var(--size-24);
    padding: 4px;
    margin-left: auto;
    border-radius: var(--rounded-full);

    &:focus-visible {
      outline: var(--focus-ring);
      outline-offset: -2px;
    }

    &:hover {
      background: var(--color-gray-alpha-100);
    }

    &:active {
      background: var(--color-gray-alpha-200);
    }
  }

  [data-nextjs-codeframe]::selection,
  [data-nextjs-codeframe] *::selection {
    background-color: var(--color-ansi-selection);
  }

  [data-nextjs-codeframe] *:not(a) {
    color: inherit;
    background-color: transparent;
    font-family: var(--font-stack-monospace);
  }

  [data-nextjs-codeframe-line][data-nextjs-codeframe-line--errored="true"] {
    position: relative;
    isolation: isolate;

    > span { 
      position: relative;
      z-index: 1;
    }

    &::after {
      content: "";
      width: calc(100% + var(--code-frame-padding) * 2);
      height: var(--code-frame-line-height);
      left: calc(-1 * var(--code-frame-padding));
      background: var(--color-red-200);
      box-shadow: 2px 0 0 0 var(--color-red-900) inset;
      position: absolute;
    }
  }

  [data-nextjs-codeframe-line] > span:first-child {
    color: var(--color-gray-alpha-500) !important;
  }

  [data-nextjs-codeframe-line][data-nextjs-codeframe-line--errored="true"]
    > span:first-child {
    color: var(--color-gray-alpha-1000) !important;
  }


  [data-nextjs-codeframe] > * {
    margin: 0;
  }

  .code-frame-link {
    display: flex;
    align-items: center;
    gap: 6px;
    margin: 0;
    outline: 0;
    padding-top: 8px;
    padding-bottom: 8px;
    padding-right: 8px;
  }
  .code-frame-pre {
    overflow-x: auto;
    overflow-y: hidden;
    display: block;
    max-width: 100%;
  }

  [data-nextjs-codeframe] svg {
    color: var(--color-gray-900);
  }
`},"./src/next-devtools/dev-overlay/components/code-frame/parse-code-frame.ts"(e,t,r){"use strict";r.d(t,{ZG:()=>l,tI:()=>c,w5:()=>s});var n=r("./dist/compiled/anser/index.js"),o=r.n(n),a=r("./dist/compiled/strip-ansi/index.js"),i=r.n(a);function s(e){let t=e.split(/\r?\n/g),r=t.map(e=>null===/^>? +\d+ +\| [ ]+/.exec(i()(e))?null:/^>? +\d+ +\| ( *)/.exec(i()(e))).filter(Boolean).map(e=>e.pop()).reduce((e,t)=>isNaN(e)?t.length:Math.min(e,t.length),NaN);return r>1?t.map((e,t)=>~(t=e.indexOf("|"))?e.substring(0,t)+e.substring(t).replace(`^\\ {${r}}`,""):e).join("\n"):t.join("\n")}function l(e){let t=o().ansiToJson(e,{json:!0,use_classes:!0,remove_empty:!0}),r=[],n=[];for(let e of t)if("string"==typeof e.content&&e.content.includes("\n")){let t=e.content.split("\n");for(let o=0;o<t.length;o++){let a=t[o];a&&n.push({...e,content:a}),o<t.length-1&&(r.push(n),n=[])}}else n.push(e);return n.length>0&&r.push(n),r}function c(e,t){var r;let n=0;for(;n<e.length&&void 0!==(r=e[n]?.content)&&/^[\s>]+$/.test(r)&&!r.includes("|");)n++;let o=e[n]?.content?.replace("|","").trim(),a=o&&/^\d+$/.test(o)?o:void 0;return{lineNumber:a,isErroredLine:void 0!==a&&a===t.line1?.toString()}}},"./src/next-devtools/dev-overlay/components/copy-button/index.tsx"(e,t,r){"use strict";r.d(t,{KY:()=>p,i8:()=>u});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js"),i=r("./src/next-devtools/dev-overlay/utils/cx.ts");function s(e){return navigator.clipboard.writeText(e).then(c,l)}function l(e){return{state:"error",error:e}}function c(){return{state:"success"}}function u(e){let t,r,l,c,u,p,h,m,g,v,x,y,b,w,_,k,j,S,C=(0,o.c)(45);C[0]!==e?({content:r,getContent:c,actionLabel:t,successLabel:m,icon:u,showLabel:h,disabled:l,...p}=e,C[0]=e,C[1]=t,C[2]=r,C[3]=l,C[4]=c,C[5]=u,C[6]=p,C[7]=h,C[8]=m):(t=C[1],r=C[2],l=C[3],c=C[4],u=C[5],p=C[6],h=C[7],m=C[8]),C[9]!==r||C[10]!==c?(g=()=>r?Promise.resolve(r):c?c():Promise.resolve(""),C[9]=r,C[10]=c,C[11]=g):g=C[11];let[E,T,N,I]=function(e){let t,r,n,i,l,c=(0,o.c)(8);c[0]!==e?(t=(t,r)=>"reset"===r?{state:"initial"}:"copy"===r?navigator.clipboard?e().then(s):{state:"error",error:"Copy to clipboard is not supported in this browser"}:t,c[0]=e,c[1]=t):t=c[1],c[2]===Symbol.for("react.memo_cache_sentinel")?(r={state:"initial"},c[2]=r):r=c[2];let[u,d,f]=a.useActionState(t,r);c[3]===Symbol.for("react.memo_cache_sentinel")?(n=function(){a.startTransition(()=>{d("copy")})},c[3]=n):n=c[3];let p=n;c[4]===Symbol.for("react.memo_cache_sentinel")?(i=()=>{d("reset")},c[4]=i):i=c[4];let h=i;return c[5]!==u||c[6]!==f?(l=[u,p,h,f],c[5]=u,c[6]=f,c[7]=l):l=c[7],l}(g),z="error"===E.state?E.error:null;C[12]!==z?(v=()=>{null!==z&&console.warn(z)},x=[z],C[12]=z,C[13]=v,C[14]=x):(v=C[13],x=C[14]),a.useEffect(v,x),C[15]!==E.state||C[16]!==N?(y=()=>{if("success"===E.state){let e=setTimeout(()=>{N()},2e3);return()=>{clearTimeout(e)}}},C[15]=E.state,C[16]=N,C[17]=y):y=C[17],C[18]!==E.state||C[19]!==I||C[20]!==N?(b=[I,E.state,N],C[18]=E.state,C[19]=I,C[20]=N,C[21]=b):b=C[21],a.useEffect(y,b);let R=!navigator.clipboard||I||l||!!z,P="success"===E.state?m:t;C[22]!==E.state||C[23]!==u?(w="success"===E.state?(0,n.jsx)(f,{}):u||(0,n.jsx)(d,{width:14,height:14,className:"error-overlay-toolbar-button-icon"}),C[22]=E.state,C[23]=u,C[24]=w):w=C[24];let L=w,O=h?void 0:P,M=`nextjs-data-copy-button--${E.state}`;C[25]!==e.className||C[26]!==M?(_=(0,i.cx)(e.className,"nextjs-data-copy-button",M),C[25]=e.className,C[26]=M,C[27]=_):_=C[27],C[28]!==T||C[29]!==R?(k=()=>{R||T()},C[28]=T,C[29]=R,C[30]=k):k=C[30],C[31]!==P||C[32]!==h?(j=h?(0,n.jsx)("span",{"data-nextjs-copy-button-label":!0,children:P}):null,C[31]=P,C[32]=h,C[33]=j):j=C[33];let A="error"===E.state?` ${E.error}`:null;return C[34]!==R||C[35]!==I||C[36]!==P||C[37]!==L||C[38]!==p||C[39]!==j||C[40]!==A||C[41]!==O||C[42]!==_||C[43]!==k?(S=(0,n.jsxs)("button",{...p,type:"button",title:O,"aria-label":P,"aria-disabled":R,"data-nextjs-copy-button":!0,"data-pending":I,className:_,onClick:k,children:[L,j,A]}),C[34]=R,C[35]=I,C[36]=P,C[37]=L,C[38]=p,C[39]=j,C[40]=A,C[41]=O,C[42]=_,C[43]=k,C[44]=S):S=C[44],S}function d(e){let t,r,a=(0,o.c)(3);return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M2.406.438c-.845 0-1.531.685-1.531 1.53v6.563c0 .846.686 1.531 1.531 1.531H3.937V8.75H2.406a.219.219 0 0 1-.219-.219V1.97c0-.121.098-.219.22-.219h4.812c.12 0 .218.098.218.219v.656H8.75v-.656c0-.846-.686-1.532-1.531-1.532H2.406zm4.375 3.5c-.845 0-1.531.685-1.531 1.53v6.563c0 .846.686 1.531 1.531 1.531h4.813c.845 0 1.531-.685 1.531-1.53V5.468c0-.846-.686-1.532-1.531-1.532H6.78zm-.218 1.53c0-.12.097-.218.218-.218h4.813c.12 0 .219.098.219.219v6.562c0 .121-.098.219-.22.219H6.782a.219.219 0 0 1-.218-.219V5.47z",fill:"currentColor"}),a[0]=t):t=a[0],a[1]!==e?(r=(0,n.jsx)("svg",{width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e,children:t}),a[1]=e,a[2]=r):r=a[2],r}function f(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{height:"16",xlinkTitle:"copied",viewBox:"0 0 16 16",width:"16",stroke:"currentColor",fill:"currentColor",children:(0,n.jsx)("path",{d:"M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"})}),t[0]=e):e=t[0],e}let p=`
  .nextjs-data-copy-button {
    color: inherit;

    svg {
      width: var(--size-16);
      height: var(--size-16);
    }
  }
  .nextjs-data-copy-button[aria-disabled="true"] {
    background-color: var(--color-gray-100);
    cursor: not-allowed;
  }
  .nextjs-data-copy-button[data-pending="true"] {
    cursor: wait;
  }
  .nextjs-data-copy-button--initial:hover:not([aria-disabled="true"]) {
    cursor: pointer;
  }
  .nextjs-data-copy-button--error:not([aria-disabled="true"]),
  .nextjs-data-copy-button--error:hover:not([aria-disabled="true"]) {
    color: var(--color-ansi-red);
  }
  .nextjs-data-copy-button--success:not([aria-disabled="true"]) {
    color: var(--color-gray-900);
  }
`},"./src/next-devtools/dev-overlay/components/dialog/index.ts"(e,t,r){"use strict";r.d(t,{R4:()=>a,R7:()=>l,Cf:()=>i});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js");r("./dist/compiled/react/index.js");let a=function(e){let t,r,a,i,s=(0,o.c)(8);return s[0]!==e?({children:t,className:r,...a}=e,s[0]=e,s[1]=t,s[2]=r,s[3]=a):(t=s[1],r=s[2],a=s[3]),s[4]!==t||s[5]!==r||s[6]!==a?(i=(0,n.jsx)("div",{"data-nextjs-dialog-body":!0,className:r,...a,children:t}),s[4]=t,s[5]=r,s[6]=a,s[7]=i):i=s[7],i},i=function(e){let t,r,a,i,s=(0,o.c)(8);return s[0]!==e?({children:t,className:r,...a}=e,s[0]=e,s[1]=t,s[2]=r,s[3]=a):(t=s[1],r=s[2],a=s[3]),s[4]!==t||s[5]!==r||s[6]!==a?(i=(0,n.jsx)("div",{"data-nextjs-dialog-content":!0,className:r,...a,children:t}),s[4]=t,s[5]=r,s[6]=a,s[7]=i):i=s[7],i};var s=r("./src/next-devtools/dev-overlay/utils/css.ts");let l=(0,s.A)`
  [data-nextjs-dialog-root] {
    --next-dialog-radius: var(--rounded-xl);
    --next-dialog-max-width: 960px;
    --next-dialog-row-padding: 16px;
    --next-dialog-padding: 12px;
    --next-dialog-border-width: 1px;

    background-color: var(--color-gray-100);
    padding: 0 4px 4px 4px;
    border-radius: var(--rounded-2xl);
    display: flex;
    flex-direction: column;
    width: 100%;
    max-height: calc(100% - 56px);
    max-width: var(--next-dialog-max-width);
    margin-right: auto;
    margin-left: auto;
    scale: 0.97;
    opacity: 0;
    transition-property: scale, opacity;
    transition-duration: var(--transition-duration);
    transition-timing-function: var(--timing-overlay);

    &[data-rendered='true'] {
      opacity: 1;
      scale: 1;
    }
  }

  [data-nextjs-dialog] {
    outline: 0;
  }

  [data-nextjs-dialog-backdrop] {
    opacity: 0;
    transition: opacity var(--transition-duration) var(--timing-overlay);
  }

  [data-nextjs-dialog-overlay] {
    margin: 8px;
  }

  [data-nextjs-dialog-overlay][data-rendered='true']
    [data-nextjs-dialog-backdrop] {
    opacity: 1;
  }

  [data-nextjs-dialog-content] {
    border: none;
    margin: 0;
    display: flex;
    flex-direction: column;
    position: relative;
    padding: 0;
  }

  [data-nextjs-dialog-content] > [data-nextjs-dialog-header] {
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    gap: 4px;
    margin-bottom: 8px;
    padding: 20px;
  }

  [data-nextjs-dialog-content] > [data-nextjs-dialog-body] {
    position: relative;
    flex: 1 1 auto;
  }

  @media (max-height: 812px) {
    [data-nextjs-dialog-overlay] {
      max-height: calc(100% - 15px);
    }
  }

  @media (min-width: 576px) {
    [data-nextjs-dialog-root] {
      --next-dialog-max-width: 540px;
    }
  }

  @media (min-width: 768px) {
    [data-nextjs-dialog-root] {
      --next-dialog-max-width: 720px;
    }
  }

  @media (min-width: 992px) {
    [data-nextjs-dialog-root] {
      --next-dialog-max-width: 960px;
    }
  }
`},"./src/next-devtools/dev-overlay/components/errors/dev-tools-indicator/utils.ts"(e,t,r){"use strict";r.d(t,{OB:()=>c,ay:()=>l,bq:()=>i,rM:()=>a,xj:()=>s});var n=r("./dist/compiled/react/compiler-runtime.js"),o=r("./dist/compiled/react/index.js");function a(e,t,r,a){let s,l,c,u=(0,n.c)(11);u[0]!==a?(s=e=>{a?a():e?.focus()},u[0]=a,u[1]=s):s=u[1];let d=(0,o.useEffectEvent)(s);u[2]!==r||u[3]!==d||u[4]!==e||u[5]!==t?(l=()=>{let n=null,o=function(e){let t;if("Tab"!==e.key||null===n)return;let[r,o]=(t=n.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'))?[t[0],t[t.length-1]]:[],a=i(n);e.shiftKey?a===r&&(o?.focus(),e.preventDefault()):a===o&&(r?.focus(),e.preventDefault())},a=setTimeout(()=>{if(n=e.current,r)d(n),n?.addEventListener("keydown",o);else{let e=i(n);t&&n?.contains(e)&&t.current?.focus()}});return()=>{clearTimeout(a),n?.removeEventListener("keydown",o)}},u[2]=r,u[3]=d,u[4]=e,u[5]=t,u[6]=l):l=u[6],u[7]!==r||u[8]!==e||u[9]!==t?(c=[r,e,t],u[7]=r,u[8]=e,u[9]=t,u[10]=c):c=u[10],(0,o.useEffect)(l,c)}function i(e){let t=e?.getRootNode();return t instanceof ShadowRoot?t?.activeElement:null}function s(e,t,r,a,i){let s,l,c=(0,n.c)(7);c[0]!==r||c[1]!==a||c[2]!==i||c[3]!==e||c[4]!==t?(s=()=>{if(!r)return;let n=i||e.current?.ownerDocument,o=function(r){let n=r.target;!(e.current&&e.current.contains(n))&&(e.current?.getBoundingClientRect()&&r.clientX>=e.current.getBoundingClientRect().left-10&&r.clientX<=e.current.getBoundingClientRect().right+10&&r.clientY>=e.current.getBoundingClientRect().top-10&&r.clientY<=e.current.getBoundingClientRect().bottom+10||t.current?.getBoundingClientRect()&&r.clientX>=t.current.getBoundingClientRect().left-10&&r.clientX<=t.current.getBoundingClientRect().right+10&&r.clientY>=t.current.getBoundingClientRect().top-10&&r.clientY<=t.current.getBoundingClientRect().bottom+10||a("outside"))},s=function(e){"Escape"===e.key&&a("escape")};return n?.addEventListener("mousedown",o),n?.addEventListener("keydown",s),()=>{n?.removeEventListener("mousedown",o),n?.removeEventListener("keydown",s)}},l=[r,a,i,e,t],c[0]=r,c[1]=a,c[2]=i,c[3]=e,c[4]=t,c[5]=s,c[6]=l):(s=c[5],l=c[6]),(0,o.useEffect)(s,l)}let l=200,c="cubic-bezier(0.175, 0.885, 0.32, 1.1)"},"./src/next-devtools/dev-overlay/components/errors/dialog/body.tsx"(e,t,r){"use strict";r.d(t,{J:()=>s,a:()=>i});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/next-devtools/dev-overlay/components/dialog/index.ts");function i(e){let t,r=(0,o.c)(2),{children:i}=e;return r[0]!==i?(t=(0,n.jsx)(a.R4,{className:"nextjs-container-errors-body",children:i}),r[0]=i,r[1]=t):t=r[1],t}let s=`
  [data-nextjs-dialog-body] {
    padding-left: 20px;
    padding-right: 20px;
    padding-bottom: 20px;
  }
`},"./src/next-devtools/dev-overlay/components/errors/dialog/dialog.tsx"(e,t,r){"use strict";r.d(t,{P:()=>l,s:()=>c});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js");let i=["[data-next-mark]","[data-issues-open]","#nextjs-dev-tools-menu","[data-nextjs-error-overlay-nav]","[data-nextjs-error-overlay-tab-bar]","[data-info-popover]","[data-nextjs-devtools-panel-overlay]","[data-nextjs-devtools-panel-footer]"],s=function(e){var t;let r,s,l,c,u,d,f,p,h,m,g,v,x,y,b,w,_=(0,o.c)(23);_[0]!==e?({children:l,className:c,onClose:u,"aria-labelledby":s,"aria-describedby":r,...d}=e,_[0]=e,_[1]=r,_[2]=s,_[3]=l,_[4]=c,_[5]=u,_[6]=d):(r=_[1],s=_[2],l=_[3],c=_[4],u=_[5],d=_[6]);let k=a.useRef(null),[j,S]=a.useState("undefined"!=typeof document&&document.hasFocus()?"dialog":void 0);return _[7]!==u?(f=e=>(e.preventDefault(),u?.()),_[7]=u,_[8]=f):f=_[8],t=f,(w=(0,o.c)(5))[0]!==i||w[1]!==k||w[2]!==t?(y=()=>{let e=k&&"current"in k?k.current:k;if(null==e||null==t)return;let r=r=>{!e||e.contains(r.target)||i.some(e=>r.target.closest(e))||t(r)},n=e.getRootNode();return n.addEventListener("mouseup",r),n.addEventListener("touchend",r,{passive:!1}),function(){n.removeEventListener("mouseup",r),n.removeEventListener("touchend",r)}},b=[t,k,i],w[0]=i,w[1]=k,w[2]=t,w[3]=y,w[4]=b):(y=w[3],b=w[4]),a.useEffect(y,b),_[9]===Symbol.for("react.memo_cache_sentinel")?(p=()=>{if(null==k.current)return;let e=function(){S(document.hasFocus()?"dialog":void 0)};return window.addEventListener("focus",e),window.addEventListener("blur",e),()=>{window.removeEventListener("focus",e),window.removeEventListener("blur",e)}},h=[],_[9]=p,_[10]=h):(p=_[9],h=_[10]),a.useEffect(p,h),_[11]===Symbol.for("react.memo_cache_sentinel")?(m=()=>{let e=k.current,t=e?.getRootNode(),r=t instanceof ShadowRoot?t?.activeElement:null;return e?.focus(),()=>{e?.blur(),r?.focus()}},g=[],_[11]=m,_[12]=g):(m=_[11],g=_[12]),a.useEffect(m,g),_[13]!==u?(v=e=>{"Escape"===e.key&&u?.()},_[13]=u,_[14]=v):v=_[14],_[15]!==r||_[16]!==s||_[17]!==l||_[18]!==c||_[19]!==d||_[20]!==j||_[21]!==v?(x=(0,n.jsx)("div",{ref:k,tabIndex:-1,"data-nextjs-dialog":!0,"data-nextjs-scrollable-content":!0,role:j,"aria-labelledby":s,"aria-describedby":r,"aria-modal":"true",className:c,onKeyDown:v,...d,children:l}),_[15]=r,_[16]=s,_[17]=l,_[18]=c,_[19]=d,_[20]=j,_[21]=v,_[22]=x):x=_[22],x};function l(e){let t,r,a,i,l=(0,o.c)(8);return l[0]!==e?({children:t,onClose:r,...a}=e,l[0]=e,l[1]=t,l[2]=r,l[3]=a):(t=l[1],r=l[2],a=l[3]),l[4]!==t||l[5]!==r||l[6]!==a?(i=(0,n.jsx)("div",{className:"error-overlay-dialog-container",children:(0,n.jsx)(s,{"aria-labelledby":"nextjs__container_errors_label","aria-describedby":"nextjs__container_errors_desc",className:"error-overlay-dialog-scroll",onClose:r,...a,children:t})}),l[4]=t,l[5]=r,l[6]=a,l[7]=i):i=l[7],i}let c=`
  .error-overlay-dialog-container {
    display: flex;
    flex-direction: column;
    background: var(--color-background-100);
    background-clip: padding-box;
    border-radius: var(--next-dialog-radius);
    box-shadow: var(--shadow-menu);
    position: relative;
    overflow: hidden;
  }

  .error-overlay-dialog-scroll {
    overflow-y: auto;
    scrollbar-gutter: stable;
    height: 100%;
  }
`},"./src/next-devtools/dev-overlay/components/errors/dialog/header.tsx"(e,t,r){"use strict";r.d(t,{q:()=>i,M:()=>s});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js");function a(e){let t,r=(0,o.c)(2);return r[0]!==e?(t=(0,n.jsx)("div",{"data-nextjs-dialog-header":!0,...e,children:e.children}),r[0]=e,r[1]=t):t=r[1],t}function i(e){let t,r=(0,o.c)(2),{children:i}=e;return r[0]!==i?(t=(0,n.jsx)(a,{className:"nextjs-container-errors-header",children:i}),r[0]=i,r[1]=t):t=r[1],t}let s=`
  .nextjs-container-errors-header {
    position: relative;
  }
  [data-nextjs-dialog-content] > .nextjs-container-errors-header {
    margin-bottom: 0;
  }
  .nextjs-container-errors-header > h1 {
    font-size: var(--size-20);
    line-height: var(--size-24);
    font-weight: bold;
    margin: calc(16px * 1.5) 0;
    color: var(--color-title-h1);
  }
  .nextjs-container-errors-header small {
    font-size: var(--size-14);
    color: var(--color-accents-1);
    margin-left: 16px;
  }
  .nextjs-container-errors-header small > span {
    font-family: var(--font-stack-monospace);
  }
  .nextjs-container-errors-header > div > small {
    margin: 0;
    margin-top: 4px;
  }
  .nextjs-container-errors-header > p > a {
    font-weight: 600;
  }
  .nextjs-container-errors-header
    > .nextjs-container-build-error-version-status {
    position: absolute;
    top: 16px;
    right: 16px;
  }
`},"./src/next-devtools/dev-overlay/components/errors/environment-name-label/environment-name-label.tsx"(e,t,r){"use strict";r.d(t,{F:()=>a,o:()=>i});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js");function a(e){let t,r=(0,o.c)(2),{environmentName:a}=e;return r[0]!==a?(t=(0,n.jsx)("span",{"data-nextjs-environment-name-label":!0,children:a}),r[0]=a,r[1]=t):t=r[1],t}let i=`
  [data-nextjs-environment-name-label] {
    padding: 2px 6px;
    margin: 0;
    border-radius: var(--rounded-md-2);
    background: var(--color-gray-100);
    font-weight: 600;
    font-size: var(--size-12);
    color: var(--color-gray-900);
    font-family: var(--font-stack-monospace);
    line-height: var(--size-20);
  }
`},"./src/next-devtools/dev-overlay/components/errors/error-overlay-call-stack/error-overlay-call-stack.tsx"(e,t,r){"use strict";r.d(t,{d:()=>i});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/index.js"),a=r("./src/next-devtools/dev-overlay/components/call-stack/call-stack.tsx");function i({frames:e,dialogResizerRef:t}){let r=(0,o.useRef)(NaN),[i,s]=(0,o.useState)(!1),l=(0,o.useMemo)(()=>e.reduce((e,t)=>e+ +!!t.ignored,0),[e]);return(0,n.jsx)(a.N,{frames:e,isIgnoreListOpen:i,onToggleIgnoreList:function(){let e=t?.current;if(i){if(!e)return void s(!1);let{height:t}=e.getBoundingClientRect();r.current||(r.current=t),e.style.height=`${r.current}px`,e.addEventListener("transitionend",function t(){e.removeEventListener("transitionend",t),s(!1)})}else{if(e){let{height:t}=e.getBoundingClientRect();r.current||(r.current=t)}s(!0)}},ignoredFramesTally:l})}},"./src/next-devtools/dev-overlay/components/errors/error-overlay-layout/error-overlay-layout.tsx"(e,t,r){"use strict";r.d(t,{V:()=>R,R:()=>P});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js"),i=r("./src/next-devtools/dev-overlay/components/dialog/index.ts"),s=r("./src/next-devtools/dev-overlay/components/copy-button/index.tsx");function l(e){let t,r,a,i,s,l,c,u,d,f,p,h,m,g=(0,o.c)(14);return g[0]===Symbol.for("react.memo_cache_sentinel")?(t={maskType:"luminance"},g[0]=t):t=g[0],g[1]===Symbol.for("react.memo_cache_sentinel")?(r=(0,n.jsx)("mask",{id:"nodejs_icon_mask_a",style:t,maskUnits:"userSpaceOnUse",x:"0",y:"0",width:"14",height:"14",children:(0,n.jsx)("path",{d:"M6.67.089 1.205 3.256a.663.663 0 0 0-.33.573v6.339c0 .237.126.455.33.574l5.466 3.17a.66.66 0 0 0 .66 0l5.465-3.17a.664.664 0 0 0 .329-.574V3.829a.663.663 0 0 0-.33-.573L7.33.089a.663.663 0 0 0-.661 0",fill:"#fff"})}),g[1]=r):r=g[1],g[2]===Symbol.for("react.memo_cache_sentinel")?(a=(0,n.jsx)("g",{mask:"url(#nodejs_icon_mask_a)",children:(0,n.jsx)("path",{d:"M18.648 2.717 3.248-4.86-4.648 11.31l15.4 7.58 7.896-16.174z",fill:"url(#nodejs_icon_linear_gradient_b)"})}),g[2]=a):a=g[2],g[3]===Symbol.for("react.memo_cache_sentinel")?(i={maskType:"luminance"},g[3]=i):i=g[3],g[4]===Symbol.for("react.memo_cache_sentinel")?(s=(0,n.jsx)("mask",{id:"nodejs_icon_mask_c",style:i,maskUnits:"userSpaceOnUse",x:"1",y:"0",width:"12",height:"14",children:(0,n.jsx)("path",{d:"M1.01 10.57a.663.663 0 0 0 .195.17l4.688 2.72.781.45a.66.66 0 0 0 .51.063l5.764-10.597a.653.653 0 0 0-.153-.122L9.216 1.18 7.325.087a.688.688 0 0 0-.171-.07L1.01 10.57z",fill:"#fff"})}),g[4]=s):s=g[4],g[5]===Symbol.for("react.memo_cache_sentinel")?(l=(0,n.jsx)("g",{mask:"url(#nodejs_icon_mask_c)",children:(0,n.jsx)("path",{d:"M-5.647 4.958 5.226 19.734l14.38-10.667L8.734-5.71-5.647 4.958z",fill:"url(#nodejs_icon_linear_gradient_d)"})}),g[5]=l):l=g[5],g[6]===Symbol.for("react.memo_cache_sentinel")?(c={maskType:"luminance"},g[6]=c):c=g[6],g[7]===Symbol.for("react.memo_cache_sentinel")?(u=(0,n.jsx)("mask",{id:"nodejs_icon_mask_e",style:c,maskUnits:"userSpaceOnUse",x:"1",y:"0",width:"13",height:"14",children:(0,n.jsx)("path",{d:"M6.934.004A.665.665 0 0 0 6.67.09L1.22 3.247l5.877 10.746a.655.655 0 0 0 .235-.08l5.465-3.17a.665.665 0 0 0 .319-.453L7.126.015a.684.684 0 0 0-.189-.01",fill:"#fff"})}),g[7]=u):u=g[7],g[8]===Symbol.for("react.memo_cache_sentinel")?(d=(0,n.jsxs)("g",{children:[u,(0,n.jsx)("g",{mask:"url(#nodejs_icon_mask_e)",children:(0,n.jsx)("path",{d:"M1.22.002v13.992h11.894V.002H1.22z",fill:"url(#nodejs_icon_linear_gradient_f)"})})]}),g[8]=d):d=g[8],g[9]===Symbol.for("react.memo_cache_sentinel")?(f=(0,n.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_b",x1:"10.943",y1:"-1.084",x2:"2.997",y2:"15.062",gradientUnits:"userSpaceOnUse",children:[(0,n.jsx)("stop",{offset:".3",stopColor:"#3E863D"}),(0,n.jsx)("stop",{offset:".5",stopColor:"#55934F"}),(0,n.jsx)("stop",{offset:".8",stopColor:"#5AAD45"})]}),g[9]=f):f=g[9],g[10]===Symbol.for("react.memo_cache_sentinel")?(p=(0,n.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_d",x1:"-.145",y1:"12.431",x2:"14.277",y2:"1.818",gradientUnits:"userSpaceOnUse",children:[(0,n.jsx)("stop",{offset:".57",stopColor:"#3E863D"}),(0,n.jsx)("stop",{offset:".72",stopColor:"#619857"}),(0,n.jsx)("stop",{offset:"1",stopColor:"#76AC64"})]}),g[10]=p):p=g[10],g[11]===Symbol.for("react.memo_cache_sentinel")?(h=(0,n.jsxs)("defs",{children:[f,p,(0,n.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_f",x1:"1.225",y1:"6.998",x2:"13.116",y2:"6.998",gradientUnits:"userSpaceOnUse",children:[(0,n.jsx)("stop",{offset:".16",stopColor:"#6BBF47"}),(0,n.jsx)("stop",{offset:".38",stopColor:"#79B461"}),(0,n.jsx)("stop",{offset:".47",stopColor:"#75AC64"}),(0,n.jsx)("stop",{offset:".7",stopColor:"#659E5A"}),(0,n.jsx)("stop",{offset:".9",stopColor:"#3E863D"})]})]}),g[11]=h):h=g[11],g[12]!==e?(m=(0,n.jsxs)("svg",{width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e,children:[r,a,s,l,d,h]}),g[12]=e,g[13]=m):m=g[13],m}function c(e){let t,r,a,i,s,l,c,u,d,f,p,h,m,g=(0,o.c)(14);return g[0]===Symbol.for("react.memo_cache_sentinel")?(t={maskType:"luminance"},g[0]=t):t=g[0],g[1]===Symbol.for("react.memo_cache_sentinel")?(r=(0,n.jsx)("mask",{id:"nodejs_icon_mask_a",style:t,maskUnits:"userSpaceOnUse",x:"0",y:"0",width:"14",height:"14",children:(0,n.jsx)("path",{d:"M6.67.089 1.205 3.256a.663.663 0 0 0-.33.573v6.339c0 .237.126.455.33.574l5.466 3.17a.66.66 0 0 0 .66 0l5.465-3.17a.664.664 0 0 0 .329-.574V3.829a.663.663 0 0 0-.33-.573L7.33.089a.663.663 0 0 0-.661 0",fill:"#fff"})}),g[1]=r):r=g[1],g[2]===Symbol.for("react.memo_cache_sentinel")?(a=(0,n.jsx)("g",{mask:"url(#nodejs_icon_mask_a)",children:(0,n.jsx)("path",{d:"M18.648 2.717 3.248-4.86-4.646 11.31l15.399 7.58 7.896-16.174z",fill:"url(#nodejs_icon_linear_gradient_b)"})}),g[2]=a):a=g[2],g[3]===Symbol.for("react.memo_cache_sentinel")?(i={maskType:"luminance"},g[3]=i):i=g[3],g[4]===Symbol.for("react.memo_cache_sentinel")?(s=(0,n.jsx)("mask",{id:"nodejs_icon_mask_c",style:i,maskUnits:"userSpaceOnUse",x:"1",y:"0",width:"12",height:"15",children:(0,n.jsx)("path",{d:"M1.01 10.571a.66.66 0 0 0 .195.172l4.688 2.718.781.451a.66.66 0 0 0 .51.063l5.764-10.597a.653.653 0 0 0-.153-.122L9.216 1.181 7.325.09a.688.688 0 0 0-.171-.07L1.01 10.572z",fill:"#fff"})}),g[4]=s):s=g[4],g[5]===Symbol.for("react.memo_cache_sentinel")?(l=(0,n.jsx)("g",{mask:"url(#nodejs_icon_mask_c)",children:(0,n.jsx)("path",{d:"M-5.647 4.96 5.226 19.736 19.606 9.07 8.734-5.707-5.647 4.96z",fill:"url(#nodejs_icon_linear_gradient_d)"})}),g[5]=l):l=g[5],g[6]===Symbol.for("react.memo_cache_sentinel")?(c={maskType:"luminance"},g[6]=c):c=g[6],g[7]===Symbol.for("react.memo_cache_sentinel")?(u=(0,n.jsx)("mask",{id:"nodejs_icon_mask_e",style:c,maskUnits:"userSpaceOnUse",x:"1",y:"0",width:"13",height:"14",children:(0,n.jsx)("path",{d:"M6.935.003a.665.665 0 0 0-.264.085l-5.45 3.158 5.877 10.747a.653.653 0 0 0 .235-.082l5.465-3.17a.665.665 0 0 0 .319-.452L7.127.014a.684.684 0 0 0-.189-.01",fill:"#fff"})}),g[7]=u):u=g[7],g[8]===Symbol.for("react.memo_cache_sentinel")?(d=(0,n.jsxs)("g",{children:[u,(0,n.jsx)("g",{mask:"url(#nodejs_icon_mask_e)",children:(0,n.jsx)("path",{d:"M1.222.001v13.992h11.893V0H1.222z",fill:"url(#nodejs_icon_linear_gradient_f)"})})]}),g[8]=d):d=g[8],g[9]===Symbol.for("react.memo_cache_sentinel")?(f=(0,n.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_b",x1:"10.944",y1:"-1.084",x2:"2.997",y2:"15.062",gradientUnits:"userSpaceOnUse",children:[(0,n.jsx)("stop",{offset:".3",stopColor:"#676767"}),(0,n.jsx)("stop",{offset:".5",stopColor:"#858585"}),(0,n.jsx)("stop",{offset:".8",stopColor:"#989A98"})]}),g[9]=f):f=g[9],g[10]===Symbol.for("react.memo_cache_sentinel")?(p=(0,n.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_d",x1:"-.145",y1:"12.433",x2:"14.277",y2:"1.819",gradientUnits:"userSpaceOnUse",children:[(0,n.jsx)("stop",{offset:".57",stopColor:"#747474"}),(0,n.jsx)("stop",{offset:".72",stopColor:"#707070"}),(0,n.jsx)("stop",{offset:"1",stopColor:"#929292"})]}),g[10]=p):p=g[10],g[11]===Symbol.for("react.memo_cache_sentinel")?(h=(0,n.jsxs)("defs",{children:[f,p,(0,n.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_f",x1:"1.226",y1:"6.997",x2:"13.117",y2:"6.997",gradientUnits:"userSpaceOnUse",children:[(0,n.jsx)("stop",{offset:".16",stopColor:"#878787"}),(0,n.jsx)("stop",{offset:".38",stopColor:"#A9A9A9"}),(0,n.jsx)("stop",{offset:".47",stopColor:"#A5A5A5"}),(0,n.jsx)("stop",{offset:".7",stopColor:"#8F8F8F"}),(0,n.jsx)("stop",{offset:".9",stopColor:"#626262"})]})]}),g[11]=h):h=g[11],g[12]!==e?(m=(0,n.jsxs)("svg",{width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e,children:[r,a,s,l,d,h]}),g[12]=e,g[13]=m):m=g[13],m}function u({defaultDevtoolsFrontendUrl:e}){let[t,r,o]=(0,a.useActionState)(async()=>{try{let e=await fetch("/__nextjs_attach-nodejs-inspector",{method:"POST"});if(!e.ok)throw Error(`${e.status} ${e.statusText}: ${await e.text()}`);let t=await e.json();return{status:"fulfilled",value:t}}catch(e){return{status:"rejected",reason:Error("Failed to attach Node.js inspector: "+String(e))}}},{status:"fulfilled",value:e}),i="fulfilled"===t.status?t.value:void 0;(0,a.useEffect)(()=>{"rejected"===t.status&&console.error(t.reason)},[t]);let u=a.startTransition.bind(null,r);return void 0===i?(0,n.jsx)("button",{className:"nodejs-inspector-button","data-pending":o,onClick:o?void 0:u,title:"rejected"===t.status?"Retry attaching Node.js inspector":"Attach Node.js inspector",children:(0,n.jsx)(c,{className:"error-overlay-toolbar-button-icon",width:14,height:14})}):(0,n.jsx)(s.i8,{"data-nextjs-data-runtime-error-copy-devtools-url":!0,className:"nodejs-inspector-button",actionLabel:"Copy DevTools URL for Chrome",successLabel:"Copied",content:i,icon:(0,n.jsx)(l,{className:"error-overlay-toolbar-button-icon",width:14,height:14})})}function d(e){let t,r=(0,o.c)(3),{error:a,generateErrorInfo:i}=e,l=!a;return r[0]!==i||r[1]!==l?(t=(0,n.jsx)(s.i8,{"data-nextjs-data-runtime-error-copy-stack":!0,className:"copy-error-button",actionLabel:"Copy Error Info",successLabel:"Error Info Copied",getContent:i,disabled:l}),r[0]=i,r[1]=l,r[2]=t):t=r[2],t}var f=r("./src/next-devtools/shared/react-19-hydration-error.ts");let p=["https://nextjs.org","https://react.dev"];function h(e){return p.some(t=>e.startsWith(t))}function m(e){let t,r,a,i=(0,o.c)(6),{errorMessage:s}=e;i[0]!==s?(t=function(e){let t,r=(t=Array.from(e.matchAll(/https?:\/\/[^\s/$.?#].[^\s)'"]*/gi),e=>e[0]),h?t.filter(e=>h(e)):t);if(0===r.length)return null;let n=r[0];return n===f.rz?f.Gg:n}(s),i[0]=s,i[1]=t):t=i[1];let l=t;if(!l){let e;return i[2]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("button",{title:"No related documentation found","aria-label":"No related documentation found",className:"docs-link-button",disabled:!0,children:(0,n.jsx)(g,{className:"error-overlay-toolbar-button-icon",width:14,height:14})}),i[2]=e):e=i[2],e}return i[3]===Symbol.for("react.memo_cache_sentinel")?(r=(0,n.jsx)(g,{className:"error-overlay-toolbar-button-icon",width:14,height:14}),i[3]=r):r=i[3],i[4]!==l?(a=(0,n.jsx)("a",{title:"Go to related documentation","aria-label":"Go to related documentation",className:"docs-link-button",href:l,target:"_blank",rel:"noopener noreferrer",children:r}),i[4]=l,i[5]=a):a=i[5],a}function g(e){let t,r,a=(0,o.c)(3);return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M0 .875h4.375C5.448.875 6.401 1.39 7 2.187A3.276 3.276 0 0 1 9.625.875H14v11.156H9.4c-.522 0-1.023.208-1.392.577l-.544.543h-.928l-.544-.543c-.369-.37-.87-.577-1.392-.577H0V.875zm6.344 3.281a1.969 1.969 0 0 0-1.969-1.968H1.312v8.53H4.6c.622 0 1.225.177 1.744.502V4.156zm1.312 7.064V4.156c0-1.087.882-1.968 1.969-1.968h3.063v8.53H9.4c-.622 0-1.225.177-1.744.502z",fill:"currentColor"}),a[0]=t):t=a[0],a[1]!==e?(r=(0,n.jsx)("svg",{width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e,children:t}),a[1]=e,a[2]=r):r=a[2],r}function v(e){let t,r,a,i,s=(0,o.c)(12),{error:l,debugInfo:c,generateErrorInfo:f}=e;s[0]!==l||s[1]!==f?(t=(0,n.jsx)(d,{error:l,generateErrorInfo:f}),s[0]=l,s[1]=f,s[2]=t):t=s[2],s[3]!==l.message?(r=(0,n.jsx)(m,{errorMessage:l.message}),s[3]=l.message,s[4]=r):r=s[4];let p=c?.devtoolsFrontendUrl,h=c?.devtoolsFrontendUrl;return s[5]!==p||s[6]!==h?(a=(0,n.jsx)(u,{defaultDevtoolsFrontendUrl:h},p),s[5]=p,s[6]=h,s[7]=a):a=s[7],s[8]!==t||s[9]!==r||s[10]!==a?(i=(0,n.jsxs)("span",{className:"error-overlay-toolbar",children:[t,r,a]}),s[8]=t,s[9]=r,s[10]=a,s[11]=i):i=s[11],i}let x=`
  .error-overlay-toolbar {
    display: flex;
    gap: 6px;
  }

  @media (max-width: 575px) {
    .error-overlay-toolbar {
      gap: 4px;
    }
  }

  .nodejs-inspector-button,
  .copy-error-button,
  .docs-link-button {
    display: flex;
    justify-content: center;
    align-items: center;

    width: var(--size-24);
    height: var(--size-24);
    background: none;
    border: none;
    border-radius: var(--rounded-full);

    svg {
      width: var(--size-14);
      height: var(--size-14);
    }

    &:focus {
      outline: var(--focus-ring);
    }

    &:not(:disabled):hover {
      background: var(--color-gray-alpha-100);
    }

    &:not(:disabled):active {
      background: var(--color-gray-alpha-200);
    }

    &:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  }

  .nodejs-inspector-button[data-pending='true'] {
    cursor: wait;
  }

  .error-overlay-toolbar-button-icon {
    color: var(--color-gray-900);
  }
`;function y(e){let t,r,i,s,l,c=(0,o.c)(12),{errorMessage:u,errorType:d}=e,[f,p]=(0,a.useState)(!1),[h,m]=(0,a.useState)(!1),g=(0,a.useRef)(null);if(c[0]===Symbol.for("react.memo_cache_sentinel")?(t=()=>{g.current&&m(g.current.scrollHeight>200)},c[0]=t):t=c[0],c[1]!==u?(r=[u],c[1]=u,c[2]=r):r=c[2],(0,a.useLayoutEffect)(t,r),!u)return null;let v="Instant"===d||"Blocking Route"===d||"Static Route"===d,x=h&&!v,y=`nextjs__container_errors_desc ${x&&!f?"truncated":""} ${v?"nextjs__container_errors_desc_instant":""}`;return c[3]!==u||c[4]!==y?(i=(0,n.jsx)("div",{className:"nextjs__container_errors_wrapper",children:(0,n.jsx)("div",{ref:g,id:"nextjs__container_errors_desc",className:y,children:u})}),c[3]=u,c[4]=y,c[5]=i):i=c[5],c[6]!==f||c[7]!==x?(s=x&&!f&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("div",{className:"nextjs__container_errors_gradient_overlay"}),(0,n.jsx)("button",{onClick:()=>p(!0),className:"nextjs__container_errors_expand_button","aria-expanded":f,"aria-controls":"nextjs__container_errors_desc",children:"Show More"})]}),c[6]=f,c[7]=x,c[8]=s):s=c[8],c[9]!==i||c[10]!==s?(l=(0,n.jsxs)(n.Fragment,{children:[i,s]}),c[9]=i,c[10]=s,c[11]=l):l=c[11],l}let b=`
  .nextjs__container_errors_wrapper {
  }

  .nextjs__container_errors_desc {
    margin: 0;
    color: var(--color-red-900);
    font-weight: 500;
    font-size: var(--size-16);
    letter-spacing: -0.32px;
    line-height: var(--size-24);
    overflow-wrap: break-word;
    white-space: pre-wrap;
  }

  .nextjs__container_errors_desc.nextjs__container_errors_desc_instant {
    color: var(--color-gray-1000);
  }

  .nextjs__container_errors_desc.truncated {
    max-height: 200px;
    overflow: hidden;
  }

  .nextjs__container_errors_desc code {
    font-family: var(--font-stack-monospace);
    font-weight: 500;
    line-height: var(--size-20);
    color: var(--color-gray-1000);
    padding: 2px 6px;
    background: var(--color-background-200);
    border: 1px solid var(--color-gray-200);
    border-radius: var(--rounded-md-2);
  }

  .nextjs__container_errors_gradient_overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 85px;
    background: linear-gradient(
      180deg,
      rgba(250, 250, 250, 0) 0%,
      var(--color-background-100) 100%
    );
  }

  .nextjs__container_errors_expand_button {
    position: absolute;
    bottom: 10px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    align-items: center;
    padding: 6px 12px;
    background: var(--color-background-100);
    border: none;
    border-radius: var(--rounded-full);
    box-shadow:
      0px 2px 2px var(--color-gray-alpha-100),
      0px 8px 8px -8px var(--color-gray-alpha-100),
      0px 0px 0px 1px var(--color-gray-alpha-400);
    font-size: var(--size-13);
    cursor: pointer;
    color: var(--color-gray-900);
    font-weight: 500;
    transition: background-color 0.2s ease;
  }

  .nextjs__container_errors_expand_button:hover {
    background: var(--color-gray-100);
  }
`;function w(e){let t,r=(0,o.c)(3),{errorType:a}=e,i=`nextjs__container_errors_label ${"Ambiguous Metadata"===a?"nextjs__container_errors_label_blocking_page":""} ${"Instant"===a?"nextjs__container_errors_label_instant":""}`;return r[0]!==a||r[1]!==i?(t=(0,n.jsx)("span",{id:"nextjs__container_errors_label",className:i,children:a}),r[0]=a,r[1]=i,r[2]=t):t=r[2],t}let _=`
  .nextjs__container_errors_label {
    padding: 2px 6px;
    margin: 0;
    border-radius: var(--rounded-md-2);
    background: var(--color-red-100);
    font-weight: 600;
    font-size: var(--size-12);
    color: var(--color-red-900);
    font-family: var(--font-stack-monospace);
    line-height: var(--size-20);
  }

  .nextjs__container_errors_label_blocking_page {
    background: var(--color-blue-100);
    color: var(--color-blue-900);
  }

  .nextjs__container_errors_label_instant {
    background: var(--color-amber-200);
    color: var(--color-amber-900);
  }
`;var k=r("./src/next-devtools/dev-overlay/components/errors/error-overlay-nav/error-overlay-nav.tsx"),j=r("./src/next-devtools/dev-overlay/components/errors/dialog/dialog.tsx"),S=r("./src/next-devtools/dev-overlay/components/errors/dialog/header.tsx"),C=r("./src/next-devtools/dev-overlay/components/errors/dialog/body.tsx"),E=r("./src/next-devtools/dev-overlay/components/errors/overlay/overlay.tsx"),T=r("./src/next-devtools/dev-overlay/components/errors/environment-name-label/environment-name-label.tsx"),N=r("./src/next-devtools/dev-overlay/components/errors/dev-tools-indicator/utils.ts"),I=r("./src/next-devtools/dev-overlay/components/resizer/index.tsx"),z=r("./src/next-devtools/dev-overlay/components/overlay/index.tsx");function R(e){let t,r,s,l,c,u,d,f,p,h,m,g,x,b,_,R,P,L,O,M=(0,o.c)(61),{errorMessage:A,errorType:D,children:F,headerChildren:$,renderTabBar:U,canGoPrevious:Z,canGoNext:q,onPrevious:B,onNext:V,error:H,debugInfo:W,isBuildError:G,onClose:K,versionInfo:Y,runtimeErrors:X,activeIdx:Q,setActiveIndex:J,dialogResizerRef:ee,generateErrorInfo:et,rendered:er,transitionDurationMs:en}=e,eo=void 0===er||er,ea=`${en}ms`;M[0]!==ea?(t={"--transition-duration":ea},M[0]=ea,M[1]=t):t=M[1];let ei=t;M[2]!==eo||M[3]!==ei?(r={"data-rendered":eo,style:ei},M[2]=eo,M[3]=ei,M[4]=r):r=M[4];let es=r,[el,ec]=a.useState(!!en),eu=a.useRef(null);(0,N.rM)(eu,null,eo),M[5]===Symbol.for("react.memo_cache_sentinel")?(s=function(e){let{propertyName:t,target:r}=e;"scale"===t&&r===eu.current&&ec(!1)},M[5]=s):s=M[5];let ed=s;M[6]!==G?(l=(0,n.jsx)(z.D,{fixed:G}),M[6]=G,M[7]=l):l=M[7],M[8]!==Q||M[9]!==q||M[10]!==Z||M[11]!==V||M[12]!==B||M[13]!==U||M[14]!==X||M[15]!==J||M[16]!==Y?(c=(0,n.jsx)(k.s,{runtimeErrors:X,activeIdx:Q,setActiveIndex:J,canGoPrevious:Z,canGoNext:q,onPrevious:B,onNext:V,versionInfo:Y,renderTabBar:U}),M[8]=Q,M[9]=q,M[10]=Z,M[11]=V,M[12]=B,M[13]=U,M[14]=X,M[15]=J,M[16]=Y,M[17]=c):c=M[17];let ef=!el;return M[18]!==D?(u=(0,n.jsx)(w,{errorType:D}),M[18]=D,M[19]=u):u=M[19],M[20]!==H.environmentName?(d=H.environmentName&&(0,n.jsx)(T.F,{environmentName:H.environmentName}),M[20]=H.environmentName,M[21]=d):d=M[21],M[22]!==u||M[23]!==d?(f=(0,n.jsxs)("span",{"data-nextjs-error-label-group":!0,children:[u,d]}),M[22]=u,M[23]=d,M[24]=f):f=M[24],M[25]!==W||M[26]!==H||M[27]!==et?(p=(0,n.jsx)(v,{error:H,debugInfo:W,generateErrorInfo:et}),M[25]=W,M[26]=H,M[27]=et,M[28]=p):p=M[28],M[29]!==f||M[30]!==p?(h=(0,n.jsxs)("div",{className:"nextjs__container_errors__error_title__row",children:[f,p]}),M[29]=f,M[30]=p,M[31]=h):h=M[31],M[32]!==A||M[33]!==D?(m=(0,n.jsx)(y,{errorMessage:A,errorType:D}),M[32]=A,M[33]=D,M[34]=m):m=M[34],M[35]!==h||M[36]!==m?(g=(0,n.jsxs)("div",{className:"nextjs__container_errors__error_title",children:[h,m]}),M[35]=h,M[36]=m,M[37]=g):g=M[37],M[38]!==$||M[39]!==g?(x=(0,n.jsxs)(S.q,{children:[g,$]}),M[38]=$,M[39]=g,M[40]=x):x=M[40],M[41]!==F?(b=(0,n.jsx)(C.a,{children:F}),M[41]=F,M[42]=b):b=M[42],M[43]!==x||M[44]!==b?(_=(0,n.jsxs)(i.Cf,{children:[x,b]}),M[43]=x,M[44]=b,M[45]=_):_=M[45],M[46]!==ee||M[47]!==_||M[48]!==ef?(R=(0,n.jsx)(I.L,{ref:ee,measure:ef,"data-nextjs-dialog-sizer":!0,children:_}),M[46]=ee,M[47]=_,M[48]=ef,M[49]=R):R=M[49],M[50]!==K||M[51]!==R?(P=(0,n.jsx)(j.P,{onClose:K,children:R}),M[50]=K,M[51]=R,M[52]=P):P=M[52],M[53]!==es||M[54]!==P||M[55]!==c?(L=(0,n.jsxs)("div",{"data-nextjs-dialog-root":!0,onTransitionEnd:ed,ref:eu,...es,children:[c,P]}),M[53]=es,M[54]=P,M[55]=c,M[56]=L):L=M[56],M[57]!==es||M[58]!==L||M[59]!==l?(O=(0,n.jsxs)(E.J,{...es,children:[l,L]}),M[57]=es,M[58]=L,M[59]=l,M[60]=O):O=M[60],O}let P=`
  ${E.q}
  ${j.s}
  ${S.M}
  ${C.J}

  ${k.R}
  ${_}
  ${b}
  ${x}

  [data-nextjs-error-label-group] {
    display: flex;
    align-items: center;
    gap: 8px;
    white-space: nowrap;
    flex-shrink: 0;
  }
`},"./src/next-devtools/dev-overlay/components/errors/error-overlay-nav/error-overlay-nav.tsx"(e,t,r){"use strict";r.d(t,{R:()=>c,s:()=>s});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/next-devtools/dev-overlay/components/errors/error-overlay-pagination/error-overlay-pagination.tsx"),i=r("./src/next-devtools/dev-overlay/components/version-staleness-info/version-staleness-info.tsx");function s(e){let t,r,s,c,d=(0,o.c)(16),{runtimeErrors:f,activeIdx:p,setActiveIndex:h,canGoPrevious:m,canGoNext:g,onPrevious:v,onNext:x,versionInfo:y,renderTabBar:b}=e,w=process.env.__NEXT_BUNDLER||"Turbopack";d[0]!==f?(t=f??[],d[0]=f,d[1]=t):t=d[1];let _=p??0,k=h??l;return d[2]!==g||d[3]!==m||d[4]!==x||d[5]!==v||d[6]!==b||d[7]!==t||d[8]!==_||d[9]!==k?(r=(0,n.jsx)(u,{side:"left",children:(0,n.jsx)(a.R,{runtimeErrors:t,activeIdx:_,onActiveIndexChange:k,canGoPrevious:m,canGoNext:g,onPrevious:v,onNext:x,renderTabBar:b})}),d[2]=g,d[3]=m,d[4]=x,d[5]=v,d[6]=b,d[7]=t,d[8]=_,d[9]=k,d[10]=r):r=d[10],d[11]!==y?(s=y&&(0,n.jsx)(u,{side:"right",children:(0,n.jsx)(i.T,{versionInfo:y,bundlerName:w})}),d[11]=y,d[12]=s):s=d[12],d[13]!==r||d[14]!==s?(c=(0,n.jsxs)("div",{"data-nextjs-error-overlay-nav":!0,children:[r,s]}),d[13]=r,d[14]=s,d[15]=c):c=d[15],c}function l(){}let c=`
  [data-nextjs-error-overlay-nav] {
    --stroke-color: var(--color-gray-400);
    --background-color: var(--color-background-100);
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;

    width: 100%;

    position: relative;
    z-index: 2;
    outline: none;
    translate: var(--next-dialog-border-width) var(--next-dialog-border-width);
    max-width: var(--next-dialog-max-width);

    .error-overlay-nav-item {
      translate: calc(var(--next-dialog-border-width) * -1);
      width: auto;
      padding: 12px;
      position: relative;

      &[data-side='left'] {
        padding-right: 0;
      }

      &[data-side='right'] {
        padding-left: 0;
      }
    }
  }

  @media (max-width: 767px) {
    [data-nextjs-error-overlay-nav] {
      flex-wrap: wrap;
      justify-content: flex-start;
      column-gap: 8px;
      row-gap: 0;
      box-sizing: border-box;
      padding: 6px 12px 12px;

      .error-overlay-nav-item {
        max-width: 100%;
        padding: 0;

        &[data-side='left'] {
          flex-grow: 1;
        }
      }

      .error-overlay-tab {
        white-space: nowrap;
      }
    }
  }

`;function u(e){let t,r=(0,o.c)(3),{children:a,side:i}=e,s=void 0===i?"left":i;return r[0]!==a||r[1]!==s?(t=(0,n.jsx)("div",{className:"error-overlay-nav-item","data-side":s,children:a}),r[0]=a,r[1]=s,r[2]=t):t=r[2],t}},"./src/next-devtools/dev-overlay/components/errors/error-overlay-pagination/error-overlay-pagination.tsx"(e,t,r){"use strict";r.d(t,{R:()=>l,i:()=>u});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js");function i(e){let t,r,a=(0,o.c)(4),{title:i,className:s}=e;return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M9.24996 12.0608L8.71963 11.5304L5.89641 8.70722C5.50588 8.3167 5.50588 7.68353 5.89641 7.29301L8.71963 4.46978L9.24996 3.93945L10.3106 5.00011L9.78029 5.53044L7.31062 8.00011L9.78029 10.4698L10.3106 11.0001L9.24996 12.0608Z",fill:"currentColor"}),a[0]=t):t=a[0],a[1]!==s||a[2]!==i?(r=(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg","aria-label":i,className:s,children:t}),a[1]=s,a[2]=i,a[3]=r):r=a[3],r}function s(e){let t,r,a=(0,o.c)(4),{title:i,className:s}=e;return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M6.75011 3.93945L7.28044 4.46978L10.1037 7.29301C10.4942 7.68353 10.4942 8.3167 10.1037 8.70722L7.28044 11.5304L6.75011 12.0608L5.68945 11.0001L6.21978 10.4698L8.68945 8.00011L6.21978 5.53044L5.68945 5.00011L6.75011 3.93945Z",fill:"currentColor"}),a[0]=t):t=a[0],a[1]!==s||a[2]!==i?(r=(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",className:s,"aria-label":i,children:t}),a[1]=s,a[2]=i,a[3]=r):r=a[3],r}function l(e){let t,r,l,u,d,f,p,h,m,g,v,x,y,b=(0,o.c)(36),{runtimeErrors:w,activeIdx:_,onActiveIndexChange:k,canGoPrevious:j,canGoNext:S,onPrevious:C,onNext:E,renderTabBar:T}=e;b[0]!==_||b[1]!==k?(t=()=>(0,a.startTransition)(()=>{_>0&&k(Math.max(0,_-1))}),b[0]=_,b[1]=k,b[2]=t):t=b[2];let N=t;b[3]!==_||b[4]!==k||b[5]!==w.length?(r=()=>(0,a.startTransition)(()=>{_<w.length-1&&k(Math.max(0,Math.min(w.length-1,_+1)))}),b[3]=_,b[4]=k,b[5]=w.length,b[6]=r):r=b[6];let I=r,z=j??_>0,R=S??_<w.length-1,P=C??N,L=E??I,O=(0,a.useRef)(null),M=(0,a.useRef)(null),[A,D]=(0,a.useState)(null);b[7]===Symbol.for("react.memo_cache_sentinel")?(l=e=>{D(e)},b[7]=l):l=b[7];let F=l;b[8]!==L||b[9]!==P||b[10]!==A?(u=()=>{if(null==A)return;let e=A.getRootNode(),t=self.document,r=function(e){"ArrowLeft"===e.key?(e.preventDefault(),e.stopPropagation(),P&&P()):"ArrowRight"===e.key&&(e.preventDefault(),e.stopPropagation(),L&&L())};return e.addEventListener("keydown",r),e!==t&&t.addEventListener("keydown",r),function(){e.removeEventListener("keydown",r),e!==t&&t.removeEventListener("keydown",r)}},d=[A,L,P],b[8]=L,b[9]=P,b[10]=A,b[11]=u,b[12]=d):(u=b[11],d=b[12]),(0,a.useEffect)(u,d),b[13]!==R||b[14]!==z||b[15]!==A?(f=()=>{if(null==A)return;let e=A.getRootNode();if(e instanceof ShadowRoot){let t=e.activeElement;z?!R&&M.current&&t===M.current&&M.current.blur():O.current&&t===O.current&&O.current.blur()}},p=[A,R,z],b[13]=R,b[14]=z,b[15]=A,b[16]=f,b[17]=p):(f=b[16],p=b[17]),(0,a.useEffect)(f,p);let $=!z,U=!z;b[18]===Symbol.for("react.memo_cache_sentinel")?(h=(0,n.jsx)(i,{title:"previous",className:"error-overlay-pagination-button-icon"}),b[18]=h):h=b[18],b[19]!==P||b[20]!==$||b[21]!==U?(m=(0,n.jsx)("button",{ref:O,type:"button",disabled:$,"aria-disabled":U,onClick:P,"data-nextjs-dialog-error-previous":!0,className:"error-overlay-pagination-button",children:h}),b[19]=P,b[20]=$,b[21]=U,b[22]=m):m=b[22];let Z=m,q=c,B=!R,V=!R;b[23]===Symbol.for("react.memo_cache_sentinel")?(g=(0,n.jsx)(s,{title:"next",className:"error-overlay-pagination-button-icon"}),b[23]=g):g=b[23],b[24]!==L||b[25]!==B||b[26]!==V?(v=(0,n.jsx)("button",{ref:M,type:"button",disabled:B,"aria-disabled":V,onClick:L,"data-nextjs-dialog-error-next":!0,className:"error-overlay-pagination-button",children:g}),b[24]=L,b[25]=B,b[26]=V,b[27]=v):v=b[27];let H=v;return b[28]!==_||b[29]!==H||b[30]!==Z||b[31]!==T||b[32]!==w.length?(x=T?T({previousButton:Z,createCount:q,nextButton:H}):(0,n.jsxs)(n.Fragment,{children:[Z,q(_,w.length||1),H]}),b[28]=_,b[29]=H,b[30]=Z,b[31]=T,b[32]=w.length,b[33]=x):x=b[33],b[34]!==x?(y=(0,n.jsx)("nav",{className:"error-overlay-pagination dialog-exclude-closing-from-outside-click",ref:F,children:x}),b[34]=x,b[35]=y):y=b[35],y}function c(e,t,r){let o=void 0===r||r;return(0,n.jsxs)("div",{className:"error-overlay-pagination-count",children:[(0,n.jsxs)("span",{...o?{"data-nextjs-dialog-error-index":e}:{},children:[0===t?0:e+1,"/"]}),(0,n.jsx)("span",{...o?{"data-nextjs-dialog-header-total-count":""}:{},children:t})]})}let u=`
  .error-overlay-pagination {
    -webkit-font-smoothing: antialiased;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 6px;
    width: fit-content;
  }

  @media (max-width: 575px) {
    .error-overlay-pagination {
      gap: 4px;
    }
  }

  .error-overlay-pagination-count {
    display: flex;
    align-items: center;
    color: inherit;
    text-align: center;
    font-size: var(--size-13);
    font-family: var(--font-mono);
    line-height: var(--size-16);
    font-variant-numeric: tabular-nums;
  }

  .error-overlay-pagination-button {
    display: flex;
    justify-content: center;
    align-items: center;

    width: var(--size-24);
    height: var(--size-24);
    background: none;
    flex-shrink: 0;

    border: none;
    border-radius: var(--rounded-full);

    svg {
      width: var(--size-16);
      height: var(--size-16);
    }

    &:focus-visible {
      outline: var(--focus-ring);
    }

    &:not(:disabled):hover {
      background: var(--color-gray-alpha-100);
    }

    &:not(:disabled):active {
      background: var(--color-gray-alpha-200);
    }

    &:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  }

  .error-overlay-pagination-button-icon {
    color: var(--color-gray-1000);
  }
`},"./src/next-devtools/dev-overlay/components/errors/overlay/overlay.tsx"(e,t,r){"use strict";r.d(t,{J:()=>s,q:()=>l});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/next-devtools/dev-overlay/utils/css.ts"),i=r("./src/next-devtools/dev-overlay/components/overlay/overlay.tsx");function s(e){let t,r,a,s=(0,o.c)(6);return s[0]!==e?({children:t,...r}=e,s[0]=e,s[1]=t,s[2]=r):(t=s[1],r=s[2]),s[3]!==t||s[4]!==r?(a=(0,n.jsx)(i.h,{...r,children:t}),s[3]=t,s[4]=r,s[5]=a):a=s[5],a}let l=(0,a.A)`
  [data-nextjs-dialog-overlay] {
    padding: initial;
    top: 10vh;
  }
`},"./src/next-devtools/dev-overlay/components/hot-linked-text/index.tsx"(e,t,r){"use strict";r.d(t,{E:()=>d});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js");function i(e){if(""===e.trim())throw Error("can't decode empty hex");let t=parseInt(e,16);if(isNaN(t))throw Error(`invalid hex: \`${e}\``);return String.fromCodePoint(t)}let s=/^__TURBOPACK__([a-zA-Z0-9_$]+)__$/,l=/__TURBOPACK__[a-zA-Z0-9_$]+__/g;function c(e){return e.replace(/\[project\]/g,".").replace(/\s\[([^\]]*)\]/g,"").replace(/\s\(([^)]*)\)/g,"").replace(/\s<([^>]*)>/g,"").trim()}let u=/https?:\/\/[^\s/$.?#].[^\s)'"]*/i,d=function(e){let t,r,d=(0,o.c)(7),{text:f,matcher:p}=e;if(d[0]!==p||d[1]!==f){let e,r=function(e){let t=e.replace(/\(0\s*,\s*(__TURBOPACK__[a-zA-Z0-9_$]+__\.[^\s)]+)\)/g,"$1"),r=[],n=0,o=RegExp(l.source,"g");for(let e=o.exec(t);null!==e;e=o.exec(t)){let a=e.index,l=o.lastIndex,u=e[0];if(a>n){let e=t.substring(n,a);r.push(["raw",e])}try{let e=function(e){let t=e.match(s);if(!t)return e;let r=t[1],n="",o=0,a="";for(let e=0;e<r.length;e++){let t=r[e];if(0===o)"_"===t?o=1:"$"===t?o=2:n+=t;else if(1===o)"_"===t?(n+=" ",o=0):"$"===t?(n+="_",o=2):(n+=t,o=0);else if(2===o)if(2===a.length&&(n+=i(a),a=""),"_"===t){if(""!==a)throw Error(`invalid hex: \`${a}\``);o=3}else if("$"===t){if(""!==a)throw Error(`invalid hex: \`${a}\``);o=0}else a+=t;else if(3===o)if("_"===t)throw Error(`invalid hex: \`${a+t}\``);else"$"===t?(n+=i(a),a="",o=0):a+=t}return n}(u);if(e!==u){let t=e.match(/^imported module (.+)$/);if(t){let e=t[1],n=c(e);r.push(["deobfuscated",`{imported module ${n}}`])}else{let t=c(e);r.push(["deobfuscated",`{${t}}`])}}else r.push(["raw",u])}catch(e){r.push(["deobfuscated",`{${u} (decoding failed: ${e})}`])}n=l}if(n<t.length){let e=t.substring(n);r.push(["raw",e])}return r}(f);d[3]!==p?(e=(e,t)=>{let[r,o]=e;if("raw"===r)return o.split(/(\s+|https?:\/\/[^\s/$.?#].[^\s)'"]*)/).map((e,r)=>{if(!u.test(e))return(0,n.jsx)(a.Fragment,{children:e},`text-${t}-${r}`);{let o=u.exec(e)[0],i=null;return"function"==typeof p&&null===(i=p(o))?(0,n.jsx)(a.Fragment,{children:e},`link-${t}-${r}`):(0,n.jsx)(a.Fragment,{children:(0,n.jsx)("a",{href:o,target:"_blank",rel:"noreferrer noopener",className:i||void 0,children:e})},`link-${t}-${r}`)}});if("deobfuscated"===r)return(0,n.jsx)("i",{children:o},`ident-${t}`);throw Error(`Unknown text part type: ${r}`)},d[3]=p,d[4]=e):e=d[4],t=r.map(e),d[0]=p,d[1]=f,d[2]=t}else t=d[2];return d[5]!==t?(r=(0,n.jsx)(n.Fragment,{children:t}),d[5]=t,d[6]=r):r=d[6],r}},"./src/next-devtools/dev-overlay/components/instant-navs/instant-nav-cookie.ts"(e,t,r){"use strict";let n;r.d(t,{pt:()=>c,Vi:()=>f,ON:()=>l});var o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js");function i(e){try{let t=JSON.parse(e);if(Array.isArray(t)&&t.length>=3){let e=t[2];if(null===e)return{state:"mpa"};if("object"==typeof e&&null!==e){let t=e.from??["",{}],r=e.to??null;return{state:"spa",fromTree:t,toTree:r}}return{state:"spa",fromTree:["",{}],toTree:null}}}catch{}return{state:"pending"}}let s="next-instant-navigation-testing";function l(){if("undefined"==typeof document)return null;let e=document.cookie.match(/next-instant-navigation-testing=([^;]*)/);return e?i(e[1]).state:null}function c(e){let t=[],r=e;for(;r;){let e=r[0],n=r[1];if("string"==typeof e)""===e||"__PAGE__"===e||"__DEFAULT__"===e||e.startsWith("(")&&e.endsWith(")")||t.push(e);else if(Array.isArray(e)){let r=e[0],n=e[2];"c"===n||n.startsWith("ci")?t.push(`[...${r}]`):"oc"===n?t.push(`[[...${r}]]`):t.push(`[${r}]`)}r=n?.children}return"/"+t.join("/")}function u(){if(void 0!==n)return n;if("undefined"==typeof document)return"";let e=document.cookie.match(/next-instant-navigation-testing=([^;]*)/);return e?e[1]:""}function d(e){if("undefined"==typeof cookieStore)return()=>{};function t(t){for(let r of t.changed)if(r.name===s){n=r.value??"",e();return}for(let r of t.deleted)if(r.name===s){n="",e();return}}return cookieStore.addEventListener("change",t),()=>{cookieStore.removeEventListener("change",t)}}function f(){let e,t=(0,o.c)(3),r=(0,a.useSyncExternalStore)(d,u);r:{let o;if(!r){e=null;break r}if(""!==r&&void 0===n&&"undefined"!=typeof self&&self.__next_instant_test){let r;t[0]===Symbol.for("react.memo_cache_sentinel")?(r={state:"mpa"},t[0]=r):r=t[0],e=r;break r}t[1]!==r?(o=i(r),t[1]=r,t[2]=o):o=t[2],e=o}return e}},"./src/next-devtools/dev-overlay/components/instant/instant-guidance-data.ts"(e,t,r){"use strict";r.d(t,{Ed:()=>n,Eg:()=>F,HI:()=>N,Ig:()=>$,Oq:()=>L,Rd:()=>I,Z8:()=>R,cV:()=>T,fK:()=>O,h6:()=>C,iJ:()=>P,nT:()=>z,vX:()=>S,zu:()=>E});let n={stream:{label:"Stream",color:"blue",icon:"align-left"},block:{label:"Block",color:"red",icon:"loading"},cache:{label:"Cache",color:"purple",icon:"database"},static:{label:"Static",color:"gray",icon:"zap"},dynamic:{label:"Dynamic",color:"blue",icon:"server-stack"},client:{label:"Client",color:"amber",icon:"layout"},defer:{label:"Defer",color:"amber",icon:"pointer-click"},measure:{label:"Measure",color:"gray",icon:"timer"},ignore:{label:"Ignore",color:"red",icon:"minus-circle"},render:{label:"Render",color:"gray",icon:"layout"},mark:{label:"Mark",color:"amber",icon:"check"},upgrade:{label:"Upgrade",color:"amber",icon:"arrow-up"},disable:{label:"Disable",color:"gray",icon:"minus"},remove:{label:"Remove",color:"red",icon:"minus"}},o=[{id:"wrap-in-or-move-into-suspense",title:"Wrap in or move into Suspense",group:"stream",link:"https://nextjs.org/docs/messages/instant-shell-url-data#wrap-in-or-move-into-suspense",snippets:[{text:"<Suspense fallback={…}>",highlight:!0},{text:"  <Details params={params} />"},{text:"</Suspense>",highlight:!0}],copyable:!0},{id:"allow-blocking-route",title:"Allow blocking route",group:"block",link:"https://nextjs.org/docs/messages/instant-shell-url-data#allow-blocking-route",snippets:[{text:"// page.tsx or layout.tsx"},{text:"export const instant = false",highlight:!0}],copyable:!0}],a=[{id:"wrap-in-or-move-into-suspense",title:"Wrap in or move into Suspense",group:"stream",link:"https://nextjs.org/docs/messages/instant-navigation-stage#wrap-in-or-move-into-suspense",snippets:[{text:"<Suspense fallback={…}>",highlight:!0},{text:"  <DataChild />"},{text:"</Suspense>",highlight:!0}],copyable:!0},{id:"allow-blocking-route",title:"Allow blocking route",group:"block",link:"https://nextjs.org/docs/messages/instant-navigation-stage#allow-blocking-route",snippets:[{text:"// page.tsx or layout.tsx"},{text:"export const instant = false",highlight:!0}],copyable:!0}],i=[{id:"wrap-in-or-move-into-suspense",title:"Wrap in or move into Suspense",group:"stream",link:"https://nextjs.org/docs/messages/blocking-prerender-runtime#wrap-in-or-move-into-suspense",snippets:[{text:"<Suspense fallback={…}>",highlight:!0},{text:"  <DataChild />"},{text:"</Suspense>",highlight:!0}],copyable:!0},{id:"allow-blocking-route",title:"Allow blocking route",group:"block",link:"https://nextjs.org/docs/messages/blocking-prerender-runtime#allow-blocking-route",snippets:[{text:"// page.tsx or layout.tsx"},{text:"export const instant = false",highlight:!0}],copyable:!0}],s=[{id:"wrap-in-or-move-into-suspense",title:"Wrap in or move into Suspense",group:"stream",link:"https://nextjs.org/docs/messages/blocking-prerender-client-hook#wrap-in-or-move-into-suspense",snippets:[{text:"<Suspense fallback={…}>",highlight:!0},{text:"  <SidebarNav />"},{text:"</Suspense>",highlight:!0}],copyable:!0},{id:"allow-blocking-route",title:"Allow blocking route",group:"block",link:"https://nextjs.org/docs/messages/blocking-prerender-client-hook#allow-blocking-route",snippets:[{text:"// page.tsx or layout.tsx"},{text:"export const instant = false",highlight:!0}],copyable:!0}],l=[{id:"wrap-in-or-move-into-suspense",title:"Wrap in or move into Suspense",group:"stream",link:"https://nextjs.org/docs/messages/blocking-prerender-dynamic#wrap-in-or-move-into-suspense",snippets:[{text:"<Suspense fallback={…}>",highlight:!0},{text:"  <DataChild />"},{text:"</Suspense>",highlight:!0}],copyable:!0},{id:"cache-the-component-or-data",title:"Cache the component or data",group:"cache",link:"https://nextjs.org/docs/messages/blocking-prerender-dynamic#cache-the-component-or-data",snippets:[{text:"async function Posts() {"},{text:'  "use cache"',highlight:!0},{text:"  return <List items={…} />"}],copyable:!0},{id:"allow-blocking-route",title:"Allow blocking route",group:"block",link:"https://nextjs.org/docs/messages/blocking-prerender-dynamic#allow-blocking-route",snippets:[{text:"// page.tsx or layout.tsx"},{text:"export const instant = false",highlight:!0}],copyable:!0}],c=[{id:"render-the-dropped-segment",title:"Render the dropped segment",group:"render",link:"https://nextjs.org/docs/messages/instant-unrendered-segment#render-the-dropped-segment",snippets:[{text:"function Layout({ children }) {",parts:[{text:"function Layout({ "},{text:"children",highlight:!0},{text:" }) {"}]},{text:"  return <><Nav />{children}</>",parts:[{text:"  return <><Nav />{"},{text:"children",highlight:!0},{text:"}</>"}]},{text:"}"}],copyable:!0},{id:"skip-validation-on-the-segment",title:"Skip validation on the segment",group:"ignore",link:"https://nextjs.org/docs/messages/instant-unrendered-segment#skip-validation-on-the-segment",snippets:[{text:"// page.tsx or layout.tsx"},{text:""},{text:"export const instant = false",highlight:!0}],copyable:!0}],u=[{id:"opt-into-partial-prefetching",title:"Opt into Partial Prefetching",group:"upgrade",link:"https://nextjs.org/docs/messages/instant-link-prefetch-partial#opt-into-partial-prefetching",snippets:[{text:"// page.tsx or layout.tsx"},{text:"export const prefetch = 'partial'",highlight:!0}],copyable:!0},{id:"use-the-default-prefetch",title:"Use the default prefetch",group:"disable",link:"https://nextjs.org/docs/messages/instant-link-prefetch-partial#use-the-default-prefetch",snippets:[{text:'<Link href="/dashboard">',highlight:!0},{text:"  Dashboard"},{text:"</Link>"}],copyable:!0},{id:"disable-validation-on-this-route",title:"Disable validation on this route",group:"ignore",link:"https://nextjs.org/docs/messages/instant-link-prefetch-partial#disable-validation-on-this-route",snippets:[{text:"// page.tsx or layout.tsx"},{text:"export const instant = false",highlight:!0}],copyable:!0}],d=[{id:"use-static-metadata",title:"Use static metadata",group:"static",link:"https://nextjs.org/docs/messages/blocking-prerender-metadata-runtime#use-static-metadata",snippets:[{text:"export const metadata = {",highlight:!0},{text:'  title: "My Page"'},{text:"}"}],copyable:!0},{id:"mark-the-route-as-dynamic",title:"Mark the route as dynamic",group:"dynamic",link:"https://nextjs.org/docs/messages/blocking-prerender-metadata-runtime#mark-the-route-as-dynamic",snippets:[{text:"// page.tsx or layout.tsx"},{text:"await connection()",highlight:!0}],copyable:!0}],f=[{id:"cache-the-metadata",title:"Cache the metadata",group:"cache",link:"https://nextjs.org/docs/messages/blocking-prerender-metadata-dynamic#cache-the-metadata",snippets:[{text:"async function generateMetadata() {"},{text:'  "use cache"',highlight:!0},{text:"  return await cms.getMeta(…)"}],copyable:!0},{id:"mark-the-route-as-dynamic",title:"Mark the route as dynamic",group:"dynamic",link:"https://nextjs.org/docs/messages/blocking-prerender-metadata-dynamic#mark-the-route-as-dynamic",snippets:[{text:"// page.tsx or layout.tsx"},{text:"await connection()",highlight:!0}],copyable:!0}],p=[{id:"use-static-viewport",title:"Use static viewport",group:"static",link:"https://nextjs.org/docs/messages/blocking-prerender-viewport-runtime#use-static-viewport",snippets:[{text:"export const viewport = {",highlight:!0},{text:'  themeColor: "#000"'},{text:"}"}],copyable:!0},{id:"allow-blocking-route",title:"Allow blocking route",group:"block",link:"https://nextjs.org/docs/messages/blocking-prerender-viewport-runtime#allow-blocking-route",snippets:[{text:"// page.tsx or layout.tsx"},{text:"export const instant = false",highlight:!0}],copyable:!0}],h=[{id:"cache-the-viewport-data",title:"Cache the viewport data",group:"cache",link:"https://nextjs.org/docs/messages/blocking-prerender-viewport-dynamic#cache-the-viewport-data",snippets:[{text:"async function generateViewport() {"},{text:'  "use cache"',highlight:!0},{text:"  return await db.getViewport(…)"}],copyable:!0},{id:"allow-blocking-route",title:"Allow blocking route",group:"block",link:"https://nextjs.org/docs/messages/blocking-prerender-viewport-dynamic#allow-blocking-route",snippets:[{text:"// page.tsx or layout.tsx"},{text:"export const instant = false",highlight:!0}],copyable:!0}],m=[{id:"render-at-request-time",title:"Generate on every request",group:"dynamic",link:"https://nextjs.org/docs/messages/blocking-prerender-current-time#generate-on-every-request",snippets:[{text:"await connection()",highlight:!0},{text:"const t = Date.now()"},{text:"return <Banner time={t} />"}],copyable:!0},{id:"cache-the-timestamp",title:"Cache the timestamp",group:"cache",link:"https://nextjs.org/docs/messages/blocking-prerender-current-time#cache-the-timestamp",snippets:[{text:"function Timestamp() {"},{text:'  "use cache"',highlight:!0},{text:"  return <time>{Date.now()}</time>"}],copyable:!0},{id:"render-on-the-client",title:"Render on the client",group:"client",link:"https://nextjs.org/docs/messages/blocking-prerender-current-time#render-on-the-client",snippets:[{text:'"use client"',highlight:!0},{text:"// runs in the browser"},{text:"const t = Date.now()"}],copyable:!0},{id:"measure-elapsed-time",title:"For telemetry, use a timing API",group:"measure",link:"https://nextjs.org/docs/messages/blocking-prerender-current-time#for-telemetry-use-a-timing-api",snippets:[{text:"const start = performance.now()",highlight:!0},{text:"doWork()"},{text:"const ms = performance.now() - start"}],copyable:!0}],g=[{id:"render-at-request-time",title:"Generate on every request",group:"dynamic",link:"https://nextjs.org/docs/messages/blocking-prerender-crypto#generate-on-every-request",snippets:[{text:"await connection()",highlight:!0},{text:"const id = crypto.randomUUID()"},{text:"return <Token id={id} />"}],copyable:!0},{id:"cache-the-generated-value",title:"Cache the generated value",group:"cache",link:"https://nextjs.org/docs/messages/blocking-prerender-crypto#cache-the-generated-value",snippets:[{text:"function TokenId() {"},{text:'  "use cache"',highlight:!0},{text:"  return crypto.randomUUID()"}],copyable:!0},{id:"render-on-the-client",title:"Render on the client",group:"client",link:"https://nextjs.org/docs/messages/blocking-prerender-crypto#render-on-the-client",snippets:[{text:'"use client"',highlight:!0},{text:"// runs in the browser"},{text:"const id = crypto.randomUUID()"}],copyable:!0}],v=[{id:"wrap-in-or-move-into-suspense",title:"Wrap in or move into Suspense",group:"stream",link:"https://nextjs.org/docs/messages/blocking-prerender-current-time-client#wrap-in-or-move-into-suspense",snippets:[{text:"<Suspense fallback={…}>",highlight:!0},{text:"  <DateDisplay />"},{text:"</Suspense>",highlight:!0}],copyable:!0},{id:"move-into-effect-or-event-handler",title:"Move into effect or event handler",group:"defer",link:"https://nextjs.org/docs/messages/blocking-prerender-current-time-client#move-into-effect-or-event-handler",snippets:[{text:"<button onClick={() => {",highlight:!0},{text:"  setT(Date.now())"},{text:"}} />"}],copyable:!0},{id:"measure-elapsed-time",title:"For telemetry, use a timing API",group:"measure",link:"https://nextjs.org/docs/messages/blocking-prerender-current-time-client#for-telemetry-use-a-timing-api",snippets:[{text:"const start = performance.now()",highlight:!0},{text:"doWork()"},{text:"const ms = performance.now() - start"}],copyable:!0}],x=[{id:"wrap-in-or-move-into-suspense",title:"Wrap in or move into Suspense",group:"stream",link:"https://nextjs.org/docs/messages/blocking-prerender-crypto-client#wrap-in-or-move-into-suspense",snippets:[{text:"<Suspense fallback={…}>",highlight:!0},{text:"  <TokenId />"},{text:"</Suspense>",highlight:!0}],copyable:!0},{id:"move-into-effect-or-event-handler",title:"Move into effect or event handler",group:"defer",link:"https://nextjs.org/docs/messages/blocking-prerender-crypto-client#move-into-effect-or-event-handler",snippets:[{text:"<button onClick={() => {",highlight:!0},{text:"  setId(crypto.randomUUID())"},{text:"}} />"}],copyable:!0}],y=[{id:"remove-the-data-access",title:"Remove the data access",group:"remove",snippets:[{text:"async function Page() {"},{text:"- const store = await cookies()",highlight:!0},{text:"  return <Content />"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-route-runtime#remove-the-data-access"},{id:"read-the-data-on-the-client",title:"Read the data on the client",group:"client",snippets:[{text:"'use client'"},{text:"use(browser())",highlight:!0},{text:"const value = readBrowserData()"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-route-runtime#read-the-data-on-the-client"}],b=[{id:"cache-the-data",title:"Cache the data",group:"cache",snippets:[{text:"async function getData() {"},{text:'  "use cache"',highlight:!0},{text:"  return await db.query(…)"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-route-dynamic#cache-the-data"},{id:"remove-the-data-access",title:"Remove the data access",group:"remove",snippets:[{text:"async function Page() {"},{text:"- await connection()",highlight:!0},{text:"  return <Content />"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-route-dynamic#remove-the-data-access"},{id:"read-the-data-on-the-client",title:"Read the data on the client",group:"client",snippets:[{text:"'use client'"},{text:"const data = useSWR('/api')",highlight:!0},{text:"return <Content data={data} />"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-route-dynamic#read-the-data-on-the-client"}],w=[{id:"use-static-metadata",title:"Use static metadata",group:"static",snippets:[{text:"export const metadata = {",highlight:!0},{text:"  title: 'My page'"},{text:"}"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-metadata-runtime#use-static-metadata"}],_=[{id:"cache-the-metadata",title:"Cache the metadata",group:"cache",snippets:[{text:"async function generateMetadata() {"},{text:'  "use cache"',highlight:!0},{text:"  return await cms.getMeta(…)"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-metadata-dynamic#cache-the-metadata"},{id:"use-static-metadata",title:"Use static metadata",group:"static",snippets:[{text:"export const metadata = {",highlight:!0},{text:"  title: 'My page'"},{text:"}"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-metadata-dynamic#use-static-metadata"}],k=[{id:"use-static-viewport",title:"Use static viewport",group:"static",snippets:[{text:"export const viewport = {",highlight:!0},{text:"  themeColor: 'black'"},{text:"}"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-viewport-runtime#use-static-viewport"}],j=[{id:"cache-the-viewport",title:"Cache the viewport",group:"cache",snippets:[{text:"async function generateViewport() {"},{text:'  "use cache"',highlight:!0},{text:"  return await cms.getViewport(…)"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-viewport-dynamic#cache-the-viewport"},{id:"use-static-viewport",title:"Use static viewport",group:"static",snippets:[{text:"export const viewport = {",highlight:!0},{text:"  themeColor: 'black'"},{text:"}"}],copyable:!0,link:"https://nextjs.org/docs/messages/static-viewport-dynamic#use-static-viewport"}],S={"static-viewport":"https://nextjs.org/docs/messages/static-viewport","static-metadata":"https://nextjs.org/docs/messages/static-metadata","static-route":"https://nextjs.org/docs/messages/static-route","blocking-route":"https://nextjs.org/docs/messages/blocking-route","client-hook":"https://nextjs.org/docs/messages/blocking-prerender-client-hook",metadata:"https://nextjs.org/docs/messages/blocking-prerender-metadata-dynamic",viewport:"https://nextjs.org/docs/messages/blocking-prerender-viewport-dynamic","sync-io":"","sync-io-client":"","unrendered-segment":"https://nextjs.org/docs/messages/instant-unrendered-segment","link-prefetch-partial":"https://nextjs.org/docs/messages/instant-link-prefetch-partial"},C={runtime:"https://nextjs.org/docs/messages/blocking-prerender-runtime",link:"https://nextjs.org/docs/messages/blocking-prerender-runtime",prefetch:"https://nextjs.org/docs/messages/instant-navigation-stage",navigation:"https://nextjs.org/docs/messages/instant-navigation-stage",dynamic:"https://nextjs.org/docs/messages/blocking-prerender-dynamic"},E={runtime:"https://nextjs.org/docs/messages/blocking-prerender-metadata-runtime",link:"https://nextjs.org/docs/messages/blocking-prerender-metadata-runtime",prefetch:"https://nextjs.org/docs/messages/instant-navigation-stage-metadata",navigation:"https://nextjs.org/docs/messages/instant-navigation-stage-metadata",dynamic:"https://nextjs.org/docs/messages/blocking-prerender-metadata-dynamic"},T={runtime:"https://nextjs.org/docs/messages/blocking-prerender-viewport-runtime",link:"https://nextjs.org/docs/messages/blocking-prerender-viewport-runtime",prefetch:"https://nextjs.org/docs/messages/instant-navigation-stage-viewport",navigation:"https://nextjs.org/docs/messages/instant-navigation-stage-viewport",dynamic:"https://nextjs.org/docs/messages/blocking-prerender-viewport-dynamic"},N={"Math.random()":"https://nextjs.org/docs/messages/blocking-prerender-random","Date.now()":"https://nextjs.org/docs/messages/blocking-prerender-current-time","Date()":"https://nextjs.org/docs/messages/blocking-prerender-current-time","new Date()":"https://nextjs.org/docs/messages/blocking-prerender-current-time","crypto.randomUUID()":"https://nextjs.org/docs/messages/blocking-prerender-crypto","crypto.getRandomValues()":"https://nextjs.org/docs/messages/blocking-prerender-crypto","require('node:crypto').randomUUID()":"https://nextjs.org/docs/messages/blocking-prerender-crypto","require('node:crypto').randomBytes(size)":"https://nextjs.org/docs/messages/blocking-prerender-crypto","require('node:crypto').randomFillSync(...)":"https://nextjs.org/docs/messages/blocking-prerender-crypto","require('node:crypto').randomInt(min, max)":"https://nextjs.org/docs/messages/blocking-prerender-crypto","require('node:crypto').generatePrimeSync(...)":"https://nextjs.org/docs/messages/blocking-prerender-crypto","require('node:crypto').generateKeyPairSync(...)":"https://nextjs.org/docs/messages/blocking-prerender-crypto","require('node:crypto').generateKeySync(...)":"https://nextjs.org/docs/messages/blocking-prerender-crypto"},I={"Math.random()":"https://nextjs.org/docs/messages/blocking-prerender-random-client","Date.now()":"https://nextjs.org/docs/messages/blocking-prerender-current-time-client","Date()":"https://nextjs.org/docs/messages/blocking-prerender-current-time-client","new Date()":"https://nextjs.org/docs/messages/blocking-prerender-current-time-client","crypto.randomUUID()":"https://nextjs.org/docs/messages/blocking-prerender-crypto-client","crypto.getRandomValues()":"https://nextjs.org/docs/messages/blocking-prerender-crypto-client","require('node:crypto').randomUUID()":"https://nextjs.org/docs/messages/blocking-prerender-crypto-client","require('node:crypto').randomBytes(size)":"https://nextjs.org/docs/messages/blocking-prerender-crypto-client","require('node:crypto').randomFillSync(...)":"https://nextjs.org/docs/messages/blocking-prerender-crypto-client","require('node:crypto').randomInt(min, max)":"https://nextjs.org/docs/messages/blocking-prerender-crypto-client","require('node:crypto').generatePrimeSync(...)":"https://nextjs.org/docs/messages/blocking-prerender-crypto-client","require('node:crypto').generateKeyPairSync(...)":"https://nextjs.org/docs/messages/blocking-prerender-crypto-client","require('node:crypto').generateKeySync(...)":"https://nextjs.org/docs/messages/blocking-prerender-crypto-client"},z={"static-viewport":"This route is configured to be fully static, but some data requires rendering at request time.","static-metadata":"This route is configured to be fully static, but some data requires rendering at request time.","static-route":"This route is configured to be fully static, but some data requires rendering at request time.","blocking-route":"This prevents the route from being prerendered, blocking navigation and leading to a slower user experience.","client-hook":"This blocks prerendering because the value is only available at runtime.",metadata:"This route's metadata is blocked, but the rest of its content can be prerendered.",viewport:"This prevents the page from being prerendered, leading to a slower user experience.","sync-io":"","sync-io-client":"This value would be evaluated during the prerender and fixed at build time, instead of recomputed on each visit.","unrendered-segment":"This segment was dropped from rendering. Issues that would prevent instant navigation will go undetected.","link-prefetch-partial":"This will lead to slower, more expensive prefetches."},R="This prevents the navigation from being instant, leading to a slower user experience.",P="This may prevent the navigation from being instant, leading to a slower user experience.",L="Metadata can already stream, so delaying it may be unintentional.",O="This prevents Next.js from creating the App Shell, leading to a slower user experience.",M={"Math.random()":[{id:"render-at-request-time",title:"Generate on every request",group:"dynamic",link:"https://nextjs.org/docs/messages/blocking-prerender-random#generate-on-every-request",snippets:[{text:"await connection()",highlight:!0},{text:"const id = Math.random()"},{text:"return <Item id={id} />"}],copyable:!0},{id:"cache-the-random-value",title:"Cache the random value",group:"cache",link:"https://nextjs.org/docs/messages/blocking-prerender-random#cache-the-random-value",snippets:[{text:"function RandomId() {"},{text:'  "use cache"',highlight:!0},{text:"  return String(Math.random())"}],copyable:!0},{id:"render-on-the-client",title:"Render on the client",group:"client",link:"https://nextjs.org/docs/messages/blocking-prerender-random#render-on-the-client",snippets:[{text:'"use client"',highlight:!0},{text:"// runs in the browser"},{text:"const id = Math.random()"}],copyable:!0}],"Date.now()":m,"Date()":m,"new Date()":m,"crypto.randomUUID()":g,"crypto.getRandomValues()":g,"require('node:crypto').randomUUID()":g,"require('node:crypto').randomBytes(size)":g,"require('node:crypto').randomFillSync(...)":g,"require('node:crypto').randomInt(min, max)":g,"require('node:crypto').generatePrimeSync(...)":g,"require('node:crypto').generateKeyPairSync(...)":g,"require('node:crypto').generateKeySync(...)":g},A={"Math.random()":[{id:"wrap-in-or-move-into-suspense",title:"Wrap in or move into Suspense",group:"stream",link:"https://nextjs.org/docs/messages/blocking-prerender-random-client#wrap-in-or-move-into-suspense",snippets:[{text:"<Suspense fallback={…}>",highlight:!0},{text:"  <RandomId />"},{text:"</Suspense>",highlight:!0}],copyable:!0},{id:"move-into-effect-or-event-handler",title:"Move into effect or event handler",group:"defer",link:"https://nextjs.org/docs/messages/blocking-prerender-random-client#move-into-effect-or-event-handler",snippets:[{text:"<button onClick={() => {",highlight:!0},{text:"  setId(Math.random())"},{text:"}} />"}],copyable:!0}],"Date.now()":v,"Date()":v,"new Date()":v,"crypto.randomUUID()":x,"crypto.getRandomValues()":x,"require('node:crypto').randomUUID()":x,"require('node:crypto').randomBytes(size)":x,"require('node:crypto').randomFillSync(...)":x,"require('node:crypto').randomInt(min, max)":x,"require('node:crypto').generatePrimeSync(...)":x,"require('node:crypto').generateKeyPairSync(...)":x,"require('node:crypto').generateKeySync(...)":x};function D(e,t,r){return"dynamic"!==t||"connection"!==r?e:e.filter(e=>"cache"!==e.group)}function F(e,t,r){switch(e){case"static-viewport":return"runtime"===t?k:D(j,t,r);case"static-metadata":return"runtime"===t?w:D(_,t,r);case"static-route":return"runtime"===t?y:D(b,t,r);case"blocking-route":switch(t){case"link":return o;case"runtime":return i;case"prefetch":case"navigation":return a;case"dynamic":return D(l,t,r);default:return t}case"client-hook":return s;case"metadata":switch(t){case"link":case"runtime":return d;case"prefetch":case"navigation":let n;return n="prefetch"===t?"prefetch":"navigation",[{id:"remove-the-api-call",title:"Remove the API call",group:"remove",link:"https://nextjs.org/docs/messages/instant-navigation-stage-metadata#remove-the-api-call",snippets:[{text:"async function generateMetadata() {"},{text:`-  await ${n}()`,highlight:!0},{text:"}"}]},{id:"confirm-the-metadata-delay",title:"Confirm the metadata delay",group:"mark",link:"https://nextjs.org/docs/messages/instant-navigation-stage-metadata#confirm-the-metadata-delay",snippets:[{text:"// page.tsx or layout.tsx"},{text:`await ${n}()`,highlight:!0}],copyable:!0}];case"dynamic":return D(f,t,r);default:return t}case"viewport":switch(t){case"link":case"runtime":return p;case"prefetch":case"navigation":return[{id:"remove-the-api-call",title:"Remove the API call",group:"remove",link:"https://nextjs.org/docs/messages/instant-navigation-stage-viewport#remove-the-api-call",snippets:[{text:"async function generateViewport() {"},{text:`-  await ${"prefetch"===t?"prefetch":"navigation"}()`,highlight:!0},{text:"}"}]},{id:"disable-validation-on-this-route",title:"Disable validation on this route",group:"ignore",link:"https://nextjs.org/docs/messages/instant-navigation-stage-viewport#disable-validation-on-this-route",snippets:[{text:"// page.tsx or layout.tsx"},{text:"export const instant = false",highlight:!0}],copyable:!0}];case"dynamic":return D(h,t,r);default:return t}case"sync-io":return r&&M[r]||[];case"sync-io-client":return r&&A[r]||[];case"unrendered-segment":return c;case"link-prefetch-partial":return u;default:return e}}function $(e,t){return"runtime"===t||"dynamic"===t?`${S[e]}-${t}`:S[e]}},"./src/next-devtools/dev-overlay/components/instant/instant-guidance.tsx"(e,t,r){"use strict";r.d(t,{YO:()=>I,gD:()=>N,HI:()=>j.HI,Rd:()=>j.Rd,Qz:()=>z});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js");let a={width:16,height:16,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};function i(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{...a,children:(0,n.jsx)("path",{d:"M3 6h18M3 12h12M3 18h18"})}),t[0]=e):e=t[0],e}function s(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,n.jsx)("path",{fill:"currentColor",fillRule:"evenodd",clipRule:"evenodd",d:"M13.5 1.5h-11v3a1 1 0 0 0 1 1h9a1 1 0 0 0 1-1zM15 0H1v4.5A2.5 2.5 0 0 0 3.5 7h9A2.5 2.5 0 0 0 15 4.5V0M2.5 13.5v-3h11v3a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1M1 9h14v4.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 1 13.5V9m3.75 4.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5M8 12.5a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0m2.5-9a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0m-1.75.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5"})}),t[0]=e):e=t[0],e}function l(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)("svg",{...a,children:[(0,n.jsx)("path",{d:"M3 12a9 9 0 109-9 9.75 9.75 0 00-6.74 2.74L3 8"}),(0,n.jsx)("path",{d:"M3 3v5h5"}),(0,n.jsx)("path",{d:"M12 7v5l4 2"})]}),t[0]=e):e=t[0],e}function c(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:Array.from({length:12},u)}),t[0]=e):e=t[0],e}function u(e,t){let r=30*t;return(0,n.jsx)("circle",{cx:"8",cy:"2.3",r:"0.9",fill:"currentColor",stroke:"none",opacity:1-.05*t,transform:`rotate(${r} 8 8)`},r)}function d(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)("svg",{...a,children:[(0,n.jsx)("circle",{cx:"12",cy:"12",r:"10"}),(0,n.jsx)("path",{d:"M7 12h10"})]}),t[0]=e):e=t[0],e}function f(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)("svg",{...a,children:[(0,n.jsx)("path",{d:"M12 4v16"}),(0,n.jsx)("path",{d:"M5 11l7-7 7 7"})]}),t[0]=e):e=t[0],e}function p(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{...a,children:(0,n.jsx)("path",{d:"M5 12l4 4L19 6"})}),t[0]=e):e=t[0],e}function h(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{...a,children:(0,n.jsx)("path",{d:"M5 12h14"})}),t[0]=e):e=t[0],e}function m(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,n.jsx)("path",{fill:"currentColor",fillRule:"evenodd",clipRule:"evenodd",d:"M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v8.5a1 1 0 0 1-1 1H8.75v3h1.75V16h-5v-1.5h1.75v-3H1a1 1 0 0 1-1-1zm1.5.5V10h13V2.5z"})}),t[0]=e):e=t[0],e}function g(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,n.jsx)("path",{fill:"currentColor",fillRule:"evenodd",clipRule:"evenodd",d:"M6.94 2.06 8 1l1.06 1.06 4.88 4.88L15 8l-1.06 1.06-4.88 4.88L8 15l-1.06-1.06-4.88-4.88L1 8l1.06-1.06zM3.12 8 8 12.88 12.88 8 8 3.12z"})}),t[0]=e):e=t[0],e}function v(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,n.jsx)("path",{fill:"currentColor",fillRule:"evenodd",clipRule:"evenodd",d:"M7.25 1.25v.79a7 7 0 0 0-3.64 1.5l-.58-.57-.53-.53L1.44 3.5l.53.53.58.58a7 7 0 1 0 10.9 0l.58-.58.53-.53-1.06-1.06-.53.53-.58.58a7 7 0 0 0-3.64-1.51v-.79H10v-1.5H6v1.5h1.25M2.5 9a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0m6.25-2.25V6h-1.5v3.75h1.5v-3"})}),t[0]=e):e=t[0],e}function x(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,n.jsx)("path",{fill:"currentColor",fillRule:"evenodd",clipRule:"evenodd",d:"M3.3.79C4.54.29 6.2 0 8 0s3.46.29 4.7.79a5 5 0 0 1 1.57.94c.41.39.73.9.73 1.52v9.5a2 2 0 0 1-.73 1.52 5 5 0 0 1-1.57.94c-1.24.5-2.9.79-4.7.79s-3.46-.29-4.7-.79a5 5 0 0 1-1.57-.94A2 2 0 0 1 1 12.75v-9.5c0-.62.32-1.13.73-1.52A5 5 0 0 1 3.3.8m-.8 4.54V8c0 .07.03.22.26.43q.33.33 1.1.64c1.02.41 2.49.68 4.14.68s3.12-.27 4.14-.68q.77-.31 1.1-.64c.23-.21.26-.36.26-.43V5.33a6 6 0 0 1-.8.38c-1.24.5-2.9.79-4.7.79s-3.46-.29-4.7-.79a6 6 0 0 1-.8-.38m11-2.08c0 .07-.03.22-.26.43q-.33.33-1.1.64C11.12 4.73 9.65 5 8 5s-3.12-.27-4.14-.68q-.77-.31-1.1-.64c-.23-.21-.26-.36-.26-.43s.03-.22.26-.43q.33-.33 1.1-.64C4.88 1.77 6.35 1.5 8 1.5s3.12.27 4.14.68q.77.31 1.1.64c.23.21.26.36.26.43m0 6.83a6 6 0 0 1-.8.38c-1.24.5-2.9.79-4.7.79s-3.46-.29-4.7-.79a6 6 0 0 1-.8-.38v2.67c0 .07.03.22.26.43q.33.33 1.1.64c1.02.41 2.49.68 4.14.68s3.12-.27 4.14-.68q.77-.31 1.1-.64c.23-.21.26-.36.26-.43z"})}),t[0]=e):e=t[0],e}function y(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,n.jsx)("path",{fill:"currentColor",fillRule:"evenodd",clipRule:"evenodd",d:"M5.5 2V0H7v2zm-4.53.03 1.5 1.5 1.06-1.06-1.5-1.5zm3.28 2.22.55 1.5 3 8.26.67 1.84.73-1.82 1.07-2.7 3.2 3.2 1.06-1.06-3.2-3.2 2.7-1.07 1.82-.73-1.84-.67-8.25-3zm7.4 4.28-1.53.61q-.7.29-.98.98l-.6 1.53-1.79-4.9zM0 7h2V5.5H0z"})}),t[0]=e):e=t[0],e}var b=r("./src/next-devtools/dev-overlay/components/copy-button/index.tsx"),w=r("./src/next-devtools/dev-overlay/icons/external.tsx"),_=r("./src/next-devtools/dev-overlay/icons/copy-prompt.tsx"),k=r("./src/next-devtools/dev-overlay/utils/css.ts"),j=r("./src/next-devtools/dev-overlay/components/instant/instant-guidance-data.ts");function S(e){let t,r,a,i=(0,o.c)(8),{title:s,group:l,link:c,generateErrorInfo:u}=e,d=j.Ed[l].label;if(i[0]!==c){let e=c.indexOf("#");t=-1===e?c:c.slice(0,e),i[0]=c,i[1]=t}else t=i[1];let f=t,p=`Apply the [${d}] "${s}" fix to the Next.js Insight raised in this project.`,h=`3. Read the rule docs at ${f} for the full Insight explanation, then read the fix section at ${c}. Pick the pattern under "### Patterns" that matches the failing code, then read "### Gotchas" before editing — they list constraints that are easy to miss. Use the canonical imports and code shape from the page; don't improvise variations.`;i[2]!==p||i[3]!==h?(r=[p,"","Steps:","","1. Make sure you can drive a browser before you start. The fix isn't verified until you've reloaded the route and looked at what renders. If you don't already have browser tooling set up, install the next-dev-loop skill (https://github.com/vercel/next.js/tree/canary/skills/next-dev-loop) first.","","2. Identify the failing code in the error block below. It may be a data-access call, a hook call, a metadata or viewport export, or a component. Keep the fix focused on that code. If you think a related refactor (a sibling component, a shared layout, a wrapping boundary) would make the result meaningfully better, name it and check with the user before doing it — don't expand the scope silently.","",h,"","4. Apply the chosen pattern to the code identified in step 2. Don't narrate the change with new comments — the code should explain itself. Only leave a comment when the *why* isn't clear (e.g. a deliberate Block with a reason).","","5. Verify the fix at runtime. The Insight clearing in the dev overlay confirms the build is happy, but not what actually renders. Reload the route in a browser and confirm the static shell still paints first and any new `<Suspense>` fallback resolves to its real content.","","6. Check the shell isn't empty. A `<Suspense>` boundary placed too high (around the whole page body, or with `fallback={null}`) can leave the build reporting a shell while the shell itself contains nothing and everything streams. If that's what you see, pull the boundary down closer to the actual dynamic read.","","7. If the fix touched shared code (a layout, a wrapper, a sidebar), re-check the sibling routes too — a shell-level change can fix one route and break another. A before/after capture of the affected routes is a useful sanity check: the visible UI may look the same (the fix often just changes what's in the shell vs streamed), but if anything regressed visually, you'll see it.","",'When you reply to the user, just summarize what you changed and why in plain prose. Don\'t echo this checklist back as headers, sections, or bullet lists labeled "Verification" or "Scope" — those are your internal steps, not the user\'s report.'],i[2]=p,i[3]=h,i[4]=r):r=i[4];let m=r.join("\n");return i[5]!==m||i[6]!==u?(a=u?(0,n.jsx)(b.i8,{getContent:async()=>{let e=await u();return e?`${m}

${e}`:m},actionLabel:"Copy prompt",successLabel:"Copied",icon:(0,n.jsx)(_.n,{}),showLabel:!0,"data-nextjs-fix-card-copy-button":!0}):(0,n.jsx)(b.i8,{content:m,actionLabel:"Copy prompt",successLabel:"Copied",icon:(0,n.jsx)(_.n,{}),showLabel:!0,"data-nextjs-fix-card-copy-button":!0}),i[5]=m,i[6]=u,i[7]=a):a=i[7],a}function C(e){let t,r,a=(0,o.c)(7),{cards:u,generateErrorInfo:b}=e;if(a[0]!==u||a[1]!==b){let e;a[3]!==b?(e=e=>{let t=j.Ed[e.group],r=(0,n.jsxs)(n.Fragment,{children:[e.link&&!e.copyable?(0,n.jsx)("span",{"data-nextjs-fix-card-link-icon":!0,"aria-hidden":"true",children:(0,n.jsx)(w.X,{width:16,height:16})}):null,(0,n.jsxs)("div",{"data-nextjs-fix-card-header":!0,children:[(0,n.jsx)("div",{"data-nextjs-fix-card-icon":!0,children:function(e){switch(e){case"align-left":return(0,n.jsx)(i,{});case"server-stack":return(0,n.jsx)(s,{});case"pointer-click":return(0,n.jsx)(y,{});case"history":return(0,n.jsx)(l,{});case"database":return(0,n.jsx)(x,{});case"timer":return(0,n.jsx)(v,{});case"minus-circle":return(0,n.jsx)(d,{});case"loading":return(0,n.jsx)(c,{});case"zap":return(0,n.jsx)(g,{});case"layout":return(0,n.jsx)(m,{});case"arrow-up":return(0,n.jsx)(f,{});case"check":return(0,n.jsx)(p,{});case"minus":return(0,n.jsx)(h,{});default:return null}}(t.icon)}),(0,n.jsxs)("div",{"data-nextjs-fix-card-header-text":!0,children:[(0,n.jsxs)("div",{"data-nextjs-fix-card-title-row":!0,children:[(0,n.jsx)("span",{"data-nextjs-fix-card-title":!0,children:t.label}),e.copyable&&e.link?(0,n.jsx)("span",{"data-nextjs-fix-card-title-link-icon":!0,"aria-hidden":"true",children:(0,n.jsx)(w.X,{width:12,height:12})}):null]}),(0,n.jsx)("span",{"data-nextjs-fix-card-description":!0,children:e.title})]})]}),(0,n.jsx)("pre",{"data-nextjs-fix-snippet":!0,children:e.snippets.map(E)})]}),o={"data-nextjs-fix-card":"","data-card-color":t.color},a=e.link?(0,n.jsx)("a",{...o,href:e.link,target:"_blank",rel:"noopener noreferrer","aria-label":`Open docs for ${e.title}`,children:r}):(0,n.jsx)("div",{...o,children:r});return e.copyable&&e.link?(0,n.jsxs)("div",{"data-nextjs-fix-card-wrapper":!0,children:[a,(0,n.jsx)(S,{title:e.title,group:e.group,link:e.link,generateErrorInfo:b})]},e.id):(0,n.jsx)("div",{"data-nextjs-fix-card-wrapper":!0,children:a},e.id)},a[3]=b,a[4]=e):e=a[4],t=u.map(e),a[0]=u,a[1]=b,a[2]=t}else t=a[2];return a[5]!==t?(r=(0,n.jsx)("div",{"data-nextjs-card-grid":!0,children:t}),a[5]=t,a[6]=r):r=a[6],r}function E(e,t){return(0,n.jsxs)("span",{"data-snippet-line":!0,children:[e.parts?e.parts.map(T):e.highlight?(0,n.jsx)("span",{"data-snippet-highlight":!0,children:e.text}):e.text,"\n"]},t)}function T(e,t){return(0,n.jsx)("span",{"data-snippet-highlight":e.highlight?"":void 0,children:e.text},t)}function N(e){let t,r,a,i,s,l,c=(0,o.c)(18),{variant:u,kind:d,explanation:f,cause:p,showExplanation:h,generateErrorInfo:m}=e,g=void 0===d?"blocking-route":d,v=void 0===h||h;c[0]!==p||c[1]!==g||c[2]!==u?(t=(0,j.Eg)(g,u,p),c[0]=p,c[1]=g,c[2]=u,c[3]=t):t=c[3];let x=t;switch(g){case"static-route":case"static-metadata":case"static-viewport":{let e;c[4]!==g||c[5]!==u?(e=(0,j.Ig)(g,u),c[4]=g,c[5]=u,c[6]=e):e=c[6],r=e;break}case"sync-io":r=(p?j.HI[p]:void 0)??j.vX[g];break;case"sync-io-client":r=(p?j.Rd[p]:void 0)??j.vX[g];break;case"blocking-route":r=j.h6[u];break;case"metadata":r=j.zu[u];break;case"viewport":r=j.cV[u];break;case"client-hook":case"unrendered-segment":case"link-prefetch-partial":r=j.vX[g]}let y=f||j.nT[g];return c[7]!==y||c[8]!==r||c[9]!==v?(a=v&&(y||r)?(0,n.jsxs)("p",{"data-nextjs-instant-explanation":!0,children:[y?(0,n.jsxs)(n.Fragment,{children:[y," "]}):null,r?(0,n.jsx)("a",{href:r,target:"_blank",rel:"noopener noreferrer",children:"Learn more"}):null]}):null,c[7]=y,c[8]=r,c[9]=v,c[10]=a):a=c[10],c[11]===Symbol.for("react.memo_cache_sentinel")?(i=(0,n.jsx)("div",{"data-nextjs-instant-fix-heading":!0,className:"nextjs__container_errors_desc nextjs__container_errors_desc_instant",children:"Ways to fix this:"}),c[11]=i):i=c[11],c[12]!==x||c[13]!==m?(s=(0,n.jsx)(C,{cards:x,generateErrorInfo:m}),c[12]=x,c[13]=m,c[14]=s):s=c[14],c[15]!==a||c[16]!==s?(l=(0,n.jsxs)("div",{"data-nextjs-instant-guidance":!0,children:[a,i,s]}),c[15]=a,c[16]=s,c[17]=l):l=c[17],l}function I(e){let t,r,a=(0,o.c)(8),{kind:i,variant:s,explanation:l,docsUrl:c}=e,u=l||(i?j.nT[i]:""),d=c;if(d||"blocking-route"!==i)if(d||"metadata"!==i)if(d||"viewport"!==i)if(d||"static-route"!==i&&"static-metadata"!==i&&"static-viewport"!==i)!d&&i&&(d=j.vX[i]);else{let e,t=s??"dynamic";a[0]!==i||a[1]!==t?(e=(0,j.Ig)(i,t),a[0]=i,a[1]=t,a[2]=e):e=a[2],d=e}else d=j.cV[s??"dynamic"];else d=j.zu[s??"dynamic"];else d=j.h6[s??"dynamic"];return a[3]!==d?(t=d?(0,n.jsx)("a",{href:d,target:"_blank",rel:"noopener noreferrer",children:"Learn more"}):null,a[3]=d,a[4]=t):t=a[4],a[5]!==u||a[6]!==t?(r=(0,n.jsxs)("p",{"data-nextjs-instant-explanation":!0,children:[u," ",t]}),a[5]=u,a[6]=t,a[7]=r):r=a[7],r}let z=(0,k.A)`
  [data-nextjs-instant-guidance] {
    margin: 0;
    padding: 0;
  }

  [data-nextjs-instant-explanation] {
    font-size: var(--size-14);
    line-height: var(--size-20);
    color: var(--color-gray-900);
    margin: 0;
  }

  [data-nextjs-instant-explanation] a {
    color: var(--color-blue-900);
    text-decoration: none;
  }

  [data-nextjs-instant-explanation] a:hover {
    text-decoration: underline;
  }

  [data-nextjs-instant-fix-heading] {
    padding: 20px 0;
  }

  [data-nextjs-card-grid] {
    --copy-prompt-offset: 10px;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: calc(12px + var(--copy-prompt-offset)) 12px;
  }

  [data-nextjs-fix-card] {
    border: 1px solid var(--color-gray-200);
    border-bottom: none;
    border-radius: var(--rounded-xl);
    color: inherit;
    display: flex;
    flex-direction: column;
    min-width: 0;
    position: relative;
    text-decoration: none;
  }

  a[data-nextjs-fix-card],
  a[data-nextjs-fix-card]:hover,
  a[data-nextjs-fix-card]:visited {
    color: inherit;
    text-decoration: none;
  }

  [data-nextjs-fix-card]:hover {
    border-color: var(--color-gray-500);
    background: var(--color-background-200);
  }

  [data-nextjs-fix-card]:hover [data-nextjs-fix-card-link-icon] {
    color: var(--color-gray-1000);
  }

  [data-nextjs-fix-card]:hover [data-nextjs-fix-snippet] {
    border-color: var(--color-gray-500);
    background: var(--color-gray-100);
  }

  a[data-nextjs-fix-card]:focus-visible {
    outline: var(--focus-ring);
    outline-offset: 2px;
  }

  [data-nextjs-fix-card-header] {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 0;
    padding: 14px;
  }

  [data-nextjs-fix-card-icon] {
    width: var(--size-28);
    height: var(--size-28);
    border-radius: var(--rounded-full);
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0.85;
  }

  [data-nextjs-fix-card-icon] svg {
    width: var(--size-14);
    height: var(--size-14);
  }

  [data-nextjs-fix-card-header-text] {
    display: flex;
    flex: 1;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  }

  [data-nextjs-fix-card-title-row] {
    display: flex;
    align-items: center;
    gap: 4px;
    color: var(--color-gray-1000);
  }

  [data-nextjs-fix-card-link-icon] {
    align-items: center;
    color: var(--color-gray-800);
    display: flex;
    opacity: 1;
    position: absolute;
    right: 14px;
    top: 14px;
    z-index: 1;
  }

  [data-nextjs-fix-card-title] {
    display: block;
    margin: 0;
    font-size: var(--size-13);
    font-weight: 500;
    line-height: var(--size-16);
    text-align: left;
  }

  [data-nextjs-fix-card-description] {
    display: block;
    margin: 0;
    font-size: var(--size-13);
    line-height: var(--size-16);
    color: var(--color-gray-900);
    text-align: left;
  }

  [data-nextjs-fix-snippet] {
    flex: 1;
    font-family: var(--font-stack-monospace);
    font-size: var(--size-12);
    line-height: 1.5;
    margin: 0;
    margin-left: -1px;
    margin-bottom: -1px;
    padding: 14px 16px;
    width: calc(100% + 2px);
    white-space: pre;
    overflow: hidden;
    background: var(--color-background-200);
    border: 1px solid var(--color-gray-200);
    border-radius: var(--rounded-xl);
    display: flex;
    flex-direction: column;
    justify-content: center;
    text-align: left;
  }

  [data-snippet-line] {
    display: block;
    color: var(--color-gray-800);
  }

  [data-nextjs-fix-snippet] [data-snippet-highlight] {
    color: var(--color-gray-1000);
    font-weight: 500;
  }

  [data-card-color='blue'] [data-nextjs-fix-snippet] [data-snippet-highlight] {
    color: var(--color-blue-800);
  }

  [data-card-color='blue'] [data-nextjs-fix-card-icon] {
    background: var(--color-blue-100);
    color: var(--color-blue-800);
  }

  [data-card-color='purple']
    [data-nextjs-fix-snippet]
    [data-snippet-highlight] {
    color: var(--color-instant-text-purple);
  }

  [data-card-color='purple'] [data-nextjs-fix-card-icon] {
    background: var(--color-purple-100);
    color: var(--color-purple-800);
  }

  [data-card-color='red'] [data-nextjs-fix-snippet] [data-snippet-highlight] {
    color: var(--color-red-800);
  }

  [data-card-color='red'] [data-nextjs-fix-card-icon] {
    background: var(--color-red-100);
    color: var(--color-red-800);
  }

  [data-card-color='gray'] [data-nextjs-fix-snippet] [data-snippet-highlight] {
    color: var(--color-gray-1000);
  }

  [data-card-color='gray'] [data-nextjs-fix-card-icon] {
    background: var(--color-gray-100);
    color: var(--color-gray-800);
  }

  [data-card-color='amber'] [data-nextjs-fix-snippet] [data-snippet-highlight] {
    color: var(--color-instant-text-amber);
  }

  [data-card-color='amber'] [data-nextjs-fix-card-icon] {
    background: var(--color-amber-100);
    color: var(--color-amber-900);
  }

  [data-nextjs-fix-card-title-link-icon] {
    align-items: center;
    color: inherit;
    display: inline-flex;
    flex-shrink: 0;
  }

  [data-nextjs-fix-card]:hover [data-nextjs-fix-card-title-link-icon] {
    color: inherit;
  }

  [data-nextjs-fix-card-wrapper] {
    display: flex;
    position: relative;
  }

  [data-nextjs-fix-card-wrapper] > [data-nextjs-fix-card] {
    flex: 1;
  }

  [data-nextjs-fix-card-copy-button] {
    align-items: center;
    background: var(--color-background-100);
    border: 1px solid var(--color-gray-alpha-300);
    border-radius: 9999px;
    color: var(--color-gray-900);
    cursor: pointer;
    display: inline-flex;
    font-family: var(--font-stack-sans);
    font-size: var(--size-11);
    font-weight: 500;
    gap: 6px;
    height: auto;
    line-height: 1;
    padding: 5px 10px;
    position: absolute;
    right: 10px;
    top: calc(-1 * var(--copy-prompt-offset));
    transition:
      background 120ms ease,
      border-color 120ms ease,
      color 120ms ease;
    z-index: 2;
  }

  [data-nextjs-fix-card-copy-button] svg {
    width: var(--size-12);
    height: var(--size-12);
    flex-shrink: 0;
  }

  [data-nextjs-fix-card-copy-button] span {
    line-height: 1;
  }

  [data-nextjs-fix-card-copy-button]:hover {
    background: var(--color-background-200);
    border-color: var(--color-gray-alpha-500);
    color: var(--color-gray-1000);
  }

  [data-nextjs-fix-card-copy-button]:focus-visible {
    outline: var(--focus-ring);
    outline-offset: 2px;
  }
`},"./src/next-devtools/dev-overlay/components/instant/unrendered-segment-info.tsx"(e,t,r){"use strict";r.d(t,{g:()=>l,r:()=>f});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/next-devtools/dev-overlay/icons/file.tsx"),i=r("./src/next-devtools/dev-overlay/components/code-frame/code-frame-shell.tsx"),s=r("./src/next-devtools/dev-overlay/utils/css.ts");function l(e){let t,r,s,l,d,f,p,h,m,g,v=(0,o.c)(32),{route:x,files:y}=e;if(v[0]!==y||v[1]!==x){let e,o,h,m,g=function(e,t){let r=e.split("/").filter(Boolean)[0],n=new Set,o=new Set;for(let e of t){let t=e.split("/").filter(Boolean);if(0===t.length)continue;if(r){let e=t.indexOf(r);e>=0&&(t=t.slice(e))}for(let e=1;e<t.length;e++)n.add(t.slice(0,e).join("/"));let a=t.join("/");n.add(a),o.add(a)}let a=Array.from(n).sort().map(e=>{let t=e.split("/"),r=o.has(e);return{key:e,parts:t,isLeaf:r}}),i=(e,t)=>!a.some((r,n)=>n>e&&r.parts.length>t&&r.parts.slice(0,t).join("/")===a[e].parts.slice(0,t).join("/"));return a.map((e,t)=>{let r=e.parts.length-1,n=i(t,r),o=[];for(let e=0;e<r;e++)o.push(i(t,e));return{label:0!==r&&e.isLeaf?e.parts[r]:`${e.parts[r]}/`,depth:r,isLastSibling:n,pipeMask:o,isMissing:e.isLeaf}})}(x,y),b=y[0]??null;v[9]!==b?(e=()=>{if(!b)return;let e=b.replace(/^.*?app\//,""),t=new URLSearchParams;t.append("file",e),t.append("isAppRelativePath","1"),self.fetch(`${process.env.__NEXT_ROUTER_BASEPATH||""}/__nextjs_launch-editor?${t.toString()}`).then(u,e=>{console.error(`Failed to open file "${b}" in your editor. Cause:`,e)})},v[9]=b,v[10]=e):e=v[10];let w=e;v[11]!==b?(o=b?.split(".").pop()??void 0,v[11]=b,v[12]=o):o=v[12];let _=o;t=i.T,v[13]!==_?(h=(0,n.jsx)("span",{className:"code-frame-icon",children:(0,n.jsx)(a.o,{lang:_})}),v[13]=_,v[14]=h):h=v[14],v[15]!==x?(m=(0,n.jsx)("span",{"data-text":!0,children:x}),v[15]=x,v[16]=m):m=v[16],v[17]!==m||v[18]!==h?(d=(0,n.jsxs)(n.Fragment,{children:[h,m]}),v[17]=m,v[18]=h,v[19]=d):d=v[19],f=b?w:void 0,p=b?`Open ${b} in editor`:void 0,r=!0,v[20]===Symbol.for("react.memo_cache_sentinel")?(s=(0,n.jsx)("div",{"data-nextjs-codeframe-line":"",children:(0,n.jsx)("span",{"data-nextjs-unrendered-segment-tree-prefix":!0,children:"│"})}),v[20]=s):s=v[20],l=g.map(c),v[0]=y,v[1]=x,v[2]=t,v[3]=r,v[4]=s,v[5]=l,v[6]=d,v[7]=f,v[8]=p}else t=v[2],r=v[3],s=v[4],l=v[5],d=v[6],f=v[7],p=v[8];return v[21]===Symbol.for("react.memo_cache_sentinel")?(h=(0,n.jsx)("div",{"data-nextjs-codeframe-line":"",children:(0,n.jsx)("span",{"data-nextjs-unrendered-segment-tree-prefix":!0,children:"│"})}),v[21]=h):h=v[21],v[22]!==r||v[23]!==s||v[24]!==l?(m=(0,n.jsxs)("div",{"data-nextjs-unrendered-segment-tree":r,children:[s,l,h]}),v[22]=r,v[23]=s,v[24]=l,v[25]=m):m=v[25],v[26]!==t||v[27]!==d||v[28]!==f||v[29]!==p||v[30]!==m?(g=(0,n.jsx)(t,{header:d,onOpen:f,openLabel:p,children:m}),v[26]=t,v[27]=d,v[28]=f,v[29]=p,v[30]=m,v[31]=g):g=v[31],g}function c(e,t){return(0,n.jsx)(d,{node:e},t)}function u(){}function d(e){let t,r,a,i,s,l=(0,o.c)(13),{node:c}=e;l[0]!==c.isMissing?(t={"data-nextjs-codeframe-line":""},c.isMissing&&(t["data-nextjs-codeframe-line--errored"]=!0),l[0]=c.isMissing,l[1]=t):t=l[1];let u="│ ";for(let e=0;e<c.depth;e++)u+=c.pipeMask[e]?"   ":"│  ";return u+=c.isLastSibling?"└─ ":"├─ ",l[2]!==u?(r=(0,n.jsx)("span",{"data-nextjs-unrendered-segment-tree-prefix":!0,children:u}),l[2]=u,l[3]=r):r=l[3],l[4]!==c.label?(a=(0,n.jsx)("span",{children:c.label}),l[4]=c.label,l[5]=a):a=l[5],l[6]!==c.isMissing?(i=c.isMissing&&(0,n.jsxs)("span",{"data-nextjs-unrendered-segment-tree-pointer":!0,children:[" ","← dropped from rendering"]}),l[6]=c.isMissing,l[7]=i):i=l[7],l[8]!==t||l[9]!==r||l[10]!==a||l[11]!==i?(s=(0,n.jsxs)("div",{...t,children:[r,a,i]}),l[8]=t,l[9]=r,l[10]=a,l[11]=i,l[12]=s):s=l[12],s}let f=(0,s.A)`
  [data-nextjs-unrendered-segment-tree-prefix] {
    color: var(--color-gray-alpha-700) !important;
  }

  [data-nextjs-unrendered-segment-tree]
    [data-nextjs-codeframe-line--errored='true']
    [data-nextjs-unrendered-segment-tree-prefix] {
    color: var(--color-gray-alpha-1000) !important;
  }

  [data-nextjs-unrendered-segment-tree-pointer] {
    color: var(--color-red-900) !important;
    margin-left: 8px;
    white-space: pre;
  }
`},"./src/next-devtools/dev-overlay/components/overlay/index.tsx"(e,t,r){"use strict";r.d(t,{h:()=>n.h,D:()=>i});var n=r("./src/next-devtools/dev-overlay/components/overlay/overlay.tsx"),o=r("./dist/compiled/react/jsx-runtime.js"),a=r("./dist/compiled/react/compiler-runtime.js");function i(e){let t,r,n,i=(0,a.c)(6);i[0]!==e?({fixed:t,...r}=e,i[0]=e,i[1]=t,i[2]=r):(t=i[1],r=i[2]);let s=!!t||void 0;return i[3]!==r||i[4]!==s?(n=(0,o.jsx)("div",{"data-nextjs-dialog-backdrop":!0,"data-nextjs-dialog-backdrop-fixed":s,...r}),i[3]=r,i[4]=s,i[5]=n):n=i[5],n}},"./src/next-devtools/dev-overlay/components/overlay/overlay.tsx"(e,t,r){"use strict";let n,o;r.d(t,{h:()=>c});var a=r("./dist/compiled/react/jsx-runtime.js"),i=r("./dist/compiled/react/compiler-runtime.js"),s=r("./dist/compiled/react/index.js");let l=0,c=function(e){let t,r,n,o,l,c=(0,i.c)(9);return c[0]!==e?({className:r,children:t,...n}=e,c[0]=e,c[1]=t,c[2]=r,c[3]=n):(t=c[1],r=c[2],n=c[3]),c[4]===Symbol.for("react.memo_cache_sentinel")?(o=[],c[4]=o):o=c[4],s.useEffect(d,o),c[5]!==t||c[6]!==r||c[7]!==n?(l=(0,a.jsx)("div",{"data-nextjs-dialog-overlay":!0,className:r,...n,children:t}),c[5]=t,c[6]=r,c[7]=n,c[8]=l):l=c[8],l};function u(){setTimeout(()=>{0!==l&&0==--l&&(void 0!==n&&(document.body.style.paddingRight=n,n=void 0),void 0!==o&&(document.body.style.overflow=o,o=void 0))})}function d(){return setTimeout(()=>{if(l++>0)return;let e=window.innerWidth-document.documentElement.clientWidth;e>0&&(n=document.body.style.paddingRight,document.body.style.paddingRight=`${e}px`),o=document.body.style.overflow,document.body.style.overflow="hidden"}),u}},"./src/next-devtools/dev-overlay/components/resizer/index.tsx"(e,t,r){"use strict";r.d(t,{L:()=>i});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js");let i=(0,a.forwardRef)(function(e,t){let r,i,s,l,c,u,d=(0,o.c)(14);d[0]!==e?({children:r,measure:i,...s}=e,d[0]=e,d[1]=r,d[2]=i,d[3]=s):(r=d[1],i=d[2],s=d[3]);let[f,p]=(0,a.useState)(null),[h,m]=function(e,t){let r,n,i,s=(0,o.c)(7),[l,c]=(0,a.useState)(0),[u,d]=(0,a.useState)(!0);return s[0]!==e||s[1]!==t?(r=()=>{let r;if(!t||!e)return;let n=new ResizeObserver(e=>{let[t]=e,{contentRect:n}=t;clearTimeout(r),r=window.setTimeout(()=>{d(!1)},100),c(n.height)});return n.observe(e),()=>n.disconnect()},n=[t,e],s[0]=e,s[1]=t,s[2]=r,s[3]=n):(r=s[2],n=s[3]),(0,a.useEffect)(r,n),s[4]!==l||s[5]!==u?(i=[l,u],s[4]=l,s[5]=u,s[6]=i):i=s[6],i}(f,i),g=m?"auto":h,v=m?"none":"height 250ms var(--timing-swift)";return d[4]!==g||d[5]!==v?(l={height:g,transition:v},d[4]=g,d[5]=v,d[6]=l):l=d[6],d[7]!==r?(c=(0,n.jsx)("div",{ref:p,children:r}),d[7]=r,d[8]=c):c=d[8],d[9]!==s||d[10]!==t||d[11]!==l||d[12]!==c?(u=(0,n.jsx)("div",{...s,ref:t,style:l,children:c}),d[9]=s,d[10]=t,d[11]=l,d[12]=c,d[13]=u):u=d[13],u})},"./src/next-devtools/dev-overlay/components/version-staleness-info/version-staleness-info.tsx"(e,t,r){"use strict";r.d(t,{R:()=>l,T:()=>s});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/next-devtools/dev-overlay/utils/cx.ts");function i(e){let t,r,a=(0,o.c)(3);return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsx)("circle",{cx:"7",cy:"7",r:"5.5",strokeWidth:"3"}),a[0]=t):t=a[0],a[1]!==e?(r=(0,n.jsx)("svg",{width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg",...e,children:t}),a[1]=e,a[2]=r):r=a[2],r}function s(e){let t,r,s,l,c,u,d,f,p,h,m,g,v=(0,o.c)(31),{versionInfo:x,bundlerName:y}=e,{staleness:b}=x;if(v[0]!==y||v[1]!==b||v[2]!==x){c=Symbol.for("react.early_return_sentinel");r:{let{text:e,indicatorClass:o,title:f}=function({installed:e,staleness:t,expected:r}){let n="",o="",a="",i=`Next.js ${e}`;switch(t){case"newer-than-npm":case"fresh":n=i,o=`Latest available version is detected (${e}).`,a="fresh";break;case"stale-patch":case"stale-minor":n=`${i} (stale)`,o=`There is a newer version (${r}) available, upgrade recommended! `,a="stale";break;case"stale-major":n=`${i} (outdated)`,o=`An outdated version detected (latest is ${r}), upgrade is highly recommended!`,a="outdated";break;case"stale-prerelease":n=`${i} (stale)`,o=`There is a newer canary version (${r}) available, please upgrade! `,a="stale";break;case"unknown":n=`${i} (unknown)`,o="No Next.js version data was found.",a="unknown"}return{text:n,indicatorClass:a,title:o}}(x);if(u=e,d=f,r="Turbopack"===y,b.startsWith("stale")){let e,t,s=r&&"turbopack-text";v[10]!==s?(e=(0,a.cx)(s),v[10]=s,v[11]=e):e=v[11],v[12]!==y||v[13]!==e?(t=(0,n.jsx)("span",{className:e,children:y}),v[12]=y,v[13]=e,v[14]=t):t=v[14],c=(0,n.jsxs)("a",{className:"nextjs-container-build-error-version-status dialog-exclude-closing-from-outside-click",target:"_blank",rel:"noopener noreferrer",href:"https://nextjs.org/docs/messages/version-staleness",children:[(0,n.jsx)(i,{className:(0,a.cx)("version-staleness-indicator",o)}),(0,n.jsx)("span",{"data-nextjs-version-checker":!0,title:d,children:u}),t]});break r}l="nextjs-container-build-error-version-status dialog-exclude-closing-from-outside-click",t=i,s=(0,a.cx)("version-staleness-indicator",o)}v[0]=y,v[1]=b,v[2]=x,v[3]=t,v[4]=r,v[5]=s,v[6]=l,v[7]=c,v[8]=u,v[9]=d}else t=v[3],r=v[4],s=v[5],l=v[6],c=v[7],u=v[8],d=v[9];if(c!==Symbol.for("react.early_return_sentinel"))return c;v[15]!==t||v[16]!==s?(f=(0,n.jsx)(t,{className:s}),v[15]=t,v[16]=s,v[17]=f):f=v[17],v[18]!==u||v[19]!==d?(p=(0,n.jsx)("span",{"data-nextjs-version-checker":!0,title:d,children:u}),v[18]=u,v[19]=d,v[20]=p):p=v[20];let w=r&&"turbopack-text";return v[21]!==w?(h=(0,a.cx)(w),v[21]=w,v[22]=h):h=v[22],v[23]!==y||v[24]!==h?(m=(0,n.jsx)("span",{className:h,children:y}),v[23]=y,v[24]=h,v[25]=m):m=v[25],v[26]!==l||v[27]!==f||v[28]!==p||v[29]!==m?(g=(0,n.jsxs)("span",{className:l,children:[f,p,m]}),v[26]=l,v[27]=f,v[28]=p,v[29]=m,v[30]=g):g=v[30],g}let l=`
  .nextjs-container-build-error-version-status {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 4px;
    white-space: nowrap;
    flex-shrink: 0;

    height: var(--size-24);
    padding: 6px 8px 6px 6px;
    background: var(--color-background-100);
    border-radius: var(--rounded-full);

    color: var(--color-gray-900);
    font-size: var(--size-12);
    font-weight: 500;
    line-height: var(--size-16);
  }

  a.nextjs-container-build-error-version-status {
    text-decoration: none;
    color: var(--color-gray-900);

    &:hover {
      background: var(--color-gray-100);
    }

    &:focus {
      outline: var(--focus-ring);
    }
  }

  .version-staleness-indicator.fresh {
    fill: var(--color-green-800);
    stroke: var(--color-green-300);
  }
  .version-staleness-indicator.stale {
    fill: var(--color-amber-800);
    stroke: var(--color-amber-300);
  }
  .version-staleness-indicator.outdated {
    fill: var(--color-red-800);
    stroke: var(--color-red-300);
  }
  .version-staleness-indicator.unknown {
    fill: var(--color-gray-800);
    stroke: var(--color-gray-300);
  }

  .nextjs-container-build-error-version-status > .turbopack-text {
    background: linear-gradient(
      to right,
      var(--color-turbopack-text-red) 0%,
      var(--color-turbopack-text-blue) 100%
    );
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
`},"./src/next-devtools/dev-overlay/container/errors.tsx"(e,t,r){"use strict";r.d(t,{n3:()=>K,R7:()=>eo,I:()=>et,s9:()=>q,go:()=>J,Xw:()=>U});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js"),i=r("./src/next-devtools/dev-overlay/components/errors/error-overlay-nav/error-overlay-nav.tsx"),s=r("./src/next-devtools/dev-overlay/components/errors/overlay/overlay.tsx"),l=r("./src/next-devtools/dev-overlay/components/errors/dialog/dialog.tsx"),c=r("./src/next-devtools/dev-overlay/components/errors/dialog/header.tsx"),u=r("./src/next-devtools/dev-overlay/components/errors/dialog/body.tsx"),d=r("./src/next-devtools/dev-overlay/components/overlay/index.tsx"),f=r("./src/next-devtools/dev-overlay/components/dialog/index.ts"),p=r("./src/next-devtools/dev-overlay/components/resizer/index.tsx"),h=r("./src/next-devtools/dev-overlay/components/errors/dev-tools-indicator/utils.ts"),m=r("./src/next-devtools/dev-overlay/components/copy-button/index.tsx"),g=r("./src/next-devtools/dev-overlay/components/code-frame/code-frame-shell.tsx"),v=r("./src/next-devtools/dev-overlay/icons/copy-prompt.tsx"),x=r("./src/next-devtools/dev-overlay/utils/css.ts");function y(e){let t,r,x,y,w,_,k,j,S,C,E,T,N,I,z,R,P,L=(0,o.c)(37),{renderTabBar:O,canGoPrevious:M,canGoNext:A,onPrevious:D,onNext:F,onClose:$,rendered:U,transitionDurationMs:Z,versionInfo:q}=e,B=`${Z}ms`;L[0]!==B?(t={"--transition-duration":B},L[0]=B,L[1]=t):t=L[1];let V=t;L[2]!==U||L[3]!==V?(r={"data-rendered":U,style:V},L[2]=U,L[3]=V,L[4]=r):r=L[4];let H=r,[W,G]=a.useState(!!Z),K=a.useRef(null);(0,h.rM)(K,null,U),L[5]===Symbol.for("react.memo_cache_sentinel")?(x=function(e){let{propertyName:t,target:r}=e;"scale"===t&&r===K.current&&G(!1)},L[5]=x):x=L[5];let Y=x;L[6]===Symbol.for("react.memo_cache_sentinel")?(y=(0,n.jsx)(d.D,{fixed:!1}),L[6]=y):y=L[6],L[7]!==A||L[8]!==M||L[9]!==F||L[10]!==D||L[11]!==O||L[12]!==q?(w=(0,n.jsx)(i.s,{versionInfo:q,renderTabBar:O,canGoPrevious:M,canGoNext:A,onPrevious:D,onNext:F}),L[7]=A,L[8]=M,L[9]=F,L[10]=D,L[11]=O,L[12]=q,L[13]=w):w=L[13];let X=!W;return L[14]===Symbol.for("react.memo_cache_sentinel")?(k=(0,n.jsx)("span",{id:"nextjs__container_errors_label",className:"nextjs__container_errors_label nextjs__container_errors_label_instant","data-nextjs-vulnerability-label":!0,children:"Security Insight"}),_=(0,n.jsx)("h2",{id:"nextjs__container_errors_desc",className:"nextjs__container_errors_desc nextjs__container_errors_desc_instant",children:"Upgrade Next.js to a safe version."}),L[14]=_,L[15]=k):(_=L[14],k=L[15]),L[16]!==q.installed?(j=(0,n.jsx)(c.q,{children:(0,n.jsxs)("div",{"data-nextjs-vulnerability-insight":!0,children:[k,_,(0,n.jsxs)("p",{children:["Next.js ",q.installed," is affected by a known security vulnerability. We strongly recommend upgrading."]})]})}),L[16]=q.installed,L[17]=j):j=L[17],L[18]===Symbol.for("react.memo_cache_sentinel")?(S=(0,n.jsx)("p",{children:"Ask your coding agent to upgrade:"}),L[18]=S):S=L[18],L[19]===Symbol.for("react.memo_cache_sentinel")?(C=(0,n.jsx)("span",{"data-nextjs-vulnerability-prompt-title":!0,children:"Agent prompt"}),L[19]=C):C=L[19],L[20]===Symbol.for("react.memo_cache_sentinel")?(E=(0,n.jsx)(u.a,{children:(0,n.jsxs)("div",{"data-nextjs-vulnerability-action":!0,children:[S,(0,n.jsx)(g.T,{header:(0,n.jsxs)(n.Fragment,{children:[C,(0,n.jsx)(m.i8,{content:"Run `next upgrade --agent=security` and follow its instructions.",actionLabel:"Copy prompt",successLabel:"Copied",icon:(0,n.jsx)(v.n,{}),showLabel:!0,"data-nextjs-vulnerability-copy":!0})]}),children:(0,n.jsx)("span",{"data-nextjs-vulnerability-prompt":!0,children:"Run `next upgrade --agent=security` and follow its instructions."})})]})}),L[20]=E):E=L[20],L[21]!==j?(T=(0,n.jsxs)(f.Cf,{children:[j,E]}),L[21]=j,L[22]=T):T=L[22],L[23]!==T||L[24]!==X?(N=(0,n.jsx)(p.L,{measure:X,"data-nextjs-dialog-sizer":!0,children:T}),L[23]=T,L[24]=X,L[25]=N):N=L[25],L[26]!==$||L[27]!==N?(I=(0,n.jsx)(l.P,{onClose:$,children:N}),L[26]=$,L[27]=N,L[28]=I):I=L[28],L[29]!==H||L[30]!==I||L[31]!==w?(z=(0,n.jsxs)("div",{"data-nextjs-dialog-root":!0,onTransitionEnd:Y,ref:K,...H,children:[w,I]}),L[29]=H,L[30]=I,L[31]=w,L[32]=z):z=L[32],L[33]===Symbol.for("react.memo_cache_sentinel")?(R=(0,n.jsx)("style",{children:b}),L[33]=R):R=L[33],L[34]!==H||L[35]!==z?(P=(0,n.jsxs)(s.J,{...H,children:[y,z,R]}),L[34]=H,L[35]=z,L[36]=P):P=L[36],P}let b=(0,x.A)`
  [data-nextjs-dialog-header]:has([data-nextjs-vulnerability-insight]) {
    padding-bottom: 0;
  }
  [data-nextjs-vulnerability-insight] h2 {
    margin: 16px 0 8px;
  }
  [data-nextjs-vulnerability-insight] p,
  [data-nextjs-vulnerability-action] > p {
    margin: 8px 0;
    font-size: var(--size-14);
    line-height: var(--size-20);
    font-family: var(--font-stack-sans);
    letter-spacing: normal;
    color: var(--color-gray-900);
  }
  [data-nextjs-vulnerability-action] {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  [data-nextjs-vulnerability-action] > p {
    margin-bottom: 0;
  }
  [data-nextjs-vulnerability-action] .code-frame-lines {
    min-width: 0;
    white-space: pre-wrap;
    overflow-wrap: anywhere;
  }
  [data-nextjs-vulnerability-action] [data-nextjs-vulnerability-prompt],
  [data-nextjs-vulnerability-action] [data-nextjs-vulnerability-prompt-title] {
    font-family: var(--font-stack-sans);
    font-size: var(--size-14);
    line-height: var(--size-20);
    letter-spacing: normal;
  }
  [data-nextjs-vulnerability-prompt-title] {
    font-size: var(--size-13);
  }
  [data-nextjs-vulnerability-copy] {
    display: inline-flex;
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    margin-left: auto;
    gap: 6px;
    height: auto;
    padding: 5px 10px;
    border: 1px solid var(--color-gray-alpha-300);
    border-radius: 9999px;
    background: var(--color-background-100);
    color: var(--color-gray-900);
    font-family: var(--font-stack-sans);
    font-size: var(--size-11);
    font-weight: 500;
    line-height: 1;
    cursor: pointer;
    transition:
      background 120ms ease,
      border-color 120ms ease,
      color 120ms ease;
  }
  [data-nextjs-vulnerability-action] [data-nextjs-copy-button-label] {
    font-family: var(--font-stack-sans);
    font-size: var(--size-11);
    line-height: 1;
  }
  [data-nextjs-vulnerability-copy] svg {
    width: var(--size-12);
    height: var(--size-12);
  }
  [data-nextjs-vulnerability-copy]:hover {
    background: var(--color-background-200);
    border-color: var(--color-gray-alpha-500);
    color: var(--color-gray-1000);
  }
  [data-nextjs-vulnerability-copy]:focus-visible {
    outline: var(--focus-ring);
    outline-offset: 2px;
  }
  [data-nextjs-vulnerability-copy][aria-disabled='true'] {
    opacity: 0.5;
  }
`;var w=r("./src/next-devtools/dev-overlay/container/runtime-error/index.tsx"),_=r("./src/shared/lib/error-source.ts"),k=r("./src/next-devtools/dev-overlay/components/hot-linked-text/index.tsx"),j=r("./src/next-devtools/dev-overlay/container/runtime-error/component-stack-pseudo-html.tsx"),S=r("./src/next-devtools/dev-overlay/components/errors/error-overlay-layout/error-overlay-layout.tsx"),C=r("./src/next-devtools/shared/react-19-hydration-error.ts"),E=r("./src/next-devtools/dev-overlay/components/code-frame/parse-code-frame.ts"),T=r("./dist/compiled/strip-ansi/index.js"),N=r.n(T);async function I({activeError:e,errorType:t,versionInfo:r,bundler:n}){if(!e)return"";let o=[];t&&o.push(`## Error Type
${t}`);let a=e.error,i=a.message;if("environmentName"in a&&a.environmentName){let e=`[ ${a.environmentName} ] `;i.startsWith(e)&&(i=i.slice(e.length))}i&&o.push(`## Error Message
${i}`);let s=await Promise.race([e.frames(),new Promise(e=>setTimeout(()=>e(null),2e3))]);if(null===s)o.push("Unable to retrieve stack frames for this error. Falling back to unsourcemapped stack\n\n"+a.stack);else{if(s.length>0){let e=s.filter(e=>!e.ignored);if(e.length>0){let t=e.map(e=>{if(e.originalStackFrame){let{methodName:t,file:r,line1:n,column1:o}=e.originalStackFrame;return`    at ${t} (${r}:${n}:${o})`}if(e.sourceStackFrame){let{methodName:t,file:r,line1:n,column1:o}=e.sourceStackFrame;return`    at ${t} (${r}:${n}:${o})`}return""}).filter(Boolean);t.length>0&&o.push(`
${t.join("\n")}`)}}let e=s.findIndex(e=>!e.ignored&&!!e.originalCodeFrame&&!!e.originalStackFrame),t=s[e]??null;if(t?.originalCodeFrame){let e=N()((0,E.w5)(t.originalCodeFrame));o.push(`## Code Frame
${e}`)}}return`${o.join("\n\n")}

Next.js version: ${r} (${n})
`}var z=r("./src/next-devtools/dev-overlay/components/instant/instant-guidance.tsx"),R=r("./src/next-devtools/dev-overlay/components/instant/instant-guidance-data.ts"),P=r("./src/next-devtools/dev-overlay/components/instant/unrendered-segment-info.tsx"),L=r("./src/next-devtools/dev-overlay/components/code-frame/code-frame.tsx"),O=r("./src/next-devtools/dev-overlay/components/errors/error-overlay-call-stack/error-overlay-call-stack.tsx"),M=r("./src/next-devtools/dev-overlay/container/runtime-error/error-cause.tsx"),A=r("./src/next-devtools/dev-overlay/utils/get-error-by-type.ts");function D(e){return e.startsWith("https://nextjs.org")?"nextjs-link":e.startsWith("https://")||e.startsWith("http://")?"external-link":null}function F(e){let t,r=(0,o.c)(2),{message:a}=e;return r[0]!==a?(t=(0,n.jsx)(k.E,{text:a,matcher:D}),r[0]=a,r[1]=t):t=r[1],t}function $(e){let t,r,a=(0,o.c)(7),{error:i}=e,s="environmentName"in i?i.environmentName:"",l=s?`[ ${s} ] `:"",c=i.message;if(c.startsWith(l)){let e;a[0]!==l.length||a[1]!==c?(e=c.slice(l.length),a[0]=l.length,a[1]=c,a[2]=e):e=a[2],c=e}return(a[3]!==c?(t=c.trim(),a[3]=c,a[4]=t):t=a[4],c=t)?(a[5]!==c?(r=(0,n.jsx)(n.Fragment,{children:(0,n.jsx)(k.E,{text:c,matcher:D})}),a[5]=c,a[6]=r):r=a[6],r):null}function U(e,t,r){return"blocking-route"===r.type?r.inNavigation?"Instant":"Blocking Route":"static-route"===r.type?"Static Route":"client-hook"===r.type?"Blocking Route":"dynamic-metadata"===r.type||"dynamic-viewport"===r.type?"prefetch"===r.variant||"navigation"===r.variant?"Instant":"Blocking Route":"sync-io"===r.type||"sync-io-client"===r.type?"Blocking Route":"unrendered-segment"===r.type||"link-prefetch-partial"===r.type?"Instant":"recoverable"===t?`Recoverable ${e.name}`:"console"===t?`Console ${e.name}`:`Runtime ${e.name}`}let Z={type:"empty"};function q(e,t){let r,n=(0,o.c)(9);r:{let o,a,i,s;if(void 0===e){r=Z;break r}n[0]!==e||n[1]!==t?(o=function(e,t){let r=t(e);if(null!==r)return{type:"hydration",warning:r.warning??null,notes:null,reactOutputComponentDiff:r.reactOutputComponentDiff??null};if(!(0,C.rJ)(e))return null;let{message:n,notes:o,diff:a}=(0,C.f5)(e);return null===n?null:{type:"hydration",warning:n,notes:o,reactOutputComponentDiff:a}}(e,t),n[0]=e,n[1]=t,n[2]=o):o=n[2];let l=o;if(l){r=l;break r}n[3]!==e?(a=Y(e),n[3]=e,n[4]=a):a=n[4];let c=a;if(c){r=c;break r}n[5]!==e?(i=X(e),n[5]=e,n[6]=i):i=n[6];let u=i;if(u){r=u;break r}n[7]!==e?(s=Q(e),n[7]=e,n[8]=s):s=n[8];let d=s;if(d){r=d;break r}r=Z}return r}function B(e){let t,r,a,i,s,l,c=(0,o.c)(25),{error:u,variant:d,kind:f,explanation:p,cause:h,showExplanation:m,dialogResizerRef:g,generateErrorInfo:v}=e,x=void 0===f?"blocking-route":f,y=void 0===m||m,b=(0,A.s)(u),w=b.findIndex(V),_=b[w]??null;c[0]!==h||c[1]!==_?.originalCodeFrame||c[2]!==x||c[3]!==d?(t=h??function(e,t,r){if("dynamic"===t&&("blocking-route"===e||"metadata"===e||"viewport"===e||"static-route"===e||"static-metadata"===e||"static-viewport"===e)&&r){for(let e of N()(r).split("\n"))if(/^\s*>/.test(e)&&/\bconnection\s*\(/.test(e))return"connection"}}(x,d,_?.originalCodeFrame),c[0]=h,c[1]=_?.originalCodeFrame,c[2]=x,c[3]=d,c[4]=t):t=c[4];let k=t;return c[5]!==_?(r=_&&(0,n.jsx)(L.Z,{stackFrame:_.originalStackFrame,codeFrame:_.originalCodeFrame}),c[5]=_,c[6]=r):r=c[6],c[7]!==k||c[8]!==p||c[9]!==v||c[10]!==x||c[11]!==y||c[12]!==d?(a=(0,n.jsx)(z.gD,{variant:d,kind:x,explanation:p,cause:k,showExplanation:y,generateErrorInfo:v}),c[7]=k,c[8]=p,c[9]=v,c[10]=x,c[11]=y,c[12]=d,c[13]=a):a=c[13],c[14]!==g||c[15]!==b?(i=b.length>0&&(0,n.jsx)(O.d,{dialogResizerRef:g,frames:b}),c[14]=g,c[15]=b,c[16]=i):i=c[16],c[17]!==g||c[18]!==u.cause?(s=u.cause&&(0,n.jsx)(M.C,{cause:u.cause,dialogResizerRef:g}),c[17]=g,c[18]=u.cause,c[19]=s):s=c[19],c[20]!==r||c[21]!==a||c[22]!==i||c[23]!==s?(l=(0,n.jsxs)(n.Fragment,{children:[r,a,i,s]}),c[20]=r,c[21]=a,c[22]=i,c[23]=s,c[24]=l):l=c[24],l}function V(e){return!e.ignored&&!!e.originalCodeFrame&&!!e.originalStackFrame}function H(e){return e.includes("encountered `navigation()`")?"navigation":e.includes("encountered `prefetch()`")?"prefetch":e.includes("encountered URL data")&&!e.includes("encountered uncached data")?"link":e.includes("encountered runtime data")&&!e.includes("encountered uncached data")?"runtime":"dynamic"}let W=["Math.random()","new Date()","Date()","Date.now()","require('node:crypto').generateKeyPairSync(...)","require('node:crypto').generateKeySync(...)","require('node:crypto').generatePrimeSync(...)","require('node:crypto').randomFillSync(...)","require('node:crypto').randomBytes(size)","require('node:crypto').randomInt(min, max)","require('node:crypto').randomUUID()","crypto.getRandomValues()","crypto.randomUUID()"],G=/https:\/\/nextjs\.org\/docs\/messages\/blocking-prerender-(random|current-time|crypto)(-client)?/;function K(e){return e.includes("or a navigation")||e.includes("/instant-navigation-stage-metadata")||e.includes("/instant-navigation-stage-viewport")||e.includes("Could not validate `instant`")||e.includes("Could not validate that a segment in your UI has instant navigation")}function Y(e){let t=e.message,r=K(t),n=/https:\/\/nextjs\.org\/docs\/messages\/static-(route|metadata|viewport)\b/.exec(t);if(n)return{type:"static-route",kind:`static-${n[1]}`,variant:H(t),headline:t.split("\n")[0].replace(/^Route "[^"]*": /,"")};let o=/Next\.js encountered URL data `([^`]+)` in a Client Component outside of `<Suspense>`\./.exec(t);if(o)return{type:"client-hook",expression:o[1]};if(t.includes("/blocking-prerender-runtime")||t.includes("/blocking-prerender-dynamic")||t.includes("/instant-shell-url-data")||t.includes("/instant-navigation-stage")&&!t.includes("/instant-navigation-stage-metadata")&&!t.includes("/instant-navigation-stage-viewport"))return{type:"blocking-route",variant:H(t),inNavigation:r};if(t.includes("/blocking-prerender-metadata-dynamic")||t.includes("/blocking-prerender-metadata-runtime")||t.includes("/instant-navigation-stage-metadata")){let e=H(t);return{type:"dynamic-metadata",variant:e,explanation:"prefetch"===e||"navigation"===e?R.Oq:void 0}}if(t.includes("/blocking-prerender-viewport-dynamic")||t.includes("/blocking-prerender-viewport-runtime")||t.includes("/instant-navigation-stage-viewport")){let e=H(t);return{type:"dynamic-viewport",variant:e,explanation:"prefetch"===e||"navigation"===e?R.fK:void 0}}if(G.test(t)){let e,r=null!==(e=G.exec(t))&&"-client"===e[2];for(let e of W)if(t.includes(e))return{type:r?"sync-io-client":"sync-io",cause:e}}return null}function X(e){let t=e.message;if("string"!=typeof t||!t.includes("Could not validate that a segment in your UI has instant navigation"))return null;let r=/^Route "([^"]+)":/.exec(t);if(!r)return null;let n=r[1],o=[],a=/\nDropped segments?:\n([^]*?)(?:\n\n|$)/.exec(t);if(a)for(let e of a[1].split("\n")){let t=e.replace(/^\s+/,"");t&&o.push(t)}return{type:"unrendered-segment",route:n,files:o}}function Q(e){let t=e.message;if("string"!=typeof t)return null;let r=/^Next\.js encountered dynamic data during prefetching for "([^"]+)"\./.exec(t);return r?{type:"link-prefetch-partial",pathname:r[1]}:null}function J(e){if(X(e)||Q(e))return!0;let t=Y(e);return t?.type==="blocking-route"?t.inNavigation:(t?.type==="dynamic-metadata"||t?.type==="dynamic-viewport")&&("prefetch"===t.variant||"navigation"===t.variant)}function ee(e){let t,r,a,i,s,l=(0,o.c)(24),{activeTab:c,onTabChange:u,errorCount:d,instantCount:f,errorActiveIdx:p,instantActiveIdx:h,previousButton:m,nextButton:g,createCount:v}=e,x="errors"===c,y=0===d,b=0===d;return l[0]!==u?(t=()=>u("errors"),l[0]=u,l[1]=t):t=l[1],l[2]!==c||l[3]!==v||l[4]!==p||l[5]!==d?(r=0===d?"No issues":(0,n.jsxs)(n.Fragment,{children:["Issues",(0,n.jsx)("span",{className:"error-overlay-tab-count","data-active":"errors"===c,children:v(p,d,"errors"===c)})]}),l[2]=c,l[3]=v,l[4]=p,l[5]=d,l[6]=r):r=l[6],l[7]!==x||l[8]!==y||l[9]!==b||l[10]!==t||l[11]!==r?(a=(0,n.jsx)("button",{type:"button",className:"error-overlay-tab","data-active":x,disabled:y,"aria-disabled":b,onClick:t,children:r}),l[7]=x,l[8]=y,l[9]=b,l[10]=t,l[11]=r,l[12]=a):a=l[12],l[13]!==c||l[14]!==v||l[15]!==h||l[16]!==f||l[17]!==u?(i=f>0&&(0,n.jsxs)("button",{type:"button",className:"error-overlay-tab","data-active":"instant"===c,onClick:()=>u("instant"),children:["Insights",(0,n.jsx)("span",{className:"error-overlay-tab-count","data-active":"instant"===c,children:v(h,f,"instant"===c)})]}),l[13]=c,l[14]=v,l[15]=h,l[16]=f,l[17]=u,l[18]=i):i=l[18],l[19]!==g||l[20]!==m||l[21]!==a||l[22]!==i?(s=(0,n.jsxs)("div",{className:"error-overlay-tab-bar","data-nextjs-error-overlay-tab-bar":!0,children:[m,a,i,g]}),l[19]=g,l[20]=m,l[21]=a,l[22]=i,l[23]=s):s=l[23],s}function et(e){let t,r,i,s,l,c,u,f,p,h,m,g,v,x,b,E,T,N,L,O,M=(0,o.c)(361);M[0]!==e?({getSquashedHydrationErrorDetails:r,runtimeErrors:c,debugInfo:t,onClose:s,hasVulnerabilityInsight:i,...l}=e,M[0]=e,M[1]=t,M[2]=r,M[3]=i,M[4]=s,M[5]=l,M[6]=c):(t=M[1],r=M[2],i=M[3],s=M[4],l=M[5],c=M[6]);let A=(0,a.useRef)(null);if(M[7]!==c){let e=[],t=[];for(let r of c)J(r.error)?t.push(r):e.push(r);u={normalErrors:e,instantErrors:t},M[7]=c,M[8]=u}else u=M[8];let{normalErrors:Z,instantErrors:V}=u,H=V.length+ +!!i;M[9]!==Z.length?(f=()=>Z.length>0?"errors":"instant",M[9]=Z.length,M[10]=f):f=M[10];let[W,G]=(0,a.useState)(f);M[11]===Symbol.for("react.memo_cache_sentinel")?(p={errors:0,instant:0},M[11]=p):p=M[11];let[K,Y]=(0,a.useState)(p),X="errors"===W?Z.length>0?"errors":"instant":H>0?"instant":"errors",Q="instant"===X?V:Z,et=Math.max(0,Math.min(K.errors,Math.max(0,Z.length-1))),eo=Math.max(0,Math.min(K.instant,Math.max(0,H-1))),ea="instant"===X?eo:et;M[12]!==X?(h=e=>{Y(t=>({...t,[X]:e}))},M[12]=X,M[13]=h):h=M[13],M[14]!==Q||M[15]!==ea||M[16]!==r||M[17]!==h?(m={runtimeErrors:Q,getSquashedHydrationErrorDetails:r,activeIdx:ea,setActiveIndex:h},M[14]=Q,M[15]=ea,M[16]=r,M[17]=h,M[18]=m):m=M[18];let{isLoading:ei,errorType:es,activeIdx:el,errorDetails:ec,activeError:eu,setActiveIndex:ed}=function(e){let t,r,n=(0,o.c)(15),{runtimeErrors:i,getSquashedHydrationErrorDetails:s,activeIdx:l,setActiveIndex:c}=e,[u,d]=(0,a.useState)(0),f=l??u,p=c??d,h=0===i.length,m=i[f]??null,g=q(m?.error,s);if(h||!m){let e;return n[0]!==f||n[1]!==h||n[2]!==p?(e={isLoading:h,activeIdx:f,setActiveIndex:p,activeError:null,errorDetails:null,errorType:null},n[0]=f,n[1]=h,n[2]=p,n[3]=e):e=n[3],e}let v=m.error;n[4]!==m.type||n[5]!==v||n[6]!==g?(t=U(v,m.type,g),n[4]=m.type,n[5]=v,n[6]=g,n[7]=t):t=n[7];let x=t;return n[8]!==m||n[9]!==f||n[10]!==g||n[11]!==x||n[12]!==h||n[13]!==p?(r={isLoading:h,activeIdx:f,setActiveIndex:p,activeError:m,errorDetails:g,errorType:x},n[8]=m,n[9]=f,n[10]=g,n[11]=x,n[12]=h,n[13]=p,n[14]=r):r=n[14],r}(m);M[19]!==eu||M[20]!==es||M[21]!==l.versionInfo.installed?(g=()=>I({activeError:eu,errorType:es,versionInfo:l.versionInfo.installed,bundler:process.env.__NEXT_BUNDLER}),M[19]=eu,M[20]=es,M[21]=l.versionInfo.installed,M[22]=g):g=M[22];let ef=g,ep=H>0;M[23]!==X||M[24]!==et||M[25]!==H||M[26]!==eo||M[27]!==Z.length||M[28]!==ep?(v=ep?e=>{let{previousButton:t,createCount:r,nextButton:o}=e;return(0,n.jsx)(ee,{activeTab:X,onTabChange:e=>{(0,a.startTransition)(()=>{G(e)})},errorCount:Z.length,instantCount:H,errorActiveIdx:et,instantActiveIdx:eo,previousButton:t,nextButton:o,createCount:r})}:void 0,M[23]=X,M[24]=et,M[25]=H,M[26]=eo,M[27]=Z.length,M[28]=ep,M[29]=v):v=M[29];let eh=v,em=ep?"errors"===X?et>0:eo>0||Z.length>0:el>0,eg=ep?"errors"===X?et<Z.length-1||H>0:eo<H-1:el<Q.length-1;M[30]!==X||M[31]!==et||M[32]!==eo||M[33]!==Z.length||M[34]!==ed||M[35]!==ep?(x=ep?()=>{(0,a.startTransition)(()=>{if("errors"===X){et>0&&ed(et-1);return}eo>0?ed(eo-1):Z.length>0&&(G("errors"),Y(e=>({...e,errors:Math.max(0,Z.length-1)})))})}:void 0,M[30]=X,M[31]=et,M[32]=eo,M[33]=Z.length,M[34]=ed,M[35]=ep,M[36]=x):x=M[36];let ev=x;M[37]!==X||M[38]!==et||M[39]!==H||M[40]!==eo||M[41]!==Z.length||M[42]!==ed||M[43]!==ep?(b=ep?()=>{(0,a.startTransition)(()=>{"errors"===X?et<Z.length-1?ed(et+1):H>0&&(G("instant"),Y(en)):eo<H-1&&ed(eo+1)})}:void 0,M[37]=X,M[38]=et,M[39]=H,M[40]=eo,M[41]=Z.length,M[42]=ed,M[43]=ep,M[44]=b):b=M[44];let ex=b;if(i&&"instant"===X&&eo===V.length){let e,t=c.some(er)?void 0:s;return M[45]!==eg||M[46]!==em||M[47]!==ex||M[48]!==ev||M[49]!==l||M[50]!==eh||M[51]!==t?(e=(0,n.jsx)(y,{...l,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:t}),M[45]=eg,M[46]=em,M[47]=ex,M[48]=ev,M[49]=l,M[50]=eh,M[51]=t,M[52]=e):e=M[52],e}if(ei){let e;return M[53]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)(d.h,{children:(0,n.jsx)(d.D,{})}),M[53]=e):e=M[53],e}if(!eu)return null;let ey=eu.error,eb=["server","edge-server"].includes((0,_.C)(ey)||""),ew=null,e_=null;switch(ec.type){case"hydration":{let e,t,r,o;if(M[54]!==ec.warning||M[55]!==ey?(e=ec.warning?(0,n.jsx)(F,{message:ec.warning}):(0,n.jsx)($,{error:ey}),M[54]=ec.warning,M[55]=ey,M[56]=e):e=M[56],E=e,M[57]!==ec.notes?(t=ec.notes?(0,n.jsx)(n.Fragment,{children:(0,n.jsx)("p",{id:"nextjs__container_errors__notes",className:"nextjs__container_errors__notes",children:ec.notes})}):null,M[57]=ec.notes,M[58]=t):t=M[58],M[59]!==ec.warning?(r=ec.warning?(0,n.jsx)("p",{id:"nextjs__container_errors__link",className:"nextjs__container_errors__link",children:(0,n.jsx)(k.E,{text:`See more info here: ${C.Gg}`})}):null,M[59]=ec.warning,M[60]=r):r=M[60],M[61]!==t||M[62]!==r?(o=(0,n.jsxs)("div",{className:"error-overlay-notes-container",children:[t,r]}),M[61]=t,M[62]=r,M[63]=o):o=M[63],ew=o,ec.reactOutputComponentDiff){let e,t=ec.reactOutputComponentDiff||"";M[64]!==t?(e=(0,n.jsx)(j.B,{reactOutputComponentDiff:t}),M[64]=t,M[65]=e):e=M[65],e_=e}break}case"blocking-route":{let e,r,o,i,c;switch(ec.variant){case"runtime":E=ec.inNavigation?"Next.js encountered runtime data during a navigation.":"Next.js encountered runtime data during prerendering.";break;case"link":E="Next.js encountered URL data outside of Suspense.";break;case"navigation":{let e;M[66]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered ",(0,n.jsx)("code",{children:"navigation()"})," outside of Suspense."]}),M[66]=e):e=M[66],E=e;break}case"prefetch":{let e;M[67]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered ",(0,n.jsx)("code",{children:"prefetch()"})," outside of Suspense."]}),M[67]=e):e=M[67],E=e;break}case"dynamic":E=ec.inNavigation?"Next.js encountered uncached data during a navigation.":"Next.js encountered uncached data during prerendering.";break;default:E=ec.variant}let u=E,d="link"===ec.variant||"prefetch"===ec.variant||"navigation"===ec.variant?R.iJ:ec.inNavigation?R.Z8:void 0;M[68]!==ec.variant||M[69]!==d?(e=(0,n.jsx)(z.YO,{kind:"blocking-route",variant:ec.variant,explanation:d}),M[68]=ec.variant,M[69]=d,M[70]=e):e=M[70];let f=eb?void 0:s;return M[71]===Symbol.for("react.memo_cache_sentinel")?(r=(0,n.jsx)("div",{"data-nextjs-error-suspended":!0}),M[71]=r):r=M[71],M[72]!==eu.id?(o=eu.id.toString(),M[72]=eu.id,M[73]=o):o=M[73],M[74]!==eu||M[75]!==ec.variant||M[76]!==ef||M[77]!==o?(i=(0,n.jsx)(a.Suspense,{fallback:r,children:(0,n.jsx)(B,{error:eu,variant:ec.variant,showExplanation:!1,dialogResizerRef:A,generateErrorInfo:ef},o)}),M[74]=eu,M[75]=ec.variant,M[76]=ef,M[77]=o,M[78]=i):i=M[78],M[79]!==Q||M[80]!==el||M[81]!==eg||M[82]!==em||M[83]!==t||M[84]!==E||M[85]!==es||M[86]!==ey||M[87]!==ef||M[88]!==ex||M[89]!==ev||M[90]!==l||M[91]!==eh||M[92]!==ed||M[93]!==e||M[94]!==f||M[95]!==i?(c=(0,n.jsx)(S.V,{errorType:es,errorMessage:u,headerChildren:e,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:f,debugInfo:t,error:ey,runtimeErrors:Q,activeIdx:el,setActiveIndex:ed,dialogResizerRef:A,generateErrorInfo:ef,...l,children:i}),M[79]=Q,M[80]=el,M[81]=eg,M[82]=em,M[83]=t,M[84]=E,M[85]=es,M[86]=ey,M[87]=ef,M[88]=ex,M[89]=ev,M[90]=l,M[91]=eh,M[92]=ed,M[93]=e,M[94]=f,M[95]=i,M[96]=c):c=M[96],c}case"client-hook":{let e,r,o,i,c,u;M[97]!==ec.expression?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered URL data"," ",(0,n.jsx)("code",{children:ec.expression})," in a Client Component outside of Suspense."]}),M[97]=ec.expression,M[98]=e):e=M[98],M[99]===Symbol.for("react.memo_cache_sentinel")?(r=(0,n.jsx)(z.YO,{kind:"client-hook"}),M[99]=r):r=M[99];let d=eb?void 0:s;return M[100]===Symbol.for("react.memo_cache_sentinel")?(o=(0,n.jsx)("div",{"data-nextjs-error-suspended":!0}),M[100]=o):o=M[100],M[101]!==eu.id?(i=eu.id.toString(),M[101]=eu.id,M[102]=i):i=M[102],M[103]!==eu||M[104]!==ec.expression||M[105]!==ef||M[106]!==i?(c=(0,n.jsx)(a.Suspense,{fallback:o,children:(0,n.jsx)(B,{error:eu,variant:"runtime",kind:"client-hook",cause:ec.expression,showExplanation:!1,dialogResizerRef:A,generateErrorInfo:ef},i)}),M[103]=eu,M[104]=ec.expression,M[105]=ef,M[106]=i,M[107]=c):c=M[107],M[108]!==Q||M[109]!==el||M[110]!==eg||M[111]!==em||M[112]!==t||M[113]!==es||M[114]!==ey||M[115]!==ef||M[116]!==ex||M[117]!==ev||M[118]!==l||M[119]!==eh||M[120]!==ed||M[121]!==e||M[122]!==d||M[123]!==c?(u=(0,n.jsx)(S.V,{errorType:es,errorMessage:e,headerChildren:r,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:d,debugInfo:t,error:ey,runtimeErrors:Q,activeIdx:el,setActiveIndex:ed,dialogResizerRef:A,generateErrorInfo:ef,...l,children:c}),M[108]=Q,M[109]=el,M[110]=eg,M[111]=em,M[112]=t,M[113]=es,M[114]=ey,M[115]=ef,M[116]=ex,M[117]=ev,M[118]=l,M[119]=eh,M[120]=ed,M[121]=e,M[122]=d,M[123]=c,M[124]=u):u=M[124],u}case"static-route":{let e,r,o,i,c,u;M[125]!==ec.headline?(e=(0,n.jsx)(k.E,{text:ec.headline,matcher:D}),M[125]=ec.headline,M[126]=e):e=M[126],M[127]!==ec.kind||M[128]!==ec.variant?(r=(0,n.jsx)(z.YO,{kind:ec.kind,variant:ec.variant}),M[127]=ec.kind,M[128]=ec.variant,M[129]=r):r=M[129];let d=eb?void 0:s;return M[130]===Symbol.for("react.memo_cache_sentinel")?(o=(0,n.jsx)("div",{"data-nextjs-error-suspended":!0}),M[130]=o):o=M[130],M[131]!==eu.id?(i=eu.id.toString(),M[131]=eu.id,M[132]=i):i=M[132],M[133]!==eu||M[134]!==ec.kind||M[135]!==ec.variant||M[136]!==ef||M[137]!==i?(c=(0,n.jsx)(a.Suspense,{fallback:o,children:(0,n.jsx)(B,{error:eu,variant:ec.variant,kind:ec.kind,showExplanation:!1,dialogResizerRef:A,generateErrorInfo:ef},i)}),M[133]=eu,M[134]=ec.kind,M[135]=ec.variant,M[136]=ef,M[137]=i,M[138]=c):c=M[138],M[139]!==Q||M[140]!==el||M[141]!==eg||M[142]!==em||M[143]!==t||M[144]!==es||M[145]!==ey||M[146]!==ef||M[147]!==ex||M[148]!==ev||M[149]!==l||M[150]!==eh||M[151]!==ed||M[152]!==e||M[153]!==r||M[154]!==d||M[155]!==c?(u=(0,n.jsx)(S.V,{errorType:es,errorMessage:e,headerChildren:r,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:d,debugInfo:t,error:ey,runtimeErrors:Q,activeIdx:el,setActiveIndex:ed,dialogResizerRef:A,generateErrorInfo:ef,...l,children:c}),M[139]=Q,M[140]=el,M[141]=eg,M[142]=em,M[143]=t,M[144]=es,M[145]=ey,M[146]=ef,M[147]=ex,M[148]=ev,M[149]=l,M[150]=eh,M[151]=ed,M[152]=e,M[153]=r,M[154]=d,M[155]=c,M[156]=u):u=M[156],u}case"dynamic-metadata":{let e,r,o,i,c;switch(ec.variant){case"runtime":{let e;M[157]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered runtime data in"," ",(0,n.jsx)("code",{children:"generateMetadata()"}),"."]}),M[157]=e):e=M[157],E=e;break}case"link":{let e;M[158]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered URL data in ",(0,n.jsx)("code",{children:"generateMetadata()"}),"."]}),M[158]=e):e=M[158],E=e;break}case"navigation":{let e,t;M[159]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("code",{children:"navigation()"}),M[159]=e):e=M[159],M[160]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered ",e," in"," ",(0,n.jsx)("code",{children:"generateMetadata()"}),"."]}),M[160]=t):t=M[160],E=t;break}case"prefetch":{let e,t;M[161]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("code",{children:"prefetch()"}),M[161]=e):e=M[161],M[162]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered ",e," in"," ",(0,n.jsx)("code",{children:"generateMetadata()"}),"."]}),M[162]=t):t=M[162],E=t;break}case"dynamic":{let e;M[163]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered uncached data in"," ",(0,n.jsx)("code",{children:"generateMetadata()"}),"."]}),M[163]=e):e=M[163],E=e;break}default:E=ec.variant}let u=E;M[164]!==ec.explanation||M[165]!==ec.variant?(e=(0,n.jsx)(z.YO,{kind:"metadata",variant:ec.variant,explanation:ec.explanation}),M[164]=ec.explanation,M[165]=ec.variant,M[166]=e):e=M[166];let d=eb?void 0:s;return M[167]===Symbol.for("react.memo_cache_sentinel")?(r=(0,n.jsx)("div",{"data-nextjs-error-suspended":!0}),M[167]=r):r=M[167],M[168]!==eu.id?(o=eu.id.toString(),M[168]=eu.id,M[169]=o):o=M[169],M[170]!==eu||M[171]!==ec.variant||M[172]!==ef||M[173]!==o?(i=(0,n.jsx)(a.Suspense,{fallback:r,children:(0,n.jsx)(B,{error:eu,variant:ec.variant,kind:"metadata",showExplanation:!1,dialogResizerRef:A,generateErrorInfo:ef},o)}),M[170]=eu,M[171]=ec.variant,M[172]=ef,M[173]=o,M[174]=i):i=M[174],M[175]!==Q||M[176]!==el||M[177]!==eg||M[178]!==em||M[179]!==t||M[180]!==E||M[181]!==es||M[182]!==ey||M[183]!==ef||M[184]!==ex||M[185]!==ev||M[186]!==l||M[187]!==eh||M[188]!==ed||M[189]!==e||M[190]!==d||M[191]!==i?(c=(0,n.jsx)(S.V,{errorType:es,errorMessage:u,headerChildren:e,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:d,debugInfo:t,error:ey,runtimeErrors:Q,activeIdx:el,setActiveIndex:ed,dialogResizerRef:A,generateErrorInfo:ef,...l,children:i}),M[175]=Q,M[176]=el,M[177]=eg,M[178]=em,M[179]=t,M[180]=E,M[181]=es,M[182]=ey,M[183]=ef,M[184]=ex,M[185]=ev,M[186]=l,M[187]=eh,M[188]=ed,M[189]=e,M[190]=d,M[191]=i,M[192]=c):c=M[192],c}case"dynamic-viewport":{let e,r,o,i,c;switch(ec.variant){case"link":{let e;M[193]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered URL data in ",(0,n.jsx)("code",{children:"generateViewport()"}),"."]}),M[193]=e):e=M[193],E=e;break}case"runtime":{let e;M[194]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered runtime data in"," ",(0,n.jsx)("code",{children:"generateViewport()"}),"."]}),M[194]=e):e=M[194],E=e;break}case"navigation":{let e,t;M[195]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("code",{children:"navigation()"}),M[195]=e):e=M[195],M[196]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered ",e," in"," ",(0,n.jsx)("code",{children:"generateViewport()"}),"."]}),M[196]=t):t=M[196],E=t;break}case"prefetch":{let e,t;M[197]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("code",{children:"prefetch()"}),M[197]=e):e=M[197],M[198]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered ",e," in"," ",(0,n.jsx)("code",{children:"generateViewport()"}),"."]}),M[198]=t):t=M[198],E=t;break}case"dynamic":{let e;M[199]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered uncached data in"," ",(0,n.jsx)("code",{children:"generateViewport()"}),"."]}),M[199]=e):e=M[199],E=e;break}default:E=ec.variant}let u=E;M[200]!==ec.explanation||M[201]!==ec.variant?(e=(0,n.jsx)(z.YO,{kind:"viewport",variant:ec.variant,explanation:ec.explanation}),M[200]=ec.explanation,M[201]=ec.variant,M[202]=e):e=M[202];let d=eb?void 0:s;return M[203]===Symbol.for("react.memo_cache_sentinel")?(r=(0,n.jsx)("div",{"data-nextjs-error-suspended":!0}),M[203]=r):r=M[203],M[204]!==eu.id?(o=eu.id.toString(),M[204]=eu.id,M[205]=o):o=M[205],M[206]!==eu||M[207]!==ec.variant||M[208]!==ef||M[209]!==o?(i=(0,n.jsx)(a.Suspense,{fallback:r,children:(0,n.jsx)(B,{error:eu,variant:ec.variant,kind:"viewport",showExplanation:!1,dialogResizerRef:A,generateErrorInfo:ef},o)}),M[206]=eu,M[207]=ec.variant,M[208]=ef,M[209]=o,M[210]=i):i=M[210],M[211]!==Q||M[212]!==el||M[213]!==eg||M[214]!==em||M[215]!==t||M[216]!==E||M[217]!==es||M[218]!==ey||M[219]!==ef||M[220]!==ex||M[221]!==ev||M[222]!==l||M[223]!==eh||M[224]!==ed||M[225]!==e||M[226]!==d||M[227]!==i?(c=(0,n.jsx)(S.V,{errorType:es,errorMessage:u,headerChildren:e,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:d,debugInfo:t,error:ey,runtimeErrors:Q,activeIdx:el,setActiveIndex:ed,dialogResizerRef:A,generateErrorInfo:ef,...l,children:i}),M[211]=Q,M[212]=el,M[213]=eg,M[214]=em,M[215]=t,M[216]=E,M[217]=es,M[218]=ey,M[219]=ef,M[220]=ex,M[221]=ev,M[222]=l,M[223]=eh,M[224]=ed,M[225]=e,M[226]=d,M[227]=i,M[228]=c):c=M[228],c}case"sync-io":{let e,r,o,i,c,u;M[229]!==ec.cause?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered the unstable value"," ",(0,n.jsx)("code",{children:ec.cause})," while prerendering."]}),M[229]=ec.cause,M[230]=e):e=M[230];let d=z.HI[ec.cause];M[231]!==d?(r=(0,n.jsx)(z.YO,{explanation:"This value can change between renders, so it must be either prerendered or computed later.",docsUrl:d}),M[231]=d,M[232]=r):r=M[232];let f=eb?void 0:s;return M[233]===Symbol.for("react.memo_cache_sentinel")?(o=(0,n.jsx)("div",{"data-nextjs-error-suspended":!0}),M[233]=o):o=M[233],M[234]!==eu.id?(i=eu.id.toString(),M[234]=eu.id,M[235]=i):i=M[235],M[236]!==eu||M[237]!==ec.cause||M[238]!==ef||M[239]!==i?(c=(0,n.jsx)(a.Suspense,{fallback:o,children:(0,n.jsx)(B,{error:eu,variant:"runtime",kind:"sync-io",cause:ec.cause,showExplanation:!1,dialogResizerRef:A,generateErrorInfo:ef},i)}),M[236]=eu,M[237]=ec.cause,M[238]=ef,M[239]=i,M[240]=c):c=M[240],M[241]!==Q||M[242]!==el||M[243]!==eg||M[244]!==em||M[245]!==t||M[246]!==es||M[247]!==ey||M[248]!==ef||M[249]!==ex||M[250]!==ev||M[251]!==l||M[252]!==eh||M[253]!==ed||M[254]!==e||M[255]!==r||M[256]!==f||M[257]!==c?(u=(0,n.jsx)(S.V,{errorType:es,errorMessage:e,headerChildren:r,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:f,debugInfo:t,error:ey,runtimeErrors:Q,activeIdx:el,setActiveIndex:ed,dialogResizerRef:A,generateErrorInfo:ef,...l,children:c}),M[241]=Q,M[242]=el,M[243]=eg,M[244]=em,M[245]=t,M[246]=es,M[247]=ey,M[248]=ef,M[249]=ex,M[250]=ev,M[251]=l,M[252]=eh,M[253]=ed,M[254]=e,M[255]=r,M[256]=f,M[257]=c,M[258]=u):u=M[258],u}case"sync-io-client":{let e,r,o,i,c,u;M[259]!==ec.cause?(e=(0,n.jsxs)(n.Fragment,{children:["Next.js encountered the unstable value"," ",(0,n.jsx)("code",{children:ec.cause})," in a Client Component."]}),M[259]=ec.cause,M[260]=e):e=M[260];let d=z.Rd[ec.cause];M[261]!==d?(r=(0,n.jsx)(z.YO,{explanation:"This value would be evaluated during the prerender, instead of recomputed on each visit.",docsUrl:d}),M[261]=d,M[262]=r):r=M[262];let f=eb?void 0:s;return M[263]===Symbol.for("react.memo_cache_sentinel")?(o=(0,n.jsx)("div",{"data-nextjs-error-suspended":!0}),M[263]=o):o=M[263],M[264]!==eu.id?(i=eu.id.toString(),M[264]=eu.id,M[265]=i):i=M[265],M[266]!==eu||M[267]!==ec.cause||M[268]!==ef||M[269]!==i?(c=(0,n.jsx)(a.Suspense,{fallback:o,children:(0,n.jsx)(B,{error:eu,variant:"runtime",kind:"sync-io-client",cause:ec.cause,showExplanation:!1,dialogResizerRef:A,generateErrorInfo:ef},i)}),M[266]=eu,M[267]=ec.cause,M[268]=ef,M[269]=i,M[270]=c):c=M[270],M[271]!==Q||M[272]!==el||M[273]!==eg||M[274]!==em||M[275]!==t||M[276]!==es||M[277]!==ey||M[278]!==ef||M[279]!==ex||M[280]!==ev||M[281]!==l||M[282]!==eh||M[283]!==ed||M[284]!==e||M[285]!==r||M[286]!==f||M[287]!==c?(u=(0,n.jsx)(S.V,{errorType:es,errorMessage:e,headerChildren:r,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:f,debugInfo:t,error:ey,runtimeErrors:Q,activeIdx:el,setActiveIndex:ed,dialogResizerRef:A,generateErrorInfo:ef,...l,children:c}),M[271]=Q,M[272]=el,M[273]=eg,M[274]=em,M[275]=t,M[276]=es,M[277]=ey,M[278]=ef,M[279]=ex,M[280]=ev,M[281]=l,M[282]=eh,M[283]=ed,M[284]=e,M[285]=r,M[286]=f,M[287]=c,M[288]=u):u=M[288],u}case"unrendered-segment":{let e,r,o,a;M[289]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)(z.YO,{kind:"unrendered-segment"}),M[289]=e):e=M[289];let i=eb?void 0:s;return M[290]!==ec.files||M[291]!==ec.route?(r=(0,n.jsx)(P.g,{route:ec.route,files:ec.files}),M[290]=ec.files,M[291]=ec.route,M[292]=r):r=M[292],M[293]===Symbol.for("react.memo_cache_sentinel")?(o=(0,n.jsx)(z.gD,{kind:"unrendered-segment",variant:"dynamic",showExplanation:!1}),M[293]=o):o=M[293],M[294]!==Q||M[295]!==el||M[296]!==eg||M[297]!==em||M[298]!==t||M[299]!==es||M[300]!==ey||M[301]!==ef||M[302]!==ex||M[303]!==ev||M[304]!==l||M[305]!==eh||M[306]!==ed||M[307]!==i||M[308]!==r?(a=(0,n.jsxs)(S.V,{errorType:es,errorMessage:"Next.js could not validate that a segment in your UI has instant navigation.",headerChildren:e,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:i,debugInfo:t,error:ey,runtimeErrors:Q,activeIdx:el,setActiveIndex:ed,dialogResizerRef:A,generateErrorInfo:ef,...l,children:[r,o]}),M[294]=Q,M[295]=el,M[296]=eg,M[297]=em,M[298]=t,M[299]=es,M[300]=ey,M[301]=ef,M[302]=ex,M[303]=ev,M[304]=l,M[305]=eh,M[306]=ed,M[307]=i,M[308]=r,M[309]=a):a=M[309],a}case"link-prefetch-partial":{let e,r,o,i,c;M[310]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)(z.YO,{kind:"link-prefetch-partial"}),M[310]=e):e=M[310];let u=eb?void 0:s;return M[311]===Symbol.for("react.memo_cache_sentinel")?(r=(0,n.jsx)("div",{"data-nextjs-error-suspended":!0}),M[311]=r):r=M[311],M[312]!==eu.id?(o=eu.id.toString(),M[312]=eu.id,M[313]=o):o=M[313],M[314]!==eu||M[315]!==ef||M[316]!==o?(i=(0,n.jsx)(a.Suspense,{fallback:r,children:(0,n.jsx)(B,{error:eu,variant:"runtime",kind:"link-prefetch-partial",showExplanation:!1,dialogResizerRef:A,generateErrorInfo:ef},o)}),M[314]=eu,M[315]=ef,M[316]=o,M[317]=i):i=M[317],M[318]!==Q||M[319]!==el||M[320]!==eg||M[321]!==em||M[322]!==t||M[323]!==es||M[324]!==ey||M[325]!==ef||M[326]!==ex||M[327]!==ev||M[328]!==l||M[329]!==eh||M[330]!==ed||M[331]!==u||M[332]!==i?(c=(0,n.jsx)(S.V,{errorType:es,errorMessage:"Next.js encountered dynamic data during prefetching.",headerChildren:e,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:u,debugInfo:t,error:ey,runtimeErrors:Q,activeIdx:el,setActiveIndex:ed,dialogResizerRef:A,generateErrorInfo:ef,...l,children:i}),M[318]=Q,M[319]=el,M[320]=eg,M[321]=em,M[322]=t,M[323]=es,M[324]=ey,M[325]=ef,M[326]=ex,M[327]=ev,M[328]=l,M[329]=eh,M[330]=ed,M[331]=u,M[332]=i,M[333]=c):c=M[333],c}case"empty":{let e;M[334]!==ey?(e=(0,n.jsx)($,{error:ey}),M[334]=ey,M[335]=e):e=M[335],E=e}}let ek=E,ej=eb?void 0:s,eS=ew,eC=e_;return M[336]===Symbol.for("react.memo_cache_sentinel")?(T=(0,n.jsx)("div",{"data-nextjs-error-suspended":!0}),M[336]=T):T=M[336],M[337]!==eu.id?(N=eu.id.toString(),M[337]=eu.id,M[338]=N):N=M[338],M[339]!==eu||M[340]!==N?(L=(0,n.jsx)(a.Suspense,{fallback:T,children:(0,n.jsx)(w.b,{error:eu,dialogResizerRef:A},N)}),M[339]=eu,M[340]=N,M[341]=L):L=M[341],M[342]!==Q||M[343]!==el||M[344]!==eg||M[345]!==em||M[346]!==t||M[347]!==E||M[348]!==es||M[349]!==ey||M[350]!==ef||M[351]!==ex||M[352]!==ev||M[353]!==e_||M[354]!==ew||M[355]!==l||M[356]!==eh||M[357]!==ed||M[358]!==ej||M[359]!==L?(O=(0,n.jsxs)(S.V,{errorType:es,errorMessage:ek,renderTabBar:eh,canGoPrevious:em,canGoNext:eg,onPrevious:ev,onNext:ex,onClose:ej,debugInfo:t,error:ey,runtimeErrors:Q,activeIdx:el,setActiveIndex:ed,dialogResizerRef:A,generateErrorInfo:ef,...l,children:[eS,eC,L]}),M[342]=Q,M[343]=el,M[344]=eg,M[345]=em,M[346]=t,M[347]=E,M[348]=es,M[349]=ey,M[350]=ef,M[351]=ex,M[352]=ev,M[353]=e_,M[354]=ew,M[355]=l,M[356]=eh,M[357]=ed,M[358]=ej,M[359]=L,M[360]=O):O=M[360],O}function er(e){let{error:t}=e;return["server","edge-server"].includes((0,_.C)(t)||"")}function en(e){return{...e,instant:0}}let eo=`
  .nextjs-error-with-static {
    bottom: calc(16px * 4.5);
  }
  p.nextjs__container_errors__link {
    font-size: var(--size-14);
  }
  p.nextjs__container_errors__notes {
    color: var(--color-stack-notes);
    font-size: var(--size-14);
    line-height: 1.5;
  }
  .nextjs-container-errors-body > h2:not(:first-child) {
    margin-top: calc(16px + 8px);
  }
  .nextjs-container-errors-body > h2 {
    color: var(--color-title-color);
    margin-bottom: 8px;
    font-size: var(--size-20);
  }
  .nextjs-toast-errors-parent {
    cursor: pointer;
    transition: transform 0.2s ease;
  }
  .nextjs-toast-errors-parent:hover {
    transform: scale(1.1);
  }
  .nextjs-toast-errors {
    display: flex;
    align-items: center;
    justify-content: flex-start;
  }
  .nextjs-toast-errors > svg {
    margin-right: 8px;
  }
  .nextjs-toast-hide-button {
    margin-left: 24px;
    border: none;
    background: none;
    color: var(--color-ansi-bright-white);
    padding: 0;
    transition: opacity 0.25s ease;
    opacity: 0.7;
  }
  .nextjs-toast-hide-button:hover {
    opacity: 1;
  }
  .nextjs__container_errors__error_title {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
    position: relative;
  }
  .nextjs__container_errors__error_title__row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 8px;
    width: 100%;
  }
  .error-overlay-notes-container {
    margin: 8px 2px;
  }
  .error-overlay-notes-container p {
    white-space: pre-wrap;
  }
  .external-link, .external-link:hover {
    color:inherit;
  }

  .error-overlay-tab-bar {
    display: flex;
    gap: 6px;
    translate: var(--next-dialog-border-width) 0;
    max-width: var(--next-dialog-max-width);
    width: 100%;
    position: relative;
    z-index: 1;
  }

  .error-overlay-tab {
    display: flex;
    align-items: center;
    gap: 2px;
    padding: 0 4px;
    border: none;
    background: none;
    color: var(--color-gray-800);
    font-size: var(--size-13);
    font-family: var(--font-stack-sans);
    cursor: pointer;
    position: relative;
    transition: color 0.15s ease;
    border-radius: var(--rounded-md);

    &:hover:not(:disabled) {
      color: var(--color-gray-1000);
    }

    &[data-active='true'] {
      color: var(--color-gray-1000);
      font-weight: 500;
    }

    &:disabled {
      opacity: 0.4;
      cursor: default;
    }

    &:focus-visible {
      outline: var(--focus-ring);
      outline-offset: 2px;
    }
  }

  .error-overlay-tab-count {
    display: flex;
    align-items: center;
    color: inherit;

    &[data-active='true'] {
      .error-overlay-pagination-count {
        font-weight: 500;
      }
    }
  }

`},"./src/next-devtools/dev-overlay/container/runtime-error/component-stack-pseudo-html.tsx"(e,t,r){"use strict";r.d(t,{c:()=>u,B:()=>l});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js");function i(e){let t,r,a,i,s=(0,o.c)(8);s[0]!==e?(t=void 0===e?{}:e,s[0]=e,s[1]=t):t=s[1];let{collapsed:l}=t;return s[2]!==l?(r="boolean"==typeof l?{style:{transform:l?void 0:"rotate(90deg)"}}:{},s[2]=l,s[3]=r):r=s[3],s[4]===Symbol.for("react.memo_cache_sentinel")?(a=(0,n.jsx)("path",{style:{fill:"var(--color-font)"},fillRule:"evenodd",d:"m6.75 3.94.53.53 2.824 2.823a1 1 0 0 1 0 1.414L7.28 11.53l-.53.53L5.69 11l.53-.53L8.69 8 6.22 5.53 5.69 5l1.06-1.06Z",clipRule:"evenodd"}),s[4]=a):a=s[4],s[5]!==l||s[6]!==r?(i=(0,n.jsx)("svg",{"data-nextjs-call-stack-chevron-icon":!0,"data-collapsed":l,width:"16",height:"16",fill:"none",...r,children:a}),s[5]=l,s[6]=r,s[7]=i):i=s[7],i}function s(e){return e.map((e,t)=>{let r="+"===e[0]||"-"===e[0],o=">"===e[0],a=r||o,i=a?e[0]:"",s=a?e.indexOf(i):-1,[l,c]=a?[e.slice(0,s),e.slice(s+1)]:[e,""];return r?(0,n.jsx)("span",{"data-nextjs-container-errors-pseudo-html-line":!0,"data-nextjs-container-errors-pseudo-html--diff":"+"===i?"add":"remove",children:(0,n.jsxs)("span",{children:[l,(0,n.jsx)("span",{"data-nextjs-container-errors-pseudo-html-line-sign":!0,children:i}),c,"\n"]})},"comp-diff"+t):(0,n.jsxs)("span",{"data-nextjs-container-errors-pseudo-html-line":!0,...o?{"data-nextjs-container-errors-pseudo-html--diff":"error"}:void 0,children:[l,(0,n.jsx)("span",{"data-nextjs-container-errors-pseudo-html-line-sign":!0,children:i}),c,"\n"]},"comp-diff"+t)})}function l(e){let t,r,l,u,d,f,p,h,m,g,v,x,y=(0,o.c)(29),{reactOutputComponentDiff:b}=e,[w,_]=(0,a.useState)(!1);if(y[0]!==b){let e=b.split("\n"),n=!1;for(let t of e)if("+"===t[0]||"-"===t[0]){n=!0;break}let o=function(e,t){let r=e=>!e.includes("<Next.js Internal Component>"),n=e=>t.has(e[0])&&r(e),o=t.has("+")?3:1,a=[],i=[],s=!1,l=-1;for(let t=0;t<e.length;t++){let c=e[t];if(n(c)){if(!s){for(let e of a)i.push(e);s=!0}i.push(c),l=t;continue}if(s)continue;let u=c.trim();""!==u&&"..."!==u&&r(c)&&(/^\s*<[A-Z]/.test(c)&&(a.length=0),a.push(c),a.length>o&&a.shift())}if(!s)return e;let c=e[l+1];/^\s*\/?>(?:\s*)$/.test(c??"")&&i.push(c);let u=1/0;for(let e of i){let r=t.has(e[0])?e.slice(1):e,n=r.length-r.trimStart().length;n<u&&(u=n)}return i.map(e=>t.has(e[0])?`${e[0]}${e.slice(1+u)}`:e.slice(u))}(e,new Set(n?["+","-"]:[">"]));t=n,r=s(o),l=s(e),y[0]=b,y[1]=t,y[2]=r,y[3]=l}else t=y[1],r=y[2],l=y[3];y[4]!==t||y[5]!==r||y[6]!==l?(u={hasClientServerDiff:t,excerptComponents:r,fullComponents:l},y[4]=t,y[5]=r,y[6]=l,y[7]=u):u=y[7];let{hasClientServerDiff:k,excerptComponents:j,fullComponents:S}=u,C=k?"client/server diff":"Rendered tree",E=k?"client-server":"invalid-html",T=`${w?"Collapse":"Expand"} ${C}`;y[8]===Symbol.for("react.memo_cache_sentinel")?(d=()=>_(c),y[8]=d):d=y[8];let N=!w;y[9]!==N?(f=(0,n.jsx)(i,{collapsed:N}),y[9]=N,y[10]=f):f=y[10],y[11]!==C?(p=(0,n.jsx)("span",{"data-nextjs-hydration-diff-title":!0,children:C}),y[11]=C,y[12]=p):p=y[12],y[13]!==w||y[14]!==p||y[15]!==T||y[16]!==f?(h=(0,n.jsxs)("button",{type:"button","aria-expanded":w,"aria-label":T,"data-nextjs-container-errors-pseudo-html-collapse-button":!0,onClick:d,children:[f,p]}),y[13]=w,y[14]=p,y[15]=T,y[16]=f,y[17]=h):h=y[17],y[18]!==k?(m=k&&(0,n.jsxs)("div",{"data-nextjs-hydration-diff-badge":!0,children:[(0,n.jsxs)("span",{"data-nextjs-hydration-diff-badge-item":"client",children:[(0,n.jsx)("span",{children:"+"})," Client"]}),(0,n.jsxs)("span",{"data-nextjs-hydration-diff-badge-item":"server",children:[(0,n.jsx)("span",{children:"-"})," Server"]})]}),y[18]=k,y[19]=m):m=y[19],y[20]!==h||y[21]!==m?(g=(0,n.jsxs)("div",{"data-nextjs-hydration-diff-header":!0,children:[h,m]}),y[20]=h,y[21]=m,y[22]=g):g=y[22];let I=w?S:j;return y[23]!==I?(v=(0,n.jsx)("pre",{className:"nextjs__container_errors__component-stack",children:(0,n.jsx)("code",{children:I})}),y[23]=I,y[24]=v):v=y[24],y[25]!==g||y[26]!==v||y[27]!==E?(x=(0,n.jsxs)("div",{"data-nextjs-container-errors-pseudo-html":!0,"data-nextjs-hydration-diff-type":E,children:[g,v]}),y[25]=g,y[26]=v,y[27]=E,y[28]=x):x=y[28],x}function c(e){return!e}let u=`
  [data-nextjs-container-errors-pseudo-html] {
    padding: 8px 0;
    margin: 8px 0;
    border: 1px solid var(--color-gray-400);
    background: var(--color-background-200);
    color: var(--color-syntax-constant);
    font-family: var(--font-stack-monospace);
    font-size: var(--size-12);
    line-height: 1.33em; /* 16px in 12px font size */
    border-radius: var(--rounded-xl);
  }
  [data-nextjs-container-errors-pseudo-html-line] {
    display: inline-block;
    width: 100%;
    padding-left: 40px;
    line-height: calc(5 / 3);
  }
  [data-nextjs-container-errors-pseudo-html--diff='error'] {
    background: var(--color-red-200);
    box-shadow: 2px 0 0 0 var(--color-red-900) inset;
    font-weight: bold;
  }
  [data-nextjs-container-errors-pseudo-html--diff='add'] {
    background: var(--color-green-300);
  }
  [data-nextjs-container-errors-pseudo-html-line-sign] {
    margin-left: calc(24px * -1);
    margin-right: 24px;
  }
  [data-nextjs-container-errors-pseudo-html--diff='add']
    [data-nextjs-container-errors-pseudo-html-line-sign] {
    color: var(--color-green-900);
  }
  [data-nextjs-container-errors-pseudo-html--diff='remove'] {
    background: var(--color-red-300);
  }
  [data-nextjs-container-errors-pseudo-html--diff='remove']
    [data-nextjs-container-errors-pseudo-html-line-sign] {
    color: var(--color-red-900);
    margin-left: calc(24px * -1);
    margin-right: 24px;
  }
  [data-nextjs-container-errors-pseudo-html--diff='error']
    [data-nextjs-container-errors-pseudo-html-line-sign] {
    color: var(--color-red-900);
  }
  
  [data-nextjs-container-errors-pseudo-html--hint] {
    display: inline-block;
    font-size: 0;
    height: 0;
  }
  [data-nextjs-container-errors-pseudo-html--tag-adjacent='false'] {
    color: var(--color-accents-1);
  }
  .nextjs__container_errors__component-stack {
    margin: 0;
  }
  .nextjs__container_errors__component-stack code {
    display: block;
    width: 100%;
    white-space: pre-wrap;
    scroll-snap-type: y mandatory;
    overflow-y: hidden;
  }
  [data-nextjs-hydration-diff-type] {
    color: var(--color-gray-1000);
    font-size: var(--size-13);
    overflow: hidden;
    padding: 0;
  }
  [data-nextjs-hydration-diff-type]
    [data-nextjs-container-errors-pseudo-html-line] {
    box-sizing: border-box;
    font-weight: normal;
    line-height: var(--size-20);
  }
  [data-nextjs-hydration-diff-type='invalid-html']
    [data-nextjs-container-errors-pseudo-html-line-sign] {
    color: var(--color-gray-alpha-1000);
  }
  [data-nextjs-hydration-diff-type]
    .nextjs__container_errors__component-stack,
  [data-nextjs-hydration-diff-type]
    .nextjs__container_errors__component-stack code {
    overflow-x: hidden;
    overflow-wrap: anywhere;
  }
  [data-nextjs-hydration-diff-type]
    .nextjs__container_errors__component-stack {
    background: var(--color-background-100);
    padding: 8px 0 10px;
  }
  [data-nextjs-hydration-diff-title] {
    color: var(--color-gray-900);
    font-family: var(--font-stack-sans);
    font-size: var(--size-12);
  }
  [data-nextjs-container-errors-pseudo-html-collapse-button] {
    all: unset;
    display: flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
    border-radius: var(--rounded-md);
  }
  [data-nextjs-container-errors-pseudo-html-collapse-button]:focus-visible {
    outline: 2px solid var(--color-blue-600);
    outline-offset: 2px;
  }
  [data-nextjs-container-errors-pseudo-html--diff] {
    scroll-snap-align: center;
  }
  .error-overlay-hydration-error-diff-plus-icon {
    color: var(--color-green-900);
  }
  .error-overlay-hydration-error-diff-minus-icon {
    color: var(--color-red-900);
  }
  [data-nextjs-hydration-diff-header] {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid var(--color-gray-200);
    min-height: 36px;
    padding: 0 12px;
  }
  [data-nextjs-hydration-diff-badge] {
    display: flex;
    gap: 8px;
    font-size: var(--size-12);
  }
  [data-nextjs-hydration-diff-badge-item] {
    display: flex;
    align-items: center;
    gap: 4px;
    color: var(--color-gray-900);
  }
  [data-nextjs-hydration-diff-badge-item='client'] span:first-child {
    color: var(--color-green-900);
    font-weight: bold;
  }
  [data-nextjs-hydration-diff-badge-item='server'] span:first-child {
    color: var(--color-red-900);
    font-weight: bold;
  }
`},"./src/next-devtools/dev-overlay/container/runtime-error/error-aggregate-errors.tsx"(e,t,r){"use strict";r.d(t,{R:()=>p,t:()=>u});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js"),i=r("./src/next-devtools/dev-overlay/components/code-frame/code-frame.tsx"),s=r("./src/next-devtools/dev-overlay/components/errors/error-overlay-call-stack/error-overlay-call-stack.tsx"),l=r("./src/next-devtools/dev-overlay/container/runtime-error/error-cause.tsx"),c=r("./src/next-devtools/dev-overlay/components/hot-linked-text/index.tsx");function u(e){let t,r,a=(0,o.c)(8),{errors:i,dialogResizerRef:s}=e;if(a[0]!==s||a[1]!==i){let e;a[3]!==s||a[4]!==i.length?(e=(e,t)=>(0,n.jsx)(d,{entry:e,index:t,total:i.length,dialogResizerRef:s},t),a[3]=s,a[4]=i.length,a[5]=e):e=a[5],t=i.map(e),a[0]=s,a[1]=i,a[2]=t}else t=a[2];return a[6]!==t?(r=(0,n.jsx)(n.Fragment,{children:t}),a[6]=t,a[7]=r):r=a[7],r}function d(e){let t,r,d,p,h,m,g,v,x,y=(0,o.c)(28),{entry:b,index:w,total:_,dialogResizerRef:k}=e;y[0]!==b?(t=b.frames(),y[0]=b,y[1]=t):t=y[1];let j=a.use(t);y[2]!==b.error.message?(r=b.error.message.trim(),y[2]=b.error.message,y[3]=r):r=y[3];let S=r,C=j.findIndex(f),E=j[C]??null,T=w+1,N=b.error.name||"Error";return y[4]!==T||y[5]!==N||y[6]!==_?(d=(0,n.jsx)("div",{className:"error-aggregate-error-header",children:(0,n.jsxs)("span",{className:"error-aggregate-error-label",children:[T," of ",_,": ",N]})}),y[4]=T,y[5]=N,y[6]=_,y[7]=d):d=y[7],y[8]!==S?(p=S?(0,n.jsx)("p",{className:"error-aggregate-error-message",children:(0,n.jsx)(c.E,{text:S})}):null,y[8]=S,y[9]=p):p=y[9],y[10]!==E?(h=E&&(0,n.jsx)(i.Z,{stackFrame:E.originalStackFrame,codeFrame:E.originalCodeFrame}),y[10]=E,y[11]=h):h=y[11],y[12]!==k||y[13]!==j?(m=j.length>0&&(0,n.jsx)(s.d,{dialogResizerRef:k,frames:j}),y[12]=k,y[13]=j,y[14]=m):m=y[14],y[15]!==k||y[16]!==b.cause?(g=b.cause&&(0,n.jsx)(l.C,{cause:b.cause,dialogResizerRef:k}),y[15]=k,y[16]=b.cause,y[17]=g):g=y[17],y[18]!==k||y[19]!==b?(v="aggregateErrors"in b&&null!==b.aggregateErrors&&(0,n.jsx)(u,{errors:b.aggregateErrors,dialogResizerRef:k}),y[18]=k,y[19]=b,y[20]=v):v=y[20],y[21]!==v||y[22]!==d||y[23]!==p||y[24]!==h||y[25]!==m||y[26]!==g?(x=(0,n.jsxs)("div",{"data-nextjs-error-aggregate-error":!0,children:[d,p,h,m,g,v]}),y[21]=v,y[22]=d,y[23]=p,y[24]=h,y[25]=m,y[26]=g,y[27]=x):x=y[27],x}function f(e){return!e.ignored&&!!e.originalCodeFrame&&!!e.originalStackFrame}let p=`
  [data-nextjs-error-aggregate-error] {
    border-top: 1px solid var(--color-gray-400);
    margin-top: 16px;
    padding-top: 16px;
  }

  .error-aggregate-error-header {
    display: flex;
    align-items: center;
    margin-bottom: 8px;
  }

  .error-aggregate-error-label {
    padding: 2px 6px;
    margin: 0;
    border-radius: var(--rounded-md-2);
    background: var(--color-red-100);
    font-weight: 600;
    font-size: var(--size-12);
    color: var(--color-red-900);
    font-family: var(--font-stack-monospace);
    line-height: var(--size-20);
  }

  .error-aggregate-error-message {
    margin: 0;
    margin-left: 4px;
    color: var(--color-red-900);
    font-weight: 500;
    font-size: var(--size-16);
    letter-spacing: -0.32px;
    line-height: var(--size-24);
    overflow-wrap: break-word;
    white-space: pre-wrap;
  }
`},"./src/next-devtools/dev-overlay/container/runtime-error/error-cause.tsx"(e,t,r){"use strict";r.d(t,{C:()=>u,R:()=>f});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./dist/compiled/react/index.js"),i=r("./src/next-devtools/dev-overlay/components/code-frame/code-frame.tsx"),s=r("./src/next-devtools/dev-overlay/components/errors/error-overlay-call-stack/error-overlay-call-stack.tsx"),l=r("./src/next-devtools/dev-overlay/container/runtime-error/error-aggregate-errors.tsx"),c=r("./src/next-devtools/dev-overlay/components/hot-linked-text/index.tsx");function u(e){let t,r,f,p,h,m,g,v,x,y=(0,o.c)(26),{cause:b,dialogResizerRef:w}=e;y[0]!==b?(t=b.frames(),y[0]=b,y[1]=t):t=y[1];let _=a.use(t);y[2]!==b.error.message?(r=b.error.message.trim(),y[2]=b.error.message,y[3]=r):r=y[3];let k=r,j=_.findIndex(d),S=_[j]??null,C=b.error.name||"Error";return y[4]!==C?(f=(0,n.jsx)("div",{className:"error-cause-header",children:(0,n.jsxs)("span",{className:"error-cause-label",children:["Caused by: ",C]})}),y[4]=C,y[5]=f):f=y[5],y[6]!==k?(p=k?(0,n.jsx)("p",{className:"error-cause-message",children:(0,n.jsx)(c.E,{text:k})}):null,y[6]=k,y[7]=p):p=y[7],y[8]!==S?(h=S&&(0,n.jsx)(i.Z,{stackFrame:S.originalStackFrame,codeFrame:S.originalCodeFrame}),y[8]=S,y[9]=h):h=y[9],y[10]!==w||y[11]!==_?(m=_.length>0&&(0,n.jsx)(s.d,{dialogResizerRef:w,frames:_}),y[10]=w,y[11]=_,y[12]=m):m=y[12],y[13]!==b.cause||y[14]!==w?(g=b.cause&&(0,n.jsx)(u,{cause:b.cause,dialogResizerRef:w}),y[13]=b.cause,y[14]=w,y[15]=g):g=y[15],y[16]!==b||y[17]!==w?(v="aggregateErrors"in b&&null!==b.aggregateErrors&&(0,n.jsx)(l.t,{errors:b.aggregateErrors,dialogResizerRef:w}),y[16]=b,y[17]=w,y[18]=v):v=y[18],y[19]!==f||y[20]!==p||y[21]!==h||y[22]!==m||y[23]!==g||y[24]!==v?(x=(0,n.jsxs)("div",{"data-nextjs-error-cause":!0,children:[f,p,h,m,g,v]}),y[19]=f,y[20]=p,y[21]=h,y[22]=m,y[23]=g,y[24]=v,y[25]=x):x=y[25],x}function d(e){return!e.ignored&&!!e.originalCodeFrame&&!!e.originalStackFrame}let f=`
  [data-nextjs-error-cause] {
    border-top: 1px solid var(--color-gray-400);
    margin-top: 16px;
    padding-top: 16px;
  }

  .error-cause-header {
    display: flex;
    align-items: center;
    margin-bottom: 8px;
  }

  .error-cause-label {
    padding: 2px 6px;
    margin: 0;
    border-radius: var(--rounded-md-2);
    background: var(--color-red-100);
    font-weight: 600;
    font-size: var(--size-12);
    color: var(--color-red-900);
    font-family: var(--font-stack-monospace);
    line-height: var(--size-20);
  }

  .error-cause-message {
    margin: 0 0 16px 4px;
    color: var(--color-red-900);
    font-weight: 500;
    font-size: var(--size-16);
    letter-spacing: -0.32px;
    line-height: var(--size-24);
    overflow-wrap: break-word;
    white-space: pre-wrap;
  }
`},"./src/next-devtools/dev-overlay/container/runtime-error/index.tsx"(e,t,r){"use strict";r.d(t,{R:()=>p,b:()=>d});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js"),a=r("./src/next-devtools/dev-overlay/components/code-frame/code-frame.tsx"),i=r("./src/next-devtools/dev-overlay/components/errors/error-overlay-call-stack/error-overlay-call-stack.tsx"),s=r("./src/next-devtools/dev-overlay/container/runtime-error/component-stack-pseudo-html.tsx"),l=r("./src/next-devtools/dev-overlay/container/runtime-error/error-cause.tsx"),c=r("./src/next-devtools/dev-overlay/container/runtime-error/error-aggregate-errors.tsx"),u=r("./src/next-devtools/dev-overlay/utils/get-error-by-type.ts");function d(e){let t,r,s,d,p,h=(0,o.c)(16),{error:m,dialogResizerRef:g}=e,v=(0,u.s)(m),x=v.findIndex(f),y=v[x]??null;return h[0]!==y?(t=y&&(0,n.jsx)(a.Z,{stackFrame:y.originalStackFrame,codeFrame:y.originalCodeFrame}),h[0]=y,h[1]=t):t=h[1],h[2]!==g||h[3]!==v?(r=v.length>0&&(0,n.jsx)(i.d,{dialogResizerRef:g,frames:v}),h[2]=g,h[3]=v,h[4]=r):r=h[4],h[5]!==g||h[6]!==m.cause?(s=m.cause&&(0,n.jsx)(l.C,{cause:m.cause,dialogResizerRef:g}),h[5]=g,h[6]=m.cause,h[7]=s):s=h[7],h[8]!==g||h[9]!==m?(d="aggregateErrors"in m&&null!==m.aggregateErrors&&(0,n.jsx)(c.t,{errors:m.aggregateErrors,dialogResizerRef:g}),h[8]=g,h[9]=m,h[10]=d):d=h[10],h[11]!==t||h[12]!==r||h[13]!==s||h[14]!==d?(p=(0,n.jsxs)(n.Fragment,{children:[t,r,s,d]}),h[11]=t,h[12]=r,h[13]=s,h[14]=d,h[15]=p):p=h[15],p}function f(e){return!e.ignored&&!!e.originalCodeFrame&&!!e.originalStackFrame}let p=`
  ${s.c}
  ${l.R}
  ${c.R}
`},"./src/next-devtools/dev-overlay/icons/copy-prompt.tsx"(e,t,r){"use strict";r.d(t,{n:()=>a});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js");function a(e){let t,r,a=(0,o.c)(3);return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsx)("path",{fill:"currentColor",d:"M6.75 14C7.16421 14 7.5 14.3358 7.5 14.75C7.5 15.1642 7.16421 15.5 6.75 15.5C6.33579 15.5 6 15.1642 6 14.75C6 14.3358 6.33579 14 6.75 14ZM10.5 14C10.9142 14 11.25 14.3358 11.25 14.75C11.25 15.1642 10.9142 15.5 10.5 15.5C10.0858 15.5 9.75 15.1642 9.75 14.75C9.75 14.3358 10.0858 14 10.5 14ZM14.25 14C14.6642 14 15 14.3358 15 14.75C15 15.1642 14.6642 15.5 14.25 15.5C13.8358 15.5 13.5 15.1642 13.5 14.75C13.5 14.3358 13.8358 14 14.25 14ZM6.75 10.75C7.16421 10.75 7.5 11.0858 7.5 11.5C7.49987 11.9141 7.16413 12.25 6.75 12.25C6.33587 12.25 6.00013 11.9141 6 11.5C6 11.0858 6.33579 10.75 6.75 10.75ZM14.25 10.75C14.6642 10.75 15 11.0858 15 11.5C14.9999 11.9141 14.6641 12.25 14.25 12.25C13.8359 12.25 13.5001 11.9141 13.5 11.5C13.5 11.0858 13.8358 10.75 14.25 10.75ZM8.25 0.5C9.2165 0.5 10 1.2835 10 2.25V3H8.5V2.25C8.5 2.11193 8.38807 2 8.25 2H2.75C2.61193 2 2.5 2.11193 2.5 2.25V9.75C2.5 9.88807 2.61193 10 2.75 10H4.5V11.5H2.75C1.7835 11.5 1 10.7165 1 9.75V2.25C1 1.2835 1.7835 0.5 2.75 0.5H8.25ZM6.75 7.75C7.16413 7.75 7.49987 8.0859 7.5 8.5C7.5 8.91421 7.16421 9.25 6.75 9.25C6.33579 9.25 6 8.91421 6 8.5C6.00013 8.0859 6.33587 7.75 6.75 7.75ZM14.25 7.75C14.6641 7.75 14.9999 8.0859 15 8.5C15 8.91421 14.6642 9.25 14.25 9.25C13.8358 9.25 13.5 8.91421 13.5 8.5C13.5001 8.0859 13.8359 7.75 14.25 7.75ZM6.75 4.5C7.16421 4.5 7.5 4.83579 7.5 5.25C7.5 5.66421 7.16421 6 6.75 6C6.33579 6 6 5.66421 6 5.25C6 4.83579 6.33579 4.5 6.75 4.5ZM10.5 4.5C10.9142 4.5 11.25 4.83579 11.25 5.25C11.25 5.66421 10.9142 6 10.5 6C10.0858 6 9.75 5.66421 9.75 5.25C9.75 4.83579 10.0858 4.5 10.5 4.5ZM14.25 4.5C14.6642 4.5 15 4.83579 15 5.25C15 5.66421 14.6642 6 14.25 6C13.8358 6 13.5 5.66421 13.5 5.25C13.5 4.83579 13.8358 4.5 14.25 4.5Z"}),a[0]=t):t=a[0],a[1]!==e?(r=(0,n.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",...e,children:t}),a[1]=e,a[2]=r):r=a[2],r}},"./src/next-devtools/dev-overlay/icons/external.tsx"(e,t,r){"use strict";r.d(t,{N:()=>i,X:()=>a});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js");function a(e){let t,r,a=(0,o.c)(3);return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",fill:"currentColor",d:"M11.5 9.75V11.25C11.5 11.3881 11.3881 11.5 11.25 11.5H4.75C4.61193 11.5 4.5 11.3881 4.5 11.25L4.5 4.75C4.5 4.61193 4.61193 4.5 4.75 4.5H6.25H7V3H6.25H4.75C3.7835 3 3 3.7835 3 4.75V11.25C3 12.2165 3.7835 13 4.75 13H11.25C12.2165 13 13 12.2165 13 11.25V9.75V9H11.5V9.75ZM8.5 3H9.25H12.2495C12.6637 3 12.9995 3.33579 12.9995 3.75V6.75V7.5H11.4995V6.75V5.56066L8.53033 8.52978L8 9.06011L6.93934 7.99945L7.46967 7.46912L10.4388 4.5H9.25H8.5V3Z"}),a[0]=t):t=a[0],a[1]!==e?(r=(0,n.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",...e,children:t}),a[1]=e,a[2]=r):r=a[2],r}function i(e){let t,r,a=(0,o.c)(3);return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsx)("path",{d:"M8.13748 3C8.69243 3.00017 9.20256 3.30665 9.46267 3.79688L13.5642 11.5312C13.9172 12.1971 13.434 12.9997 12.6804 13H3.32595C2.57197 13 2.08881 12.1973 2.44217 11.5312L6.54763 3.79688C6.80787 3.30678 7.31792 3.00005 7.87283 3H8.13748ZM4.15701 11.5H11.8494L8.13748 4.5H7.87283L4.15701 11.5ZM8.00857 9.55176C8.38926 9.55189 8.69788 9.86053 8.69802 10.2412C8.69802 10.622 8.38935 10.9305 8.00857 10.9307C7.62768 10.9307 7.31912 10.6221 7.31912 10.2412C7.31926 9.86045 7.62777 9.55176 8.00857 9.55176ZM8.75467 9H7.25467V6.25H8.75467V9Z",fill:"currentColor"}),a[0]=t):t=a[0],a[1]!==e?(r=(0,n.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",...e,children:t}),a[1]=e,a[2]=r):r=a[2],r}},"./src/next-devtools/dev-overlay/icons/file.tsx"(e,t,r){"use strict";r.d(t,{o:()=>a});var n=r("./dist/compiled/react/jsx-runtime.js"),o=r("./dist/compiled/react/compiler-runtime.js");function a(e){let t=(0,o.c)(6),{lang:r}=e;if(!r){let e;return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)(c,{}),t[0]=e):e=t[0],e}switch(r.toLowerCase()){case"jsx":case"tsx":{let e;return t[1]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)(u,{}),t[1]=e):e=t[1],e}case"ts":case"typescript":{let e;return t[2]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)(l,{}),t[2]=e):e=t[2],e}case"javascript":case"js":case"mjs":{let e;return t[3]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)(s,{}),t[3]=e):e=t[3],e}case"json":{let e;return t[4]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)(i,{}),t[4]=e):e=t[4],e}default:{let e;return t[5]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)(c,{}),t[5]=e):e=t[5],e}}}function i(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{clipRule:"evenodd",fillRule:"evenodd",height:"16",viewBox:"0 0 1321.45 1333.33",width:"16",children:(0,n.jsx)("path",{d:"M221.37 618.44h757.94V405.15H755.14c-23.5 0-56.32-12.74-71.82-28.24-15.5-15.5-25-43.47-25-66.97V82.89H88.39c-1.99 0-3.49 1-4.49 2-1.5 1-2 2.5-2 4.5v1155.04c0 1.5 1 3.5 2 4.5 1 1.49 3 1.99 4.49 1.99H972.8c2 0 1.89-.99 2.89-1.99 1.5-1 3.61-3 3.61-4.5v-121.09H221.36c-44.96 0-82-36.9-82-81.99V700.44c0-45.1 36.9-82 82-82zm126.51 117.47h75.24v146.61c0 30.79-2.44 54.23-7.33 70.31-4.92 16.03-14.8 29.67-29.65 40.85-14.86 11.12-33.91 16.72-57.05 16.72-24.53 0-43.51-3.71-56.94-11.06-13.5-7.36-23.89-18.1-31.23-32.3-7.35-14.14-11.69-31.67-12.99-52.53l71.5-10.81c.11 11.81 1.07 20.61 2.81 26.33 1.76 5.78 4.75 10.37 9 13.95 2.87 2.33 6.94 3.46 12.25 3.46 8.4 0 14.58-3.46 18.53-10.37 3.9-6.92 5.87-18.6 5.87-35V735.92zm112.77 180.67l71.17-4.97c1.54 12.81 4.69 22.62 9.44 29.28 7.74 10.88 18.74 16.34 33.09 16.34 10.68 0 18.93-2.76 24.68-8.36 5.81-5.58 8.7-12.07 8.7-19.41 0-6.97-2.71-13.26-8.2-18.79-5.47-5.53-18.23-10.68-38.28-15.65-32.89-8.17-56.27-19.1-70.26-32.74-14.12-13.57-21.18-30.92-21.18-52.03 0-13.83 3.61-26.89 10.85-39.21 7.22-12.38 18.07-22.06 32.59-29.09 14.52-7.04 34.4-10.56 59.65-10.56 31 0 54.62 6.41 70.88 19.29 16.28 12.81 25.92 33.24 29.04 61.27l-70.5 4.65c-1.87-12.25-5.81-21.17-11.81-26.7-6.05-5.6-14.35-8.36-24.9-8.36-8.71 0-15.31 2.07-19.73 6.16-4.4 4.09-6.59 9.12-6.59 15.02 0 4.27 1.81 8.11 5.37 11.57 3.45 3.59 11.8 6.85 25.02 9.93 32.75 7.86 56.2 15.84 70.31 23.87 14.18 8.05 24.52 17.98 30.96 29.92 6.44 11.88 9.66 25.2 9.66 39.96 0 17.29-4.3 33.24-12.88 47.89-8.63 14.58-20.61 25.7-36.08 33.24-15.41 7.54-34.85 11.31-58.33 11.31-41.24 0-69.81-8.86-85.68-26.52-15.88-17.65-24.85-40.09-26.96-67.3zm248.74-45.5c0-44.05 11.02-78.36 33.09-102.87 22.09-24.57 52.82-36.82 92.24-36.82 40.38 0 71.5 12.07 93.34 36.13 21.86 24.13 32.77 57.94 32.77 101.37 0 31.54-4.75 57.36-14.3 77.54-9.54 20.18-23.37 35.89-41.4 47.13-18.07 11.24-40.55 16.84-67.48 16.84-27.33 0-49.99-4.83-67.94-14.52-17.92-9.74-32.49-25.07-43.62-46.06-11.13-20.92-16.72-47.19-16.72-78.74zm74.89.19c0 27.21 4.57 46.81 13.68 58.68 9.13 11.88 21.57 17.85 37.26 17.85 16.1 0 28.65-5.84 37.45-17.47 8.87-11.68 13.28-32.54 13.28-62.77 0-25.39-4.63-43.92-13.84-55.61-9.26-11.76-21.75-17.6-37.56-17.6-15.13 0-27.34 5.97-36.49 17.85-9.21 11.88-13.78 31.61-13.78 59.07zm209.08-135.36h69.99l90.98 149.05V735.91h70.83v269.96h-70.83l-90.48-148.24v148.24h-70.49V735.91zm67.71-117.47h178.37c45.1 0 82 37.04 82 82v340.91c0 44.96-37.03 81.99-82 81.99h-178.37v147c0 17.5-6.99 32.99-18.5 44.5-11.5 11.49-27 18.5-44.5 18.5H62.97c-17.5 0-32.99-7-44.5-18.5-11.49-11.5-18.5-27-18.5-44.5V63.49c0-17.5 7-33 18.5-44.5S45.97.49 62.97.49H700.1c1.5-.5 3-.5 4.5-.5 7 0 14 3 19 7.49h1c1 .5 1.5 1 2.5 2l325.46 329.47c5.5 5.5 9.5 13 9.5 21.5 0 2.5-.5 4.5-1 7v250.98zM732.61 303.47V96.99l232.48 235.47H761.6c-7.99 0-14.99-3.5-20.5-8.49-4.99-5-8.49-12.5-8.49-20.5z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function s(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{height:"16",viewBox:"0 0 50 50",width:"16",xmlns:"http://www.w3.org/2000/svg",children:(0,n.jsx)("path",{d:"M 43.335938 4 L 6.667969 4 C 5.195313 4 4 5.195313 4 6.667969 L 4 43.332031 C 4 44.804688 5.195313 46 6.667969 46 L 43.332031 46 C 44.804688 46 46 44.804688 46 43.335938 L 46 6.667969 C 46 5.195313 44.804688 4 43.335938 4 Z M 27 36.183594 C 27 40.179688 24.65625 42 21.234375 42 C 18.140625 42 15.910156 39.925781 15 38 L 18.144531 36.097656 C 18.75 37.171875 19.671875 38 21 38 C 22.269531 38 23 37.503906 23 35.574219 L 23 23 L 27 23 Z M 35.675781 42 C 32.132813 42 30.121094 40.214844 29 38 L 32 36 C 32.816406 37.335938 33.707031 38.613281 35.589844 38.613281 C 37.171875 38.613281 38 37.824219 38 36.730469 C 38 35.425781 37.140625 34.960938 35.402344 34.199219 L 34.449219 33.789063 C 31.695313 32.617188 29.863281 31.148438 29.863281 28.039063 C 29.863281 25.179688 32.046875 23 35.453125 23 C 37.878906 23 39.621094 23.84375 40.878906 26.054688 L 37.910156 27.964844 C 37.253906 26.789063 36.550781 26.328125 35.453125 26.328125 C 34.335938 26.328125 33.628906 27.039063 33.628906 27.964844 C 33.628906 29.109375 34.335938 29.570313 35.972656 30.28125 L 36.925781 30.691406 C 40.171875 32.078125 42 33.496094 42 36.683594 C 42 40.117188 39.300781 42 35.675781 42 Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function l(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsxs)("svg",{fill:"none",height:"14",viewBox:"0 0 512 512",width:"14",xmlns:"http://www.w3.org/2000/svg",children:[(0,n.jsx)("rect",{fill:"currentColor",height:"512",rx:"50",width:"512"}),(0,n.jsx)("rect",{fill:"currentColor",height:"512",rx:"50",width:"512"}),(0,n.jsx)("path",{clipRule:"evenodd",d:"m316.939 407.424v50.061c8.138 4.172 17.763 7.3 28.875 9.386s22.823 3.129 35.135 3.129c11.999 0 23.397-1.147 34.196-3.442 10.799-2.294 20.268-6.075 28.406-11.342 8.138-5.266 14.581-12.15 19.328-20.65s7.121-19.007 7.121-31.522c0-9.074-1.356-17.026-4.069-23.857s-6.625-12.906-11.738-18.225c-5.112-5.319-11.242-10.091-18.389-14.315s-15.207-8.213-24.18-11.967c-6.573-2.712-12.468-5.345-17.685-7.9-5.217-2.556-9.651-5.163-13.303-7.822-3.652-2.66-6.469-5.476-8.451-8.448-1.982-2.973-2.974-6.336-2.974-10.091 0-3.441.887-6.544 2.661-9.308s4.278-5.136 7.512-7.118c3.235-1.981 7.199-3.52 11.894-4.615 4.696-1.095 9.912-1.642 15.651-1.642 4.173 0 8.581.313 13.224.938 4.643.626 9.312 1.591 14.008 2.894 4.695 1.304 9.259 2.947 13.694 4.928 4.434 1.982 8.529 4.276 12.285 6.884v-46.776c-7.616-2.92-15.937-5.084-24.962-6.492s-19.381-2.112-31.066-2.112c-11.895 0-23.163 1.278-33.805 3.833s-20.006 6.544-28.093 11.967c-8.086 5.424-14.476 12.333-19.171 20.729-4.695 8.395-7.043 18.433-7.043 30.114 0 14.914 4.304 27.638 12.912 38.172 8.607 10.533 21.675 19.45 39.204 26.751 6.886 2.816 13.303 5.579 19.25 8.291s11.086 5.528 15.415 8.448c4.33 2.92 7.747 6.101 10.252 9.543 2.504 3.441 3.756 7.352 3.756 11.733 0 3.233-.783 6.231-2.348 8.995s-3.939 5.162-7.121 7.196-7.147 3.624-11.894 4.771c-4.748 1.148-10.303 1.721-16.668 1.721-10.851 0-21.597-1.903-32.24-5.71-10.642-3.806-20.502-9.516-29.579-17.13zm-84.159-123.342h64.22v-41.082h-179v41.082h63.906v182.918h50.874z",fill:"var(--color-background-100)",fillRule:"evenodd"})]}),t[0]=e):e=t[0],e}function c(){let e,t=(0,o.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("svg",{width:"16",height:"17",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,n.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M14.5 7v7a2.5 2.5 0 0 1-2.5 2.5H4A2.5 2.5 0 0 1 1.5 14V.5h7.586a1 1 0 0 1 .707.293l4.414 4.414a1 1 0 0 1 .293.707V7zM13 7v7a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2h5v5h5zM9.5 2.621V5.5h2.879L9.5 2.621z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function u(){let e,t,r=(0,o.c)(2);return r[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,n.jsx)("g",{clipPath:"url(#file_react_clip0_872_3183)",children:(0,n.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M4.5 1.93782C4.70129 1.82161 4.99472 1.7858 5.41315 1.91053C5.83298 2.03567 6.33139 2.31073 6.87627 2.73948C7.01136 2.84578 7.14803 2.96052 7.28573 3.08331C6.86217 3.53446 6.44239 4.04358 6.03752 4.60092C5.35243 4.67288 4.70164 4.78186 4.09916 4.92309C4.06167 4.74244 4.03064 4.56671 4.00612 4.39656C3.90725 3.71031 3.91825 3.14114 4.01979 2.71499C4.12099 2.29025 4.29871 2.05404 4.5 1.93782ZM7.49466 1.95361C7.66225 2.08548 7.83092 2.22804 7.99999 2.38067C8.16906 2.22804 8.33773 2.08548 8.50532 1.95361C9.10921 1.47842 9.71982 1.12549 10.3012 0.952202C10.8839 0.778496 11.4838 0.7738 12 1.0718C12.5161 1.3698 12.812 1.89169 12.953 2.48322C13.0936 3.07333 13.0932 3.77858 12.9836 4.53917C12.9532 4.75024 12.9141 4.9676 12.8665 5.19034C13.0832 5.26044 13.291 5.33524 13.489 5.41444C14.2025 5.69983 14.8134 6.05217 15.2542 6.46899C15.696 6.8868 16 7.404 16 8C16 8.596 15.696 9.11319 15.2542 9.53101C14.8134 9.94783 14.2025 10.3002 13.489 10.5856C13.291 10.6648 13.0832 10.7396 12.8665 10.8097C12.9141 11.0324 12.9532 11.2498 12.9837 11.4608C13.0932 12.2214 13.0936 12.9267 12.953 13.5168C12.812 14.1083 12.5161 14.6302 12 14.9282C11.4839 15.2262 10.8839 15.2215 10.3012 15.0478C9.71984 14.8745 9.10923 14.5216 8.50534 14.0464C8.33775 13.9145 8.16906 13.7719 7.99999 13.6193C7.83091 13.7719 7.66223 13.9145 7.49464 14.0464C6.89075 14.5216 6.28014 14.8745 5.69879 15.0478C5.11605 15.2215 4.51613 15.2262 3.99998 14.9282C3.48383 14.6302 3.18794 14.1083 3.047 13.5168C2.9064 12.9267 2.90674 12.2214 3.01632 11.4608C3.04673 11.2498 3.08586 11.0324 3.13351 10.8097C2.91679 10.7395 2.709 10.6648 2.511 10.5856C1.79752 10.3002 1.18658 9.94783 0.745833 9.53101C0.304028 9.11319 0 8.596 0 8C0 7.404 0.304028 6.8868 0.745833 6.46899C1.18658 6.05217 1.79752 5.69983 2.511 5.41444C2.709 5.33524 2.9168 5.26044 3.13352 5.19034C3.08587 4.9676 3.04675 4.75024 3.01634 4.53917C2.90676 3.77858 2.90642 3.07332 3.04702 2.48321C3.18796 1.89169 3.48385 1.3698 4 1.0718C4.51615 0.773798 5.11607 0.778495 5.69881 0.952201C6.28016 1.12549 6.89077 1.47841 7.49466 1.95361ZM7.36747 4.51025C7.57735 4.25194 7.78881 4.00927 7.99999 3.78356C8.21117 4.00927 8.42263 4.25194 8.63251 4.51025C8.42369 4.50346 8.21274 4.5 8 4.5C7.78725 4.5 7.5763 4.50345 7.36747 4.51025ZM8.71425 3.08331C9.13781 3.53447 9.55759 4.04358 9.96246 4.60092C10.6475 4.67288 11.2983 4.78186 11.9008 4.92309C11.9383 4.74244 11.9693 4.56671 11.9939 4.39657C12.0927 3.71031 12.0817 3.14114 11.9802 2.71499C11.879 2.29025 11.7013 2.05404 11.5 1.93782C11.2987 1.82161 11.0053 1.7858 10.5868 1.91053C10.167 2.03568 9.66859 2.31073 9.12371 2.73948C8.98862 2.84578 8.85196 2.96052 8.71425 3.08331ZM8 5.5C8.48433 5.5 8.95638 5.51885 9.41188 5.55456C9.67056 5.93118 9.9229 6.33056 10.1651 6.75C10.4072 7.16944 10.6269 7.58766 10.8237 7.99998C10.6269 8.41232 10.4072 8.83055 10.165 9.25C9.92288 9.66944 9.67053 10.0688 9.41185 10.4454C8.95636 10.4812 8.48432 10.5 8 10.5C7.51567 10.5 7.04363 10.4812 6.58813 10.4454C6.32945 10.0688 6.0771 9.66944 5.83494 9.25C5.59277 8.83055 5.37306 8.41232 5.17624 7.99998C5.37306 7.58765 5.59275 7.16944 5.83492 6.75C6.07708 6.33056 6.32942 5.93118 6.5881 5.55456C7.04361 5.51884 7.51566 5.5 8 5.5ZM11.0311 6.25C11.1375 6.43423 11.2399 6.61864 11.3385 6.80287C11.4572 6.49197 11.5616 6.18752 11.6515 5.89178C11.3505 5.82175 11.0346 5.75996 10.706 5.70736C10.8163 5.8848 10.9247 6.06576 11.0311 6.25ZM11.0311 9.75C11.1374 9.56576 11.2399 9.38133 11.3385 9.19709C11.4572 9.50801 11.5617 9.81246 11.6515 10.1082C11.3505 10.1782 11.0346 10.24 10.7059 10.2926C10.8162 10.1152 10.9247 9.93424 11.0311 9.75ZM11.9249 7.99998C12.2051 8.62927 12.4362 9.24738 12.6151 9.83977C12.7903 9.78191 12.958 9.72092 13.1176 9.65708C13.7614 9.39958 14.2488 9.10547 14.5671 8.80446C14.8843 8.50445 15 8.23243 15 8C15 7.76757 14.8843 7.49555 14.5671 7.19554C14.2488 6.89453 13.7614 6.60042 13.1176 6.34292C12.958 6.27907 12.7903 6.21808 12.6151 6.16022C12.4362 6.7526 12.2051 7.37069 11.9249 7.99998ZM9.96244 11.3991C10.6475 11.3271 11.2983 11.2181 11.9008 11.0769C11.9383 11.2576 11.9694 11.4333 11.9939 11.6034C12.0928 12.2897 12.0817 12.8589 11.9802 13.285C11.879 13.7098 11.7013 13.946 11.5 14.0622C11.2987 14.1784 11.0053 14.2142 10.5868 14.0895C10.167 13.9643 9.66861 13.6893 9.12373 13.2605C8.98863 13.1542 8.85196 13.0395 8.71424 12.9167C9.1378 12.4655 9.55758 11.9564 9.96244 11.3991ZM8.63249 11.4898C8.42262 11.7481 8.21116 11.9907 7.99999 12.2164C7.78881 11.9907 7.57737 11.7481 7.36749 11.4897C7.57631 11.4965 7.78726 11.5 8 11.5C8.21273 11.5 8.42367 11.4965 8.63249 11.4898ZM4.96891 9.75C5.07528 9.93424 5.18375 10.1152 5.29404 10.2926C4.9654 10.24 4.64951 10.1782 4.34844 10.1082C4.43833 9.81246 4.54276 9.508 4.66152 9.19708C4.76005 9.38133 4.86254 9.56575 4.96891 9.75ZM6.03754 11.3991C5.35244 11.3271 4.70163 11.2181 4.09914 11.0769C4.06165 11.2576 4.03062 11.4333 4.0061 11.6034C3.90723 12.2897 3.91823 12.8589 4.01977 13.285C4.12097 13.7098 4.29869 13.946 4.49998 14.0622C4.70127 14.1784 4.9947 14.2142 5.41313 14.0895C5.83296 13.9643 6.33137 13.6893 6.87625 13.2605C7.01135 13.1542 7.14802 13.0395 7.28573 12.9167C6.86217 12.4655 6.4424 11.9564 6.03754 11.3991ZM4.07507 7.99998C3.79484 8.62927 3.56381 9.24737 3.38489 9.83977C3.20969 9.78191 3.042 9.72092 2.88239 9.65708C2.23864 9.39958 1.75123 9.10547 1.43294 8.80446C1.11571 8.50445 1 8.23243 1 8C1 7.76757 1.11571 7.49555 1.43294 7.19554C1.75123 6.89453 2.23864 6.60042 2.88239 6.34292C3.042 6.27907 3.2097 6.21808 3.3849 6.16022C3.56383 6.75261 3.79484 7.37069 4.07507 7.99998ZM4.66152 6.80287C4.54277 6.49197 4.43835 6.18752 4.34846 5.89178C4.64952 5.82175 4.96539 5.75996 5.29402 5.70736C5.18373 5.8848 5.07526 6.06576 4.96889 6.25C4.86253 6.43423 4.76005 6.61864 4.66152 6.80287ZM9.25 8C9.25 8.69036 8.69036 9.25 8 9.25C7.30964 9.25 6.75 8.69036 6.75 8C6.75 7.30965 7.30964 6.75 8 6.75C8.69036 6.75 9.25 7.30965 9.25 8Z",fill:"currentColor"})}),r[0]=e):e=r[0],r[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,n.jsxs)("svg",{height:"16",strokeLinejoin:"round",viewBox:"0 0 16 16",width:"16",children:[e,(0,n.jsx)("defs",{children:(0,n.jsx)("clipPath",{id:"file_react_clip0_872_3183",children:(0,n.jsx)("rect",{width:"16",height:"16",fill:"white"})})})]}),r[1]=t):t=r[1],t}},"./src/next-devtools/dev-overlay/segment-explorer-trie.ts"(e,t,r){"use strict";r.d(t,{JW:()=>c,YY:()=>u,j1:()=>f,kN:()=>d});var n=r("./dist/compiled/react/index.js");let o=new Set,{subscribe:a,getSnapshot:i,getServerSnapshot:s}={subscribe:e=>(o.add(e),()=>o.delete(e)),getSnapshot:()=>l.getRoot(),getServerSnapshot:()=>l.getRoot()},l=function({getCharacters:e=e=>[e],compare:t=(e,t)=>e===t}){let r={value:void 0,children:Object.create(null)};function n(){for(let e of o)e()}function a(e){return Object.assign(Object.create(null),e)}function i(e){let t={value:r.value,children:a(r.children)},n=[t],o=t;for(let t of e){let e=o.children[t],r={value:e?.value,children:e?a(e.children):Object.create(null)};o.children[t]=r,o=r,n.push(r)}return n}return{insert:function(t){let o=i(e(t));o[o.length-1].value=t,r=o[0],n()},remove:function(o){let a=e(o),s=r;for(let e of a){let t=s.children[e];if(!t)return;s=t}if(!t(s.value,o))return;let l=i(a);l[l.length-1].value=void 0;for(let e=a.length-1;e>=0;e--){let t=l[e],r=a[e],n=t.children[r];void 0===n.value&&0===Object.keys(n.children).length&&delete t.children[r]}r=l[0],n()},getRoot:function(){return r}}}({compare:(e,t)=>!!e&&!!t&&e.pagePath===t.pagePath&&e.type===t.type&&e.boundaryType===t.boundaryType,getCharacters:e=>e.pagePath.split("/")}),c=l.insert,u=l.remove,d=l.getRoot;function f(){return(0,n.useSyncExternalStore)(a,i,s)}},"./src/next-devtools/dev-overlay/shared.ts"(e,t,r){"use strict";r.d(t,{Ou:()=>K,dP:()=>D,BI:()=>X,ei:()=>b,Bz:()=>T,JS:()=>k,Z7:()=>_,Vv:()=>V,W7:()=>A,$P:()=>Z,z9:()=>G,TA:()=>Q,Wq:()=>w,z8:()=>S,u6:()=>B,sG:()=>O,TJ:()=>q,ef:()=>Y,Lf:()=>y,kO:()=>P,s2:()=>z,xo:()=>W,VA:()=>I,rS:()=>M,iL:()=>E,Rm:()=>C,Kr:()=>ei,jQ:()=>j,xZ:()=>U,cV:()=>N,Zl:()=>$,Gu:()=>F,AE:()=>L,P6:()=>J,Ok:()=>H,Wv:()=>R});var n=r("./dist/compiled/react/compiler-runtime.js"),o=r("./dist/compiled/react/index.js"),a=r("./src/server/lib/parse-stack.ts");let i=Symbol.for("next.console.error.digest");var s=r("./src/shared/lib/request-insights.ts"),l=r("./src/next-devtools/dev-overlay/components/instant-navs/instant-nav-cookie.ts"),c=r("./src/next-devtools/dev-overlay/container/errors.tsx");let u=["(..)(..)","(.)","(..)","(...)"],d=/\/[^/]*\[[^/]+\][^/]*(?=\/|$)/,f=/\/\[[^/]+\](?=\/|$)/,p={shared:"shared",reactServerComponents:"rsc",serverSideRendering:"ssr",actionBrowser:"action-browser",apiNode:"api-node",apiEdge:"api-edge",middleware:"middleware",instrument:"instrument",edgeAsset:"edge-asset",appPagesBrowser:"app-pages-browser",pagesDirBrowser:"pages-dir-browser",pagesDirEdge:"pages-dir-edge",pagesDirNode:"pages-dir-node"};({...p,GROUP:{builtinReact:[p.reactServerComponents,p.actionBrowser],serverOnly:[p.reactServerComponents,p.actionBrowser,p.instrument,p.middleware],neutralTarget:[p.apiNode,p.apiEdge],clientOnly:[p.serverSideRendering,p.appPagesBrowser],bundled:[p.reactServerComponents,p.actionBrowser,p.serverSideRendering,p.appPagesBrowser,p.shared,p.instrument,p.middleware],appPages:[p.reactServerComponents,p.serverSideRendering,p.appPagesBrowser,p.actionBrowser]}});let h=/[|\\{}()[\]^$+*?.-]/,m=/[|\\{}()[\]^$+*?.-]/g;function g(e){return h.test(e)?e.replace(m,"\\$&"):e}let v=/^([^[]*)\[((?:\[[^\]]*\])|[^\]]+)\](.*)$/;function x(e){let t=e.startsWith("[")&&e.endsWith("]");t&&(e=e.slice(1,-1));let r=e.startsWith("...");return r&&(e=e.slice(3)),{key:e,repeat:r,optional:t}}let y={Small:16/14,Medium:1,Large:16/18},b="cache-indicator",w="static-indicator",_="build-ok",k="build-error",j="before-fast-refresh",S="fast-refresh",C="version-info",E="unhandled-error",T="unhandled-rejection",N="debug-info",I="dev-indicator",z="dev-indicator-disable",R="error-overlay-open",P="error-overlay-close",L="error-overlay-toggle",O="building-indicator-show",M="building-indicator-hide",A="rendering-indicator-show",D="rendering-indicator-hide",F="devtools-position",$="devtools-panel-position",U="devtools-scale",Z="devtools-config",q="instant-navs-toggle",B="instant-navs-reset",V="instant-errors-clear",H="request-insights-snapshot",W="request-insights-update",G="vulnerability-insight",K="__nextjs-dev-tools-panel-position",Y="__nextjs-dev-tools-panel-size",X="__nextjs-dev-tools-shared-panel-size",Q="__nextjs-dev-tools-shared-panel-location",J="segment-explorer-update-route-state",ee=/\s+(at Object\.react_stack_bottom_frame.*)|(react_stack_bottom_frame@.*)|(at react-stack-bottom-frame.*)|(react-stack-bottom-frame@.*)/;function et(e){return e?.split(ee)[0]}let er=process.env.__NEXT_DEV_INDICATOR?.toString()==="false",en=process.env.__NEXT_DEV_INDICATOR_POSITION??"bottom-left",eo=!!process.env.__NEXT_INSTANT_NAV_TOGGLE&&null!==(0,l.ON)(),ea={nextId:1,buildError:null,errors:[],notFound:!1,renderingIndicator:!1,cacheIndicator:"disabled",staticIndicator:"disabled",showIndicator:eo,disableDevIndicator:!1,buildingIndicator:!1,refreshState:{type:"idle"},versionInfo:{installed:"0.0.0",staleness:"unknown"},debugInfo:{devtoolsFrontendUrl:void 0},devToolsPosition:en,devToolsPanelPosition:{[Q]:en},devToolsPanelSize:{},scale:y.Medium,page:"",tree:null,theme:"system",hideShortcut:null,instantNavs:eo,requestInsights:[],requestInsightsConfig:{showInternal:!1,verbose:!1},hasVulnerabilityInsight:!1};function ei(e,t,r,l,p){let h,m,y,K=(0,n.c)(9),Y=void 0!==p&&p;K[0]!==Y||K[1]!==t||K[2]!==r?(h=function(e,n,o,s){let l=t(o),c=(0,a.G)((o.stack||"")+(l||"")),u={id:n,error:o,frames:c,type:Y&&void 0!==s?"runtime":r(o)?"recoverable":o&&"NEXT_CONSOLE_ERROR"===o[i]?"console":"runtime"};if(Y)return function(e,t,r){let n=e=>""+e.error==""+t.error&&(e.error.stack===t.error.stack||et(e.error.stack)===et(t.error.stack))&&r(e.error)===r(t.error),o=e.findIndex(e=>n(e)&&e.boundary?.kind===t.boundary?.kind&&e.boundary?.name===t.boundary?.name);if(-1===o&&t.isFatal&&(o=e.findIndex(e=>n(e)&&!e.isFatal&&void 0===e.boundary)),-1===o)return[...e,t];let a=e[o];return t.isFatal&&!a.isFatal?e.map((e,r)=>r===o?{...t,id:a.id}:e):e}(e,{...u,isFatal:s?.fatal??!1,boundary:s?.boundary},t);let d=e.filter(e=>""+e.error!=""+u.error||e.error.stack!==u.error.stack&&et(e.error.stack)!==et(u.error.stack)||t(e.error)!==t(u.error));return d.length===e.length?(d.push(u),d):e},K[0]=Y,K[1]=t,K[2]=r,K[3]=h):h=K[3];let X=h;if(K[4]!==X?(m=(e,t)=>{switch(t.type){case N:return{...e,debugInfo:t.debugInfo};case b:return{...e,cacheIndicator:t.cacheIndicator};case w:return{...e,staticIndicator:t.staticIndicator};case _:return{...e,buildError:null};case k:return{...e,buildError:t.message};case j:return{...e,refreshState:{type:"pending",errors:[]}};case S:return{...e,buildError:null,errors:"pending"===e.refreshState.type?e.refreshState.errors:[],refreshState:{type:"idle"}};case E:case T:switch(e.refreshState.type){case"idle":return{...e,nextId:e.nextId+1,errors:X(e.errors,e.nextId,t.reason,t.metadata)};case"pending":return{...e,nextId:e.nextId+1,refreshState:{...e.refreshState,errors:X(e.errors,e.nextId,t.reason,t.metadata)}};default:return e}case C:return{...e,versionInfo:t.versionInfo};case z:return{...e,disableDevIndicator:t.disabled};case I:return{...e,showIndicator:!0,disableDevIndicator:er||!!t.devIndicator.disabledUntil};case R:return{...e,isErrorOverlayOpen:!0};case P:return{...e,isErrorOverlayOpen:!1};case L:return{...e,isErrorOverlayOpen:!e.isErrorOverlayOpen};case O:return{...e,buildingIndicator:!0};case M:return{...e,buildingIndicator:!1};case A:return{...e,renderingIndicator:!0};case D:return{...e,renderingIndicator:!1};case F:return{...e,devToolsPosition:t.devToolsPosition};case $:return{...e,devToolsPanelPosition:{...e.devToolsPanelPosition,[t.key]:t.devToolsPanelPosition}};case U:return{...e,scale:t.scale};case J:return{...e,page:t.page,tree:t.tree};case Z:{let{theme:r,disableDevIndicator:n,devToolsPosition:o,devToolsPanelPosition:a,devToolsPanelSize:i,scale:s,hideShortcut:l,requestInsights:c}=t.devToolsConfig;return{...e,theme:r??e.theme,disableDevIndicator:n??e.disableDevIndicator,devToolsPosition:o??e.devToolsPosition,devToolsPanelPosition:a??e.devToolsPanelPosition,scale:s??e.scale,devToolsPanelSize:i??e.devToolsPanelSize,hideShortcut:void 0!==l?l:e.hideShortcut,requestInsightsConfig:c?{showInternal:c.showInternal??e.requestInsightsConfig.showInternal,verbose:c.verbose??e.requestInsightsConfig.verbose}:e.requestInsightsConfig}}case q:return{...e,instantNavs:!e.instantNavs};case B:return{...e,instantNavs:!1};case V:{let r=e.errors.filter(e=>{var r;let n=function(e){if(!e||"object"!=typeof e)return null;let t=e.message;if("string"!=typeof t||!(0,c.n3)(t))return null;let r=/^Route "([^"]+)":/.exec(t);return r?r[1]:null}(e.error);return null===n||n===(r=t.currentPath)||!!function(e,t=!0){return(void 0!==e.split("/").find(e=>u.find(t=>e.startsWith(t)))&&(e=function(e){var t;let r,n,o;for(let t of e.split("/"))if(n=u.find(e=>t.startsWith(e))){[r,o]=e.split(n,2);break}if(!r||!n||!o)throw Error(`Invalid interception route: ${e}. Must be in the format /<intercepting route>/(..|...|..)(..)/<intercepted route>`);switch(r=(t=r.split("/").reduce((e,t,r,n)=>t?"("===t[0]&&t.endsWith(")")||"@"===t[0]||("page"===t||"route"===t)&&r===n.length-1?e:`${e}/${t}`:e,"")).startsWith("/")?t:`/${t}`,n){case"(.)":o="/"===r?`/${o}`:r+"/"+o;break;case"(..)":if("/"===r)throw Error(`Invalid interception route: ${e}. Cannot use (..) marker at the root level, use (.) instead.`);o=r.split("/").slice(0,-1).concat(o).join("/");break;case"(...)":o="/"+o;break;case"(..)(..)":let a=r.split("/");if(a.length<=2)throw Error(`Invalid interception route: ${e}. Cannot use (..)(..) marker at the root level or one level up.`);o=a.slice(0,-2).concat(o).join("/");break;default:throw Error("Invariant: unexpected marker")}return{interceptingRoute:r,interceptedRoute:o}}(e).interceptedRoute),t)?f.test(e):d.test(e)}(n)&&(function(e,{includeSuffix:t=!1,includePrefix:r=!1,excludeOptionalTrailingSlash:n=!1}={}){let{parameterizedRoute:o,groups:a}=function(e,t,r){let n={},o=1,a=[];for(let i of(47===e.charCodeAt(e.length-1)&&e.length>1?e.slice(0,-1):e).slice(1).split("/")){let e=u.find(e=>i.startsWith(e)),s=i.match(v);if(e&&s&&s[2]){let{key:t,optional:r,repeat:i}=x(s[2]);n[t]={pos:o++,repeat:i,optional:r},a.push(`/${g(e)}([^/]+?)`)}else if(s&&s[2]){let{key:e,repeat:t,optional:i}=x(s[2]);n[e]={pos:o++,repeat:t,optional:i},r&&s[1]&&a.push(`/${g(s[1])}`);let l=t?i?"(?:/(.+?))?":"/(.+?)":"/([^/]+?)";r&&s[1]&&(l=l.substring(1)),a.push(l)}else a.push(`/${g(i)}`);t&&s&&s[3]&&a.push(g(s[3]))}return{parameterizedRoute:a.join(""),groups:n}}(e,t,r),i=o;return n||(i+="(?:/)?"),{re:RegExp(`^${i}$`),groups:a}})(n).re.test(r)});if(r.length===e.errors.length)return e;return{...e,errors:r}}case H:return{...e,requestInsights:t.snapshot.requests};case G:return{...e,hasVulnerabilityInsight:t.hasVulnerabilityInsight};case W:var r,n;let o,a;return{...e,requestInsights:(r=e.requestInsights,n=t.insight,o=(0,s.v)(n),(a=r.filter(e=>(0,s.v)(e)!==o)).push(n),a.slice(-100))};default:return e}},K[4]=X,K[5]=m):m=K[5],K[6]!==l||K[7]!==e)y={...ea,isErrorOverlayOpen:"pages"===e,routerType:e,cacheIndicator:l?"ready":"disabled"},K[6]=l,K[7]=e,K[8]=y;else y=K[8];return(0,o.useReducer)(m,y)}},"./src/next-devtools/dev-overlay/utils/css.ts"(e,t,r){"use strict";function n(e,...t){let r=e.length-1;return(e.slice(0,r).reduce((e,r,n)=>e+r+t[n],"")+e[r]).replace(/\/\*[\s\S]*?\*\//g,"").replace(/\s+/g," ").replace(/\s*([:;,{}])\s*/g,"$1").replace(/;+}/g,"}").trim()}r.d(t,{A:()=>n})},"./src/next-devtools/dev-overlay/utils/cx.ts"(e,t,r){"use strict";function n(...e){return e.filter(Boolean).join(" ")}r.d(t,{cx:()=>n})},"./src/next-devtools/dev-overlay/utils/get-error-by-type.ts"(e,t,r){"use strict";r.d(t,{W:()=>l,s:()=>s});var n=r("./src/next-devtools/shared/stack-frame.ts"),o=r("./src/shared/lib/error-source.ts"),a=r("./src/server/lib/parse-stack.ts"),i=r("./dist/compiled/react/index.js");let s=e=>{if(!e)return[];let t=e.frames;return i.use(t())};function l(e,t){return e.error instanceof AggregateError?{id:e.id,runtime:!0,error:e.error,type:e.type,frames:d(async()=>await (0,n.w)(e.frames,(0,o.C)(e.error),t)),cause:c(e.error,t),aggregateErrors:u(e.error,t)}:{id:e.id,runtime:!0,error:e.error,type:e.type,frames:d(async()=>await (0,n.w)(e.frames,(0,o.C)(e.error),t)),cause:c(e.error,t)}}function c(e,t,r=0){if(r>=5)return;let i=e.cause;if(!(i instanceof Error))return;let s=(0,a.G)(i.stack||"");return i instanceof AggregateError?{error:i,frames:d(async()=>await (0,n.w)(s,(0,o.C)(i),t)),cause:c(i,t,r+1),aggregateErrors:u(i,t,r+1)}:{error:i,frames:d(async()=>await (0,n.w)(s,(0,o.C)(i),t)),cause:c(i,t,r+1)}}function u(e,t,r=0){if(r>=5||0===e.errors.length)return null;let i=[];for(let s=0;s<e.errors.length;s++){let l=e.errors[s];if(l instanceof AggregateError){let e=(0,a.G)(l.stack||"");i.push({error:l,frames:d(async()=>await (0,n.w)(e,(0,o.C)(l),t)),cause:c(l,t,r+1),aggregateErrors:u(l,t,r+1)})}else if(l instanceof Error){let e=(0,a.G)(l.stack||"");i.push({error:l,frames:d(async()=>await (0,n.w)(e,(0,o.C)(l),t)),cause:c(l,t,r+1)})}if(i.length>=5)break}return i}function d(e){let t=e();return function(){return t}}},"./src/next-devtools/dev-overlay/utils/use-open-in-editor.ts"(e,t,r){"use strict";r.d(t,{Y:()=>o});var n=r("./dist/compiled/react/compiler-runtime.js");function o(e){let t,r,o=(0,n.c)(6);o[0]!==e?(t=void 0===e?{}:e,o[0]=e,o[1]=t):t=o[1];let{file:i,line1:s,column1:l}=t;return o[2]!==l||o[3]!==i||o[4]!==s?(r=()=>{if(null==i||null==s||null==l)return;let e=new URLSearchParams;e.append("file",i),e.append("line1",String(s)),e.append("column1",String(l)),self.fetch(`${process.env.__NEXT_ROUTER_BASEPATH||""}/__nextjs_launch-editor?${e.toString()}`).then(a,e=>{console.error(`Failed to open file "${i} (${s}:${l})" in your editor. Cause:`,e)})},o[2]=l,o[3]=i,o[4]=s,o[5]=r):r=o[5],r}function a(){}},"./src/next-devtools/shared/react-19-hydration-error.ts"(e,t,r){"use strict";r.d(t,{Gg:()=>o,f5:()=>l,rJ:()=>i,rz:()=>n});let n="https://react.dev/link/hydration-mismatch",o="https://nextjs.org/docs/messages/react-hydration-error",a=[/^In HTML, (.+?) cannot be a child of <(.+?)>\.(.*)\nThis will cause a hydration error\.(.*)/,/^In HTML, (.+?) cannot be a descendant of <(.+?)>\.\nThis will cause a hydration error\.(.*)/,/^In HTML, text nodes cannot be a child of <(.+?)>\.\nThis will cause a hydration error\./,/^In HTML, whitespace text nodes cannot be a child of <(.+?)>\. Make sure you don't have any extra whitespace between tags on each line of your source code\.\nThis will cause a hydration error\./];function i(e){return s(e.message)||/Hydration failed because the server rendered (text|HTML) didn't match the client\./.test(e.message)||/A tree hydrated but some attributes of the server rendered HTML didn't match the client properties./.test(e.message)}function s(e){return a.some(t=>t.test(e))}function l(e){let t=e.message;if(s(t)){let[e,r=""]=t.split("\n\n"),n=r.trim();return{message:""===n?t.trim():e.trim(),diff:n,notes:null}}let[r,o]=t.split(`${n}`),a=r.trim();if(void 0!==o&&o.length>1){let e=[];o.split("\n").forEach(t=>{""!==t.trim()&&(t.trim().startsWith("at ")||e.push(t))});let[t,...r]=a.split("\n\n");return{message:t,diff:e.join("\n"),notes:r.join("\n\n")||null}}{let[e,...t]=a.split("\n\n");return{message:e,diff:null,notes:t.join("\n\n")}}}},"./src/next-devtools/shared/stack-frame.ts"(e,t,r){"use strict";r.d(t,{w:()=>s,Q:()=>l});let n=[/^webpack-internal:\/\/\/(\([\w-]+\)\/)?/,/^(webpack:\/\/\/|webpack:\/\/(_N_E\/)?)(\([\w-]+\)\/)?/];function o(e){for(let t of n){if(t.test(e))return!0;e=e.replace(t,"")}return!1}function a(e){for(let t of n)e=e.replace(t,"");return e}function i(e,t){async function r(){if("rejected"===t.status)throw Error(t.reason);let r=t.value;return{error:!1,reason:null,external:!1,sourceStackFrame:e,originalStackFrame:r.originalStackFrame,originalCodeFrame:r.originalCodeFrame||null,ignored:r.originalStackFrame?.ignored||!1}}return"file://"===e.file||e.file?.match(/https?:\/\//)?Promise.resolve({error:!1,reason:null,external:!0,sourceStackFrame:e,originalStackFrame:null,originalCodeFrame:null,ignored:!0}):r().catch(t=>({error:!0,reason:t?.message??t?.toString()??"Unknown Error",external:!1,sourceStackFrame:e,originalStackFrame:null,originalCodeFrame:null,ignored:!1}))}async function s(e,t,r){let n,o;try{n=await fetch("/__nextjs_original-stack-frames",{method:"POST",body:JSON.stringify({frames:e,isServer:"server"===t,isEdgeServer:"edge-server"===t,isAppDirectory:r})})}catch(e){o=e+""}if(n&&n.ok&&204!==n.status){let t=await n.json();return Promise.all(e.map((e,r)=>i(e,t[r])))}return n&&(o=await n.text()),Promise.all(e.map(e=>i(e,{status:"rejected",reason:`Failed to fetch the original stack frames ${o?`: ${o}`:""}`})))}function l(e){if(!e.file)return"";let t=o(e.file),r="";if(t)r=a(e.file);else try{let t=new URL(e.file),n="";globalThis.location?.origin!==t.origin&&("null"===t.origin?n+=t.protocol:n+=t.origin),n+=t.pathname,r=a(n)}catch{r=a(e.file)}return!o(e.file)&&null!=e.line1&&r&&"<anonymous>"!==e.file&&(null!=e.column1?r+=` (${e.line1}:${e.column1})`:r+=` (${e.line1})`),r}},"./src/server/lib/parse-stack.ts"(e,t,r){"use strict";r.d(t,{G:()=>a});var n=r("./dist/compiled/stacktrace-parser/stack-trace-parser.cjs.js");let o=/\/_next(\/static\/.+)/;function a(e,t=process.env.__NEXT_DIST_DIR){return e?(e=e.split("\n").map(e=>(e.includes("(eval ")&&(e=e.replace(/eval code/g,"eval").replace(/\(eval at [^()]* \(/,"(file://").replace(/\),.*$/g,")")),e)).join("\n"),(0,n.parse)(e).map(e=>{try{let r=new URL(e.file),n=o.exec(r.pathname);if(n){let o=t?.replace(/\\/g,"/")?.replace(/\/$/,"");o&&(e.file="file://"+o.concat(n.pop())+r.search)}}catch{}return{file:e.file,line1:e.lineNumber,column1:e.column,methodName:e.methodName,arguments:e.arguments}})):[]}},"./src/shared/lib/error-source.ts"(e,t,r){"use strict";r.d(t,{C:()=>o});let n=Symbol.for("NextjsError");function o(e){return e[n]||null}},"./src/shared/lib/request-insights.ts"(e,t,r){"use strict";function n(e){return e.kind??"request"}function o(e){return`${n(e)}:${e.requestId}`}r.d(t,{o:()=>n,v:()=>o})},"./dist/compiled/zod/index.cjs"(e){(()=>{"use strict";var t={247:function(e,t,r){var n=this&&this.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var o=Object.getOwnPropertyDescriptor(t,r);(!o||("get"in o?!t.__esModule:o.writable||o.configurable))&&(o={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,o)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),o=this&&this.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),a=this&&this.__importStar||function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var r in e)"default"!==r&&Object.prototype.hasOwnProperty.call(e,r)&&n(t,e,r);return o(t,e),t},i=this&&this.__exportStar||function(e,t){for(var r in e)"default"===r||Object.prototype.hasOwnProperty.call(t,r)||n(t,e,r)};Object.defineProperty(t,"__esModule",{value:!0}),t.z=void 0;let s=a(r(390));t.z=s,i(r(390),t),t.default=s},360:(e,t,r)=>{Object.defineProperty(t,"__esModule",{value:!0}),t.ZodError=t.quotelessJson=t.ZodIssueCode=void 0;let n=r(361);t.ZodIssueCode=n.util.arrayToEnum(["invalid_type","invalid_literal","custom","invalid_union","invalid_union_discriminator","invalid_enum_value","unrecognized_keys","invalid_arguments","invalid_return_type","invalid_date","invalid_string","too_small","too_big","invalid_intersection_types","not_multiple_of","not_finite"]),t.quotelessJson=e=>JSON.stringify(e,null,2).replace(/"([^"]+)":/g,"$1:");class o extends Error{get errors(){return this.issues}constructor(e){super(),this.issues=[],this.addIssue=e=>{this.issues=[...this.issues,e]},this.addIssues=(e=[])=>{this.issues=[...this.issues,...e]};const t=new.target.prototype;Object.setPrototypeOf?Object.setPrototypeOf(this,t):this.__proto__=t,this.name="ZodError",this.issues=e}format(e){let t=e||function(e){return e.message},r={_errors:[]},n=e=>{for(let o of e.issues)if("invalid_union"===o.code)o.unionErrors.map(n);else if("invalid_return_type"===o.code)n(o.returnTypeError);else if("invalid_arguments"===o.code)n(o.argumentsError);else if(0===o.path.length)r._errors.push(t(o));else{let e=r,n=0;for(;n<o.path.length;){let r=o.path[n];n===o.path.length-1?(e[r]=e[r]||{_errors:[]},e[r]._errors.push(t(o))):e[r]=e[r]||{_errors:[]},e=e[r],n++}}};return n(this),r}static assert(e){if(!(e instanceof o))throw Error(`Not a ZodError: ${e}`)}toString(){return this.message}get message(){return JSON.stringify(this.issues,n.util.jsonStringifyReplacer,2)}get isEmpty(){return 0===this.issues.length}flatten(e=e=>e.message){let t={},r=[];for(let n of this.issues)if(n.path.length>0){let r=n.path[0];t[r]=t[r]||[],t[r].push(e(n))}else r.push(e(n));return{formErrors:r,fieldErrors:t}}get formErrors(){return this.flatten()}}t.ZodError=o,o.create=e=>new o(e)},890:function(e,t,r){var n=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.defaultErrorMap=void 0,t.setErrorMap=function(e){a=e},t.getErrorMap=function(){return a};let o=n(r(570));t.defaultErrorMap=o.default;let a=o.default},390:function(e,t,r){var n=this&&this.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var o=Object.getOwnPropertyDescriptor(t,r);(!o||("get"in o?!t.__esModule:o.writable||o.configurable))&&(o={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,o)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),o=this&&this.__exportStar||function(e,t){for(var r in e)"default"===r||Object.prototype.hasOwnProperty.call(t,r)||n(t,e,r)};Object.defineProperty(t,"__esModule",{value:!0}),o(r(890),t),o(r(650),t),o(r(95),t),o(r(361),t),o(r(734),t),o(r(360),t)},849:(e,t)=>{var r,n;Object.defineProperty(t,"__esModule",{value:!0}),t.errorUtil=void 0,(n=r||(t.errorUtil=r={})).errToObj=e=>"string"==typeof e?{message:e}:e||{},n.toString=e=>"string"==typeof e?e:e?.message},650:function(e,t,r){var n=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.isAsync=t.isValid=t.isDirty=t.isAborted=t.OK=t.DIRTY=t.INVALID=t.ParseStatus=t.EMPTY_PATH=t.makeIssue=void 0,t.addIssueToContext=function(e,r){let n=(0,o.getErrorMap)(),i=(0,t.makeIssue)({issueData:r,data:e.data,path:e.path,errorMaps:[e.common.contextualErrorMap,e.schemaErrorMap,n,n===a.default?void 0:a.default].filter(e=>!!e)});e.common.issues.push(i)};let o=r(890),a=n(r(570));t.makeIssue=e=>{let{data:t,path:r,errorMaps:n,issueData:o}=e,a=[...r,...o.path||[]],i={...o,path:a};if(void 0!==o.message)return{...o,path:a,message:o.message};let s="";for(let e of n.filter(e=>!!e).slice().reverse())s=e(i,{data:t,defaultError:s}).message;return{...o,path:a,message:s}},t.EMPTY_PATH=[];class i{constructor(){this.value="valid"}dirty(){"valid"===this.value&&(this.value="dirty")}abort(){"aborted"!==this.value&&(this.value="aborted")}static mergeArray(e,r){let n=[];for(let o of r){if("aborted"===o.status)return t.INVALID;"dirty"===o.status&&e.dirty(),n.push(o.value)}return{status:e.value,value:n}}static async mergeObjectAsync(e,t){let r=[];for(let e of t){let t=await e.key,n=await e.value;r.push({key:t,value:n})}return i.mergeObjectSync(e,r)}static mergeObjectSync(e,r){let n={};for(let o of r){let{key:r,value:a}=o;if("aborted"===r.status||"aborted"===a.status)return t.INVALID;"dirty"===r.status&&e.dirty(),"dirty"===a.status&&e.dirty(),"__proto__"!==r.value&&(void 0!==a.value||o.alwaysSet)&&(n[r.value]=a.value)}return{status:e.value,value:n}}}t.ParseStatus=i,t.INVALID=Object.freeze({status:"aborted"}),t.DIRTY=e=>({status:"dirty",value:e}),t.OK=e=>({status:"valid",value:e}),t.isAborted=e=>"aborted"===e.status,t.isDirty=e=>"dirty"===e.status,t.isValid=e=>"valid"===e.status,t.isAsync=e=>"undefined"!=typeof Promise&&e instanceof Promise},95:(e,t)=>{Object.defineProperty(t,"__esModule",{value:!0})},361:(e,t)=>{var r,n,o;Object.defineProperty(t,"__esModule",{value:!0}),t.getParsedType=t.ZodParsedType=t.objectUtil=t.util=void 0,(o=r||(t.util=r={})).assertEqual=e=>{},o.assertIs=function(e){},o.assertNever=function(e){throw Error()},o.arrayToEnum=e=>{let t={};for(let r of e)t[r]=r;return t},o.getValidEnumValues=e=>{let t=o.objectKeys(e).filter(t=>"number"!=typeof e[e[t]]),r={};for(let n of t)r[n]=e[n];return o.objectValues(r)},o.objectValues=e=>o.objectKeys(e).map(function(t){return e[t]}),o.objectKeys="function"==typeof Object.keys?e=>Object.keys(e):e=>{let t=[];for(let r in e)Object.prototype.hasOwnProperty.call(e,r)&&t.push(r);return t},o.find=(e,t)=>{for(let r of e)if(t(r))return r},o.isInteger="function"==typeof Number.isInteger?e=>Number.isInteger(e):e=>"number"==typeof e&&Number.isFinite(e)&&Math.floor(e)===e,o.joinValues=function(e,t=" | "){return e.map(e=>"string"==typeof e?`'${e}'`:e).join(t)},o.jsonStringifyReplacer=(e,t)=>"bigint"==typeof t?t.toString():t,(n||(t.objectUtil=n={})).mergeShapes=(e,t)=>({...e,...t}),t.ZodParsedType=r.arrayToEnum(["string","nan","number","integer","float","boolean","date","bigint","symbol","function","undefined","null","array","object","unknown","promise","void","never","map","set"]),t.getParsedType=e=>{switch(typeof e){case"undefined":return t.ZodParsedType.undefined;case"string":return t.ZodParsedType.string;case"number":return Number.isNaN(e)?t.ZodParsedType.nan:t.ZodParsedType.number;case"boolean":return t.ZodParsedType.boolean;case"function":return t.ZodParsedType.function;case"bigint":return t.ZodParsedType.bigint;case"symbol":return t.ZodParsedType.symbol;case"object":if(Array.isArray(e))return t.ZodParsedType.array;if(null===e)return t.ZodParsedType.null;if(e.then&&"function"==typeof e.then&&e.catch&&"function"==typeof e.catch)return t.ZodParsedType.promise;if("undefined"!=typeof Map&&e instanceof Map)return t.ZodParsedType.map;if("undefined"!=typeof Set&&e instanceof Set)return t.ZodParsedType.set;if("undefined"!=typeof Date&&e instanceof Date)return t.ZodParsedType.date;return t.ZodParsedType.object;default:return t.ZodParsedType.unknown}}},570:(e,t,r)=>{Object.defineProperty(t,"__esModule",{value:!0});let n=r(360),o=r(361);t.default=(e,t)=>{let r;switch(e.code){case n.ZodIssueCode.invalid_type:r=e.received===o.ZodParsedType.undefined?"Required":`Expected ${e.expected}, received ${e.received}`;break;case n.ZodIssueCode.invalid_literal:r=`Invalid literal value, expected ${JSON.stringify(e.expected,o.util.jsonStringifyReplacer)}`;break;case n.ZodIssueCode.unrecognized_keys:r=`Unrecognized key(s) in object: ${o.util.joinValues(e.keys,", ")}`;break;case n.ZodIssueCode.invalid_union:r="Invalid input";break;case n.ZodIssueCode.invalid_union_discriminator:r=`Invalid discriminator value. Expected ${o.util.joinValues(e.options)}`;break;case n.ZodIssueCode.invalid_enum_value:r=`Invalid enum value. Expected ${o.util.joinValues(e.options)}, received '${e.received}'`;break;case n.ZodIssueCode.invalid_arguments:r="Invalid function arguments";break;case n.ZodIssueCode.invalid_return_type:r="Invalid function return type";break;case n.ZodIssueCode.invalid_date:r="Invalid date";break;case n.ZodIssueCode.invalid_string:"object"==typeof e.validation?"includes"in e.validation?(r=`Invalid input: must include "${e.validation.includes}"`,"number"==typeof e.validation.position&&(r=`${r} at one or more positions greater than or equal to ${e.validation.position}`)):"startsWith"in e.validation?r=`Invalid input: must start with "${e.validation.startsWith}"`:"endsWith"in e.validation?r=`Invalid input: must end with "${e.validation.endsWith}"`:o.util.assertNever(e.validation):r="regex"!==e.validation?`Invalid ${e.validation}`:"Invalid";break;case n.ZodIssueCode.too_small:r="array"===e.type?`Array must contain ${e.exact?"exactly":e.inclusive?"at least":"more than"} ${e.minimum} element(s)`:"string"===e.type?`String must contain ${e.exact?"exactly":e.inclusive?"at least":"over"} ${e.minimum} character(s)`:"number"===e.type||"bigint"===e.type?`Number must be ${e.exact?"exactly equal to ":e.inclusive?"greater than or equal to ":"greater than "}${e.minimum}`:"date"===e.type?`Date must be ${e.exact?"exactly equal to ":e.inclusive?"greater than or equal to ":"greater than "}${new Date(Number(e.minimum))}`:"Invalid input";break;case n.ZodIssueCode.too_big:r="array"===e.type?`Array must contain ${e.exact?"exactly":e.inclusive?"at most":"less than"} ${e.maximum} element(s)`:"string"===e.type?`String must contain ${e.exact?"exactly":e.inclusive?"at most":"under"} ${e.maximum} character(s)`:"number"===e.type?`Number must be ${e.exact?"exactly":e.inclusive?"less than or equal to":"less than"} ${e.maximum}`:"bigint"===e.type?`BigInt must be ${e.exact?"exactly":e.inclusive?"less than or equal to":"less than"} ${e.maximum}`:"date"===e.type?`Date must be ${e.exact?"exactly":e.inclusive?"smaller than or equal to":"smaller than"} ${new Date(Number(e.maximum))}`:"Invalid input";break;case n.ZodIssueCode.custom:r="Invalid input";break;case n.ZodIssueCode.invalid_intersection_types:r="Intersection results could not be merged";break;case n.ZodIssueCode.not_multiple_of:r=`Number must be a multiple of ${e.multipleOf}`;break;case n.ZodIssueCode.not_finite:r="Number must be finite";break;default:r=t.defaultError,o.util.assertNever(e)}return{message:r}}},734:(e,t,r)=>{var n,o;let a;Object.defineProperty(t,"__esModule",{value:!0}),t.discriminatedUnion=t.date=t.boolean=t.bigint=t.array=t.any=t.coerce=t.ZodFirstPartyTypeKind=t.late=t.ZodSchema=t.Schema=t.ZodReadonly=t.ZodPipeline=t.ZodBranded=t.BRAND=t.ZodNaN=t.ZodCatch=t.ZodDefault=t.ZodNullable=t.ZodOptional=t.ZodTransformer=t.ZodEffects=t.ZodPromise=t.ZodNativeEnum=t.ZodEnum=t.ZodLiteral=t.ZodLazy=t.ZodFunction=t.ZodSet=t.ZodMap=t.ZodRecord=t.ZodTuple=t.ZodIntersection=t.ZodDiscriminatedUnion=t.ZodUnion=t.ZodObject=t.ZodArray=t.ZodVoid=t.ZodNever=t.ZodUnknown=t.ZodAny=t.ZodNull=t.ZodUndefined=t.ZodSymbol=t.ZodDate=t.ZodBoolean=t.ZodBigInt=t.ZodNumber=t.ZodString=t.ZodType=void 0,t.NEVER=t.void=t.unknown=t.union=t.undefined=t.tuple=t.transformer=t.symbol=t.string=t.strictObject=t.set=t.record=t.promise=t.preprocess=t.pipeline=t.ostring=t.optional=t.onumber=t.oboolean=t.object=t.number=t.nullable=t.null=t.never=t.nativeEnum=t.nan=t.map=t.literal=t.lazy=t.intersection=t.instanceof=t.function=t.enum=t.effect=void 0,t.datetimeRegex=R,t.custom=ex;let i=r(360),s=r(890),l=r(849),c=r(650),u=r(361);class d{constructor(e,t,r,n){this._cachedPath=[],this.parent=e,this.data=t,this._path=r,this._key=n}get path(){return this._cachedPath.length||(Array.isArray(this._key)?this._cachedPath.push(...this._path,...this._key):this._cachedPath.push(...this._path,this._key)),this._cachedPath}}let f=(e,t)=>{if((0,c.isValid)(t))return{success:!0,data:t.value};if(!e.common.issues.length)throw Error("Validation failed but no issues detected.");return{success:!1,get error(){if(this._error)return this._error;let t=new i.ZodError(e.common.issues);return this._error=t,this._error}}};function p(e){if(!e)return{};let{errorMap:t,invalid_type_error:r,required_error:n,description:o}=e;if(t&&(r||n))throw Error('Can\'t use "invalid_type_error" or "required_error" in conjunction with custom error map.');return t?{errorMap:t,description:o}:{errorMap:(t,o)=>{let{message:a}=e;return"invalid_enum_value"===t.code?{message:a??o.defaultError}:void 0===o.data?{message:a??n??o.defaultError}:"invalid_type"!==t.code?{message:o.defaultError}:{message:a??r??o.defaultError}},description:o}}class h{get description(){return this._def.description}_getType(e){return(0,u.getParsedType)(e.data)}_getOrReturnCtx(e,t){return t||{common:e.parent.common,data:e.data,parsedType:(0,u.getParsedType)(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}_processInputParams(e){return{status:new c.ParseStatus,ctx:{common:e.parent.common,data:e.data,parsedType:(0,u.getParsedType)(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}}_parseSync(e){let t=this._parse(e);if((0,c.isAsync)(t))throw Error("Synchronous parse encountered promise.");return t}_parseAsync(e){return Promise.resolve(this._parse(e))}parse(e,t){let r=this.safeParse(e,t);if(r.success)return r.data;throw r.error}safeParse(e,t){let r={common:{issues:[],async:t?.async??!1,contextualErrorMap:t?.errorMap},path:t?.path||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:(0,u.getParsedType)(e)},n=this._parseSync({data:e,path:r.path,parent:r});return f(r,n)}"~validate"(e){let t={common:{issues:[],async:!!this["~standard"].async},path:[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:(0,u.getParsedType)(e)};if(!this["~standard"].async)try{let r=this._parseSync({data:e,path:[],parent:t});return(0,c.isValid)(r)?{value:r.value}:{issues:t.common.issues}}catch(e){e?.message?.toLowerCase()?.includes("encountered")&&(this["~standard"].async=!0),t.common={issues:[],async:!0}}return this._parseAsync({data:e,path:[],parent:t}).then(e=>(0,c.isValid)(e)?{value:e.value}:{issues:t.common.issues})}async parseAsync(e,t){let r=await this.safeParseAsync(e,t);if(r.success)return r.data;throw r.error}async safeParseAsync(e,t){let r={common:{issues:[],contextualErrorMap:t?.errorMap,async:!0},path:t?.path||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:(0,u.getParsedType)(e)},n=this._parse({data:e,path:r.path,parent:r});return f(r,await ((0,c.isAsync)(n)?n:Promise.resolve(n)))}refine(e,t){return this._refinement((r,n)=>{let o=e(r),a=()=>n.addIssue({code:i.ZodIssueCode.custom,..."string"==typeof t||void 0===t?{message:t}:"function"==typeof t?t(r):t});return"undefined"!=typeof Promise&&o instanceof Promise?o.then(e=>!!e||(a(),!1)):!!o||(a(),!1)})}refinement(e,t){return this._refinement((r,n)=>!!e(r)||(n.addIssue("function"==typeof t?t(r,n):t),!1))}_refinement(e){return new el({schema:this,typeName:n.ZodEffects,effect:{type:"refinement",refinement:e}})}superRefine(e){return this._refinement(e)}constructor(e){this.spa=this.safeParseAsync,this._def=e,this.parse=this.parse.bind(this),this.safeParse=this.safeParse.bind(this),this.parseAsync=this.parseAsync.bind(this),this.safeParseAsync=this.safeParseAsync.bind(this),this.spa=this.spa.bind(this),this.refine=this.refine.bind(this),this.refinement=this.refinement.bind(this),this.superRefine=this.superRefine.bind(this),this.optional=this.optional.bind(this),this.nullable=this.nullable.bind(this),this.nullish=this.nullish.bind(this),this.array=this.array.bind(this),this.promise=this.promise.bind(this),this.or=this.or.bind(this),this.and=this.and.bind(this),this.transform=this.transform.bind(this),this.brand=this.brand.bind(this),this.default=this.default.bind(this),this.catch=this.catch.bind(this),this.describe=this.describe.bind(this),this.pipe=this.pipe.bind(this),this.readonly=this.readonly.bind(this),this.isNullable=this.isNullable.bind(this),this.isOptional=this.isOptional.bind(this),this["~standard"]={version:1,vendor:"zod",validate:e=>this["~validate"](e)}}optional(){return ec.create(this,this._def)}nullable(){return eu.create(this,this._def)}nullish(){return this.nullable().optional()}array(){return V.create(this)}promise(){return es.create(this,this._def)}or(e){return W.create([this,e],this._def)}and(e){return Y.create(this,e,this._def)}transform(e){return new el({...p(this._def),schema:this,typeName:n.ZodEffects,effect:{type:"transform",transform:e}})}default(e){return new ed({...p(this._def),innerType:this,defaultValue:"function"==typeof e?e:()=>e,typeName:n.ZodDefault})}brand(){return new eh({typeName:n.ZodBranded,type:this,...p(this._def)})}catch(e){return new ef({...p(this._def),innerType:this,catchValue:"function"==typeof e?e:()=>e,typeName:n.ZodCatch})}describe(e){return new this.constructor({...this._def,description:e})}pipe(e){return em.create(this,e)}readonly(){return eg.create(this)}isOptional(){return this.safeParse(void 0).success}isNullable(){return this.safeParse(null).success}}t.ZodType=h,t.Schema=h,t.ZodSchema=h;let m=/^c[^\s-]{8,}$/i,g=/^[0-9a-z]+$/,v=/^[0-9A-HJKMNP-TV-Z]{26}$/i,x=/^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i,y=/^[a-z0-9_-]{21}$/i,b=/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/,w=/^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/,_=/^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i,k=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,j=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/,S=/^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/,C=/^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,E=/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/,T=/^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/,N="((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))",I=RegExp(`^${N}$`);function z(e){let t="[0-5]\\d";e.precision?t=`${t}\\.\\d{${e.precision}}`:null==e.precision&&(t=`${t}(\\.\\d+)?`);let r=e.precision?"+":"?";return`([01]\\d|2[0-3]):[0-5]\\d(:${t})${r}`}function R(e){let t=`${N}T${z(e)}`,r=[];return r.push(e.local?"Z?":"Z"),e.offset&&r.push("([+-]\\d{2}:?\\d{2})"),t=`${t}(${r.join("|")})`,RegExp(`^${t}$`)}class P extends h{_parse(e){var t,r,n,o;let s;if(this._def.coerce&&(e.data=String(e.data)),this._getType(e)!==u.ZodParsedType.string){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.string,received:t.parsedType}),c.INVALID}let l=new c.ParseStatus;for(let d of this._def.checks)if("min"===d.kind)e.data.length<d.value&&(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{code:i.ZodIssueCode.too_small,minimum:d.value,type:"string",inclusive:!0,exact:!1,message:d.message}),l.dirty());else if("max"===d.kind)e.data.length>d.value&&(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{code:i.ZodIssueCode.too_big,maximum:d.value,type:"string",inclusive:!0,exact:!1,message:d.message}),l.dirty());else if("length"===d.kind){let t=e.data.length>d.value,r=e.data.length<d.value;(t||r)&&(s=this._getOrReturnCtx(e,s),t?(0,c.addIssueToContext)(s,{code:i.ZodIssueCode.too_big,maximum:d.value,type:"string",inclusive:!0,exact:!0,message:d.message}):r&&(0,c.addIssueToContext)(s,{code:i.ZodIssueCode.too_small,minimum:d.value,type:"string",inclusive:!0,exact:!0,message:d.message}),l.dirty())}else if("email"===d.kind)_.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"email",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty());else if("emoji"===d.kind)a||(a=RegExp("^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$","u")),a.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"emoji",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty());else if("uuid"===d.kind)x.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"uuid",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty());else if("nanoid"===d.kind)y.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"nanoid",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty());else if("cuid"===d.kind)m.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"cuid",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty());else if("cuid2"===d.kind)g.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"cuid2",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty());else if("ulid"===d.kind)v.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"ulid",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty());else if("url"===d.kind)try{new URL(e.data)}catch{s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"url",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty()}else"regex"===d.kind?(d.regex.lastIndex=0,d.regex.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"regex",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty())):"trim"===d.kind?e.data=e.data.trim():"includes"===d.kind?e.data.includes(d.value,d.position)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{code:i.ZodIssueCode.invalid_string,validation:{includes:d.value,position:d.position},message:d.message}),l.dirty()):"toLowerCase"===d.kind?e.data=e.data.toLowerCase():"toUpperCase"===d.kind?e.data=e.data.toUpperCase():"startsWith"===d.kind?e.data.startsWith(d.value)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{code:i.ZodIssueCode.invalid_string,validation:{startsWith:d.value},message:d.message}),l.dirty()):"endsWith"===d.kind?e.data.endsWith(d.value)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{code:i.ZodIssueCode.invalid_string,validation:{endsWith:d.value},message:d.message}),l.dirty()):"datetime"===d.kind?R(d).test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{code:i.ZodIssueCode.invalid_string,validation:"datetime",message:d.message}),l.dirty()):"date"===d.kind?I.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{code:i.ZodIssueCode.invalid_string,validation:"date",message:d.message}),l.dirty()):"time"===d.kind?RegExp(`^${z(d)}$`).test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{code:i.ZodIssueCode.invalid_string,validation:"time",message:d.message}),l.dirty()):"duration"===d.kind?w.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"duration",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty()):"ip"===d.kind?(t=e.data,!(("v4"===(r=d.version)||!r)&&k.test(t)||("v6"===r||!r)&&S.test(t))&&1&&(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"ip",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty())):"jwt"===d.kind?!function(e,t){if(!b.test(e))return!1;try{let[r]=e.split(".");if(!r)return!1;let n=r.replace(/-/g,"+").replace(/_/g,"/").padEnd(r.length+(4-r.length%4)%4,"="),o=JSON.parse(atob(n));if("object"!=typeof o||null===o||"typ"in o&&o?.typ!=="JWT"||!o.alg||t&&o.alg!==t)return!1;return!0}catch{return!1}}(e.data,d.alg)&&(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"jwt",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty()):"cidr"===d.kind?(n=e.data,!(("v4"===(o=d.version)||!o)&&j.test(n)||("v6"===o||!o)&&C.test(n))&&1&&(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"cidr",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty())):"base64"===d.kind?E.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"base64",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty()):"base64url"===d.kind?T.test(e.data)||(s=this._getOrReturnCtx(e,s),(0,c.addIssueToContext)(s,{validation:"base64url",code:i.ZodIssueCode.invalid_string,message:d.message}),l.dirty()):u.util.assertNever(d);return{status:l.value,value:e.data}}_regex(e,t,r){return this.refinement(t=>e.test(t),{validation:t,code:i.ZodIssueCode.invalid_string,...l.errorUtil.errToObj(r)})}_addCheck(e){return new P({...this._def,checks:[...this._def.checks,e]})}email(e){return this._addCheck({kind:"email",...l.errorUtil.errToObj(e)})}url(e){return this._addCheck({kind:"url",...l.errorUtil.errToObj(e)})}emoji(e){return this._addCheck({kind:"emoji",...l.errorUtil.errToObj(e)})}uuid(e){return this._addCheck({kind:"uuid",...l.errorUtil.errToObj(e)})}nanoid(e){return this._addCheck({kind:"nanoid",...l.errorUtil.errToObj(e)})}cuid(e){return this._addCheck({kind:"cuid",...l.errorUtil.errToObj(e)})}cuid2(e){return this._addCheck({kind:"cuid2",...l.errorUtil.errToObj(e)})}ulid(e){return this._addCheck({kind:"ulid",...l.errorUtil.errToObj(e)})}base64(e){return this._addCheck({kind:"base64",...l.errorUtil.errToObj(e)})}base64url(e){return this._addCheck({kind:"base64url",...l.errorUtil.errToObj(e)})}jwt(e){return this._addCheck({kind:"jwt",...l.errorUtil.errToObj(e)})}ip(e){return this._addCheck({kind:"ip",...l.errorUtil.errToObj(e)})}cidr(e){return this._addCheck({kind:"cidr",...l.errorUtil.errToObj(e)})}datetime(e){return"string"==typeof e?this._addCheck({kind:"datetime",precision:null,offset:!1,local:!1,message:e}):this._addCheck({kind:"datetime",precision:void 0===e?.precision?null:e?.precision,offset:e?.offset??!1,local:e?.local??!1,...l.errorUtil.errToObj(e?.message)})}date(e){return this._addCheck({kind:"date",message:e})}time(e){return"string"==typeof e?this._addCheck({kind:"time",precision:null,message:e}):this._addCheck({kind:"time",precision:void 0===e?.precision?null:e?.precision,...l.errorUtil.errToObj(e?.message)})}duration(e){return this._addCheck({kind:"duration",...l.errorUtil.errToObj(e)})}regex(e,t){return this._addCheck({kind:"regex",regex:e,...l.errorUtil.errToObj(t)})}includes(e,t){return this._addCheck({kind:"includes",value:e,position:t?.position,...l.errorUtil.errToObj(t?.message)})}startsWith(e,t){return this._addCheck({kind:"startsWith",value:e,...l.errorUtil.errToObj(t)})}endsWith(e,t){return this._addCheck({kind:"endsWith",value:e,...l.errorUtil.errToObj(t)})}min(e,t){return this._addCheck({kind:"min",value:e,...l.errorUtil.errToObj(t)})}max(e,t){return this._addCheck({kind:"max",value:e,...l.errorUtil.errToObj(t)})}length(e,t){return this._addCheck({kind:"length",value:e,...l.errorUtil.errToObj(t)})}nonempty(e){return this.min(1,l.errorUtil.errToObj(e))}trim(){return new P({...this._def,checks:[...this._def.checks,{kind:"trim"}]})}toLowerCase(){return new P({...this._def,checks:[...this._def.checks,{kind:"toLowerCase"}]})}toUpperCase(){return new P({...this._def,checks:[...this._def.checks,{kind:"toUpperCase"}]})}get isDatetime(){return!!this._def.checks.find(e=>"datetime"===e.kind)}get isDate(){return!!this._def.checks.find(e=>"date"===e.kind)}get isTime(){return!!this._def.checks.find(e=>"time"===e.kind)}get isDuration(){return!!this._def.checks.find(e=>"duration"===e.kind)}get isEmail(){return!!this._def.checks.find(e=>"email"===e.kind)}get isURL(){return!!this._def.checks.find(e=>"url"===e.kind)}get isEmoji(){return!!this._def.checks.find(e=>"emoji"===e.kind)}get isUUID(){return!!this._def.checks.find(e=>"uuid"===e.kind)}get isNANOID(){return!!this._def.checks.find(e=>"nanoid"===e.kind)}get isCUID(){return!!this._def.checks.find(e=>"cuid"===e.kind)}get isCUID2(){return!!this._def.checks.find(e=>"cuid2"===e.kind)}get isULID(){return!!this._def.checks.find(e=>"ulid"===e.kind)}get isIP(){return!!this._def.checks.find(e=>"ip"===e.kind)}get isCIDR(){return!!this._def.checks.find(e=>"cidr"===e.kind)}get isBase64(){return!!this._def.checks.find(e=>"base64"===e.kind)}get isBase64url(){return!!this._def.checks.find(e=>"base64url"===e.kind)}get minLength(){let e=null;for(let t of this._def.checks)"min"===t.kind&&(null===e||t.value>e)&&(e=t.value);return e}get maxLength(){let e=null;for(let t of this._def.checks)"max"===t.kind&&(null===e||t.value<e)&&(e=t.value);return e}}t.ZodString=P,P.create=e=>new P({checks:[],typeName:n.ZodString,coerce:e?.coerce??!1,...p(e)});class L extends h{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte,this.step=this.multipleOf}_parse(e){let t;if(this._def.coerce&&(e.data=Number(e.data)),this._getType(e)!==u.ZodParsedType.number){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.number,received:t.parsedType}),c.INVALID}let r=new c.ParseStatus;for(let n of this._def.checks)"int"===n.kind?u.util.isInteger(e.data)||(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:"integer",received:"float",message:n.message}),r.dirty()):"min"===n.kind?(n.inclusive?e.data<n.value:e.data<=n.value)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_small,minimum:n.value,type:"number",inclusive:n.inclusive,exact:!1,message:n.message}),r.dirty()):"max"===n.kind?(n.inclusive?e.data>n.value:e.data>=n.value)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_big,maximum:n.value,type:"number",inclusive:n.inclusive,exact:!1,message:n.message}),r.dirty()):"multipleOf"===n.kind?0!==function(e,t){let r=(e.toString().split(".")[1]||"").length,n=(t.toString().split(".")[1]||"").length,o=r>n?r:n;return Number.parseInt(e.toFixed(o).replace(".",""))%Number.parseInt(t.toFixed(o).replace(".",""))/10**o}(e.data,n.value)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.not_multiple_of,multipleOf:n.value,message:n.message}),r.dirty()):"finite"===n.kind?Number.isFinite(e.data)||(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.not_finite,message:n.message}),r.dirty()):u.util.assertNever(n);return{status:r.value,value:e.data}}gte(e,t){return this.setLimit("min",e,!0,l.errorUtil.toString(t))}gt(e,t){return this.setLimit("min",e,!1,l.errorUtil.toString(t))}lte(e,t){return this.setLimit("max",e,!0,l.errorUtil.toString(t))}lt(e,t){return this.setLimit("max",e,!1,l.errorUtil.toString(t))}setLimit(e,t,r,n){return new L({...this._def,checks:[...this._def.checks,{kind:e,value:t,inclusive:r,message:l.errorUtil.toString(n)}]})}_addCheck(e){return new L({...this._def,checks:[...this._def.checks,e]})}int(e){return this._addCheck({kind:"int",message:l.errorUtil.toString(e)})}positive(e){return this._addCheck({kind:"min",value:0,inclusive:!1,message:l.errorUtil.toString(e)})}negative(e){return this._addCheck({kind:"max",value:0,inclusive:!1,message:l.errorUtil.toString(e)})}nonpositive(e){return this._addCheck({kind:"max",value:0,inclusive:!0,message:l.errorUtil.toString(e)})}nonnegative(e){return this._addCheck({kind:"min",value:0,inclusive:!0,message:l.errorUtil.toString(e)})}multipleOf(e,t){return this._addCheck({kind:"multipleOf",value:e,message:l.errorUtil.toString(t)})}finite(e){return this._addCheck({kind:"finite",message:l.errorUtil.toString(e)})}safe(e){return this._addCheck({kind:"min",inclusive:!0,value:Number.MIN_SAFE_INTEGER,message:l.errorUtil.toString(e)})._addCheck({kind:"max",inclusive:!0,value:Number.MAX_SAFE_INTEGER,message:l.errorUtil.toString(e)})}get minValue(){let e=null;for(let t of this._def.checks)"min"===t.kind&&(null===e||t.value>e)&&(e=t.value);return e}get maxValue(){let e=null;for(let t of this._def.checks)"max"===t.kind&&(null===e||t.value<e)&&(e=t.value);return e}get isInt(){return!!this._def.checks.find(e=>"int"===e.kind||"multipleOf"===e.kind&&u.util.isInteger(e.value))}get isFinite(){let e=null,t=null;for(let r of this._def.checks)if("finite"===r.kind||"int"===r.kind||"multipleOf"===r.kind)return!0;else"min"===r.kind?(null===t||r.value>t)&&(t=r.value):"max"===r.kind&&(null===e||r.value<e)&&(e=r.value);return Number.isFinite(t)&&Number.isFinite(e)}}t.ZodNumber=L,L.create=e=>new L({checks:[],typeName:n.ZodNumber,coerce:e?.coerce||!1,...p(e)});class O extends h{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte}_parse(e){let t;if(this._def.coerce)try{e.data=BigInt(e.data)}catch{return this._getInvalidInput(e)}if(this._getType(e)!==u.ZodParsedType.bigint)return this._getInvalidInput(e);let r=new c.ParseStatus;for(let n of this._def.checks)"min"===n.kind?(n.inclusive?e.data<n.value:e.data<=n.value)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_small,type:"bigint",minimum:n.value,inclusive:n.inclusive,message:n.message}),r.dirty()):"max"===n.kind?(n.inclusive?e.data>n.value:e.data>=n.value)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_big,type:"bigint",maximum:n.value,inclusive:n.inclusive,message:n.message}),r.dirty()):"multipleOf"===n.kind?e.data%n.value!==BigInt(0)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.not_multiple_of,multipleOf:n.value,message:n.message}),r.dirty()):u.util.assertNever(n);return{status:r.value,value:e.data}}_getInvalidInput(e){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.bigint,received:t.parsedType}),c.INVALID}gte(e,t){return this.setLimit("min",e,!0,l.errorUtil.toString(t))}gt(e,t){return this.setLimit("min",e,!1,l.errorUtil.toString(t))}lte(e,t){return this.setLimit("max",e,!0,l.errorUtil.toString(t))}lt(e,t){return this.setLimit("max",e,!1,l.errorUtil.toString(t))}setLimit(e,t,r,n){return new O({...this._def,checks:[...this._def.checks,{kind:e,value:t,inclusive:r,message:l.errorUtil.toString(n)}]})}_addCheck(e){return new O({...this._def,checks:[...this._def.checks,e]})}positive(e){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!1,message:l.errorUtil.toString(e)})}negative(e){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!1,message:l.errorUtil.toString(e)})}nonpositive(e){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!0,message:l.errorUtil.toString(e)})}nonnegative(e){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!0,message:l.errorUtil.toString(e)})}multipleOf(e,t){return this._addCheck({kind:"multipleOf",value:e,message:l.errorUtil.toString(t)})}get minValue(){let e=null;for(let t of this._def.checks)"min"===t.kind&&(null===e||t.value>e)&&(e=t.value);return e}get maxValue(){let e=null;for(let t of this._def.checks)"max"===t.kind&&(null===e||t.value<e)&&(e=t.value);return e}}t.ZodBigInt=O,O.create=e=>new O({checks:[],typeName:n.ZodBigInt,coerce:e?.coerce??!1,...p(e)});class M extends h{_parse(e){if(this._def.coerce&&(e.data=!!e.data),this._getType(e)!==u.ZodParsedType.boolean){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.boolean,received:t.parsedType}),c.INVALID}return(0,c.OK)(e.data)}}t.ZodBoolean=M,M.create=e=>new M({typeName:n.ZodBoolean,coerce:e?.coerce||!1,...p(e)});class A extends h{_parse(e){let t;if(this._def.coerce&&(e.data=new Date(e.data)),this._getType(e)!==u.ZodParsedType.date){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.date,received:t.parsedType}),c.INVALID}if(Number.isNaN(e.data.getTime())){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_date}),c.INVALID}let r=new c.ParseStatus;for(let n of this._def.checks)"min"===n.kind?e.data.getTime()<n.value&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_small,message:n.message,inclusive:!0,exact:!1,minimum:n.value,type:"date"}),r.dirty()):"max"===n.kind?e.data.getTime()>n.value&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_big,message:n.message,inclusive:!0,exact:!1,maximum:n.value,type:"date"}),r.dirty()):u.util.assertNever(n);return{status:r.value,value:new Date(e.data.getTime())}}_addCheck(e){return new A({...this._def,checks:[...this._def.checks,e]})}min(e,t){return this._addCheck({kind:"min",value:e.getTime(),message:l.errorUtil.toString(t)})}max(e,t){return this._addCheck({kind:"max",value:e.getTime(),message:l.errorUtil.toString(t)})}get minDate(){let e=null;for(let t of this._def.checks)"min"===t.kind&&(null===e||t.value>e)&&(e=t.value);return null!=e?new Date(e):null}get maxDate(){let e=null;for(let t of this._def.checks)"max"===t.kind&&(null===e||t.value<e)&&(e=t.value);return null!=e?new Date(e):null}}t.ZodDate=A,A.create=e=>new A({checks:[],coerce:e?.coerce||!1,typeName:n.ZodDate,...p(e)});class D extends h{_parse(e){if(this._getType(e)!==u.ZodParsedType.symbol){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.symbol,received:t.parsedType}),c.INVALID}return(0,c.OK)(e.data)}}t.ZodSymbol=D,D.create=e=>new D({typeName:n.ZodSymbol,...p(e)});class F extends h{_parse(e){if(this._getType(e)!==u.ZodParsedType.undefined){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.undefined,received:t.parsedType}),c.INVALID}return(0,c.OK)(e.data)}}t.ZodUndefined=F,F.create=e=>new F({typeName:n.ZodUndefined,...p(e)});class $ extends h{_parse(e){if(this._getType(e)!==u.ZodParsedType.null){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.null,received:t.parsedType}),c.INVALID}return(0,c.OK)(e.data)}}t.ZodNull=$,$.create=e=>new $({typeName:n.ZodNull,...p(e)});class U extends h{constructor(){super(...arguments),this._any=!0}_parse(e){return(0,c.OK)(e.data)}}t.ZodAny=U,U.create=e=>new U({typeName:n.ZodAny,...p(e)});class Z extends h{constructor(){super(...arguments),this._unknown=!0}_parse(e){return(0,c.OK)(e.data)}}t.ZodUnknown=Z,Z.create=e=>new Z({typeName:n.ZodUnknown,...p(e)});class q extends h{_parse(e){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.never,received:t.parsedType}),c.INVALID}}t.ZodNever=q,q.create=e=>new q({typeName:n.ZodNever,...p(e)});class B extends h{_parse(e){if(this._getType(e)!==u.ZodParsedType.undefined){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.void,received:t.parsedType}),c.INVALID}return(0,c.OK)(e.data)}}t.ZodVoid=B,B.create=e=>new B({typeName:n.ZodVoid,...p(e)});class V extends h{_parse(e){let{ctx:t,status:r}=this._processInputParams(e),n=this._def;if(t.parsedType!==u.ZodParsedType.array)return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.array,received:t.parsedType}),c.INVALID;if(null!==n.exactLength){let e=t.data.length>n.exactLength.value,o=t.data.length<n.exactLength.value;(e||o)&&((0,c.addIssueToContext)(t,{code:e?i.ZodIssueCode.too_big:i.ZodIssueCode.too_small,minimum:o?n.exactLength.value:void 0,maximum:e?n.exactLength.value:void 0,type:"array",inclusive:!0,exact:!0,message:n.exactLength.message}),r.dirty())}if(null!==n.minLength&&t.data.length<n.minLength.value&&((0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_small,minimum:n.minLength.value,type:"array",inclusive:!0,exact:!1,message:n.minLength.message}),r.dirty()),null!==n.maxLength&&t.data.length>n.maxLength.value&&((0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_big,maximum:n.maxLength.value,type:"array",inclusive:!0,exact:!1,message:n.maxLength.message}),r.dirty()),t.common.async)return Promise.all([...t.data].map((e,r)=>n.type._parseAsync(new d(t,e,t.path,r)))).then(e=>c.ParseStatus.mergeArray(r,e));let o=[...t.data].map((e,r)=>n.type._parseSync(new d(t,e,t.path,r)));return c.ParseStatus.mergeArray(r,o)}get element(){return this._def.type}min(e,t){return new V({...this._def,minLength:{value:e,message:l.errorUtil.toString(t)}})}max(e,t){return new V({...this._def,maxLength:{value:e,message:l.errorUtil.toString(t)}})}length(e,t){return new V({...this._def,exactLength:{value:e,message:l.errorUtil.toString(t)}})}nonempty(e){return this.min(1,e)}}t.ZodArray=V,V.create=(e,t)=>new V({type:e,minLength:null,maxLength:null,exactLength:null,typeName:n.ZodArray,...p(t)});class H extends h{constructor(){super(...arguments),this._cached=null,this.nonstrict=this.passthrough,this.augment=this.extend}_getCached(){if(null!==this._cached)return this._cached;let e=this._def.shape(),t=u.util.objectKeys(e);return this._cached={shape:e,keys:t},this._cached}_parse(e){if(this._getType(e)!==u.ZodParsedType.object){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.object,received:t.parsedType}),c.INVALID}let{status:t,ctx:r}=this._processInputParams(e),{shape:n,keys:o}=this._getCached(),a=[];if(!(this._def.catchall instanceof q&&"strip"===this._def.unknownKeys))for(let e in r.data)o.includes(e)||a.push(e);let s=[];for(let e of o){let t=n[e],o=r.data[e];s.push({key:{status:"valid",value:e},value:t._parse(new d(r,o,r.path,e)),alwaysSet:e in r.data})}if(this._def.catchall instanceof q){let e=this._def.unknownKeys;if("passthrough"===e)for(let e of a)s.push({key:{status:"valid",value:e},value:{status:"valid",value:r.data[e]}});else if("strict"===e)a.length>0&&((0,c.addIssueToContext)(r,{code:i.ZodIssueCode.unrecognized_keys,keys:a}),t.dirty());else if("strip"===e);else throw Error("Internal ZodObject error: invalid unknownKeys value.")}else{let e=this._def.catchall;for(let t of a){let n=r.data[t];s.push({key:{status:"valid",value:t},value:e._parse(new d(r,n,r.path,t)),alwaysSet:t in r.data})}}return r.common.async?Promise.resolve().then(async()=>{let e=[];for(let t of s){let r=await t.key,n=await t.value;e.push({key:r,value:n,alwaysSet:t.alwaysSet})}return e}).then(e=>c.ParseStatus.mergeObjectSync(t,e)):c.ParseStatus.mergeObjectSync(t,s)}get shape(){return this._def.shape()}strict(e){return l.errorUtil.errToObj,new H({...this._def,unknownKeys:"strict",...void 0!==e?{errorMap:(t,r)=>{let n=this._def.errorMap?.(t,r).message??r.defaultError;return"unrecognized_keys"===t.code?{message:l.errorUtil.errToObj(e).message??n}:{message:n}}}:{}})}strip(){return new H({...this._def,unknownKeys:"strip"})}passthrough(){return new H({...this._def,unknownKeys:"passthrough"})}extend(e){return new H({...this._def,shape:()=>({...this._def.shape(),...e})})}merge(e){return new H({unknownKeys:e._def.unknownKeys,catchall:e._def.catchall,shape:()=>({...this._def.shape(),...e._def.shape()}),typeName:n.ZodObject})}setKey(e,t){return this.augment({[e]:t})}catchall(e){return new H({...this._def,catchall:e})}pick(e){let t={};for(let r of u.util.objectKeys(e))e[r]&&this.shape[r]&&(t[r]=this.shape[r]);return new H({...this._def,shape:()=>t})}omit(e){let t={};for(let r of u.util.objectKeys(this.shape))e[r]||(t[r]=this.shape[r]);return new H({...this._def,shape:()=>t})}deepPartial(){return function e(t){if(t instanceof H){let r={};for(let n in t.shape){let o=t.shape[n];r[n]=ec.create(e(o))}return new H({...t._def,shape:()=>r})}if(t instanceof V)return new V({...t._def,type:e(t.element)});if(t instanceof ec)return ec.create(e(t.unwrap()));if(t instanceof eu)return eu.create(e(t.unwrap()));if(t instanceof X)return X.create(t.items.map(t=>e(t)));else return t}(this)}partial(e){let t={};for(let r of u.util.objectKeys(this.shape)){let n=this.shape[r];e&&!e[r]?t[r]=n:t[r]=n.optional()}return new H({...this._def,shape:()=>t})}required(e){let t={};for(let r of u.util.objectKeys(this.shape))if(e&&!e[r])t[r]=this.shape[r];else{let e=this.shape[r];for(;e instanceof ec;)e=e._def.innerType;t[r]=e}return new H({...this._def,shape:()=>t})}keyof(){return eo(u.util.objectKeys(this.shape))}}t.ZodObject=H,H.create=(e,t)=>new H({shape:()=>e,unknownKeys:"strip",catchall:q.create(),typeName:n.ZodObject,...p(t)}),H.strictCreate=(e,t)=>new H({shape:()=>e,unknownKeys:"strict",catchall:q.create(),typeName:n.ZodObject,...p(t)}),H.lazycreate=(e,t)=>new H({shape:e,unknownKeys:"strip",catchall:q.create(),typeName:n.ZodObject,...p(t)});class W extends h{_parse(e){let{ctx:t}=this._processInputParams(e),r=this._def.options;if(t.common.async)return Promise.all(r.map(async e=>{let r={...t,common:{...t.common,issues:[]},parent:null};return{result:await e._parseAsync({data:t.data,path:t.path,parent:r}),ctx:r}})).then(function(e){for(let t of e)if("valid"===t.result.status)return t.result;for(let r of e)if("dirty"===r.result.status)return t.common.issues.push(...r.ctx.common.issues),r.result;let r=e.map(e=>new i.ZodError(e.ctx.common.issues));return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_union,unionErrors:r}),c.INVALID});{let e,n=[];for(let o of r){let r={...t,common:{...t.common,issues:[]},parent:null},a=o._parseSync({data:t.data,path:t.path,parent:r});if("valid"===a.status)return a;"dirty"!==a.status||e||(e={result:a,ctx:r}),r.common.issues.length&&n.push(r.common.issues)}if(e)return t.common.issues.push(...e.ctx.common.issues),e.result;let o=n.map(e=>new i.ZodError(e));return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_union,unionErrors:o}),c.INVALID}}get options(){return this._def.options}}t.ZodUnion=W,W.create=(e,t)=>new W({options:e,typeName:n.ZodUnion,...p(t)});let G=e=>{if(e instanceof er)return G(e.schema);if(e instanceof el)return G(e.innerType());if(e instanceof en)return[e.value];if(e instanceof ea)return e.options;if(e instanceof ei)return u.util.objectValues(e.enum);else if(e instanceof ed)return G(e._def.innerType);else if(e instanceof F)return[void 0];else if(e instanceof $)return[null];else if(e instanceof ec)return[void 0,...G(e.unwrap())];else if(e instanceof eu)return[null,...G(e.unwrap())];else if(e instanceof eh)return G(e.unwrap());else if(e instanceof eg)return G(e.unwrap());else if(e instanceof ef)return G(e._def.innerType);else return[]};class K extends h{_parse(e){let{ctx:t}=this._processInputParams(e);if(t.parsedType!==u.ZodParsedType.object)return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.object,received:t.parsedType}),c.INVALID;let r=this.discriminator,n=t.data[r],o=this.optionsMap.get(n);return o?t.common.async?o._parseAsync({data:t.data,path:t.path,parent:t}):o._parseSync({data:t.data,path:t.path,parent:t}):((0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_union_discriminator,options:Array.from(this.optionsMap.keys()),path:[r]}),c.INVALID)}get discriminator(){return this._def.discriminator}get options(){return this._def.options}get optionsMap(){return this._def.optionsMap}static create(e,t,r){let o=new Map;for(let r of t){let t=G(r.shape[e]);if(!t.length)throw Error(`A discriminator value for key \`${e}\` could not be extracted from all schema options`);for(let n of t){if(o.has(n))throw Error(`Discriminator property ${String(e)} has duplicate value ${String(n)}`);o.set(n,r)}}return new K({typeName:n.ZodDiscriminatedUnion,discriminator:e,options:t,optionsMap:o,...p(r)})}}t.ZodDiscriminatedUnion=K;class Y extends h{_parse(e){let{status:t,ctx:r}=this._processInputParams(e),n=(e,n)=>{if((0,c.isAborted)(e)||(0,c.isAborted)(n))return c.INVALID;let o=function e(t,r){let n=(0,u.getParsedType)(t),o=(0,u.getParsedType)(r);if(t===r)return{valid:!0,data:t};if(n===u.ZodParsedType.object&&o===u.ZodParsedType.object){let n=u.util.objectKeys(r),o=u.util.objectKeys(t).filter(e=>-1!==n.indexOf(e)),a={...t,...r};for(let n of o){let o=e(t[n],r[n]);if(!o.valid)return{valid:!1};a[n]=o.data}return{valid:!0,data:a}}if(n===u.ZodParsedType.array&&o===u.ZodParsedType.array){if(t.length!==r.length)return{valid:!1};let n=[];for(let o=0;o<t.length;o++){let a=e(t[o],r[o]);if(!a.valid)return{valid:!1};n.push(a.data)}return{valid:!0,data:n}}if(n===u.ZodParsedType.date&&o===u.ZodParsedType.date&&+t==+r)return{valid:!0,data:t};return{valid:!1}}(e.value,n.value);return o.valid?(((0,c.isDirty)(e)||(0,c.isDirty)(n))&&t.dirty(),{status:t.value,value:o.data}):((0,c.addIssueToContext)(r,{code:i.ZodIssueCode.invalid_intersection_types}),c.INVALID)};return r.common.async?Promise.all([this._def.left._parseAsync({data:r.data,path:r.path,parent:r}),this._def.right._parseAsync({data:r.data,path:r.path,parent:r})]).then(([e,t])=>n(e,t)):n(this._def.left._parseSync({data:r.data,path:r.path,parent:r}),this._def.right._parseSync({data:r.data,path:r.path,parent:r}))}}t.ZodIntersection=Y,Y.create=(e,t,r)=>new Y({left:e,right:t,typeName:n.ZodIntersection,...p(r)});class X extends h{_parse(e){let{status:t,ctx:r}=this._processInputParams(e);if(r.parsedType!==u.ZodParsedType.array)return(0,c.addIssueToContext)(r,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.array,received:r.parsedType}),c.INVALID;if(r.data.length<this._def.items.length)return(0,c.addIssueToContext)(r,{code:i.ZodIssueCode.too_small,minimum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),c.INVALID;!this._def.rest&&r.data.length>this._def.items.length&&((0,c.addIssueToContext)(r,{code:i.ZodIssueCode.too_big,maximum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),t.dirty());let n=[...r.data].map((e,t)=>{let n=this._def.items[t]||this._def.rest;return n?n._parse(new d(r,e,r.path,t)):null}).filter(e=>!!e);return r.common.async?Promise.all(n).then(e=>c.ParseStatus.mergeArray(t,e)):c.ParseStatus.mergeArray(t,n)}get items(){return this._def.items}rest(e){return new X({...this._def,rest:e})}}t.ZodTuple=X,X.create=(e,t)=>{if(!Array.isArray(e))throw Error("You must pass an array of schemas to z.tuple([ ... ])");return new X({items:e,typeName:n.ZodTuple,rest:null,...p(t)})};class Q extends h{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(e){let{status:t,ctx:r}=this._processInputParams(e);if(r.parsedType!==u.ZodParsedType.object)return(0,c.addIssueToContext)(r,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.object,received:r.parsedType}),c.INVALID;let n=[],o=this._def.keyType,a=this._def.valueType;for(let e in r.data)n.push({key:o._parse(new d(r,e,r.path,e)),value:a._parse(new d(r,r.data[e],r.path,e)),alwaysSet:e in r.data});return r.common.async?c.ParseStatus.mergeObjectAsync(t,n):c.ParseStatus.mergeObjectSync(t,n)}get element(){return this._def.valueType}static create(e,t,r){return new Q(t instanceof h?{keyType:e,valueType:t,typeName:n.ZodRecord,...p(r)}:{keyType:P.create(),valueType:e,typeName:n.ZodRecord,...p(t)})}}t.ZodRecord=Q;class J extends h{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(e){let{status:t,ctx:r}=this._processInputParams(e);if(r.parsedType!==u.ZodParsedType.map)return(0,c.addIssueToContext)(r,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.map,received:r.parsedType}),c.INVALID;let n=this._def.keyType,o=this._def.valueType,a=[...r.data.entries()].map(([e,t],a)=>({key:n._parse(new d(r,e,r.path,[a,"key"])),value:o._parse(new d(r,t,r.path,[a,"value"]))}));if(r.common.async){let e=new Map;return Promise.resolve().then(async()=>{for(let r of a){let n=await r.key,o=await r.value;if("aborted"===n.status||"aborted"===o.status)return c.INVALID;("dirty"===n.status||"dirty"===o.status)&&t.dirty(),e.set(n.value,o.value)}return{status:t.value,value:e}})}{let e=new Map;for(let r of a){let n=r.key,o=r.value;if("aborted"===n.status||"aborted"===o.status)return c.INVALID;("dirty"===n.status||"dirty"===o.status)&&t.dirty(),e.set(n.value,o.value)}return{status:t.value,value:e}}}}t.ZodMap=J,J.create=(e,t,r)=>new J({valueType:t,keyType:e,typeName:n.ZodMap,...p(r)});class ee extends h{_parse(e){let{status:t,ctx:r}=this._processInputParams(e);if(r.parsedType!==u.ZodParsedType.set)return(0,c.addIssueToContext)(r,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.set,received:r.parsedType}),c.INVALID;let n=this._def;null!==n.minSize&&r.data.size<n.minSize.value&&((0,c.addIssueToContext)(r,{code:i.ZodIssueCode.too_small,minimum:n.minSize.value,type:"set",inclusive:!0,exact:!1,message:n.minSize.message}),t.dirty()),null!==n.maxSize&&r.data.size>n.maxSize.value&&((0,c.addIssueToContext)(r,{code:i.ZodIssueCode.too_big,maximum:n.maxSize.value,type:"set",inclusive:!0,exact:!1,message:n.maxSize.message}),t.dirty());let o=this._def.valueType;function a(e){let r=new Set;for(let n of e){if("aborted"===n.status)return c.INVALID;"dirty"===n.status&&t.dirty(),r.add(n.value)}return{status:t.value,value:r}}let s=[...r.data.values()].map((e,t)=>o._parse(new d(r,e,r.path,t)));return r.common.async?Promise.all(s).then(e=>a(e)):a(s)}min(e,t){return new ee({...this._def,minSize:{value:e,message:l.errorUtil.toString(t)}})}max(e,t){return new ee({...this._def,maxSize:{value:e,message:l.errorUtil.toString(t)}})}size(e,t){return this.min(e,t).max(e,t)}nonempty(e){return this.min(1,e)}}t.ZodSet=ee,ee.create=(e,t)=>new ee({valueType:e,minSize:null,maxSize:null,typeName:n.ZodSet,...p(t)});class et extends h{constructor(){super(...arguments),this.validate=this.implement}_parse(e){let{ctx:t}=this._processInputParams(e);if(t.parsedType!==u.ZodParsedType.function)return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.function,received:t.parsedType}),c.INVALID;function r(e,r){return(0,c.makeIssue)({data:e,path:t.path,errorMaps:[t.common.contextualErrorMap,t.schemaErrorMap,(0,s.getErrorMap)(),s.defaultErrorMap].filter(e=>!!e),issueData:{code:i.ZodIssueCode.invalid_arguments,argumentsError:r}})}function n(e,r){return(0,c.makeIssue)({data:e,path:t.path,errorMaps:[t.common.contextualErrorMap,t.schemaErrorMap,(0,s.getErrorMap)(),s.defaultErrorMap].filter(e=>!!e),issueData:{code:i.ZodIssueCode.invalid_return_type,returnTypeError:r}})}let o={errorMap:t.common.contextualErrorMap},a=t.data;if(this._def.returns instanceof es){let e=this;return(0,c.OK)(async function(...t){let s=new i.ZodError([]),l=await e._def.args.parseAsync(t,o).catch(e=>{throw s.addIssue(r(t,e)),s}),c=await Reflect.apply(a,this,l);return await e._def.returns._def.type.parseAsync(c,o).catch(e=>{throw s.addIssue(n(c,e)),s})})}{let e=this;return(0,c.OK)(function(...t){let s=e._def.args.safeParse(t,o);if(!s.success)throw new i.ZodError([r(t,s.error)]);let l=Reflect.apply(a,this,s.data),c=e._def.returns.safeParse(l,o);if(!c.success)throw new i.ZodError([n(l,c.error)]);return c.data})}}parameters(){return this._def.args}returnType(){return this._def.returns}args(...e){return new et({...this._def,args:X.create(e).rest(Z.create())})}returns(e){return new et({...this._def,returns:e})}implement(e){return this.parse(e)}strictImplement(e){return this.parse(e)}static create(e,t,r){return new et({args:e||X.create([]).rest(Z.create()),returns:t||Z.create(),typeName:n.ZodFunction,...p(r)})}}t.ZodFunction=et;class er extends h{get schema(){return this._def.getter()}_parse(e){let{ctx:t}=this._processInputParams(e);return this._def.getter()._parse({data:t.data,path:t.path,parent:t})}}t.ZodLazy=er,er.create=(e,t)=>new er({getter:e,typeName:n.ZodLazy,...p(t)});class en extends h{_parse(e){if(e.data!==this._def.value){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{received:t.data,code:i.ZodIssueCode.invalid_literal,expected:this._def.value}),c.INVALID}return{status:"valid",value:e.data}}get value(){return this._def.value}}function eo(e,t){return new ea({values:e,typeName:n.ZodEnum,...p(t)})}t.ZodLiteral=en,en.create=(e,t)=>new en({value:e,typeName:n.ZodLiteral,...p(t)});class ea extends h{_parse(e){if("string"!=typeof e.data){let t=this._getOrReturnCtx(e),r=this._def.values;return(0,c.addIssueToContext)(t,{expected:u.util.joinValues(r),received:t.parsedType,code:i.ZodIssueCode.invalid_type}),c.INVALID}if(this._cache||(this._cache=new Set(this._def.values)),!this._cache.has(e.data)){let t=this._getOrReturnCtx(e),r=this._def.values;return(0,c.addIssueToContext)(t,{received:t.data,code:i.ZodIssueCode.invalid_enum_value,options:r}),c.INVALID}return(0,c.OK)(e.data)}get options(){return this._def.values}get enum(){let e={};for(let t of this._def.values)e[t]=t;return e}get Values(){let e={};for(let t of this._def.values)e[t]=t;return e}get Enum(){let e={};for(let t of this._def.values)e[t]=t;return e}extract(e,t=this._def){return ea.create(e,{...this._def,...t})}exclude(e,t=this._def){return ea.create(this.options.filter(t=>!e.includes(t)),{...this._def,...t})}}t.ZodEnum=ea,ea.create=eo;class ei extends h{_parse(e){let t=u.util.getValidEnumValues(this._def.values),r=this._getOrReturnCtx(e);if(r.parsedType!==u.ZodParsedType.string&&r.parsedType!==u.ZodParsedType.number){let e=u.util.objectValues(t);return(0,c.addIssueToContext)(r,{expected:u.util.joinValues(e),received:r.parsedType,code:i.ZodIssueCode.invalid_type}),c.INVALID}if(this._cache||(this._cache=new Set(u.util.getValidEnumValues(this._def.values))),!this._cache.has(e.data)){let e=u.util.objectValues(t);return(0,c.addIssueToContext)(r,{received:r.data,code:i.ZodIssueCode.invalid_enum_value,options:e}),c.INVALID}return(0,c.OK)(e.data)}get enum(){return this._def.values}}t.ZodNativeEnum=ei,ei.create=(e,t)=>new ei({values:e,typeName:n.ZodNativeEnum,...p(t)});class es extends h{unwrap(){return this._def.type}_parse(e){let{ctx:t}=this._processInputParams(e);if(t.parsedType!==u.ZodParsedType.promise&&!1===t.common.async)return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.promise,received:t.parsedType}),c.INVALID;let r=t.parsedType===u.ZodParsedType.promise?t.data:Promise.resolve(t.data);return(0,c.OK)(r.then(e=>this._def.type.parseAsync(e,{path:t.path,errorMap:t.common.contextualErrorMap})))}}t.ZodPromise=es,es.create=(e,t)=>new es({type:e,typeName:n.ZodPromise,...p(t)});class el extends h{innerType(){return this._def.schema}sourceType(){return this._def.schema._def.typeName===n.ZodEffects?this._def.schema.sourceType():this._def.schema}_parse(e){let{status:t,ctx:r}=this._processInputParams(e),n=this._def.effect||null,o={addIssue:e=>{(0,c.addIssueToContext)(r,e),e.fatal?t.abort():t.dirty()},get path(){return r.path}};if(o.addIssue=o.addIssue.bind(o),"preprocess"===n.type){let e=n.transform(r.data,o);if(r.common.async)return Promise.resolve(e).then(async e=>{if("aborted"===t.value)return c.INVALID;let n=await this._def.schema._parseAsync({data:e,path:r.path,parent:r});return"aborted"===n.status?c.INVALID:"dirty"===n.status||"dirty"===t.value?(0,c.DIRTY)(n.value):n});{if("aborted"===t.value)return c.INVALID;let n=this._def.schema._parseSync({data:e,path:r.path,parent:r});return"aborted"===n.status?c.INVALID:"dirty"===n.status||"dirty"===t.value?(0,c.DIRTY)(n.value):n}}if("refinement"===n.type){let e=e=>{let t=n.refinement(e,o);if(r.common.async)return Promise.resolve(t);if(t instanceof Promise)throw Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");return e};if(!1!==r.common.async)return this._def.schema._parseAsync({data:r.data,path:r.path,parent:r}).then(r=>"aborted"===r.status?c.INVALID:("dirty"===r.status&&t.dirty(),e(r.value).then(()=>({status:t.value,value:r.value}))));{let n=this._def.schema._parseSync({data:r.data,path:r.path,parent:r});return"aborted"===n.status?c.INVALID:("dirty"===n.status&&t.dirty(),e(n.value),{status:t.value,value:n.value})}}if("transform"===n.type)if(!1!==r.common.async)return this._def.schema._parseAsync({data:r.data,path:r.path,parent:r}).then(e=>(0,c.isValid)(e)?Promise.resolve(n.transform(e.value,o)).then(e=>({status:t.value,value:e})):c.INVALID);else{let e=this._def.schema._parseSync({data:r.data,path:r.path,parent:r});if(!(0,c.isValid)(e))return c.INVALID;let a=n.transform(e.value,o);if(a instanceof Promise)throw Error("Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.");return{status:t.value,value:a}}u.util.assertNever(n)}}t.ZodEffects=el,t.ZodTransformer=el,el.create=(e,t,r)=>new el({schema:e,typeName:n.ZodEffects,effect:t,...p(r)}),el.createWithPreprocess=(e,t,r)=>new el({schema:t,effect:{type:"preprocess",transform:e},typeName:n.ZodEffects,...p(r)});class ec extends h{_parse(e){return this._getType(e)===u.ZodParsedType.undefined?(0,c.OK)(void 0):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}}t.ZodOptional=ec,ec.create=(e,t)=>new ec({innerType:e,typeName:n.ZodOptional,...p(t)});class eu extends h{_parse(e){return this._getType(e)===u.ZodParsedType.null?(0,c.OK)(null):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}}t.ZodNullable=eu,eu.create=(e,t)=>new eu({innerType:e,typeName:n.ZodNullable,...p(t)});class ed extends h{_parse(e){let{ctx:t}=this._processInputParams(e),r=t.data;return t.parsedType===u.ZodParsedType.undefined&&(r=this._def.defaultValue()),this._def.innerType._parse({data:r,path:t.path,parent:t})}removeDefault(){return this._def.innerType}}t.ZodDefault=ed,ed.create=(e,t)=>new ed({innerType:e,typeName:n.ZodDefault,defaultValue:"function"==typeof t.default?t.default:()=>t.default,...p(t)});class ef extends h{_parse(e){let{ctx:t}=this._processInputParams(e),r={...t,common:{...t.common,issues:[]}},n=this._def.innerType._parse({data:r.data,path:r.path,parent:{...r}});return(0,c.isAsync)(n)?n.then(e=>({status:"valid",value:"valid"===e.status?e.value:this._def.catchValue({get error(){return new i.ZodError(r.common.issues)},input:r.data})})):{status:"valid",value:"valid"===n.status?n.value:this._def.catchValue({get error(){return new i.ZodError(r.common.issues)},input:r.data})}}removeCatch(){return this._def.innerType}}t.ZodCatch=ef,ef.create=(e,t)=>new ef({innerType:e,typeName:n.ZodCatch,catchValue:"function"==typeof t.catch?t.catch:()=>t.catch,...p(t)});class ep extends h{_parse(e){if(this._getType(e)!==u.ZodParsedType.nan){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.nan,received:t.parsedType}),c.INVALID}return{status:"valid",value:e.data}}}t.ZodNaN=ep,ep.create=e=>new ep({typeName:n.ZodNaN,...p(e)}),t.BRAND=Symbol("zod_brand");class eh extends h{_parse(e){let{ctx:t}=this._processInputParams(e),r=t.data;return this._def.type._parse({data:r,path:t.path,parent:t})}unwrap(){return this._def.type}}t.ZodBranded=eh;class em extends h{_parse(e){let{status:t,ctx:r}=this._processInputParams(e);if(r.common.async)return(async()=>{let e=await this._def.in._parseAsync({data:r.data,path:r.path,parent:r});return"aborted"===e.status?c.INVALID:"dirty"===e.status?(t.dirty(),(0,c.DIRTY)(e.value)):this._def.out._parseAsync({data:e.value,path:r.path,parent:r})})();{let e=this._def.in._parseSync({data:r.data,path:r.path,parent:r});return"aborted"===e.status?c.INVALID:"dirty"===e.status?(t.dirty(),{status:"dirty",value:e.value}):this._def.out._parseSync({data:e.value,path:r.path,parent:r})}}static create(e,t){return new em({in:e,out:t,typeName:n.ZodPipeline})}}t.ZodPipeline=em;class eg extends h{_parse(e){let t=this._def.innerType._parse(e),r=e=>((0,c.isValid)(e)&&(e.value=Object.freeze(e.value)),e);return(0,c.isAsync)(t)?t.then(e=>r(e)):r(t)}unwrap(){return this._def.innerType}}function ev(e,t){let r="function"==typeof e?e(t):"string"==typeof e?{message:e}:e;return"string"==typeof r?{message:r}:r}function ex(e,t={},r){return e?U.create().superRefine((n,o)=>{let a=e(n);if(a instanceof Promise)return a.then(e=>{if(!e){let e=ev(t,n),a=e.fatal??r??!0;o.addIssue({code:"custom",...e,fatal:a})}});if(!a){let e=ev(t,n),a=e.fatal??r??!0;o.addIssue({code:"custom",...e,fatal:a})}}):U.create()}t.ZodReadonly=eg,eg.create=(e,t)=>new eg({innerType:e,typeName:n.ZodReadonly,...p(t)}),t.late={object:H.lazycreate},(o=n||(t.ZodFirstPartyTypeKind=n={})).ZodString="ZodString",o.ZodNumber="ZodNumber",o.ZodNaN="ZodNaN",o.ZodBigInt="ZodBigInt",o.ZodBoolean="ZodBoolean",o.ZodDate="ZodDate",o.ZodSymbol="ZodSymbol",o.ZodUndefined="ZodUndefined",o.ZodNull="ZodNull",o.ZodAny="ZodAny",o.ZodUnknown="ZodUnknown",o.ZodNever="ZodNever",o.ZodVoid="ZodVoid",o.ZodArray="ZodArray",o.ZodObject="ZodObject",o.ZodUnion="ZodUnion",o.ZodDiscriminatedUnion="ZodDiscriminatedUnion",o.ZodIntersection="ZodIntersection",o.ZodTuple="ZodTuple",o.ZodRecord="ZodRecord",o.ZodMap="ZodMap",o.ZodSet="ZodSet",o.ZodFunction="ZodFunction",o.ZodLazy="ZodLazy",o.ZodLiteral="ZodLiteral",o.ZodEnum="ZodEnum",o.ZodEffects="ZodEffects",o.ZodNativeEnum="ZodNativeEnum",o.ZodOptional="ZodOptional",o.ZodNullable="ZodNullable",o.ZodDefault="ZodDefault",o.ZodCatch="ZodCatch",o.ZodPromise="ZodPromise",o.ZodBranded="ZodBranded",o.ZodPipeline="ZodPipeline",o.ZodReadonly="ZodReadonly",t.instanceof=(e,t={message:`Input not instance of ${e.name}`})=>ex(t=>t instanceof e,t);let ey=P.create;t.string=ey;let eb=L.create;t.number=eb,t.nan=ep.create,t.bigint=O.create;let ew=M.create;t.boolean=ew,t.date=A.create,t.symbol=D.create,t.undefined=F.create,t.null=$.create,t.any=U.create,t.unknown=Z.create,t.never=q.create,t.void=B.create,t.array=V.create,t.object=H.create,t.strictObject=H.strictCreate,t.union=W.create,t.discriminatedUnion=K.create,t.intersection=Y.create,t.tuple=X.create,t.record=Q.create,t.map=J.create,t.set=ee.create,t.function=et.create,t.lazy=er.create,t.literal=en.create,t.enum=ea.create,t.nativeEnum=ei.create,t.promise=es.create;let e_=el.create;t.effect=e_,t.transformer=e_,t.optional=ec.create,t.nullable=eu.create,t.preprocess=el.createWithPreprocess,t.pipeline=em.create,t.ostring=()=>ey().optional(),t.onumber=()=>eb().optional(),t.oboolean=()=>ew().optional(),t.coerce={string:e=>P.create({...e,coerce:!0}),number:e=>L.create({...e,coerce:!0}),boolean:e=>M.create({...e,coerce:!0}),bigint:e=>O.create({...e,coerce:!0}),date:e=>A.create({...e,coerce:!0})},t.NEVER=c.INVALID}},r={};function n(e){var o=r[e];if(void 0!==o)return o.exports;var a=r[e]={exports:{}},i=!0;try{t[e].call(a.exports,a,a.exports,n),i=!1}finally{i&&delete r[e]}return a.exports}n.ab="//",e.exports=n(247)})()}},__webpack_module_cache__={};function __webpack_require__(e){var t=__webpack_module_cache__[e];if(void 0!==t)return t.exports;var r=__webpack_module_cache__[e]={id:e,exports:{}};return __webpack_modules__[e](r,r.exports,__webpack_require__),r.exports}__webpack_require__.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return __webpack_require__.d(t,{a:t}),t},(()=>{var e,t=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__;__webpack_require__.t=function(r,n){if(1&n&&(r=this(r)),8&n||"object"==typeof r&&r&&(4&n&&r.__esModule||16&n&&"function"==typeof r.then))return r;var o=Object.create(null);__webpack_require__.r(o);var a={};e=e||[null,t({}),t([]),t(t)];for(var i=2&n&&r;("object"==typeof i||"function"==typeof i)&&!~e.indexOf(i);i=t(i))Object.getOwnPropertyNames(i).forEach(e=>{a[e]=()=>r[e]});return a.default=()=>r,__webpack_require__.d(o,a),o}})(),__webpack_require__.d=(e,t)=>{for(var r in t)__webpack_require__.o(t,r)&&!__webpack_require__.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},__webpack_require__.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),__webpack_require__.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},__webpack_require__.nc=void 0;var __webpack_exports__={};for(var __rspack_i in(()=>{"use strict";__webpack_require__.r(__webpack_exports__),__webpack_require__.d(__webpack_exports__,{DevOverlayContext:()=>e.pj,dispatcher:()=>e.oh,getSegmentTrieData:()=>e.ac,getSerializedOverlayState:()=>e.qs,getSerializedRuntimeErrorState:()=>e.iw,renderAppDevOverlay:()=>e.Z8,renderPagesDevOverlay:()=>e.yl,subscribeToRuntimeErrorState:()=>e.hu,useDevOverlayContext:()=>e.OS});var e=__webpack_require__("./src/next-devtools/dev-overlay.browser.tsx")})(),exports.DevOverlayContext=__webpack_exports__.DevOverlayContext,exports.dispatcher=__webpack_exports__.dispatcher,exports.getSegmentTrieData=__webpack_exports__.getSegmentTrieData,exports.getSerializedOverlayState=__webpack_exports__.getSerializedOverlayState,exports.getSerializedRuntimeErrorState=__webpack_exports__.getSerializedRuntimeErrorState,exports.renderAppDevOverlay=__webpack_exports__.renderAppDevOverlay,exports.renderPagesDevOverlay=__webpack_exports__.renderPagesDevOverlay,exports.subscribeToRuntimeErrorState=__webpack_exports__.subscribeToRuntimeErrorState,exports.useDevOverlayContext=__webpack_exports__.useDevOverlayContext,__webpack_exports__)-1===["DevOverlayContext","dispatcher","getSegmentTrieData","getSerializedOverlayState","getSerializedRuntimeErrorState","renderAppDevOverlay","renderPagesDevOverlay","subscribeToRuntimeErrorState","useDevOverlayContext"].indexOf(__rspack_i)&&(exports[__rspack_i]=__webpack_exports__[__rspack_i]);Object.defineProperty(exports,"__esModule",{value:!0});
//# sourceMappingURL=index.js.map
})();
}),
]);

//# sourceMappingURL=node_modules_next_dist_compiled_next-devtools_index_090k2jmam7qwg.js.map