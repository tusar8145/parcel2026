(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_dist_20wefz_f1k6jn._.js","static/chunks/apps_web_src_shared_LegacyScripts_tsx_1xje4_1ofuu9v._.js"],
    source: "entry"
});
